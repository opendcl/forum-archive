(princ "\ncommand: gridtest sample for checkbox, layer, color, textstyle, lineweight, linetype ")

(defun c:gridtest ( / gridcontrol column_styles row )
  (or LoadRunTime (load "_OpenDclUtils.lsp") 
    (exit)
  )
  (LoadRunTime)
  (dcl_Project_Load "gridtest.odcl" T)

  (dcl_FORM_SHOW Form1)
  (setq gridcontrol Form1_Grid1)
  
  (dcl_Grid_Clear gridcontrol)
    
;; something like (dcl_get_columtypes)
;;                          ck ly  col tsty      lwt     lty
  (setq column_styles (list 1  27  30  21        32      33))
  
  (setq row                 "0;0;256;standard;bylayer;bylayer")
  (dcl_Grid_AddString gridcontrol row ";")
  
  (setq row                 "1;lay2;0;standard;bylayer;bylayer")
  (dcl_Grid_AddString gridcontrol row ";")
  
  (setq row                 "1;;;standard;bylayer;bylayer")
  (dcl_Grid_AddString gridcontrol row ";")
  
  (setq row                 "1; ; ;standard;bylayer;bylayer")
  (dcl_Grid_AddString gridcontrol row ";")
  
  (set_checkboxes_from_data gridcontrol column_styles)


) ;; (c:grid_test ( / gridcontrol column_styles row ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun set_checkboxes_from_data ( gridcontrol column_styles / 
              column_style 
              ncol nrow
              column_cell column_cells
            )
  (setq ncol 0)
  (foreach column_style column_styles
    (cond
      ((= column_style 1)
        (setq column_cells (dcl_Grid_GetColumnCells gridcontrol ncol))
        (setq nrow 0)
        (foreach column_cell column_cells
          (setq column_cell (vl-string-trim " \n\r\t" (strcase column_cell)))
          (cond
            ((wcmatch column_cell "0,OFF,")
              (dcl_Grid_SetCellCheckState gridcontrol nrow ncol 0)
              (dcl_Grid_SetCellText gridcontrol nrow ncol "OFF")
            )
            ((wcmatch column_cell "1,ON")
              (dcl_Grid_SetCellCheckState gridcontrol nrow ncol 1)
              (dcl_Grid_SetCellText gridcontrol nrow ncol "ON")
            )
          )
          (setq nrow (1+ nrow))
        )
      )
    )
    (setq ncol (1+ ncol))
  )

) ;; (defun set_checkboxes_from_data ( column_styles / column_style ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun c:Form1_Grid1_OnButtonClicked (Row Column /)
 (dcl_MessageBox "To Do: code must be added to event handler\r\nc:Form1_Grid1_OnButtonClicked" "To do")
  (cond
    ((not setq cstyle (dcl_Grid_GetCellStyle Form1_Grid1 Row Column)))
    ((not (setq cstate (dcl_Grid_GetCellCheckState Form1_Grid1 Row Column))))
    ((= 0 cstate)
      (dcl_Grid_SetCellText Form1_Grid1 Row Column "Off")
    )
    ((= 1 cstate)
      (dcl_Grid_SetCellText Form1_Grid1 Row Column "On")
    )
  )
) ;; (defun c:Form1_Grid1_OnButtonClicked (Row Column /))

(princ)