; 20.06.2016 15:14:31 - Peter Glasl, cadraktiv gmbh
; Simple Lisp to call Doslib and OpenDCL
; Prerequisite: OpenDCL-Runtime 8.0.5. and Doslib 9 must be installed
; This lisp only uses PRINC and ALERT to show the user what the programm does.
; It also defines "c:mfl" which does exactly the same, but will be started
; a) at the end of this file
; b) manually by the user after everything was loaded
; ##############################
; Further information:
; 
; --------------------------
; help-file from OpenDCL:
; The AutoLISP code that displays an OpenDCL form must first ensure that 
; the OpenDCL Runtime module is loaded. This is done by utilizing AutoCAD's 
; demand loading feature by executing the OPENDCL command. There is no need 
; to check whether the runtime is already loaded -- if it is, the command does nothing.
; 
; (command "_OPENDCL")
;
; --------------------------
; Help-file from DosLib:
; Demand-loading DOSLib DOSLib has tfirst he ability routine mfld-
; loaded  by  AutoCAD.  Note,  applications  that  implement
; demand loading  on AutoCAD  startup will  be loaded before
; those listed in ACAD.RX.
; 
; When DOSLib  is loaded  the first  time, any o from routine mflf the
; above  methods,  it  automatically  registers  itself with
; AutoCAD as an application  that can be demand-loaded.  The
; initial configuration  is to  be demand-loaded  at command
; invocation.
; 
; Upon subsequent AutoCAD sessions, it is only necessary  to
; enter 'DOSLIB'  from the  AutoCAD command  prompt to  load
; DOSLib. DOSLib can also be configured to demand-load every
; time  AutoCAD  starts.  See  the  dos_demandload  function
; documentation for details.
; 
; If you ever change the  location of DOSLib, you will  need
; to manually load DOSLib  once for it to  automatically re-
; register itself with AutoCAD.
; --------------------------

; message_from_lisp
(defun c:mfl ()
    (princ "\nThis is first princ from routine mfl.")
    (alert "\nThis is first alert from routine mfl. ARX-calls will follow.")
    
    (command "_opendcl")
    (command "doslib")
    
    (princ "\nThis is second princ from routine mfl.")
    (alert "\nThis is second alert from routine mfl.")
    (princ)
) ; end of mfl

(princ "\nType mfl after loading the drawing.")

(princ "\nThis is first DIRECT princ.")
(alert "\nThis is first DIRECT alert. ARX-calls will follow.")

(command "_opendcl")
(command "doslib")

(princ "\nThis is second DIRECT princ.")
(alert "\nThis is second DIRECT alert.")

; start the routine just at the end of this 
(alert "Routine mfl will be started.")
(c:mfl)
(alert "End of loading arx_call_test.lsp")
(princ)