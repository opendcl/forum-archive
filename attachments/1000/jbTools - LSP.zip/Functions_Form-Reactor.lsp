;;;								;
;;;		kbTools OpenDCL Forms Reactor			;
;;;								;

;;;								;
;;;		Command Reactors				;
;;;								;

;;;		Support Functions				;
;;;		Only used by Routines in this File		;

;;;		Call-back Functions				;

;;;		Command Ended					;
(defun kb:OpenDCLCommandEnded (calling-reactor commands /)
  (cond	((member (car commands)
		 (list "-BLOCK"	"BLOCK"	"PURGE"	"-PURGE" "RENAME" "-RENAME" "INSERT" "-INSERT"
		       )
		 )
	 (if dcl_HideErrorMsgBox
	   (progn (if (dcl_Form_IsActive Blocks_BlockManager)
		    (c:Blocks_BlockManager_OnDocActivated)
		    )
		  )
	   )
	 )
	((member (car commands) (list "XREF" "XATTACH" "-XREF"))
	 (if dcl_HideErrorMsgBox
	   (progn (if (dcl_Form_IsActive Palette_Main)
		    (kb:LayerStates_OnInitialize)
		    )
		  )
	   )
	 )
	)
  (princ)
  )

;;;		Command Cancelled					;
(defun kb:OpenDCLCommandCancelled (calling-reactor commands /) (princ))


;;;		Construct the Command Reactor				;
(defun kb::ConstructOpenDCLCommandReactor (/)
  (if (= (type *kbOpenDCLCommandReactor*) 'VLR-Command-Reactor)
    (progn (vlr-remove *kbOpenDCLCommandReactor*)
	   (setq *kbOpenDCLCommandReactor* nil)
	   )
    )
  (if (/= (type *kbOpenDCLCommandReactor*) 'VLR-Command-Reactor)
    (setq *kbOpenDCLCommandReactor*
	   (VLR-Command-Reactor
	     "kbTools OpenDCL Forms Reactor" ; Data associated with the editor reactor
	     ;; call backs
	     '
	      ((:VLR-commandEnded . kb:OpenDCLCommandEnded)
	       (:VLR-commandCancelled . kb:OpenDCLCommandCancelled)
	       )
	     ) ;_ end of vlr-editor-reactor
	  )
    )
  (if (not (vlr-added-p *kbOpenDCLCommandReactor*))
    (progn (vlr-add *kbOpenDCLCommandReactor*)
	   (vlr-set-notification *kbOpenDCLCommandReactor* 'active-document-only)
	   )
    ) ;added 09.26.2003
  (princ)
  )




;;;				load reactors				;


(if kb::ConstructOpenDCLCommandReactor
  (kb::ConstructOpenDCLCommandReactor)
  )

;;;pgp: kbRemoveOpenDCLReactor,		*kbRemoveOpenDCLReactor
(defun c:kbRemoveOpenDCLReactor	()
  (progn (vlr-remove *kbOpenDCLCommandReactor*)
	 (setq *kbOpenDCLCommandReactor* nil)
	 )
  (prompt "OpenDCL Reactor removed!")
  (princ)
  )



 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
