;PANGROUPS
; An library to manage OpenDCL floating forms at runtime by grouping.

; Latest Release: 1.0.0.1

; For any inquiries, contact:  kevin@klecknerassociates.com

; Copyright 2009 Kevin A. Douglas

;;; Permission to use, copy, modify, and distribute this
;;; software for any purpose and without fee is hereby
;;; granted, provided that the above copyright notice
;;; appears in all copies and that both that copyright
;;; notice and the limited warranty and restricted
;;; rights notice below appear in all supporting
;;; documentation.

;;; KEVIN A. DOUGLAS PROVIDES THIS PROGRAM "AS IS" AND WITH
;;; ALL FAULTS. KEVIN A. DOUGLAS SPECIFICALLY DISCLAIMS ANY
;;; IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A
;;; PARTICULAR USE.
;;; KEVIN A. DOUGLAS DOES NOT WARRANT THAT THE OPERATION OF
;;; THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.



;=============================================================================================================================================================================



; Release 1.0.0.1 Notes:
; 1.  Currently, PANGROUPS is based on a no allow resize basis.  I hope to impliment this in a future release.
; 2.  I am aware that there are some bugs and I am trying hard to fix, but please send me an email so I can
;     track and apply fixes: kevin@klecknerassociates.com
; 3.  When I use the words Panel and Form they are both the same thing.
; 4.  There are a few global variables.  In the future releases I hope to eliminate them.
; 5.  Sorry for the mess.  Next release will be more readable with better notation.
; 6.  Below is a text diagram depiction of the "Magnet Pairs" (CM = The corners of each form; # = The connection combination)
;     If you take a look at $:Get_MagPair and interpret it, you may understand this diagram a little better.  This diagram is
;     the reason this "panel stacking" method actually works.


                                  ;;;;;;;;;;;;;;;;;;;;;;;;
                                  ; 10  11          0  1 ;
                                  ; 9 CM            CM 2 ;
                                  ;         Panel        ;
                                  ; 8 CM            CM 3 ;
                                  ; 7   6           5  4 ;
                                  ;;;;;;;;;;;;;;;;;;;;;;;;



;=============================================================================================================================================================================



;;; Naming Conventions
;global prefix = @
;;; @: = global function
;local prefix = $
;;; $: = local function
;parameter prefix = %

;str = string
;int = integer
;rel = real
;sym = symbol
;lst = list
;bol = booleen



;=============================================================================================================================================================================



;Loading/Closing



;Load OpenDCL ARX files
(vl-load-com)
(command "OPENDCL")
;FUNCTION DESCRIPTION: Convert String to Symbol
(defun $:stos (%str) (eval (read %str)))
;FUNCTION DESCRIPTION: FUNCTION DESCRIPTION: Returns the evaluated list 
(defun $:Trim_List (%lst %cnt) (if (or (zerop %cnt) (not %lst)) nil (cons (car %lst) ($:Trim_List (cdr %lst) (1- %cnt)))))



;FUNCTION DESCRIPTION: Load Project
(defun c:PanGroups (/)
  (dcl_Project_Load "PanGroups" T)
  (dcl_Form_Show PanGroups_Controller)
  )
;FUNCTION DESCRIPTION: Close Project
(defun c:PanGroups_Controller_Close_OnClicked (/) ($:CloseForms) (setq @lstPanGrps nil))
;FUNCTION DESCRIPTION: Close All Open Forms
(defun $:CloseForms (/ $lstForms)
  (setq $lstForms (dcl_Project_GetForms "PanGroups"))
  (while $lstForms
    (if (dcl_Form_IsActive (car $lstForms))
      (dcl_Form_Close (car $lstForms))
      )
    (setq $lstForms (vl-remove (car $lstForms) $lstForms))
    )
  )



;=============================================================================================================================================================================



;;; Form Pinning / Rolling



;FUNCTION DESCRIPTION: Sets the state of the form.
;
;;SYNTAX: ($:Set_FormState <%strProject> <%strForm> <%strControl> <%strState> <%strCaption>)
(defun @:Set_FormState (%strProject %strForm %strControl
			/
			$symForm $symControl $strProjForm $lstPanGroup $lstLinGroup $lstNewFrmSize
			$lstMinFrmSize $lstMaxFrmSize $symCurForm $lstNewPos $lstLTAdj $intMagSeqLen)
  ; set locals
  (setq $symForm ($:stos (strcat %strProject "_" %strForm))
	$symControl ($:stos (strcat %strProject "_" %strForm "_" %strControl))
	; get min and max sizes of the form
	$lstMinFrmSize (list (dcl_Control_GetMinWidth $symForm) (dcl_Control_GetMinHeight $symForm))
	$lstMaxFrmSize (list (dcl_Control_GetMaxWidth $symForm) (dcl_Control_GetMaxHeight $symForm))
	; if @lstPanGrps exists, check if %strForm is a child of an existing panel group
	$lstPanGroup ($:Get_PanGroup %strForm)
	; if %strForm is a child of a panel group, then get the linear group
	$lstLinGroup (cond
		       ((member %strForm (assoc "Parent" $lstPanGroup))
			($:Get_Children $lstPanGroup 0)
			)
		       ((assoc %strForm ($:Get_Children $lstPanGroup 0))
			($:Get_LinearGrp $lstPanGroup (if (assoc %strForm ($:Get_Children $lstPanGroup 0))
							(cadr (assoc %strForm ($:Get_Children $lstPanGroup 0)))
							(cadr (car ($:Get_Children $lstPanGroup 0)))))
			)
		       (nil)
		       ))
  ; roll on state
  (if (= (dcl_Control_GetPicture $symControl) 101)
    (progn
      (dcl_Control_SetPicture $symControl 100)
      (dcl_Control_SetMouseOverPicture $symControl 101)
      (dcl_Control_SetFontBold $symControl nil)
      (setq $lstLTAdj (list (- (car $lstMinFrmSize) (car $lstMaxFrmSize)) (- (cadr $lstMinFrmSize) (cadr $lstMaxFrmSize))))
      ($:Roll_Panel %strProject %strForm $lstMinFrmSize)
      )
    (progn
      (dcl_Control_SetPicture $symControl 101)
      (dcl_Control_SetMouseOverPicture $symControl 100)
      (dcl_Control_SetFontBold $symControl T)
      (setq $lstLTAdj (list (- (car $lstMaxFrmSize) (car $lstMinFrmSize)) (- (cadr $lstMaxFrmSize) (cadr $lstMinFrmSize))))
      ($:Roll_Panel %strProject %strForm $lstMaxFrmSize)
      (dcl_Control_SetFocus $symForm)))
  ; if form belongs to a group and %strForm is not the oldest child, then move older children on roll
  (if (and $lstLinGroup $lstLTAdj)
    (progn
      ; get the length of the magnet sequence for %strForm
      (setq $intMagSeqLen (if (assoc %strForm $lstLinGroup) (length (cadr (car $lstLinGroup))) (1- (length (cadr (car $lstLinGroup))))))
      ; make exception if %strForm is a parent or if %strForm has only one sibling
      (if (and (assoc %strForm ($:Get_Children $lstPanGroup 0)) (= (length (cadr (car $lstLinGroup))) 1)) (setq $lstLinGroup (vl-remove (car $lstLinGroup) $lstLinGroup)))
      ; loop while $lstPanGroup does not equal nil
      (while (null (not $lstLinGroup))
	(setq $symCurForm ($:stos (strcat %strProject "_" (car (car $lstLinGroup))))
	      $intMagPair (nth $intMagSeqLen (cadr (car $lstLinGroup)))
	      $lstNewPos (list (if (member $intMagPair '(0 1 2 3 4 5)) (+ (car (dcl_Control_GetPos $symCurForm)) (car $lstLTAdj)) (car (dcl_Control_GetPos $symCurForm)))
			       (if (member $intMagPair '(3 4 5 6 7 8)) (+ (cadr (dcl_Control_GetPos $symCurForm)) (cadr $lstLTAdj)) (cadr (dcl_Control_GetPos $symCurForm)))))
	(dcl_Control_SetPos $symCurForm (car $lstNewPos) (cadr $lstNewPos))
	(setq $lstLinGroup (vl-remove (car $lstLinGroup) $lstLinGroup))
	)
      )
    )
  )
;FUNCTION DESCRIPTION: Rolls Panels accordingly.
;
;;SYNTAX: ($:Roll_Panel <%strProjForm> <%intOrgHt>))
(defun $:Roll_Panel (%strProject %strForm %lstNewSize / $strProjForm $symForm $lstMags)
  (setq $symForm ($:stos (setq $strProjForm (strcat %strProject "_" %strForm)))
	$lstMags (mapcar (function (lambda (x / y) (setq y ($:stos (strcat $strProjForm x)))
				     (list y (list (- (car %lstNewSize) (dcl_Control_GetWidth y))
						   (- (cadr %lstNewSize) (dcl_Control_GetHeight y)))))) '("_TRMag" "_BLMag" "_BRMag")))
  (dcl_Form_Resize $symForm (car %lstNewSize) (cadr %lstNewSize))
  (while $lstMags
    (dcl_Control_SetPos (car (car $lstMags))
      (if (/= (length $lstMags) 2) (car (cadr (car $lstMags))) (car (dcl_Control_GetPos (car (car $lstMags)))))
      (if (= (length $lstMags) 3) (cadr (dcl_Control_GetPos (car (car $lstMags)))) (cadr (cadr (car $lstMags)))))
    (setq $lstMags (vl-remove (car $lstMags) $lstMags))
    )
  )


;=============================================================================================================================================================================



;;; Panel Stacking



;FUNCTION DESCRIPTION: Returns the panel group %strConForm belongs
;
;;SYNTAX: ($:Get_PanGroup %strConForm)
(defun $:Get_PanGroup (%strConForm / $lstTmpGroup $lstPanGroup)
  (setq $lstTmpGroup @lstPanGrps)
  (while (and (null $lstPanGroup) (not (null $lstTmpGroup)))
    (if (or (member %strConForm (assoc "Parent" (car $lstTmpGroup)))
	    (assoc %strConForm (cdr (assoc "Children" (car $lstTmpGroup)))))
      (setq $lstPanGroup (car $lstTmpGroup))
      (setq $lstTmpGroup (vl-remove (car $lstTmpGroup) $lstTmpGroup))
      )
    )
  $lstPanGroup
  )
;FUNCTION DESCRIPTION: Returns the linear connection in a panel group
;
;;SYNTAX: ($:Get_LinearGrp %lstPanGroup %lstMagPrefix)
(defun $:Get_LinearGrp (%lstPanGroup %lstMagPrefix / $lstChildren $lstNewLinGrp)
  (setq $lstChildren (cdr (assoc "Children" %lstPanGroup))
	$lstNewLinGrp (vl-sort
			(vl-remove nil (mapcar (function (lambda (x) (if (equal ($:Trim_List (cadr x) (length %lstMagPrefix)) %lstMagPrefix) x))) $lstChildren))
			(function (lambda (a b) (< (length (cadr a)) (length (cadr b)))))
			))
  (if (= (length %lstMagPrefix) 1)
    $lstNewLinGrp
    (cdr $lstNewLinGrp)
    )
  )
;FUNCTION DESCRIPTION: Returns the new linear connection of a panel group
;
;;SYNTAX: ($:Get_NewLinGrp %lstMagPrefix %lstLinearGrp)
(defun $:Get_NewLinGrp (%lstMagPrefix %lstLinearGrp /)
  (if (= (length %lstMagPrefix) 1)
    (mapcar (function (lambda (x) (list (car x) (append %lstMagPrefix (cadr x))))) %lstLinearGrp)
    (mapcar (function (lambda (x)
	     (list (car x)
		   (append %lstMagPrefix (reverse ($:Trim_List (reverse (cadr x)) (1+ (- (length (cadr x)) (length (cadr (car %lstLinearGrp)))))))))))
      %lstLinearGrp)
    )
  )
;FUNCTION DESCRIPTION: Returns the number of the magnet pair
;
;;SYNTAX: ($:Get_MagPair %strConCtrl %strMovCtrl)
;($:Get_MagPair "TRMag" "TLMag")
(defun $:Get_MagPair (%strConCtrl %strMovCtrl /)
  (cadr (assoc (strcat %strConCtrl %strMovCtrl)
  '(("TRMagBRMag" 0)("TRMagBLMag" 1)("TRMagTLMag" 2)("BRMagBLMag" 3)("BRMagTLMag" 4)("BRMagTRMag" 5)
    ("BLMagTLMag" 6)("BLMagTRMag" 7)("BLMagBRMag" 8)("TLMagTRMag" 9)("TLMagBRMag" 10)("TLMagBLMag" 11))))
  )
;FUNCTION DESCRIPTION: Returns the new left and top position of the panel
;
;; SYNTAX: ($:Get_FormCoords %strConCtrl %strMovCtrl %lstConFormPos %lstMovFormPos)
(defun $:Get_FormCoords (%strConCtrl %strMovCtrl %lstConFormPos %lstMovFormPos %intMagPair / $lstCoords $intMagPair)
  (setq $lstCoords (list (nth 0 %lstConFormPos);0 = Left of parent form
			 (nth 1 %lstConFormPos);1 = Top of parent form
			 (- (nth 0 %lstConFormPos) (nth 2 %lstMovFormPos));2 = Left of parent form less width of child form
			 (- (nth 1 %lstConFormPos) (nth 3 %lstMovFormPos));3 = Top of parent form less height of child form
			 (+ (nth 0 %lstConFormPos) (nth 2 %lstConFormPos));4 = Sum of left of parent form and width of parent form
			 (+ (nth 1 %lstConFormPos) (nth 3 %lstConFormPos));5 = Sum of top of parent form and height of parent form
			 (+ (nth 0 %lstConFormPos) (- (nth 2 %lstConFormPos) (nth 2 %lstMovFormPos)));6 = Sum of left of parent form and the difference of parent form width and child form width.
			 (+ (nth 1 %lstConFormPos) (- (nth 3 %lstConFormPos) (nth 3 %lstMovFormPos))));7 = Sum of top of parent form and the difference of parent form height and child form height
	$intMagPair (if (= (type %intMagPair) 'INT) (list %intMagPair) (list ($:Get_MagPair %strConCtrl %strMovCtrl))))
  (cdr (assoc $intMagPair
	      (list (list '(0) (nth 6 $lstCoords) (nth 3 $lstCoords))
		    (list '(1) (nth 4 $lstCoords) (nth 3 $lstCoords))
		    (list '(2) (nth 4 $lstCoords) (nth 1 $lstCoords))
		    (list '(3) (nth 4 $lstCoords) (nth 7 $lstCoords))
		    (list '(4) (nth 4 $lstCoords) (nth 5 $lstCoords))
		    (list '(5) (nth 6 $lstCoords) (nth 5 $lstCoords))
		    (list '(6) (nth 0 $lstCoords) (nth 5 $lstCoords))
		    (list '(7) (nth 2 $lstCoords) (nth 5 $lstCoords))
		    (list '(8) (nth 2 $lstCoords) (nth 7 $lstCoords))
		    (list '(9) (nth 2 $lstCoords) (nth 1 $lstCoords))
		    (list '(10) (nth 2 $lstCoords) (nth 3 $lstCoords))
		    (list '(11) (nth 0 $lstCoords) (nth 3 $lstCoords)))))
  )
;FUNCTION DESCRIPTION: Magnetizes %strMovForm to %strConForm.
;
;; SYNTAX: ($:Magnetize %strProject %strMovForm %strMovCtrl %strConForm %strConCtrl)
(defun @:Magnetize (%strProject %strMovForm %strMovCtrl %strConForm %strConCtrl
		    /
		    $symMovForm $symConForm $symMovCtrl $symConCtrl $lstConFormPos $lstMovFormPos $lstNewPos)
  (setq $symMovForm ($:stos (strcat %strProject "_" %strMovForm))
	$symMovCtrl ($:stos (strcat %strProject "_" %strMovForm "_" %strMovCtrl))
	$symConForm ($:stos (strcat %strProject "_" %strConForm))
	$symConCtrl ($:stos (strcat %strProject "_" %strConForm "_" %strConCtrl))
	$lstMovFormPos (dcl_Control_GetPos $symMovForm)
	$lstConFormPos (dcl_Control_GetPos $symConForm)
	$lstNewPos ($:Get_FormCoords %strConCtrl %strMovCtrl $lstConFormPos $lstMovFormPos (list nil)))
  (if $lstNewPos
    (progn
      (dcl_Control_SetPos $symMovForm (car $lstNewPos) (cadr $lstNewPos))
      ($:Add_Child %strProject %strConForm %strMovForm %strConCtrl %strMovCtrl $symConCtrl $symMovCtrl $lstMovFormPos)
      )
    (dcl_MessageBox "Magnetizing the selected corners is not possible." "Error: Improper Selection" 2 4)
    )
  )
;FUNCTION DESCRIPTION: Returns an association list of children
;
;; SYNTAX: ($:Get_Children %lstPanGroup %ynReverse)
(defun $:Get_Children (%lstPanGroup %ynReverse /)
  (if (= %ynReverse 1)
    (mapcar (function (lambda (x) (reverse x))) (cdr (assoc "Children" %lstPanGroup)))
    (cdr (assoc "Children" %lstPanGroup))
    )
  )
;FUNCTION DESCRIPTION: Move magnetized forms
;
;;SYNTAX: ($:Move_Child %strProject %strMovForm %strConForm %intMagPair)
(defun $:Move_Child (%strProject %strMovForm %strConForm %intMagPair / $symMovForm $symConForm $symMovCtrl $symConCtrl $lstConFormPos $lstMovFormPos $lstNewPos)
  (setq $symMovForm ($:stos (strcat %strProject "_" %strMovForm))
	$symConForm ($:stos (strcat %strProject "_" %strConForm))
	$lstMovFormPos (dcl_Control_GetPos $symMovForm)
	$lstConFormPos (dcl_Control_GetPos $symConForm)
	$lstNewPos ($:Get_FormCoords "" "" $lstConFormPos $lstMovFormPos %intMagPair))
  (if $lstNewPos
    (dcl_Control_SetPos $symMovForm (car $lstNewPos) (cadr $lstNewPos))
    (dcl_MessageBox "Something is wrong." "Error: Improper syntax" 2 4)
    )
  )
;FUNCTION DESCRIPTION: Adds a child form to a parent form.
;
;; SYNTAX: ($:Add_Child %strConForm %strMovForm %strConCtrl %strMovCtrl)
(defun $:Add_Child (%strProject %strConForm %strMovForm %strConCtrl %strMovCtrl %symConCtrl %symMovCtrl %lstMovFormPos / $lstPanGroup $intMagPair $lstMovForm $strMovForm $strConForm $lstNewLinGrp $lstNewPanGrp $lstNewGroup $symMovCtrl $lstRemGroup $lstForGroup)
  (setq $lstPanGroup ($:Get_PanGroup %strConForm)
	$lstForGroup ($:Get_PanGroup %strMovForm)
	$intMagPair ($:Get_MagPair %strConCtrl %strMovCtrl)
	$lstMovForm (list %strMovForm (list $intMagPair))
	$symMovCtrl ($:stos (strcat %strProject "_" %strMovForm "_" %strConCtrl)))
  (cond
    ;if no panel groups existing, create @lstPanGrps
    ((or (null @lstPanGrps)(null $lstPanGroup))
     (setq $lstNewGroup (list (list "Parent" %strConForm)(list "Children" $lstMovForm))
	   @lstPanGrps (if (null $lstPanGroup) (reverse (cons $lstNewGroup (reverse @lstPanGrps))) (list $lstNewGroup)))
     )
    ;if @lstPanGrps exists and %strMovForm is a parent of an existing panel group
    ((setq $lstRemGroup (car (vl-remove nil (mapcar '(lambda (x) (if (= %strMovForm (cadr (assoc "Parent" x))) x)) @lstPanGrps))))
     (setq @lstPanGrps (vl-remove $lstRemGroup @lstPanGrps))
     (if (member %strConForm (assoc "Parent" $lstPanGroup))
       (progn
	 (if (assoc (list $intMagPair) ($:Get_Children $lstPanGroup 1))
	   (setq $lstNewLinGrp ($:Get_NewLinGrp (list $intMagPair) ($:Get_LinearGrp $lstPanGroup (list $intMagPair))))
	   (setq @lstPanGrps (subst (cons (assoc "Parent" $lstPanGroup) (list (reverse (cons $lstMovForm (reverse (assoc "Children" $lstPanGroup)))))) $lstPanGroup @lstPanGrps))
	   )
	 )
       (progn
	 (setq $lstMovForm (list %strMovForm (append (cadr (assoc %strConForm ($:Get_Children $lstPanGroup 0))) (list $intMagPair))))
	 (if (reverse (car (assoc (cadr $lstMovForm) ($:Get_Children $lstPanGroup 1))))
	   (setq $lstNewLinGrp ($:Get_NewLinGrp (cadr $lstMovForm) ($:Get_LinearGrp $lstPanGroup (cadr $lstMovForm))))
	   (setq @lstPanGrps (subst (cons (assoc "Parent" $lstPanGroup) (list (reverse (cons $lstMovForm (reverse (assoc "Children" $lstPanGroup)))))) $lstPanGroup @lstPanGrps))
	   )
	 )
       )
     )
    ;if @lstPanGrps exists and %strMovForm is a child of an existing panel group
    ((assoc %strMovForm ($:Get_Children $lstPanGroup 0))
     (if (member %strConForm (assoc "Parent" $lstPanGroup))
       (progn
	 (setq $lstCurMagHold (reverse (assoc (list $intMagPair) ($:Get_Children $lstPanGroup 1)))
	       ;update Previous Magnet Pair holder
	       $lstNewMagHold (list (car $lstCurMagHold) (cadr (assoc %strMovForm ($:Get_Children $lstPanGroup 0))))
	       $lstNewPanGrp (subst (cons "Children" (subst $lstNewMagHold $lstCurMagHold ($:Get_Children $lstPanGroup 0))) (assoc "Children" $lstPanGroup) $lstPanGroup)
	       ;update MovForm Magnet Pair
	       $lstNewPanGrp (subst (cons "Children" (subst $lstMovForm (assoc %strMovForm ($:Get_Children $lstNewPanGrp 0)) ($:Get_Children $lstNewPanGrp 0))) (assoc "Children" $lstNewPanGrp) $lstNewPanGrp)
	       ;update @lstPanGrps with new panel group
	       @lstPanGrps (subst $lstNewPanGrp $lstPanGroup @lstPanGrps))
	 ;move current magnet pair holder
	 (dcl_Control_SetPos ($:stos (strcat %strProject "_" (cadr (assoc (list $intMagPair) ($:Get_Children $lstPanGroup 1))))) (car %lstMovFormPos) (cadr %lstMovFormPos))
	 )
       (progn
	 (setq $lstCurMagHold (reverse (assoc (append (cadr (assoc %strConForm ($:Get_Children $lstPanGroup 0))) (list $intMagPair)) ($:Get_Children $lstPanGroup 1)))
	       ;update Previous Magnet Pair holder
	       $lstNewMagHold (list (car $lstCurMagHold) (cadr (assoc %strMovForm ($:Get_Children $lstPanGroup 0))))
	       $lstNewPanGrp (subst (cons "Children" (subst $lstNewMagHold $lstCurMagHold ($:Get_Children $lstPanGroup 0))) (assoc "Children" $lstPanGroup) $lstPanGroup)
	       ;update MovForm Magnet Pair
	       $lstMovForm (list %strMovForm (append (cadr (assoc %strConForm ($:Get_Children $lstPanGroup 0))) (list $intMagPair)))
	       $lstNewPanGrp (subst (cons "Children" (subst $lstMovForm (assoc %strMovForm ($:Get_Children $lstNewPanGrp 0)) ($:Get_Children $lstNewPanGrp 0))) (assoc "Children" $lstNewPanGrp) $lstNewPanGrp)
	       ;update @lstPanGrps with new panel group
	       @lstPanGrps (subst $lstNewPanGrp $lstPanGroup @lstPanGrps))
	 ;move current magnet pair holder
	 (dcl_Control_SetPos ($:stos (strcat %strProject "_" (car $lstCurMagHold))) (car %lstMovFormPos) (cadr %lstMovFormPos))
	 )
       )
     ;update @lstPanGrps
     )
    ;if @lstPanGrps exists and %strConForm is a parent of an existing panel group
    ((member %strConForm (assoc "Parent" $lstPanGroup))
     (if (assoc (list $intMagPair) ($:Get_Children $lstPanGroup 1))
       (setq $lstNewLinGrp ($:Get_NewLinGrp (list $intMagPair) ($:Get_LinearGrp $lstPanGroup (list $intMagPair))))
       (setq @lstPanGrps (subst (cons (assoc "Parent" $lstPanGroup) (list (reverse (cons $lstMovForm (reverse (assoc "Children" $lstPanGroup)))))) $lstPanGroup @lstPanGrps))
       )
     )
    ;if @lstPanGrps exists and %strConForm is a child of an existing panel group
    ((assoc %strConForm (cdr (assoc "Children" $lstPanGroup)))
     (setq $lstMovForm (list %strMovForm (append (cadr (assoc %strConForm ($:Get_Children $lstPanGroup 0))) (list $intMagPair))))
     (if (reverse (car (assoc (cadr $lstMovForm) ($:Get_Children $lstPanGroup 1))))
       (setq $lstNewLinGrp ($:Get_NewLinGrp (cadr $lstMovForm) ($:Get_LinearGrp $lstPanGroup (cadr $lstMovForm))))
       (setq @lstPanGrps (subst (cons (assoc "Parent" $lstPanGroup) (list (reverse (cons $lstMovForm (reverse (assoc "Children" $lstPanGroup)))))) $lstPanGroup @lstPanGrps))
       )
     ))
  ;;;end conditions
  
  ;if a child adopted or relocated, start shoving them around
  (if $lstNewLinGrp
    (progn
      ;set locals for shoving
      (setq $strConForm %strMovForm
	    $strMovForm (nth 0 (car $lstNewLinGrp))
	    $intMagPair (last (nth 1 (car $lstNewLinGrp)))
	    $lstNewPanGrp $lstPanGroup)
      ;loop while there are children to be shoved around
      (while (not (null $lstNewLinGrp))
	($:Move_Child %strProject $strMovForm $strConForm $intMagPair)
	(setq $lstNewPanGrp (cons
			      (assoc "Parent" $lstNewPanGrp)
			      (list (subst (car $lstNewLinGrp) (assoc $strMovForm ($:Get_Children $lstNewPanGrp 0)) (assoc "Children" $lstNewPanGrp))))
	      $strConForm $strMovForm
	      $lstNewLinGrp (vl-remove (car $lstNewLinGrp) $lstNewLinGrp))
	(if $lstNewLinGrp (setq $strMovForm (nth 0 (car $lstNewLinGrp)) $intMagPair (last (nth 1 (car $lstNewLinGrp)))))
	)
      ;recompile the panel groups with the newly adapted panel group
      (setq @lstPanGrps (subst $lstNewPanGrp $lstPanGroup @lstPanGrps)
	    @lstPanGrps (subst (cons (assoc "Parent" $lstNewPanGrp) (list (append (assoc "Children" $lstNewPanGrp) (list $lstMovForm)))) $lstNewPanGrp @lstPanGrps)))
    )
  (if $lstForGroup
    (setq @lstPanGrps (subst (subst (vl-remove (assoc %strMovForm ($:Get_Children $lstForGroup 0)) (assoc "Children" $lstForGroup)) (assoc "Children" $lstForGroup) $lstForGroup) $lstForGroup @lstPanGrps)
	  $lstForGroup (subst (vl-remove (assoc %strMovForm ($:Get_Children $lstForGroup 0)) (assoc "Children" $lstForGroup)) (assoc "Children" $lstForGroup) $lstForGroup))
    )
  ;handle empty nesters
  (if (= (length (assoc "Children" $lstForGroup)) 1) (setq @lstPanGrps (vl-remove $lstForGroup @lstPanGrps))
    )
  )



;============================================================================================================================================================================



;;; Panel Group Moving



;FUNCTION DESCRIPTION: Moves Panel Groups
;
;;SYNTAX: (@:Move_PanGroup %strProject %strForm)
(defun @:Move_PanGroup (%strProject %strForm
			/
			$symForm $lstPanGroup $lstChildren $bolParent $lstMagPair $lstChild $symChild $symParent $lstCldLoc $lstCldSiz $lstAdjLoc $lstTemp $intLen)
  (setq $symForm ($:stos (strcat %strProject "_" %strForm));get the symbol for the moved form
	$lstPanGroup ($:Get_PanGroup %strForm));get the panel group it belongs to
  ;if $lstPanGroup exists, continue
  (if $lstPanGroup
    (progn
      (setq $lstChildren (setq $lstTemp ($:Get_Children $lstPanGroup 0))
	    $bolParent (if (member %strForm (assoc "Parent" $lstPanGroup)) T nil))
      (if $bolParent
	;if %strForm is a Parent
	(progn
	  (while (> (length (setq $lstMagPair (cadr (setq $lstChild (car $lstTemp))))) 1)
	    (setq $lstTemp (vl-remove (car $lstTemp) $lstTemp))
	    )
	  (setq $symChild ($:stos (strcat %strProject "_" (car $lstChild)))
		$lstAdjLoc ($:Get_AdjLoc $lstMagPair $symForm $symChild)
		$lstTemp (mapcar 'car $lstChildren))
	  )
	;if %strForm is a Child
	(progn
	  ;  %strProject    %strForm    $symForm    $lstPanGroup    $lstChildren    $bolParent    $lstCurLoc    $lstCurSiz
	  ;
	  (if (= (length (setq $lstMagPair (cadr (assoc %strForm $lstChildren)))) 1)
	    ;if the child has a magnet combination list length of 1, then use the parent location to determine $lstAdjLoc
	    (progn
	      (setq $symParent ($:stos (strcat %strProject "_" (cadr (assoc "Parent" $lstPanGroup))))
		    $lstAdjLoc ($:Get_AdjLoc ($:Get_AdjMagPair $lstMagPair) $symForm $symParent)
		    $lstTemp (vl-remove nil (cons (cadr (assoc "Parent" $lstPanGroup)) (mapcar 'car (vl-remove (assoc %strForm $lstChildren) $lstChildren)))))
	      )
	    ;if the child has a magnet combination list length of 1<, then use the sibling with a list length 1- of the magnet combination
	    (progn
	      (setq $intLen (1- (length (cadr (assoc %strForm $lstChildren)))))
	      (while (/= (length (setq $lstMagPair (cadr (setq $lstChild (car $lstTemp))))) $intLen)
		(setq $lstTemp (vl-remove (car $lstTemp) $lstTemp))
		)
	      (setq $symChild ($:stos (strcat %strProject "_" (car $lstChild)))
		    $lstAdjLoc ($:Get_AdjLoc ($:Get_AdjMagPair $lstMagPair) $symForm $symChild)
		    $lstTemp (cons (cadr (assoc "Parent" $lstPanGroup)) (mapcar 'car (vl-remove (assoc %strForm $lstChildren) $lstChildren))))
	      )
	    )
	  )
	)
      (while $lstTemp
	(setq $symChild ($:stos (strcat %strProject "_" (car $lstTemp)))
	      $lstCldLoc (reverse (cddr (reverse (dcl_Control_GetPos $symChild)))))
	(dcl_Control_SetPos $symChild (+ (car $lstCldLoc) (car $lstAdjLoc)) (+ (cadr $lstCldLoc) (cadr $lstAdjLoc)))
	(setq $lstTemp (vl-remove (car $lstTemp) $lstTemp))
	)
      )
    )
  )
;FUNCTION DESCRIPTION: Returns the appropriate magnet pair for moving panel groups by the children
;
;;SYNTAX: ($:Get_AdjMagPair %intMagPair)
(defun $:Get_AdjMagPair (%lstMagPair /)
  (vl-remove (last %lstMagPair) (assoc (last %lstMagPair) '((0 5)(1 7)(2 9)(3 8)(4 10)(5 0)(6 11)(7 1)(8 3)(9 2)(10 4)(11 6))))
  )
;FUNCTION DESCRIPTION: Returns the previous location of the moved family member based on the magnet combination
;
;;SYNTAX: ($:Get_AdjLoc %lstMagCom %lstCldLoc)
(defun $:Get_AdjLoc (%lstMagPair %symForm %symChild / $lstFormPos $lstChildPos $lstCoords)
  (setq $lstFormPos (dcl_Control_GetPos %symForm)
	$lstChildPos (dcl_Control_GetPos %symChild)
	$lstCoords (list (nth 0 $lstFormPos);0 = Left of parent form
			 (nth 1 $lstFormPos);1 = Top of parent form
			 (- (nth 0 $lstFormPos) (nth 2 $lstChildPos));2 = Left of parent form less width of child form
			 (- (nth 1 $lstFormPos) (nth 3 $lstChildPos));3 = Top of parent form less height of child form
			 (+ (nth 0 $lstFormPos) (nth 2 $lstFormPos));4 = Sum of left of parent form and width of parent form
			 (+ (nth 1 $lstFormPos) (nth 3 $lstFormPos));5 = Sum of top of parent form and height of parent form
			 (+ (nth 0 $lstFormPos) (- (nth 2 $lstFormPos) (nth 2 $lstChildPos)));6 = Sum of left of parent form and the difference of parent form width and child form width.
			 (+ (nth 1 $lstFormPos) (- (nth 3 $lstFormPos) (nth 3 $lstChildPos))));7 = Sum of top of parent form and the difference of parent form height and child form height
	$lstCoords (cdr (assoc %lstMagPair
			       (list (list '(0) (nth 6 $lstCoords) (nth 3 $lstCoords))
				     (list '(1) (nth 4 $lstCoords) (nth 3 $lstCoords))
				     (list '(2) (nth 4 $lstCoords) (nth 1 $lstCoords))
				     (list '(3) (nth 4 $lstCoords) (nth 7 $lstCoords))
				     (list '(4) (nth 4 $lstCoords) (nth 5 $lstCoords))
				     (list '(5) (nth 6 $lstCoords) (nth 5 $lstCoords))
				     (list '(6) (nth 0 $lstCoords) (nth 5 $lstCoords))
				     (list '(7) (nth 2 $lstCoords) (nth 5 $lstCoords))
				     (list '(8) (nth 2 $lstCoords) (nth 7 $lstCoords))
				     (list '(9) (nth 2 $lstCoords) (nth 1 $lstCoords))
				     (list '(10) (nth 2 $lstCoords) (nth 3 $lstCoords))
				     (list '(11) (nth 0 $lstCoords) (nth 3 $lstCoords))))))
  (list (- (nth 0 $lstCoords) (nth 0 $lstChildPos)) (- (nth 1 $lstCoords) (nth 1 $lstChildPos)))
  )




;============================================================================================================================================================================



;;; Corner Magnets



(defun c:PanGroups_Controller_BLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Controller" "BLMag"))
(defun c:PanGroups_Controller_BRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Controller" "BRMag"))
(defun c:PanGroups_Controller_TLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Controller" "TLMag"))
(defun c:PanGroups_Controller_TRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Controller" "TRMag"))

;============================================================================================================================================================================



;;; Panel Toggling


;FUNCTION DESCRIPTION: Toggles panels
;
;;SYNTAX: ($:Tog_Panel %symPanel)
(defun $:Tog_Panel (%symPanel /)
  (if (null (dcl_Form_IsActive %symPanel)) (progn (dcl_Form_Show %symPanel) (dcl_Form_Center %symPanel)) (dcl_Form_Close %symPanel))
  )
;panel toggles
(defun c:PanGroups_Controller_Panel1_OnClicked (/) ($:Tog_Panel PanGroups_Panel1))
(defun c:PanGroups_Controller_Panel2_OnClicked (/) ($:Tog_Panel PanGroups_Panel2))
(defun c:PanGroups_Controller_Panel3_OnClicked (/) ($:Tog_Panel PanGroups_Panel3))
(defun c:PanGroups_Controller_Panel4_OnClicked (/) ($:Tog_Panel PanGroups_Panel4))
;Mouse Enter/Exit Buttons
(defun c:PanGroups_Controller_Panel1_OnMouseEntered (/) (dcl_Control_SetPicture PanGroups_Controller_Panel1 103))
(defun c:PanGroups_Controller_Panel1_OnMouseMovedOff (/) (dcl_Control_SetPicture PanGroups_Controller_Panel1 102))
(defun c:PanGroups_Controller_Panel2_OnMouseEntered (/) (dcl_Control_SetPicture PanGroups_Controller_Panel2 105))
(defun c:PanGroups_Controller_Panel2_OnMouseMovedOff (/) (dcl_Control_SetPicture PanGroups_Controller_Panel2 104))
(defun c:PanGroups_Controller_Panel3_OnMouseEntered (/) (dcl_Control_SetPicture PanGroups_Controller_Panel3 103))
(defun c:PanGroups_Controller_Panel3_OnMouseMovedOff (/) (dcl_Control_SetPicture PanGroups_Controller_Panel3 102))
(defun c:PanGroups_Controller_Panel4_OnMouseEntered (/) (dcl_Control_SetPicture PanGroups_Controller_Panel4 105))
(defun c:PanGroups_Controller_Panel4_OnMouseMovedOff (/) (dcl_Control_SetPicture PanGroups_Controller_Panel4 104))
;Paint Text on Buttons
(defun @:Paint_Text (%symCtrl %lstDWText %lstPaintPic /)
  (dcl_PictureBox_DrawWrappedText %symCtrl %lstDWText) (dcl_PictureBox_PaintPicture %symCtrl %lstPaintPic)
  )
(defun c:PanGroups_Controller_Panel1_OnPaint (HasFocus /)
  (@:Paint_Text PanGroups_Controller_Panel1 (list (list 3 3 40 -15 -24 "Panel1" 2)) (list (list 196 8 102 T T))))
(defun c:PanGroups_Controller_Panel2_OnPaint (HasFocus /)
  (@:Paint_Text PanGroups_Controller_Panel2 (list (list 0 3 40 -15 -24 "Panel2" 2)) (list (list 196 8 102 T T))))
(defun c:PanGroups_Controller_Panel3_OnPaint (HasFocus /)
  (@:Paint_Text PanGroups_Controller_Panel3 (list (list 3 3 40 -15 -24 "Panel3" 2)) (list (list 196 8 102 T T))))
(defun c:PanGroups_Controller_Panel4_OnPaint (HasFocus /)
  (@:Paint_Text PanGroups_Controller_Panel4 (list (list 0 3 40 -15 -24 "Panel4" 2)) (list (list 196 8 102 T T))))
;Roll down / Roll up
(defun c:PanGroups_Controller_Roll_OnClicked (/) (@:Set_FormState "PanGroups" "Controller" "Roll"))
;Move Panel Group
(defun c:PanGroups_Controller_OnMouseMovedOff (/) (@:Move_PanGroup "PanGroups" "Controller"))

