

;;	test OpenDCL for compiling in separate vlx namespace

;;	For loading put VLXNS.odcl in ACAD support path,

;;	Appload VLXNS.vlx

;;;	by Slavko Ivanovic, slavko.ivanovich@gmail.com

;;||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
;; Import dcl_*** functions from doc to VLX.
;; For calling BEFORE calling dcl_Project_Load or dcl_Project_Import.
;; OpenDCL.arx must be loaded in Acad previously, of course.
(DEFUN si-vlx-Import-OpenDCL (/ ~pa)
   (OR DCL_GETVERSION
       (VL-ARX-IMPORT
          (STRCAT "OpenDCL"
                  (IF (AND (SETQ ~pa (GETENV "PROCESSOR_ARCHITECTURE"))
                           (< 1 (STRLEN ~pa))
                           (EQ "64" (SUBSTR ~pa (1- (STRLEN ~pa))))
                      )
                     ".x64."
                     "."
                  )
                  (SUBSTR (GETVAR "acadver") 1 2)
                  ".arx"
          )
       )
   )
)

;;||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
;; Clone assigned symbol references for all Forms in given project, from Doc to Vlx.
;; For calling BEFORE calling dcl_form_show func.
;; Argument @prn = project name as STRING 
(DEFUN si-vlx-Import-Forms (@prn / ~r)
   (MAPCAR '(LAMBDA (@sym) (SET @sym (VL-DOC-REF @sym)))
           (MAPCAR 'READ
                   (MAPCAR '(LAMBDA (@f) (STRCAT @prn "_" (DCL_CONTROL_GETPROPERTY @f "(Name)")))
                           (DCL_PROJECT_GETFORMS @prn)
                   )
           )
   )
)
;;||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
;; Clone assigned symbol references for all Controls in given Form, from Doc to Vlx.
;; For calling INSIDE _OnInitialize - first thing to call.
;; Arguments @prj = project name as STRING  |  @fn = Form name as STRING
(DEFUN si-vlx-Import-Controls (@prn @fn)
   (SETQ @fn (STRCAT @prn "_" @fn))
   (MAPCAR '(LAMBDA (@sym) (SET @sym (VL-DOC-REF @sym)))
           (MAPCAR 'READ
                   (MAPCAR '(LAMBDA (@cn) (STRCAT @fn "_" @cn))
                           (MAPCAR '(LAMBDA (@c) (DCL_CONTROL_GETPROPERTY @c "(Name)"))
                                   (DCL_FORM_GETCONTROLS (VL-SYMBOL-VALUE (READ @fn)))
                           )
                   )
           )
   )
)


;;||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
;;||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
;; TEST FUNKCIJA :
(DEFUN c:vlxns (/ ~prj)
   ;;
   ;;
   ;;load event functions
   (SETQ
      ~evf (LIST ;;Form1 initialization
                 (DEFUN c:VLXNS_Form1_OnInitialize (/)
                    (si-vlx-Import-Controls ~prj "Form1")
                                           ;***** 3. si-vlx-Import-Controls IN ONINITIALIZE function *****
                 )
                 ;;Form2 initialization
                 (DEFUN c:VLXNS_Form2_OnInitialize (/)
                    (DCL_MESSAGEBOX
                       "Form2 Form Dont Have (si-vlx-Import-Controls) in _OnInitialize func."
                       "Initialization of Form2"
                       2
                       2
                    )
                 )
                 ;; Form1 buttons
                 (DEFUN c:VLXNS_Form1_TextButton1_OnClicked (/ ~p ~w)
                    (SETQ ~p (DCL_CONTROL_GETPOS VLXNS_Form1_TextButton1))
                    (OR (AND (= (CAR ~p) 24) (SETQ ~w 184)) (SETQ ~w 24))
                    (DCL_CONTROL_SETPOS VLXNS_Form1_TextButton1 ~w (CADR ~p) (CADR (REVERSE ~p)) (CAR (REVERSE ~p)))
                 )
                 (DEFUN c:VLXNS_Form1_TextButton2_OnClicked (/) (PRINC))
                 ;; Form2 buttons
                 (DEFUN c:VLXNS_Form2_TextButton1_OnClicked (/ ~p ~w)
                    (SETQ ~p (DCL_CONTROL_GETPOS VLXNS_Form2_TextButton1))
                    (OR (AND (= (CAR ~p) 184) (SETQ ~w 24)) (SETQ ~w 184))
                    (DCL_CONTROL_SETPOS VLXNS_Form2_TextButton1 ~w (CADR ~p) (CADR (REVERSE ~p)) (CAR (REVERSE ~p)))
                 )
                 (DEFUN c:VLXNS_Form2_TextButton2_OnClicked (/)
                    (si-vlx-Import-Controls "VLXNS" "Form2")
                    (DCL_CONTROL_SETCAPTION VLXNS_Form2_TextButton1 "Click Me Again Now.")
                    (PRINC)
                 )
           )
   )
   ;;event functions loaded
   ;;
   ;;
   ;;main start
   (si-vlx-Import-OpenDCL)                 ;***** si-vlx-Import-OpenDCL 1. BEFORE LOADING *****
   (SETQ ~prj (DCL_PROJECT_LOAD (FINDFILE "VLXNS.odcl") T))
   (si-vlx-Import-Forms ~prj)              ;***** si-vlx-Import-Forms 2. BEFORE SHOWING *****
   (DCL_FORM_SHOW VLXNS_form1)
   (DCL_FORM_SHOW VLXNS_form2)
   ;;main end
   ;;
   ;;
   (MAPCAR '(LAMBDA (x) (SET x nil)) (CONS '~evf ~evf)) ; kill events
   (PRINC)
)
;;||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
(prompt "\n* Type VLXNS for test.")
;;||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

;|�Visual LISP� Format Options�
(120 3 43 2 nil "-->" 100 6 2 0 0 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
