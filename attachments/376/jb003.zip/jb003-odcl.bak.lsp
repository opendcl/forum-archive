;;;							;
;;;	jbBlock Tools v2.0					;
;;;	include files:					;
;;;		jbCommonFunctions			;
;;;		jbCommonLayerFunctions			;
;;;							;


;;;							;
;;;	OpenDCL Subs					;
;;;							;

;;;	Propogate Form Controls				;

(defun jb:ImportBlocksPopulate	(local /)
  (dcl_BlockView_Clear jb003_00_BlockView)
  (if local
    (progn (dcl_Control_SetEnabled jb003_00_Swap 1)
	   (dcl_Control_SetEnabled jb003_00_ImportBlocks 0)
	   (dcl_Control_SetEnabled jb003_00_InsertBlock 1)
	   (dcl_Control_SetPicture jb003_00_Document 108)
	   (dcl_Control_SetEnabled jb003_00_Document 1)
	   (dcl_Control_SetEnabled jb003_00_Xref 1)
	   (dcl_Control_SetCaption jb003_00_PATH "")
	   (dcl_Control_SetCaption jb003_00_PATH (getvar "dwgname"))
	   (setq blocklist (jb:ListBlocks))
	   (dcl_ListBox_Clear jb003_00_BlockList)
	   (dcl_ListBox_AddList jb003_00_BlockList blocklist))
    (progn (dcl_Control_SetEnabled jb003_00_Swap 0)
	   (dcl_Control_SetEnabled jb003_00_ImportBlocks 1)
	   (dcl_Control_SetEnabled jb003_00_InsertBlock 0)
	   (dcl_Control_SetPicture jb003_00_Document 107)
	   (dcl_Control_SetEnabled jb003_00_Document 0)
	   (dcl_Control_SetEnabled jb003_00_Xref 0)
	   (dcl_Control_SetCaption jb003_00_PATH "")
	   (dcl_Control_SetCaption jb003_00_PATH jb%importblockdwg)
	   (setq blocklist (jb:ReturnDBXBlocks jb%importblockdwg))
	   (dcl_ListBox_Clear jb003_00_BlockList)
	   (dcl_ListBox_AddList jb003_00_BlockList blocklist)))
  (princ)
  (princ))

(defun c:jb003_00_count_OnClicked ( /)
     (dcl_SetCmdBarFocus)
  (vla-sendcommand(vla-get-activedocument(vlax-get-acad-object))"jbCountBlock ")
  (princ)
)


(defun c:jb003_00_Open_OnClicked  (/)
  (if (setq jb%importblockdwg
	     (getfiled
	       "Select a drawing"
	       (strcat (jb:ReturnProjectDir) "\\")
	       "dwg;dws;dwt"
	       0))
    (progn (dcl_Control_SetEnabled jb003_00_Swap 0)
	   (dcl_Control_SetEnabled jb003_00_ImportBlocks 1)
	   (dcl_Control_SetEnabled jb003_00_InsertBlock 0)
	   (dcl_BlockView_Clear jb003_00_BlockView)
	   (dcl_Control_SetPicture jb003_00_Document 107)
	   (setq blocklist (jb:ReturnDBXBlocks jb%importblockdwg))
	   (dcl_Control_SetCaption jb003_00_Path jb%importblockdwg)
	   (dcl_ListBox_Clear jb003_00_BlockList)
	   (dcl_ListBox_AddList jb003_00_BlockList blocklist)))
  (princ)
  (princ))

(defun c:jb003_00_ImportBlocks_OnClicked  (/)
  (Setq rValue (dcl_ListBox_GetSelecteditems jb003_00_BlockList))
  (if rValue
    (progn (jb:ImportBlocks jb%importblockdwg rValue)
	   (dcl_ListBox_SelItemRange
	     jb003_00_BlockList
	     0
	     (dcl_ListBox_GetCount jb003_00_BlockList)
	     0))
    (alert "Select some blocks!"))
  (princ)
  (princ))

(defun c:jb003_00_InsertBlock_OnClicked	 (/ blk rValue) ;(alert "insert")
  (Setq rValue (dcl_ListBox_GetSelectedNths jb003_00_BlockList))
  (if (eq (length rValue) 1)
    (progn (setvar "cmdecho" 1)
	   (setq blk (dcl_ListBox_GetText jb003_00_BlockList (car rValue)))
	   (command "insert" blk)))
  (princ)
  (princ))

(defun c:jb003_00_Swap_OnClicked  (/ rValue)
  (Setq	rValue (dcl_ListBox_GetText
		 jb003_00_BlockList
		 (dcl_ListBox_GetCurSel jb003_00_BlockList)))
  (if rValue
    (progn (dcl_SetCmdBarFocus) (jb:Swap rValue)))
  (princ)
  (princ))


(defun c:jb003_00_FindBlock_OnClicked  (/ sel)
  (setq sel (dcl_ListBox_GetSelectedNths jb003_00_BlockList))
  (cond	((= (length sel) 1)
	 (jb:findblock
	   (dcl_Listbox_GetText
	     jb003_00_BlockList
	     (dcl_ListBox_GetCurSel jb003_00_BlockList))))
	((> (length sel) 1) (alert "Select only one Block please!"))
	(t (alert "Select a Block please!")))
  (princ)
  (princ))


(defun c:jb003_00_AllowExplode_OnClicked  (/ sel blkname)
  (setq sel (dcl_ListBox_GetSelectedNths jb003_00_BlockList))
  (cond	((= (length sel) 1)
	 (setq blkname
		(dcl_Listbox_GetText
		  jb003_00_BlockList
		  (dcl_ListBox_GetCurSel jb003_00_BlockList)))
	 (vla-put-explodable
	   (vla-item
	     (vla-get-blocks (vla-get-activedocument (vlax-get-acad-object)))
	     blkname)
	   :vlax-true)
	 (princ "\nYou can explode that block now!"))
	((> (length sel) 1) (alert "Select only one Block please!"))
	(t (alert "Select a Block please!")))
  (princ)
  (princ))



(defun c:jb003_00_Document_OnClicked  (/)
  (setq curDoc (dcl_Control_GetCaption jb003_00_PATH)) ;toggle
  (if (= curDoc (getvar "dwgname"))
    (jb:ImportBlocksPopulate nil)
    (jb:ImportBlocksPopulate t))
  (princ)
  (princ))



(defun c:jb003_00_BlockList_OnSelChanged  (nSelection sSelText /)
  (setq curDoc (dcl_Control_GetCaption jb003_00_PATH))
  (if (/= curDoc (getvar "dwgname"))
    (dcl_BlockView_PreLoadDwg jb003_00_BlockView curDoc))
  (Setq rValue (dcl_ListBox_GetSelectedNths jb003_00_BlockList))
  (if (= (length rvalue) 1)
    (progn (setq blk (dcl_ListBox_GetText jb003_00_BlockList (car rValue)))
	   (dcl_BlockView_DisplayBlock jb003_00_BlockView blk 0 1.0))
    (dcl_BlockView_Clear jb003_00_BlockView))
  (princ)
  (princ))

(defun c:jb003_00_Comment_OnClicked  (/)
  (dcl_MessageBox "This feature is not yet supported - sorry" "To do")
  (princ)
  (princ))

(defun c:jb003_00_Xref_OnClicked  (/ caption blocklist)
  (Setq caption (dcl_Control_GetPicture jb003_00_Xref))
  (if (= caption 102)
    (progn (setq blocklist (jb:ListBlocks))
	   (dcl_Control_SetPicture jb003_00_Xref 109)
	   (dcl_Control_SetToolTipMainText jb003_00_Xref "Show Xrefs")
	   (dcl_ListBox_Clear jb003_00_BlockList)
	   (dcl_ListBox_AddList jb003_00_BlockList blocklist))
    (progn (setq blocklist (jb:ListXrefs))
	   (dcl_Control_SetPicture jb003_00_Xref 102)
	   (dcl_Control_SetToolTipMainText jb003_00_Xref "Show Blocks")
	   (dcl_ListBox_Clear jb003_00_BlockList)
	   (dcl_ListBox_AddList jb003_00_BlockList blocklist)))
  (princ)
  (princ))

(defun c:jb003_00_OnInitialize	(/)
  (if jb%importblockdwg
    (jb:ImportBlocksPopulate nil)
    (jb:ImportBlocksPopulate t))
  (princ)
  (princ))

(defun c:jb003_00_OnClose  (nUpperLeftX nUpperLeftY /)
  (vl-bb-set 'jbBlockFloating "false")
  (dcl_form_close jb003_00)
  (princ)
  (princ))


(defun c:jb003_00_OnEnteringNoDocState	(/)
  (if (dcl_Form_IsActive jb003_00)
    (progn (vl-bb-set 'jbBlockFloating "true") (dcl_form_close jb003_00)))
  (princ)
  (princ))

(defun c:jb003_00_OnDocActivated  (/)
  (if (dcl_Form_IsActive jb003_00)
    (c:jb003_00_OnInitialize))
  (princ)
  (princ))


(defun c:jb003_00_Refresh_OnClicked  (/)
  (c:jb003_00_OnInitialize)
  (princ)
  (princ))


;;;							;
;;;	Command Interface				;
;;;							;

(defun c:jbBlockManager	 (/)
  (if (not (member "jb003" (dcl_GetProjects)))
    (dcl_Project_load "jb003"))
  (if dcl_HideErrorMsgBox
    (progn (if (not (dcl_Form_IsActive jb003_00))
	     (dcl_Form_Show jb003_00)))
    (alert "The OpenDCL arx module did not load!"))
  (princ)
  (princ))


;;;							;
;;;		Floating Form				;
;;;		Document Opened				;
;;;							;

(defun jb:003_IsFloating  (/)
  (if dcl_HideErrorMsgBox
    (progn (if (dcl_Form_IsActive jb003_00)
	     (c:jb003_00_OnDocActivated)))
    (alert "The OpenDCL arx module did not load!"))
  (princ)
  (princ))


(jb:003_IsFloating)

(if (= (vl-bb-ref 'jbBlockFloating) "true")
  (c:jbBlockManager))


(princ "\n003 - jbTools Block Manager loaded!")
(princ)
;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
