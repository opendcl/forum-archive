;;;							;
;;;		File Name dictionary			;
;;;							;
;(kb:ReturnKeynoteFilename)
(defun kb:ReturnKeynoteFilename	(/)
  (setq kb%KeyFile (findfile (strcat (kb:returnprojectdir) "\\Project.key")))
  (if (not kb%KeyFile)
    (setq kb%KeyFile(findfile "Project.key"))
    )
  kb%KeyFile
)



;;;								;
;;;		Dynamic Keynotes				;
;;;								;
(defun kb:getKeyNoteFileForSyncing (file / ofile key note inilst ret)
  (prompt
    (strcat "\nOpening " (vl-filename-base file) ", please wait . . .")
  )
  (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx)))
  ) ;_ eofwhile
  (close ofile)
  (foreach
	 i
	  inilst
    (if	(and i (/= i "") (/= (VL-STRING-POSITION (ascii "*") i) 0))
      (progn (setq key	(substr i 1 (vl-string-position (ascii "\t") i))
		   note	(substr i (+ 2 (vl-string-position (ascii "\t") i)))
	     )
	     (setq ret (append ret (list (cons key note))))
      )
    )
  )
  ret
)
;;;		Keynotes are linked to the .key file.		;
;;;		When the key file is edited or a drawing	;
;;;		is opened containing keynotes the user		;
;;;		will be prompted to update keynotes.		;
;;;		A command will also be available to update	;
;;;		keynotes "kbSyncKeynotes".			;
;;;								;
;(setq i(vlax-ename->vla-object(car(entsel))))
(defun kb:SyncKeynoteFiletoDrawing  (/ file data key oldnote newnote keytype xdata ent)
  (princ "\nSyncing Keynote File, please wait . . ..")
  (setq file (kb:ReturnKeynoteFilename))
  (if file
    (progn
      (setq data (kb:getKeyNoteFileForSyncing file))
      (vlax-for
	     i	(kb:getactivespace)
	(setq ent   (vlax-vla-object->ename i)
	      xdata (kb:getKeyNotexdata ent))
	(if (nth 2 xdata)
	  (progn (setq nscale  (nth 3 xdata)
		       keyType (nth 2 xdata)
		       oldnote (nth 1 xdata)
		       key     (nth 0 xdata)
		       newnote (cdr (assoc key data)))
	    ;if there is no new note then the key doesn't exist in the file
	    (if newnote
		 (cond
		   ((= keyType "KEYLEADER")
		    (if	(not(eq oldnote newnote))
		      (progn (vla-put-textstring i key)
			     (vlax-put i "color" acbylayer)
			     (kb:putKeyNotexdata ent key newnote "KEYLEADER" nscale)
			)
		      (vla-put-textstring i key)
		      ))
		   ((= keyType "NOTELEADER")
		    (if	(not(eq oldnote newnote))
		      (progn (vla-put-textstring i newnote)
			     (vlax-put i "color" acbylayer)
			     (kb:putKeyNotexdata ent key newnote "NOTELEADER" nscale)
			)
		      (vla-put-textstring i newnote)
		      ))
		   ((= keyType "MTEXT")
		    (if	(not(eq oldnote newnote))
		      (progn (vla-put-textstring i newnote)
			     (vlax-put i "color" acbylayer)
			     (kb:putKeyNotexdata ent key newnote "MTEXT" nscale)
			)
		      (vla-put-textstring i newnote)
		      ))
		   )

	      ;no new note - key no longer exists.
	      (cond
		   ((= keyType "KEYLEADER")
			     (vlax-put i "color" acred)
		    (kb:putKeyNotexdata ent "" "" "KEYLEADER" "")
			     )
		   ((= keyType "NOTELEADER")
			     (vlax-put i "color" acred)
		    (kb:putKeyNotexdata ent "" "" "NOTELEADER" "")
		    )
		   ((= keyType "MTEXT")
			     (vlax-put i "color" acred)
		   (kb:putKeyNotexdata ent "" "" "MTEXT" "")
		    )
		   ((= keyType "KEYNOTELEGEND")
		    (vlax-put i "color" 165)
		    )
		   )
	      
	      )
	    )
	  )
	)
      )
    )
  )
  
;;;Automatically sync file when routine is loaded
(if kb:SyncKeynoteFiletoDrawing
        (kb:SyncKeynoteFiletoDrawing))