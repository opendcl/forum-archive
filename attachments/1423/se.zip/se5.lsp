(dcl_project_load "softengine5" T)
(dcl_form_show Softengine5_se5)
(dcl_PictureBox_LoadPictureFile Softengine5_se5_window "c:\\teste.bmp" T)