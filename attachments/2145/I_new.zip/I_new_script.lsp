(defun C:Iii ()
  (setvar "SDI" 0) ; Turn on multiple document interface.
  (command "OPENDCL")
  (dcl-Project-Load "I_new")
  (dcl-Form-Show I_new/Main)
  (princ)
)

(defun c:I_new/Main/DrawingsListBox#OnDblClicked ( / docObj fptr path scr)
  (setq path (car (dcl-ListBox-GetSelectedItems I_new/Main/DrawingsListBox)))
  (setq path (strcat (getvar 'dwgprefix) path ".dwg"))
  (print "Start")
  (cond
    ((= (strcase path) (strcase (strcat (getvar 'dwgprefix) (getvar 'dwgname))))
      (print "a")
      nil
    )
    (
      (setq docObj
        (vl-some
          '(lambda (obj) (if (= (strcase path) (strcase (vla-get-fullname obj))) obj))
          (vle-collection->list (vla-get-documents (vlax-get-acad-object)))
        )
      )
      (print "b")
      (vla-activate docObj)
    )
    (T
      (print "c")
      (setq scr (vl-filename-mktemp ".scr"))
      (if (setq fptr (open scr "w"))
        (progn
          (write-line
            (strcat
              "(progn"
              "\n  (vl-file-delete " (vl-prin1-to-string scr) ")" ; The script deletes itself.
              "\n  (setvar 'cmdecho 1)" ; Reset cmdecho in 'calling' dwg.
              "\n  (princ)"
              "\n)"
              "\n_.OPEN " path
            )
            fptr
          )
          (close fptr)
          (setvar 'cmdecho 0)
          (print "c1")
          (dcl-SendString (strcat "_.script " scr "\n"))
          (print "c2")
        )
      )
    )
  )
  (print "End")
)

(defun c:I_new/Main/DrawingsRefresh#OnClicked ( / lst)
  (setq lst
    (vl-sort
      (mapcar
        'vl-filename-base
        (vl-directory-files (strcat (getvar "dwgprefix"))  "*.dwg")
      )
      '<
    )
  )
  (dcl-ListBox-Clear I_new/Main/DrawingsListBox)
  (dcl-ListBox-AddList I_new/Main/DrawingsListBox lst)
)

(princ "\nIII Loaded ")
(princ)