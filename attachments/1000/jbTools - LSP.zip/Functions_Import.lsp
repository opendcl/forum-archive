;;;							;
;;;							;
;;;	Common Import Functions				;
;;;							;
;;;							;

;;;							;
;;;	Drawing Opened?					;
;;;	This Routine is used when a Form Accesses 	;
;;;	Information via ObjectDBX to ensure the form	;
;;;	isn't trying to reference the active drawing!	;
;;;							;

    ;(setq refDwg(kb:ReturnProjectAECStylesStandardsFile))
(defun kb:IsDwgOpened (refDwg / ret)
  (setq ret (findfile
              (strcat (vl-filename-directory refDwg)
                      (chr 92)
                      (vl-filename-base refDwg)
                      ".dwl"
                      )
              )
        )
  ret
  )

;;; ObjectDBX functions
;;;
;;;

(if (< (atoi (getvar "AcadVer")) 16)
  (cond ((vl-registry-read "HKEY_CLASSES_ROOT\\ObjectDBX.AxDbDocument\\CLSID"))
        ((not (setq dbxserver (findfile "AxDb15.dll")))
         (alert "Error: Can't locate ObjectDBX Library (AxDb15.dll)")
         )
        (t
         (startapp "regsvr32.exe" (strcat "/s \"" dbxserver "\""))
         (or (vl-registry-read "HKEY_CLASSES_ROOT\\ObjectDBX.AxDbDocument\\CLSID")
             (alert "Error: Failed to register ObjectDBX ActiveX services.")
             )
         )
        )
  )

;;;(setq dwgname(findfile "AecLayerStd.dwg"))
;;; 		Open a dbxDoc						;
;;; 		use (setq dbxDocument(kb:OpenDbxDocument dwgname)) ;
(defun kb:OpenDbxDocument (DwgName / app doc dbxopen dbxDoc)
  (setq app (vlax-get-acad-object)
        doc (vla-get-ActiveDocument app)
        )
  (if (/= dwgname (vla-get-fullname doc))
    (progn (cond ((= (substr (getvar "ACADVER") 1 5) "15.06")
                  (setq dbxDoc  (vla-GetInterfaceObject app "ObjectDBX.AxDbDocument")
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName))
                        )
                  )
                 (t
                  (setq dbxDoc  (vla-GetInterfaceObject
                                  app
                                  (strcat "ObjectDBX.AxDbDocument." (substr (getvar "acadver") 1 2))
                                  )
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName))
                        )
                  )
                 )
           (if (vl-catch-all-error-p dbxopen)
             (setq dbxDoc nil)
             )
           )
    )
  dbxDoc
  )

;;; (vlax-dump-Object dbxDoc t)
;;; Close dbxDoc
;;; (kb:CloseDbxDocument dbxDocument)
(defun kb:CloseDbxDocument (dbxdoc)
  (if (= (type dbxDoc) 'VLA-OBJECT)
    (progn (vlax-release-object dbxDoc) (setq dbxDoc nil))
    )
  )


;;;							;
;;;							;
;;;	(kb:ImportADTStyle (kb:ReturnProjectAECStylesStandardsFile) "AECDOOR" "AL-2-AL");
;;;							;

(defun kb:ImportADTStyle (file aecobjtype stylename / dbxDoc blocks block aecobj newblk
                          localBlocks
                          )
  (setq dbxDoc (kb:OpenDbxDocument file))
  (if dbxdoc
    (progn (setq localBlocks (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
                 blocks      (vla-get-blocks dbxDoc)
                 block       (vla-add blocks (vlax-3d-point 0 0) "kbTempBlock")
                 aecobj      (vla-AddCustomObject block aecobjtype)
                 )
           (if aecobj
             (progn (vla-put-stylename aecobj stylename)
                    (setq newblk (vl-catch-all-apply
                                   'vla-CopyObjects
                                   (list dbxDoc
                                         (vlax-safearray-fill
                                           (vlax-make-safearray vlax-vbObject '(0 . 0))
                                           (list (vla-item blocks "kbTempBlock"))
                                           )
                                         localBlocks
                                         )
                                   )
                          )
                    )
             )
           )
    )
  (if (tblsearch "block" "kbTempBlock")
    (vla-delete (vla-item localBlocks "kbTempBlock"))
    )
  (if dbxdoc
    (kb:closedbxdocument dbxDoc)
    )
  )



;;;							;
;;;	Import Multiple Blocks from a DBX Document	;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   listofblocks; list of names to import;
;;;	Return:	the block object			;
;;;							;

(defun kb:ImportCollectionObjects (DwgName CollectionType SelList / dbxCollection LocalCollection dbxDoc ImortObjectList)
  (if (setq dbxDoc (kb:OpenDbxDocument DwgName))
    (progn
      (cond((= (strcase CollectionType) "BLOCKS")
             (setq dbxCollection  (vla-get-blocks dbxDoc)
		 LocalCollection (vla-get-blocks (vla-get-activedocument (vlax-get-acad-object)))
		 ))
           ((= (strcase CollectionType) "LAYERS")
             (setq dbxCollection  (vla-get-layers dbxDoc)
		 LocalCollection (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
		 ))

           ((= (strcase CollectionType) "VIEWS")
             (setq dbxCollection  (vla-get-views dbxDoc)
		 LocalCollection (vla-get-views (vla-get-activedocument (vlax-get-acad-object)))
		 ))

           ((= (strcase CollectionType) "UCS")
             (setq dbxCollection  (vla-get-UserCoordinateSystems dbxDoc)
		 LocalCollection (vla-get-UserCoordinateSystems (vla-get-activedocument (vlax-get-acad-object)))
		 ))
           ((= (strcase CollectionType) "TEXTSTYLES")
             (setq dbxCollection  (vla-get-textstyles dbxDoc)
		 LocalCollection (vla-get-textstyles (vla-get-activedocument (vlax-get-acad-object)))
		 ))
           ((= (strcase CollectionType) "DIMSTYLES")
             (setq dbxCollection  (vla-get-dimstyles dbxDoc)
		 LocalCollection (vla-get-dimstyles (vla-get-activedocument (vlax-get-acad-object)))
		 ))

           )
	   (foreach
		  i SelList
	     (setq ImortObjectList (append ImortObjectList (list (vla-item dbxCollection i))))
	     )

      (setq ImportError
       (vl-catch-all-apply
         'vla-CopyObjects
         (list dbxDoc
               (vlax-safearray-fill
                 (vlax-make-safearray
                   vlax-vbObject
                   (cons 0 (1- (length ImortObjectList)))
                   )
                 ImortObjectList
                 )
               LocalCollection
               )
         )
      )
	   (kb:CloseDbxDocument dbxDoc)
	   )
    )
  ImportError
  )
;;;								;
;;;	Return ollection list from a DBX Document		;
;;;	Arguments: dwgName; a valid drawing name and path	;
;;;		   CollecionType: string Collection Name	;
;;;	Return:	List of strings					;
;;;								;
;(setq ret nil)
(defun kb:ReturnDBXCollectionObjects (DwgName CollectionType / dbxDoc ret)
  (if (setq dbxDoc (kb:OpenDbxDocument DwgName))
    (progn
      (cond ((= (strcase CollectionType) "BLOCKS")
              (vlax-for
                     x (vla-get-blocks dbxDoc)
                (if (and (= (vlax-get x 'isxref) 0)
                         (not (vl-string-search (chr 42) (vla-get-name x)))
                         (not (vl-string-search (chr 124) (vla-get-name x)))
                         )
                  (setq ret (append ret (list (vla-get-name x))))
                  )
                )
              )
            ((= (strcase CollectionType) "LAYERS")
              (vlax-for
                     x (vla-get-layers dbxDoc)
                (if (or (not (wcmatch (strcase (vla-get-name x)) "*|*"))
                        (not (wcmatch (strcase (vla-get-name x)) "DEFPOINTS"))
                        (not (wcmatch (strcase (vla-get-name x)) "0"))
                        )
                  (setq ret (append ret (list (vla-get-name x))))
                  )
                )
              )
            ((= (strcase CollectionType) "VIEWS")
              (vlax-for
                     x (vla-get-views dbxDoc)
                (setq ret (append ret (list (vla-get-name x))))
                )
              )
            ((= (strcase CollectionType) "UCS")
              (vlax-for
                     x (vla-get-UserCoordinateSystems dbxDoc)
                (setq ret (append ret (list (vla-get-name x))))
                )
              )
            ((= (strcase CollectionType) "TEXTSTYLES")
              (vlax-for
                     x (vla-get-textstyles dbxDoc)
                (setq ret (append ret (list (vla-get-name x))))
                )
              )
            ((= (strcase CollectionType) "DIMSTYLES")
              (vlax-for
                     x (vla-get-dimstyles dbxDoc)
                (setq ret (append ret (list (vla-get-name x))))
                )
              )
            )
      )
    )
  (if dbxdoc
    (kb:closedbxdocument dbxDoc)
    )
  ret
  )


;;;							;
;;;	Import Layer Filters from a DBX Document	;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   llist; list of layer names to import	;
;;;							;
;;;							;

    ;(kb:ImportLayerFilter(findfile "kb-layers-edit.dwg") "architectural")
(defun kb:ImportLayerFilter (dwg xrec / dbxDoc l ly)
  (if dwg
    (progn (setq dbxDoc (kb:OpenDbxDocument dwg))
           (if dbxDoc
             (progn (setq l  (vla-item
                               (vla-GetExtensionDictionary (vla-get-layers dbxDoc))
                               "ACAD_LAYERFILTERS"
                               )
                          ly (vla-item
                               (vla-GetExtensionDictionary
                                 (vla-get-layers (vla-get-ActiveDocument (vlax-get-acad-object)))
                                 )
                               "ACAD_LAYERFILTERS"
                               )
                          )
                    (vla-CopyObjects
                      dbxDoc
                      (vlax-safearray-fill
                        (vlax-make-safearray vlax-vbObject '(0 . 0))
                        (list (vla-item l xrec))
                        )
                      ly
                      )
                    (vlax-release-object ly)
                    (kb:CloseDbxDocument dbxDoc)
                    )
             )
           )
    )
  )

 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
