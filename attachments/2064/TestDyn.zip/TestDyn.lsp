(setvar 'cmdecho 0)
(vl-cmdf "_Opendcl")
(setvar 'cmdecho 1)

; (DynBlockPutValue (vlax-ename->vla-object (car (entsel))) "Distance" 8000.0)
; (DynBlockPutValue (vlax-ename->vla-object (car (entsel))) "Visibility1" "Dyn_deur_20")
(defun DynBlockPutValue (blockRefObject propName propValue)
  (setq propName (strcase propName))
  (vl-some
    '(lambda (a)
      (if (= (strcase (vla-get-propertyname a)) propName)
        (progn
          (vla-put-value a propValue)
          T
        )
      )
    )
    (vlax-invoke blockRefObject 'getdynamicblockproperties)
  )
)

(defun CreateTmpBlock (blockName propName propValue / blockDefObject blockRefObject)
  (setq blockDefObject (vlax-invoke (vla-get-blocks (vla-get-activedocument (vlax-get-acad-object))) 'add '(0.0 0.0 0.0) "*U"))
  (setq blockRefObject (vlax-invoke blockDefObject 'insertblock '(0.0 0.0 0.0) blockName 1.0 1.0 1.0 0.0))
  (vla-put-layer blockRefObject "0")
  (DynBlockPutValue blockRefObject propName propValue)
  (vla-get-name blockDefObject)
)


; BlockName          : "dyn_deur_085-078"
; PropName           : "Visibility1"
; Possible propValues: "Dyn_deur_20", "Dyn_deur_90", "Dyn_deur_VAR"
(defun c:TestDyn/Form1#OnInitialize (/)
  (dcl-Control-SetList TestDyn/Form1/ComboBox '("Dyn_deur_20" "Dyn_deur_90" "Dyn_deur_VAR"))
  (dcl-ComboBox-SelectString TestDyn/Form1/ComboBox "Dyn_deur_20")
  (dcl-Control-SetBlockName
    TestDyn/Form1/BlockView
    (CreateTmpBlock "dyn_deur_085-078" "Visibility1" "Dyn_deur_20")
  )
)

(defun c:TestDyn/Form1/ComboBox#OnSelChanged (index value)
  (dcl-Control-SetBlockName
    TestDyn/Form1/BlockView
    (CreateTmpBlock "dyn_deur_085-078" "Visibility1" value)
  )
)

(defun c:Test ()
  (dcl_Project_Load "TestDyn" T)
  (dcl_Form_Show TestDyn/Form1)
)
