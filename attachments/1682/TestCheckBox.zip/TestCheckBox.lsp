(setvar 'cmdecho 0)
(vl-cmdf "_Opendcl")
(setvar 'cmdecho 1)

(defun c:TestCheckBox ()
  (dcl_Project_Load "TestCheckBox" 'T)
  (dcl_Form_Show TestCheckBox_Main)
  (princ)
)
