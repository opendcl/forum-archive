(defun c:TestOnInitializeReturn_Main_OnInitialize ()
  '(
    (xyz 4)
    (abc (def))
    (ghi (jkl))
  )
)

(defun c:TestOnInitializeReturn ()
  (command "_Opendcl")
  (dcl_Project_Load "TestOnInitializeReturn" 'T)
  (dcl_Form_Show TestOnInitializeReturn_Main)
)
