;;; Roll Down / Roll Up
(defun c:PanGroups_Panel4_Roll_OnClicked (/) (@:Set_FormState "PanGroups" "Panel4" "Roll"))
;;; Move Panel Group
(defun c:PanGroups_Panel4_OnMouseMovedOff (/) (@:Move_PanGroup "PanGroups" "Panel4"))
;;; Corner Magnets
(defun c:PanGroups_Panel4_BLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel4" "BLMag"))
(defun c:PanGroups_Panel4_BRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel4" "BRMag"))
(defun c:PanGroups_Panel4_TLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel4" "TLMag"))
(defun c:PanGroups_Panel4_TRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel4" "TRMag"))