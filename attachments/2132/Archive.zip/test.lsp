
(defun c:dclButtonClicked ()

	(print (strcat 
		"Event invoke: "
		(itoa (dcl-Control-GetEventInvoke palette/form1))
	)) ; strcat print

	(setvar "LWDISPLAY" 1)

) ; ButtonClicked

(defun c:test ()
	(command "_.OPENDCL")
	
	(dcl_project_load "palette" t)
	
	(dcl_form_show palette/form1)

(princ)
) ; test

(c:test)

(princ)
