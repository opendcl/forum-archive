;===========================================================================================
(defun StartInsert ( / )

	(command "_OPENDCL")  
	(dcl_Project_Load "InsertBlock.odcl" T)

	;-----------------------------------------------------------------------------------------
	(defun c:CdTroon_DclSelBlock_bntLoadDwg_OnClicked (/ sFileNme)
		
  	(setq sFileNme (GetFiled "Select drawing file" (getvar "dwgprefix") "dwg" 128))

	  (if sFileNme
		 (progn
			 
			 ; Next line does not work in BricsCAD V13
			 (dcl_BlockView_DisplayDwg InsertBlock_DclSelBlock_blkPreview sFileNme 0 0.9)
		))
  )
	;-----------------------------------------------------------------------------------------
	;-----Start Dcl----------------------------------------------------------------------
	;-----------------------------------------------------------------------------------------
	(dcl_Form_Show InsertBlock_DclSelBlock)
)
;===========================================================================================

