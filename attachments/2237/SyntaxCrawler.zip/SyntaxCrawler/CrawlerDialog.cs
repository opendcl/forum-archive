﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SyntaxCrawler
{
  public partial class CrawlerDialog : Form
  {
    const string mypath = @"D:\Daten\euroGIS\OpenDCL\OpenDCL 8.0\Studio\DEU\Content\Reference";

    HashSet<string> functions;
    HashSet<string> syntaxes;
    WebBrowser browser;

    public CrawlerDialog()
    {
      InitializeComponent();

      functions = new HashSet<string>();
      syntaxes = new HashSet<string>();
      browser = new WebBrowser();
      browser.ScriptErrorsSuppressed = true;
    }

    void SelectPath()
    {
      using (FolderBrowserDialog dlg = new FolderBrowserDialog())
      {
        dlg.Description = @"Select the Reference folder of your language (Studio\ENU\Content\Reference)";
        dlg.ShowNewFolderButton = false;
        if (!string.IsNullOrEmpty(edtFolder.Text))
          dlg.SelectedPath = edtFolder.Text;
        else if (Directory.Exists(mypath))
          dlg.SelectedPath = mypath;
        if (dlg.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
        {
          edtFolder.Text = dlg.SelectedPath;
          ReadFiles();
        }
      }
    }

    void ReadFiles()
    {
      if (!string.IsNullOrEmpty(edtFolder.Text) && Directory.Exists(edtFolder.Text))
      {
        functions.Clear();
        syntaxes.Clear();

        lstFunctions.Items.Clear();
        lstSyntax.Items.Clear();

        foreach (string file in Directory.EnumerateFiles(edtFolder.Text, "*.htm", SearchOption.AllDirectories))
        {
          if (Path.GetFileName(file) != "@Template.htm")
            ReadFile(file);
        }

        lstFunctions.Items.AddRange(functions.ToArray());
        lstSyntax.Items.AddRange(syntaxes.ToArray());
      }
    }

    void ReadFile(string strFile)
    {
      string content = null;
      using (StreamReader stream = new StreamReader(strFile, true))
      {
        content = stream.ReadToEnd();
        stream.Close();
      }

      if (!string.IsNullOrEmpty(content))
      {
        // from http://stackoverflow.com/questions/56107/what-is-the-best-way-to-parse-html-in-c
        browser.DocumentText = "feces of a dummy";
        HtmlDocument doc = browser.Document.OpenNew(true);
        doc.Write(content);
        foreach (HtmlElement code in doc.Body.GetElementsByTagName("code"))
        {
          if (!string.IsNullOrEmpty(code.Id) && code.Id.ToUpper() == "SYNTAX")
          {

            Match match = Regex.Match(code.InnerText, @"([A-Za-z0-9\-]+)");
            if (match.Success && match.Value != "defun" && !functions.Contains(match.Value))
              functions.Add(match.Value);

            string syntax = code.InnerText.Replace("\r", string.Empty)
                                .Replace("\n", string.Empty)
                                .Replace("\t", " ")
                                .Replace("<CONTROL-NAME>", (code.InnerText.Contains("-Form-") ? "project/form" : "project/form/control"))
                                .Replace("<CONTROL>", (code.InnerText.Contains("-Form-") ? "project/form" : "project/form/control"));
            if (!syntaxes.Contains(syntax))
              syntaxes.Add(syntax);
          }
        }
      }
    }

    private void pbFolder_Click(object sender, EventArgs e)
    {
      SelectPath();
    }

    private void pbFunction_Click(object sender, EventArgs e)
    {
      using (SaveFileDialog dlg = new SaveFileDialog())
      {
        dlg.AddExtension = true;
        dlg.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
        dlg.FilterIndex = 0;
        dlg.Title = "Save functions to";
        dlg.ShowHelp = false;
        if (dlg.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
        {
          using (FileStream stream = new FileStream(dlg.FileName, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
          {
            using (TextWriter writer = new StreamWriter(stream, System.Text.Encoding.UTF8))
            {
              writer.Write(string.Join("\r\n", lstFunctions.Items.Cast<string>().ToArray()));
              writer.Close();
            }
            stream.Close();
          }
        }
      }
    }

    private void pbSyntax_Click(object sender, EventArgs e)
    {
      using (SaveFileDialog dlg = new SaveFileDialog())
      {
        dlg.AddExtension = true;
        dlg.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
        dlg.FilterIndex = 0;
        dlg.Title = "Save syntax to";
        dlg.ShowHelp = false;
        if (dlg.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
        {
          using (FileStream stream = new FileStream(dlg.FileName, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
          {
            using (TextWriter writer = new StreamWriter(stream, System.Text.Encoding.UTF8))
            {
              writer.Write(string.Join("\r\n", lstSyntax.Items.Cast<string>().ToArray()));
              writer.Close();
            }
            stream.Close();
          }
        }
      }
    }
  }
}
