;;;							;
;;;	Visibility Manager				;
;;;							;
;;;		include files:				;
;;;							;
(vl-load-com)

(if (not (vl-bb-ref 'kbVmanager))
  (vl-bb-set
    'kbVmanager
    (dcl_project_import
      '("YWt6A3oyAACmF9KUBuKTJDMSKitqQLvIwoDJdnhbTx3a9v80JbSGbR3q5Fg2NVdm8zotReMXV3JK"
"FzU/SUJouNR1Sk9YODOC92SPIS/3VbzUEHJ16VpQpuYeE2nYdQFmsUeRmaAFoLJV0ZNK0Q+QleVJ"
"oYNHieANsQmQAwmk7sXgfYkQBHw4HmKRaqAnwlmeR5b/f0bwiU4aHnK0fp6MJH715C68mZg/NrwD"
"Bsmf6/rjrnyJHf1fxmnBCz5Vyr1Qgkj+C6SGJWy1rSY8h2fCrfYtBo9ODFrPfRXIHPUI0K20DNbp"
"agGl+7EoKRx5iK28w5AKm3IfAGSvXrTW+GRsNN3Q2K+gfChn0n9JHy9H10n8dCSBPNvlIzgz0sl7"
"4GqGbCoG5kDSVdyC2v/leZ9/JqbCg57z2WEEjw1xoCoReg3Xu40mtYQligo0nhcmmReW1BRj/gxR"
"9TgV4wh4M5dJysbLMJ+p14J5+8eDCXwBUZThKYYxvIH2gCD6y2BgWALZT3eVbe62FeL6TvGL7a9w"
"0tMYwUKnKv1ZBfXikuT9Vlv1iV40kTjXV7iHcsh4UiEnsyYNGtIMAZjjjCArAPgO268X3aAXfDgv"
"43piOkr4B2eMwtHqzyagqbwGq3xhSZqpiN5K7AbmhbeciTmPDWbSYavGGLpaSe7iEzRxbBYTLpvZ"
"d5EphnqfQPtJbxAo5ngWky2GK7wF+60KVbIEivaMuXro7QPpzv1Ih/l2qXRgAleOmXwBX44ZdU5C"
"lYmRnt18YY25LUgxiGBrmzl6ALuS8ePpFKouqHCXwgsF7mDdRs19ljlnpvMNTP9ph+2uwksE0ldS"
"pfc941IdbvAcFwSrJ6jkj1OXnpXUQAWsYdyDkQDGDI4YrwAo8/m1XXhuUx6mbnZmVWluVCp+Hkck"
"/iYxhnOv8Whe5o4k/uZdgtj0jEKQM3QZvnJeKXYhTbijGEQffGNRezmivkfgSQpA9ku4nl9SZ73s"
"b1DhHsNtks6dYgzjVkF0WfPuu12qPGjRHV9f9Y9M+FLMzjGHJLR3LsDUaUlNPVirgQHQyG8yKR2p"
"dw9LoB4W0EhzfykVAmIzRLiQTFTi0mnEjvTl3fZ2wQNPxTeXNNu2wA4aiXckOVY+ruQ5ppW38F+V"
"j0OvGVXBoqzy66gc0SJ17nH9Z16xPQb+YnxNPsB1/34HxWleV1pwxl3Z6a83ofPNB6mWIKZpxZ6X"
"7cbgDHxayGjekci7w8Tp9iVcUPptCUXmupvjNHYPrR5s6fcQbMk/kxIoa0uXPlw2s5RQWCpE8uBT"
"r5fnMRT33DvbVunlalOJ2B9LLuu52y/rMUc91gRmMtQg/H4rEYuKWQwEEdOEH1/H3jcd48BI5oob"
"c+g+IahGfAOlP90RXZt6ybnjgqBDYAAiy/aTDwDHW3TRSvtVqjrSeGxNd4nlUGI4nGKLqVlSHuzG"
"ICc+78b1cdrwU/fQQogcruvKFdzixVsjlYvdyzCo+xbqPBMwezGplTQ6D+1atGe2zWNTqPFGX5CA"
"VeaQwH+yS/eV5ZAC+eSIejkrDTvE702n3IFSehvYuCXoH3UEZQCfl5B0wmMIxZm2yjwblnKHZ5/2"
"7GZpcsJdhJRYBYqoS0RlQf8fOyGdfEoilASpwbzKMPeA2HoALJ7peugfnxv/oWyGV/9xd4IKEr2y"
"IZzJGYCzKHVFAjCA7w6I+yibaegX64Aoio3zviSmnNOPeZxJinE7gw0c24Iqn3qf5d+0YSlQbnpB"
"8MbvATHzmFi84faIDHEe9YyJ+0ipOnYUaKQWX694TVrMwu4TRelRn9Plitu/7PXbx8J0tHEi0weT"
"krEzkSL7Dc6JPCEIfF73+KajPeHq7AYRexnhobbTSFQN9wpPBMx9t7dRWqLRXt4ZL4FRwItdlyWS"
"KhZCX4fch9S18doR2jqytLrjJ9vnw8ZcV1r8m2Px5ptl904P1WE3oTb35ktqaRhrbGzkEXmpfLCx"
"FwEP0GE/oRzZO6YBGAioga2NC8nyDYOcp+HmO4FJbRUYMyGAO4IXi5PeWYVrevIbg3aEaEVrZDE2"
"AKLmbFEYr2URXxizfU8VoJMebFrN4mlHRUZoSacwX9S9ccQSqG1ic6Jm4LVHccQMAsxzLTjMU5kn"
"l0KTGUt2TjvLvxOq7rWzL+vNCl4vhkcbR4vW061nZgOAeUe72QM="))))

;;;pgp: kbNestedOff,		*kbNestedOff
(defun c:kbNestedOff( / ent)
  (setq ent(nentsel))
  (if ent
      (vla-put-Visible(vlax-ename->vla-object(car ent)):vlax-false)))


;;;							;
;;;	OnInitialize Event				;
;;;							;
(defun c:VisibilityManager_Main_OnInitialize	(/ vlist col0 col1 col2 col3)
  (if (= (dcl_ListView_GetColumnCount VisibilityManager_Main_ListView) 4)
    (dcl_ListView_DeleteColumns VisibilityManager_Main_ListView (list 0 1 2 3)))

  (dcl_ListView_AddColumns
    VisibilityManager_Main_ListView
    (list (list "Object" 1 200)
	  (list "State" 1 40)
	  (list "Layer" 1 80)
	  (list "Handle" 1 80)))

  (vlax-for
	 x  (kb:getactivespace)
    (dcl_ListView_AddItem
      VisibilityManager_Main_ListView
      (list (vla-get-ObjectName x)
	    (if	(= (vla-get-Visible x) :vlax-true)
	      "On"
	      "Off")
	    (vla-get-layer x)
	    (vla-get-handle x))))
  (setq col0(vl-registry-read
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main" 
 "col0")
	col1(vl-registry-read
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main" 
 "col1")
	col2(vl-registry-read
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main" 
 "col2")
	col3(vl-registry-read
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main" 
 "col3")
	)
  (if col0(dcl_ListView_SetColWidth VisibilityManager_Main_ListView 0 col0))
  (if col1(dcl_ListView_SetColWidth VisibilityManager_Main_ListView 1 col1))
  (if col2(dcl_ListView_SetColWidth VisibilityManager_Main_ListView 2 col2))
  (if col3(dcl_ListView_SetColWidth VisibilityManager_Main_ListView 3 col3))
  (princ)(princ))


;;;							;
;;;	Isolate Control Clicked				;
;;;							;

(defun c:VisibilityManager_Main_IsolateButton_OnClicked  (/ layers ss cnt num)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
  (if (dcl_Control_GetValue VisibilityManager_Main_ScreenCheckbox)
    (progn
      (dcl_form_Close VisibilityManager_Main)
      (setq ss (ssget))
      (if ss
	(progn
	  (vlax-for
		 x  (kb:GetActiveSpace)
	    (if
	      (and (vlax-property-available-p x 'visible T)
		   (= (vla-get-lock (vla-item layers (vla-get-layer x))) :vlax-false))
	       (vla-put-Visible x :vlax-false)))
	  (setq	cnt 0
		num (sslength ss))
	  (while (< cnt num)
	    (setq e (ssname ss cnt))
	    (vla-put-Visible (vlax-ename->vla-object e) :vlax-true)
	    (setq cnt (1+ cnt)))
	  (dcl_Form_Show VisibilityManager_Main))))
    (progn
      (if (dcl_ListView_GetSelectedNths VisibilityManager_Main_ListView)
	(progn
      (setq cnt 0
		 num (dcl_ListView_GetCount VisibilityManager_Main_ListView))
	   (vlax-for
		  x  (kb:GetActiveSpace)
	     (if (and (vlax-property-available-p x 'visible T)
		      (= (vla-get-lock (vla-item layers (vla-get-layer x))) :vlax-false))
	       (vla-put-Visible x :vlax-false)))
	   (while (< cnt num)
	     (dcl_ListView_SetItemText VisibilityManager_Main_ListView "Off" cnt 1)
	     (setq cnt (1+ cnt)))
      )
	(dcl_messagebox "Select something" "Isolate Object(s)" 2 1)
	)
	)
    )
  (princ)
  (princ))




;;;							;
;;;	Off Control Clicked				;
;;;							;
(defun c:VisibilityManager_Main_OffButton_OnClicked  (/ ss cnt num items layers)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
  (if (=(dcl_Control_GetValue VisibilityManager_Main_ScreenCheckbox)1)
    (progn (dcl_form_Close VisibilityManager_Main)
      (setq ss (ssget))
	   (if ss
	     (progn (setq cnt 0
			  num (sslength ss))
		    (while (< cnt num)
		      (setq e (ssname ss cnt))
		      (vla-put-Visible (vlax-ename->vla-object e) :vlax-false)
		      (setq cnt (1+ cnt)))
		    )
	     )
      (dcl_Form_Show VisibilityManager_Main)
      )
    (progn (setq items (dcl_ListView_GetSelectedNths VisibilityManager_Main_ListView))
	   (foreach
		  x  items
	     (vla-put-Visible
	       (vla-HandleToObject
		 (vla-get-activedocument (vlax-get-acad-object))
		 (nth 3 (dcl_ListView_GetRowItems VisibilityManager_Main_ListView x)))
	       :vlax-false)
	     (dcl_ListView_SetItemText VisibilityManager_Main_ListView x 1 "Off"))))
  (princ)
  (princ))


;;;							;
;;;	On Control Clicked				;
;;;							;

(defun c:VisibilityManager_Main_OnButton_OnClicked	(/ items)
  (setq items (dcl_ListView_GetSelectedNths VisibilityManager_Main_ListView))
  (foreach
	 x  items
    (vla-put-Visible
      (vla-HandleToObject
	(vla-get-activedocument (vlax-get-acad-object))
	(nth 3 (dcl_ListView_GetRowItems VisibilityManager_Main_ListView x)))
      :vlax-true)
    (dcl_ListView_SetItemText VisibilityManager_Main_ListView x 1 "On"))
  (princ)
  (princ))

;;;							;
;;;	AllOn Control Clicked				;
;;;							;

(defun c:VisibilityManager_Main_AllOnButton_OnClicked  (/ layers cnt num)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
  (vlax-for
	 x  (kb:GetActiveSpace)
    (if	(and (vlax-property-available-p x 'visible T)
	     (= (vla-get-lock (vla-item layers (vla-get-layer x))) :vlax-false))
      (vla-put-Visible x :vlax-true)))
  (setq	cnt 0
	num (dcl_ListView_GetCount VisibilityManager_Main_ListView))
  (while (< cnt num)
    (dcl_ListView_SetItemText VisibilityManager_Main_ListView cnt 1 "On")
    (setq cnt (1+ cnt)))
  (princ)
  (princ))


;;;							;
;;;	Find Control Clicked				;
;;;							;
(defun c:VisibilityManager_Main_FindButton_OnClicked  (/ ss items)
  (setq	ss    (ssadd)
	items (dcl_ListView_GetSelectedNths VisibilityManager_Main_ListView))
  (foreach
	 x  items
    (vla-put-Visible
      (vla-HandleToObject
	(vla-get-activedocument (vlax-get-acad-object))
	(nth 3 (dcl_ListView_GetRowItems VisibilityManager_Main_ListView x)))
      :vlax-true)
    (dcl_ListView_SetItemText VisibilityManager_Main_ListView "On" x 1)
    (ssadd (vlax-vla-object->ename
	     (vla-HandleToObject
	       (vla-get-activedocument (vlax-get-acad-object))
	       (nth 3 (dcl_ListView_GetRowItems VisibilityManager_Main_ListView x))))
	   ss))
  (dcl_Form_close VisibilityManager_Main)
  (if ss
    (sssetfirst ss ss))
  (princ)(princ)
  )


;;;							;
;;;	ListView Column Clicked				;
;;;	Sort						;

(defun c:VisibilityManager_Main_ListView_OnColumnClick  (nColumn /)
  (dcl_ListView_SortTextItems
    VisibilityManager_Main_ListView
    nColumn
    1 ;[as Integer, T or Nil] (1 or T = Ascending, 0 or Nil = Descending)
    )
  (princ)(princ))


;;;							;
;;;		Close Clicked				;
;;;							;

(defun c:VisibilityManager_Main_CloseButton_OnClicked ( / col0 col1 col2 col3)
  (Setq col0 (dcl_ListView_GetColWidth VisibilityManager_Main_ListView 0)
	col1(dcl_ListView_GetColWidth VisibilityManager_Main_ListView 1)
	col2(dcl_ListView_GetColWidth VisibilityManager_Main_ListView 2)
	col3(dcl_ListView_GetColWidth VisibilityManager_Main_ListView 3))
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main"
 "col0"
 col0
  )
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main"
 "col1"
 col1
  )
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main"
 "col2"
 col2
  )
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\VisibilityManager_Main"
 "col3"
 col3
  )
  (dcl_form_close VisibilityManager_Main)
)


;;;							;
;;;		Command Interface			;
;;;							;
;;;pgp: kbVManager,		*kbVManager
(defun c:kbVManager  (/)
  (if (kb:Dwghasxrefs)
    (alert "Visibility Tools dose not yet support XREF visibility!"))
  (if (not (member "VisibilityManager" (dcl_GetProjects)))
    (dcl_Project_load "VisibilityManager"))
  (if dcl_HideErrorMsgBox
      (dcl_Form_Show VisibilityManager_Main)  
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)(princ))

;;;							;
;;;	kbTools Visibility Tools			;
;;;	Commandline Tools				;
;;;		include files:				;
;;;							;

;;;							;
;;;	Isolate Objects					;
;;;							;
;;;pgp: kbIsolate,		*kbIsolate
(defun c:kbIsolate  (/ layers ss cnt num)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
   ss (ssget))
      (if ss
	(progn
	  (vlax-for
		 x  (kb:GetActiveSpace)
	    (if
	      (and (vlax-property-available-p x 'visible T)
		   (= (vla-get-lock (vla-item layers (vla-get-layer x))) :vlax-false))
	       (vla-put-Visible x :vlax-false)))
	  (setq	cnt 0
		num (sslength ss))
	  (while (< cnt num)
	    (setq e (ssname ss cnt))
	    (vla-put-Visible (vlax-ename->vla-object e) :vlax-true)
	    (setq cnt (1+ cnt)))
	  )
    
    )
  (princ)
  (princ))




;;;							;
;;;	Off 						;
;;;							;
;;;pgp: kbVisOff,		*kbVisOff
(defun c:kbVisOff(/ ss cnt num items layers)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))ss (ssget))
	   (if ss
	     (progn (setq cnt 0
			  num (sslength ss))
		    (while (< cnt num)
		      (setq e (ssname ss cnt))
		      (vla-put-Visible (vlax-ename->vla-object e) :vlax-false)
		      (setq cnt (1+ cnt)))
		    ))
  (princ)
  (princ))



;;;							;
;;;	AllOn 						;
;;;							;
;;;pgp: kbVisAllOn,		*kbVisAllOn
(defun c:kbVisAllOn(/ layers cnt num)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
  (vlax-for
	 x  (kb:GetActiveSpace)
    (if	(and (vlax-property-available-p x 'visible T)
	     (= (vla-get-lock (vla-item layers (vla-get-layer x))) :vlax-false))
      (vla-put-Visible x :vlax-true)))
  (princ)
  (princ))



(princ "\nVisibility Commands loaded!")
(princ)