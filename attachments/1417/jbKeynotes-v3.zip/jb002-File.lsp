;;;							;
;;;		File Name dictionary			;
;;;							;
;;;	***If not using Project Navigator kb.key must	;
;;;	be in AutoCAD's search path.			;
;;;							;
;(jb:ReturnKeynoteFilename)
(defun jb:ReturnKeynoteFilename	(/)
  (setq jb%KeyFile (findfile (strcat (jb:returnprojectdir) "\\kb.key")))
  (if (not jb%KeyFile)
    (setq jb%KeyFile(findfile "kb.key"))
    )
  jb%KeyFile
)



;;;								;
;;;		Dynamic Keynotes				;
;;;								;
(defun jb:getKeyNoteFileForSyncing (file / ofile key note inilst ret)
  (prompt
    (strcat "\nOpening " (vl-filename-base file) ", please wait . . .")
  )
  (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx)))
  ) ;_ eofwhile
  (close ofile)
  (foreach
	 i
	  inilst
    (if	(and i (/= i "") (/= (VL-STRING-POSITION (ascii "*") i) 0))
      (progn (setq key	(substr i 1 (vl-string-position (ascii "\t") i))
		   note	(substr i (+ 2 (vl-string-position (ascii "\t") i)))
	     )
	     (setq ret (append ret (list (cons key note))))
      )
    )
  )
  ret
)
;;;		Keynotes are linked to the .key file.		;
;;;		When the key file is edited or a drawing	;
;;;		is opened containing keynotes the user		;
;;;		will be prompted to update keynotes.		;
;;;		A command will also be available to update	;
;;;		keynotes "jbSyncKeynotes".			;
;;;								;
;(setq i(vlax-ename->vla-object(car(entsel))))
(defun jb:SyncKeynoteFiletoDrawing  (/ file data key oldnote newnote keytype xdata ent)
  (princ "\nSyncing Keynote File, please wait . . ..")
  (setq file (jb:ReturnKeynoteFilename))
  (if file
    (progn
      (setq data (jb:getKeyNoteFileForSyncing file))
      (vlax-for
	     i	(jb:getactivespace)
	(setq ent   (vlax-vla-object->ename i)
	      xdata (jb:getKeyNotexdata ent))
	(if (nth 2 xdata)
	  (progn (setq keyType (nth 2 xdata)
		       oldnote (nth 1 xdata)
		       key     (nth 0 xdata)
		       newnote (cdr (assoc key data)))
	    ;if there is no new note then the key doesn't exist in the file
	    (if newnote
		 (cond
		   ((= keyType "KEYLEADER")
		    (if	(not(eq oldnote newnote))
		      (progn (vla-put-textstring i key)
			     (vlax-put i "color" acbylayer)
			     (jb:putKeyNotexdata ent key newnote "KEYLEADER")
			)
		      (vla-put-textstring i key)
		      ))
		   ((= keyType "NOTELEADER")
		    (if	(not(eq oldnote newnote))
		      (progn (vla-put-textstring i newnote)
			     (vlax-put i "color" acbylayer)
			     (jb:putKeyNotexdata ent key newnote "NOTELEADER")
			)
		      (vla-put-textstring i newnote)
		      ))
		   ((= keyType "MTEXT")
		    (if	(not(eq oldnote newnote))
		      (progn (vla-put-textstring i newnote)
			     (vlax-put i "color" acbylayer)
			     (jb:putKeyNotexdata ent key newnote "MTEXT")
			)
		      (vla-put-textstring i newnote)
		      ))
		   )

	      ;no new note - key no longer exists.
	      (cond
		   ((= keyType "KEYLEADER")
		    (if oldnote(vla-put-textstring i oldnote))
			     (vlax-put i "color" acred)
		    (jb:putKeyNotexdata ent "" "" "KEYLEADER")
			     )
		   ((= keyType "NOTELEADER")
		    (if oldnote(vla-put-textstring i oldnote))
			     (vlax-put i "color" acred)
		    (jb:putKeyNotexdata ent "" "" "NOTELEADER")
		    )
		   ((= keyType "MTEXT")
		    (if oldnote(vla-put-textstring i oldnote))
			     (vlax-put i "color" acred)
		   (jb:putKeyNotexdata ent "" "" "MTEXT")
		    )
		   ((= keyType "KEYNOTELEGEND")
		    (vlax-put i "color" 165)
		    )
		   )
	      
	      )
	    )
	  )
	)
      )
    )
  )
  
;;;Automatically sync file when routine is loaded
(if jb:SyncKeynoteFiletoDrawing
        (jb:SyncKeynoteFiletoDrawing))