;------------------------------------------------------------------------------
;funcao que retorna o valor do rotulo na lista "lista"
(defun dxf (rotulo lista)
   (cdr (assoc rotulo lista))
 )
;------------------------------------------------------------------------------
;------------------------------------------------------------------------------
;Esta funcao faz a conversao de radianos p/ graus
(defun rtd (rad / ang)
  (setq ang (/ (* rad 180) pi))
  ang
 )

;------------------------------------------------------------------------------
;recebe um numero e o numero de casas e faz o arredondamento.
(defun arredonda (num casas / mult num_arred)
   (setq mult (expt 10.0 casas))
   (setq num_arred (* (realcc num) mult))
   (setq num_arred (+ num_arred 0.5))
   (setq num_arred (/ (intcc num_arred) mult))
   num_arred
 )
;------------------------------------------------------------------------------

;recebe uma variavel e retorna a string
(defun strcc (var / str tipo)
   (setq tipo (type var))
   (cond
      ((= tipo 'real) (setq str (rtos var)))
      ((= tipo 'int) (setq str (itoa var)))
      ((= tipo 'str) (setq str var))
      ((= tipo nil) (setq str ""))
      (T            (setq str ""))
    )
   str
 )

;------------------------------------------------------------------------------
;recebe uma variavel e retorna o real
(defun realcc (var / tipo real)
   (setq tipo (type var))
   (cond
      ((= tipo 'real) (setq real var))
      ((= tipo 'int) (setq real (* 1.0 var)))
      ((= tipo 'str) (setq real (atof var)))
      ((= tipo nil) (setq real 0.0))
      (T            (setq real 0.0))
    )
   real
 )

;------------------------------------------------------------------------------

;------------------------------------------------------------------------------
(defun rotacionar_presilhas ( / ent ld acad arq_odc result)

  (setq ent nil)
  (while (null ent)
    (setq ent (entsel "\nSelecione a presilha a ser modificada: "))
    (if ent
      (progn
        (setq ld (entget (car ent)))
        ;COMPARO UMA PARTE DO NOME DO BLOCO
        (if (and (/= (dxf 2 ld) "Presilha 111-16 - Superior")
                 (/= (dxf 2 ld) "Presilha 111-17 - Superior"))
          (progn
            (dcl_MessageBox "A entidade selecionada n�o � uma presilha." "Aten��o!" 2 4)
      	    (setq ent nil)
           )
         )  ;;if (/=  (dxf 2 ld) "Presilha 111-17 - Superior")
       )
     )      ;;if ent
   )        ;;while (null ent)

  (setq e_name (car ent))

  (setq arq_odc "RMenrol.odc")
  (command "_.OPENDCL")
  (dcl_LoadProject arq_odc t)

  ;mostra o formulario
  (dcl-Form-Show RMenrol/DclModelessForm_Rotacionar_Presilhas)

  (princ)
 )

;*********************************************************************
;*********************************************************************
(defun c:RMenrol/DclModelessForm_Rotacionar_Presilhas#OnInitialize ( / ld inclinacao mensagem)

  (setq ld (entget e_name))
  (setq inclinacao (dxf 50 ld))
  (setq inclinacao (- (rtd inclinacao) 90))

  (if (<= inclinacao 0)
    (setq inclinacao (+ 360 inclinacao))
   )
  (setq inclinacao (arredonda inclinacao 2))

  (setq mensagem (strcat "A presilha selecionada est� posicionada a " (strcc inclinacao) " graus."))

  (dcl_Control_SetCaption RMenrol_DclForm_Rotacionar_Presilhas_Label_Angulo_Presilha mensagem)
  (princ)
 )

;*********************************************************************
;*********************************************************************
;*********************************************************************
;*********************************************************************
;TB_Deslocamento
(defun c:RMenrol_DclForm_Rot_Presil_TB_Deslocamento#OnKillFocus (/)
  (dcl-Control-SetFocus RMenrol_DclForm_Rotacionar_Presilhas_TB_Rotacionar)
 )


;*********************************************************************
;*********************************************************************
;TB_Rotacionar
(defun c:RMenrol_DclForm_Rotacionar_Presilhas_TB_Rotacionar#OnClicked ( / )
  (setq deslocamento (realcc (dcl_Control_GetText RMenrol_DclForm_Rotacionar_Presilhas_TB_Deslocamento)))
  (dcl-Form-Enable RMenrol/DclModelessForm_Rotacionar_Presilhas nil)
  (command "_.rotate" e_name "" (list 0 0 0) deslocamento)
  (dcl-Form-Enable RMenrol/DclModelessForm_Rotacionar_Presilhas t)
 )

;*********************************************************************
;*********************************************************************
;TB_Cancelar
(defun c:RMenrol_DclForm_Rotacionar_Presilhas_TB_Cancelar#OnClicked ( / )
  (dcl-Form-Close RMenrol/DclModelessForm_Rotacionar_Presilhas)
 )
