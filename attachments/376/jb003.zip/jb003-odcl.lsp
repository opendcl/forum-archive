;;;							;
;;;	jbBlock Tools v2.0				;
;;;	include files:					;
;;;		jbCommonFunctions			;
;;;		jbCommonLayerFunctions			;
;;;							;


;;;							;
;;;	OpenDCL Subs					;
;;;							;

(defun c:jb003_00_count_OnClicked ( /)
     (dcl_SetCmdBarFocus)
  (vla-sendcommand(vla-get-activedocument(vlax-get-acad-object))"jbCountBlock ")
  (princ)
)


(defun c:jb003_00_Open_OnClicked  (/ blocklist)
  (if (setq jb%importblockdwg
	     (getfiled
	       "Select a drawing"
	       (strcat (jb:ReturnProjectDir) "\\")
	       "dwg;dws;dwt"
	       0))
    (progn (setq blocklist (jb:ReturnDBXBlocks jb%importblockdwg))
	   (dcl_Control_SetCaption jb003_00_dwgname jb%importblockdwg)
      
	   (dcl_ListBox_Clear jb003_00_BlockListImport)
	   (dcl_ListBox_AddList jb003_00_BlockListImport blocklist)))
  (princ)
  (princ))

(defun c:jb003_00_ImportBlocks_OnClicked  (/)
  (Setq rValue (dcl_ListBox_GetSelecteditems jb003_00_BlockListImport))
  (if rValue
    (progn (jb:ImportBlocks jb%importblockdwg rValue)
	   (dcl_ListBox_SelItemRange jb003_00_BlockListImport 0
	     (dcl_ListBox_GetCount jb003_00_BlockListImport)
	     0)
      (dcl_ListBox_Clear jb003_00_BlockList)
  (dcl_ListBox_AddList jb003_00_BlockList (jb:listblocks))
      )
    (alert "Select some blocks!"))
  (princ)
  (princ))

(defun c:jb003_00_InsertBlock_OnClicked	 (/ nIndex rValue)
  (if (setq nIndex (dcl_ListBox_GetCurSel jb003_00_BlockList))
    (progn (setq rValue (dcl_ListBox_GetText jb003_00_BlockList nIndex))
	   (setvar "cmdecho" 1)
	   (command "insert" rValue)))
  (princ)
  (princ))

(defun c:jb003_00_Swap_OnClicked  (/ nIndex rValue)
  (if (setq nIndex (dcl_ListBox_GetCurSel jb003_00_BlockList))
    (progn (setq rValue (dcl_ListBox_GetText jb003_00_BlockList nIndex))
	   (dcl_SetCmdBarFocus) (jb:Swap rValue))
    (progn
      (setvar "cmdecho" 1)
      (command "jbswap"))
    )
  (princ)
  (princ))



(defun c:jb003_00_XREF_OnClicked ( /)
     (cond((=(dcl_Control_GetPicture jb003_00_XREF)110);switch to blocks
	   (dcl_Control_SetPicture jb003_00_XREF 107)
	   (dcl_ListBox_Clear jb003_00_BlockList)
	   (dcl_ListBox_AddList jb003_00_BlockList (jb:listblocks))
  (dcl_BlockView_Clear jb003_00_BlockView))
	  ((=(dcl_Control_GetPicture jb003_00_XREF)107);switch to xrefs
	   (dcl_Control_SetPicture jb003_00_XREF 110)
	   (dcl_ListBox_Clear jb003_00_BlockList)
	   (dcl_ListBox_AddList jb003_00_BlockList (jb:listxrefs))
  (dcl_BlockView_Clear jb003_00_BlockView))
	  )
 (princ)(princ) 
)


(defun c:jb003_00_Find_OnClicked  (/ nIndex rValue)
  (if (setq nIndex (dcl_ListBox_GetCurSel jb003_00_BlockList))
    (progn (setq rValue (dcl_ListBox_GetText jb003_00_BlockList nIndex))
	   (jb:findblock rValue)))
  (princ)
  (princ))


(defun c:jb003_00_BlockList_OnSelChanged  (nSelection sSelText /)
  (dcl_BlockView_DisplayBlock jb003_00_BlockView sSelText 0 1.0)
  (dcl_Control_SetEnabled jb003_00_InsertBlock t)
  (dcl_Control_SetEnabled jb003_00_Swap t)
  (dcl_Control_SetEnabled jb003_00_Find t)
  (princ)
  (princ))


(defun c:jb003_00_BlockListImport_OnSelChanged (nSelection sSelText /)
  (dcl_Control_SetEnabled jb003_00_ImportBlocks t)   
)

(defun c:jb003_00_OnInitialize	( / importlist)
  (dcl_Control_SetEnabled jb003_00_ImportBlocks nil)
  (dcl_Control_SetEnabled jb003_00_InsertBlock nil)
  (dcl_Control_SetEnabled jb003_00_Swap nil)
  (dcl_Control_SetEnabled jb003_00_Find nil)
  (dcl_Control_SetText jb003_00_Path "")
  (dcl_Control_SetToolTipMainText jb003_00_Path "")
  (dcl_ListBox_Clear jb003_00_BlockList)
  (dcl_ListBox_AddList jb003_00_BlockList (jb:listblocks))
  (dcl_BlockView_Clear jb003_00_BlockView)
  (dcl_ListBox_Clear jb003_00_BlockListImport)

  (if jb%importblockdwg
    (if (setq importlist(jb:ReturnDBXBlocks jb%importblockdwg))
    (progn
      (dcl_Control_SetText jb003_00_Path jb%importblockdwg)
      (dcl_Control_SetToolTipMainText jb003_00_Path jb%importblockdwg)
      (dcl_ListBox_AddList jb003_00_BlockListImport importlist)
      ))
    )
  (princ)
  (princ))

(defun c:jb003_00_OnClose  (nUpperLeftX nUpperLeftY /)
  (princ)
  (princ))


(defun c:jb003_00_OnEnteringNoDocState	(/)
  (dcl_form_close jb003_00)
  (vl-bb-set 'jbBlockFloating "true")
  (princ)
  (princ))

(defun c:jb003_00_OnDocActivated  (/)
  (if (dcl_Form_IsActive jb003_00)
    (c:jb003_00_OnInitialize))
  (princ)
  (princ))


(defun c:jb003_00_Refresh_OnClicked  (/)
  (c:jb003_00_OnInitialize)
  (princ)
  (princ))

(defun c:jb003_00_CLOSE_OnClicked ( /)
  (vl-bb-set 'jbBlockFloating "false")
  (dcl_form_close jb003_00)
)


(defun c:jb003_00_Tray_OnClicked ( / rValue wd ht)
  (Setq rValue (dcl_Form_GetControlArea jb003_00)
	wd(car rvalue)
	ht(cadr rvalue))
  (cond(
	(=(dcl_Control_GetPicture jb003_00_Tray)101);roll it up

	(foreach x (dcl_Form_GetControls jb003_00) 
	(dcl_Control_SetVisible x nil))
	(foreach x (list jb003_00_Tray jb003_00_Close
			 jb003_00_TrayRectangle jb003_00_TrayLabel)
	  (dcl_Control_SetVisible x T))
	
	(dcl_Control_SetToolTipMainText jb003_00_Tray "Roll Down Form")

	(dcl_Control_SetMouseOverPicture jb003_00_Tray 100)
	(dcl_Control_SetPicture jb003_00_Tray 100)
	
	(dcl_Form_Resize jb003_00 wd 16)
	(setq %old001Hieght(cadr rvalue)))
       (
	(=(dcl_Control_GetPicture jb003_00_Tray)100);roll down

	(foreach x (dcl_Form_GetControls jb003_00)
	(dcl_Control_SetVisible x t))

	(dcl_Control_SetToolTipMainText jb003_00_Tray "Roll Up Form")
	
	(dcl_Control_SetMouseOverPicture jb003_00_Tray 101)
	(dcl_Control_SetPicture jb003_00_Tray 101)
	
	(if(or(not %old001Hieght)(= %old001Hieght 16))
	  (dcl_Form_Resize jb003_00 (car rValue) 350)
	  (dcl_Form_Resize jb003_00 (car rValue) %old001Hieght))
	)
       )
	 
)
;;;							;
;;;	Command Interface				;
;;;							;

(defun c:jbBlockManager	 (/)
  (if (not (member "jb003" (dcl_GetProjects)))
    (dcl_Project_load "jb003"))
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive jb003_00))
	(dcl_Form_Show jb003_00)
	 )
      (if (=(cadr (dcl_Form_GetControlArea jb003_00))16);it's rolled up
	(c:jb003_00_Tray_OnClicked))
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ))


;;;							;
;;;		Floating Form				;
;;;		Document Opened				;
;;;							;

(defun jb:003_IsFloating  (/)
  (if dcl_HideErrorMsgBox
    (progn (if (dcl_Form_IsActive jb003_00)
	     (c:jb003_00_OnDocActivated)))
    (alert "The OpenDCL arx module did not load!"))
  (princ)
  (princ))


(jb:003_IsFloating)


(princ "\n003 - jbTools Block Manager loaded!")
(princ)
;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
