;;;							;
;;;	kbKeynotes v2.0					;
;;;	include files:					;
;;;		kbCommonFunctions			;
;;;		kbCommonLayerFunctions			;
;;;							;

(vl-load-com)

(if (not (vl-bb-ref 'kbAnnotation))
  (vl-bb-set
    'kbAnnotation
    (dcl_project_import
      '("YWt6A2s7AAADzpN6BuKTJKMRKjtqQXWliKzo8Ww39uQmfHxvaKQTNcl66/E8+gCsqFb3d5JQJVIS"
"JTzfavwP91oS3PfkZvMvoQJOOj9tgvYxOiGKu4Z5hlr3Xy+qWWBuJ7FHDQmRssc1iVAFyZA8CYmg"
"xxmwsufHTZkJsLLiI+TH5X+F1KF/bYbj+u1uuxVy4Vgef36CInkeL99+bObQ9zx8nM57JF/8F2n6"
"jmD5TgA9rrDCvYZquwVy127KH6dmCl4Bao1cBgufQ9JksO66MFKjdOMm0O21+I5gOSdv6Kb3LCSP"
"13XBd5r6LjxmNe/qZsoet1bI774Vb0oaRbThOb90jkWOeSdLURyjVsHci31SsQySXKhues0nWr0E"
"q28LfQUUA3lL3gPSm3CBbdxpeLKEIUUCUIHb3sEMljU6IQuWpTqhb4MnE8KynGACl02I4lveZ8rp"
"ha9Wd6gEX4ch1rN0GID5/OBoiif9IGv50+4xIXAUA0Z2feat84cPUmWZTK2yNR5nVR02IpkjnBDC"
"Nrh3Uk9/Od5htdco+JPkd84Ab4NBE64xBhETUSAdsvE8bJEZN4QFPIRl/IA5rk1YszQ0jb0NyihU"
"FxNRyDuuN9zkJfM8qGs/AViWtfyAKq634jDPOCa5ekPgreq+U6yHN79BVJap+4JCziR+KEg1+Spj"
"rz95LCqiZA6G8W0jFZzJoSiI0x4DkP79WwFfvixRFnegdz0MHWHUMU0gUY2+WY/HZZE5voSol68z"
"ZG5zivk2sHhfCft+h97+oAD5wDKK7XDD75YA+UA5CvE9jQWKdIcD/KBZFhd0qPcPrzI9USCg682z"
"sbcw/xXM/bTAK7gqUX0B2QRb5i2DaOYts4y0QqurGCXC1RjF4dSHcMYqzQ9+ZUS0FePt1kBd1ti5"
"VbhUh9PUqh8jK0H4BytTLyuVeR5Zkr3bslCq429Gfv2GIhORJiD2K3vqeL/6bNGcS1aPBYR2WwCx"
"bN46xep81MfOeSuPPucjhX1Hx9vECkFYyaQSNn8bcoidWBL6Eh0nyWtr3/D5viELUgtNj67UXevW"
"2dKz0GuYTtQc0ZPIu8XTiAjY3jUuWXLFhiJfcLmqxzb78e4LTUlc9MCV6hlzhi2qgf1/l64VOoPB"
"4oBOoUWugdiQFb4YmSRXvtBveDZ9hF06wVWkU8pAAUFJ8vSB5j0Z1kOzboI4gqG7Rhb4/4PsGGam"
"EevO4JmAaR9mloMNCMH/DCIIwbCntMs8Navn7xzrRlbqMC0UHHbbEGCY/7cQQN0G1+3s84aq9TEK"
"ijCZ3YPH7Z832uQNClsGxdtOxckd26o+jlXmoNBzMhG5RfYAf8xHKpRVOpUvbPQNLpJc/COTmoa7"
"H/AX8gwyHWrIHgB2x2MIMl34onACdF2jv8TBe1ks8ez6z2CbOt910TDSbZgkd+im+BO6R5CstO/v"
"7lMxD7xiAfcOE1M0vBCwa1vXoX+5h0IdfIWi87AXYth0uzXmUFwgjGKvW7o15sBUlkXcQRjC2hhx"
"nR5i+R3IhrZ7AlRPQFzdZfucb4A6auS+4K5r0HdjzNM76l1YN3DWax/aEHZdW+mqZb79ryZQvtv/"
"40PJeIgqvnpFjUvOjWwgfUVRC5mOOpQi3t55BSb8RqwBN6seRRCE0YQTFiqIPGGuvxd8GC5R4dd2"
"4VpxetrkIH4tMz/WlxUe1BdN5hTEYJgoMyF/JTMXDGVXmRepF7Fekr+DNz97IiwYe/J3hxc/wV6W"
"+t7bfAFelumQAWm9ipLF5qQ/ilV3CpQd1rPQY7MWD56kUljKm6ABNMaTewLbfNW3Wd47OkFajprw"
"Fv0G0TyAHN1+NDauMfeIwWnKeJr7WhHrfqRYfxoN+YuSdvC+ZtDt5Af3Q701ja3m3bhauLUOAyM7"
"5QNURbcJZMMTJpR65DzLnNwsLYhv/B1WF8dBG1GEc9tVyaeXbN0LwRgWT5vGs67OTD2Nrh5HOz79"
"tZWudnYW/sGuHpYrQkr4n+pz8jNrc3NA7eOJw1uHIEupoAIRsHJT31LJZwQA0LNuvZd/Tj3g6LRA"
"5F8gFGkZ+AiAQRhW+CrigdIGYsfETxR5jou29Jdsg4rCT1S3ZlO0TZ0gMmzLP1nckO4tDnYI3WDH"
"vDMVkWMQtAkECW7MDGCK3u35JyQ4uR+dRiSt8od/MDGO8m+U2YJyNMtuoUKBVqICe3rTJhBvP9XC"
"Jcwn/CjZXrHotUqmk5BGOUC91ZC9csd6jcw4pWIZG7yN8IlSga6XeGHyjIMS6NZ6ByPJNybOdQTb"
"RyYt0kdeZ43YXi09EUH3XexWTZaL+NRuoKV9WMJnaDu62mcoWMJl4m/fiyxIRi03HqJwZGZXwiyW"
"UV+AhHetgBsToQawiCvdXJujZrLcNlm/im0ioSraNtcAXLRoTHcZSlGfUplVpSGOd/yXdahplXVg"
"2IFaB453y8RAN9G+ZQYuBGf+O25ixKCOiOVBSwMKY1A/sUmF7bbG+8LjA8mSFK3eyN21klUeCVh7"
"iYTaak3rLHcDV3URqdAjveJyga641PrAZ0jH7shB18r7CXXVLrSr65pSE42tF9k4RNus9YbdPMaJ"
"3Ko0qePgXzgUWNOs9WnH+OszR+VATRdk5y1rQEzUrUJ8V2RcNFO1EK3fE8BNPFWHmdqZ5eRGgUIA"
"K//rGBQZ1YpBjxkm7A=="))))

;;;								;
;;;	Font and Formatting tools				;
;;;								;


;;; looks for this sequence 123 92 102
;;;(setq cnt2 nil fontend nil end nil endp nil pos nil ret nil fonts nil i nil poss nil pos nil)
(defun kb:StripFontFormat  (str / pos poss fonts cnt num newstrlist newlist)

  ; start of font defs
  (setq cnt 0
        num (length (vl-string->list str)))
  (while (< cnt num)
    (cond(
    (setq pos (vl-string-search "{\\f" str cnt)))
         ((setq pos (vl-string-search "{\\F" str cnt))))
    (if pos
      (setq cnt  (+ 3 pos)
            poss (append poss (list pos)))
      (setq cnt (1+ cnt))))

  (if poss
    (foreach i poss
      (setq fonts(append fonts
                     (list(substr str (1+ i) (+ (- (vl-string-search ";" str i) i) 1)))))))
  (if fonts(foreach x fonts
    (setq str(vl-string-subst "" x str))))
;now strip the end of font def marker
(setq pos 0 newlist nil)
(foreach i (vl-string->list str)
  (setq newlist(append newlist(list(cons pos (chr i))))
        pos(1+ pos)
        newstrlist ""))
(foreach x newlist
  (if(=(cdr x)"}")
    (if (=(ascii(cdr(nth(1-(car x))newlist)))92)
      (setq newstrlist(strcat newstrlist(cdr x))))
    (setq newstrlist(strcat newstrlist(cdr x)))))
  
  newstrlist)


;;;(jb:StripFont(vla-get-textstring(vlax-ename->vla-object(car(entsel)))))
;;;(setq str(vla-get-textstring(vlax-ename->vla-object(car(entsel)))))
;;;
(defun c:kbStripFont( / str textobj)
  (setq textobj(vlax-ename->vla-object(car(entsel)))
	str(vla-get-TextString textobj)
        nstr(kb:StripFontFormat str))
  (vla-put-Textstring textobj nstr)
  (princ))


(defun c:kbCopyString  (/ *Error* ent ent2 obj obj2 str)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (if ent(redraw ent 4))
    (if ent2(redraw ent2 4))
    (princ))
  (setq ent (car (entsel "\nSelect a text to copy: ")))
  (if ent
    (progn (redraw ent 3)
      (setq ent2 (car (entsel "\nSelect text: ")))
           (if ent2
             (progn
               (redraw ent2 3)
               (if (and (member (cdr (assoc 0 (entget ent))) (list "MTEXT" "TEXT"))
                        (member (cdr (assoc 0 (entget ent2))) (list "MTEXT" "TEXT")))
                 (progn (setq obj  (vlax-ename->vla-object ent)
                              obj2 (vlax-ename->vla-object ent2)
                              str  (vlax-get obj "TextString"))
                        (vlax-put obj2 "TextString" (kb:StripFontFormat str)))
                 (princ "\nOne of the Selection was not of type TEXT!"))))))
  (*Error* nil)
  )


;;;								;
;;;	Set Dimension Text to "EQ"				;
;;;								;
(defun c:kbeq( / ss cnt num)
  (setq ss(ssget '((0 . "DIMENSION"))))
  (if ss
    (progn
    (setq cnt(sslength ss)
	  num 0)
    (while (< num cnt)
      (progn
      (vla-put-TextOverride(vlax-ename->vla-object(ssname ss num)) "EQ.")
      (setq num(1+ num))
      )
      )
    )
    )
  (princ)(princ)
  )


;;;								;
;;;	GetText subroutine					;
;;;								;
(defun kb:GetKeynoteSelection  (/ text)
  (if(dcl_Form_IsActive Palette_Main)
	 (setq text (dcl_ListBox_GetText
		      Palette_Main_05KeynoteslistBox
		      (dcl_ListBox_GetCurSel Palette_Main_05KeynoteslistBox))))
	
  text)

;;;*00								;
;;;	Fix Width when scale changes				;
;;;								;
;;;pgp: kbFixWidth,		*kbFixWidth
(defun c:kbFixWidth  (/ *Error* doc ss cnt num snt)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq	doc (vla-get-activedocument (vlax-get-acad-object))
	ss  (ssget '((-4 . "<OR") (0 . "MULTILEADER") (0 . "MTEXT") (-4 . "OR>"))))
  (vla-StartUndoMark doc)
  (if ss
    (progn (setq cnt 0
		 num (sslength ss))
	   (while (< cnt num)
	     (setq ent (ssname ss cnt))
	     (vla-put-TextWidth (vlax-ename->vla-object ent) (kb:TextWidthValue))
	     (setq cnt (1+ cnt)))))
  (vla-EndUndoMark doc)
  (princ)
  (princ))




;;;								;
;;;	Change between a KEYLEADER type and a			;
;;;	NOTELEADER type						;
;;;								;
;;;(setq obj(vlax-ename->vla-object(car(entsel))))		;
;;;pgp: kbSwapKeyandNote,		*kbSwapKeyandNote
(defun c:kbSwapKeyandNote
       (/ *Error* ss cnt num ent obj xdata key note objtype width nscale)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq	doc (vla-get-activedocument (vlax-get-acad-object))
	ss  (ssget '((-4 . "<OR") (0 . "MULTILEADER") (0 . "MTEXT") (-4 . "OR>"))))
  (vla-StartUndoMark doc)
  (if ss
    (progn (setq cnt 0
		 num (sslength ss))
	   (while (< cnt num)
	     (setq ent	   (ssname ss cnt)
		   obj	   (vlax-ename->vla-object ent)
		   xdata   (kb:getKeyNotexdata ent)
		   key	   (nth 0 xdata)
		   note	   (nth 1 xdata)
		   objtype (nth 2 xdata)
		   width   (kb:TextWidthValue)
		   nscale  (rtos (kb:cannoscale) 2 1))
	     (if (not width)
	       (setq width 2.5))
	     (cond ((= objtype "NOTELEADER")
		    (progn (vlax-put-property obj 'TextString key)
			   (kb:putKeyNotexdata ent key note "KEYLEADER" nscale)))
		   ((= objtype "KEYLEADER")
		    (progn (vlax-put-property obj 'TextString note)
			   (if (= (vlax-get-property obj 'TextWidth) 0.0)
			     (vlax-put-property obj 'textwidth width))
			   (kb:putKeyNotexdata ent key note "NOTELEADER" nscale)))
		   ((= objtype "MTEXT")
		    (dcl_messagebox
		      "Sorry, you can't change MTEXT objects    "
		      "Swap Keys and Notes"
		      2
		      1)
		    (princ "\nCan't change an MTEXT object, Dude")))
	     (setq cnt (1+ cnt)))))
  (vla-EndUndoMark doc)
  (princ))


;;;								;
;;;	Place a KeyNote and Qleader				;
;;;	Qleader and Mtext					;
;;;	NOTE USED						;
;;;pgp: kbPlaceKeyNoteQleader,		*kbPlaceKeyNoteQleader

(defun c:kbPlaceKeyNoteQleader	(/ *Error* text p1 p2 key note qleader qleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (kb:GetKeynoteSelection))
  (if (and text (/= text ""))
    (progn
      (setq key	 (kb:ReturnKey text)
	    note (kb:ReturnNote text)
	    doc	 (vla-get-ActiveDocument (vlax-get-acad-object)))
      (if (and key note)
	(progn
	  (vla-StartUndoMark doc)
	  (kb:SetAcadDim
	    '((3 . "")
	      (40 . 0.0)
	      (60 . 0)
	      (61 . 0)
	      (62 . 1)
	      (63 . 1)
	      (64 . 0)
	      (65 . 0)
	      (67 . 2)
	      (68 . 1)
	      (69 . 0)
	      (70 . 0)
	      (72 . 0)))
	  (prompt "\nSpecify first leader point: ")
	  (vl-cmdf "_.qleader" pause)
	  (prompt "\nSpecify next point: ")
	  (vl-cmdf pause) ;(prompt "\nSpecify text width: ")
	  (vl-cmdf "" "." "")
	  (setq qleader (entlast))
	  (if
	    (= (vla-get-objectname (setq qleaderObj (vlax-ename->vla-object qleader)))
	       "AcDbMText")
	     (progn (vlax-put-property qleaderObj 'TextString key)
		    (kb:putKeyNotexdata (entlast) key note "KEYLEADER" nscale)))
	  (vla-EndUndoMark doc)))))
  (princ))

;;;								;
;;;	Place a Keyed Note and Qleader				;
;;;	Qleader and Mtext					;
;;;	NOT USED						;
;;;pgp: kbPlaceNoteQleade,		*kbPlaceNoteQleade
(defun c:kbPlaceNoteQleader  (/ *Error* text p1 p2 key note qleader qleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (kb:GetKeynoteSelection))
  (if (and text (/= text ""))
    (progn
      (setq key	 (kb:ReturnKey text)
	    note (kb:ReturnNote text)
	    doc	 (vla-get-ActiveDocument (vlax-get-acad-object)))
      (if (and key note)
	(progn
	  (vla-StartUndoMark doc)
	  (kb:SetAcadDim
	    '((3 . "")
	      (40 . 0.0)
	      (60 . 0)
	      (61 . 0)
	      (62 . 1)
	      (63 . 1)
	      (64 . 0)
	      (65 . 0)
	      (67 . 2)
	      (68 . 1)
	      (69 . 0)
	      (70 . 0)
	      (72 . 0)))
	  (prompt "\nSpecify first leader point: ")
	  (vl-cmdf "_.qleader" pause)
	  (prompt "\nSpecify next point: ")
	  (vl-cmdf pause)
	  (prompt "\nSpecify text width: ")
	  (vl-cmdf pause "." "")
	  (setq qleader (entlast))
	  (if
	    (= (vla-get-objectname (setq qleaderObj (vlax-ename->vla-object qleader)))
	       "AcDbMText")
	     (progn (vlax-put-property qleaderObj 'TextString note)
		    (kb:putKeyNotexdata (entlast) key note "NOTELEADER" nscale)))
	  (vla-EndUndoMark doc)))))
  (princ))
;;;								;
;;;	Place a KeyNote and Leader				;
;;;	Mleader and Mtext					;
;;;								;
;;;pgp: kbPlaceKeyNote,		*kbPlaceKeyNote
(defun c:kbPlaceKeyNote	 (/ *Error* text key note mleader mleaderObj gap)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (kb:GetKeynoteSelection))
  (if (and text (/= text ""))
    (progn
      (setq key	   (kb:ReturnKey text)
	    note   (kb:ReturnNote text)
	    nscale (rtos (kb:cannoscale) 2 1))
      (if (and key note)
	(progn
	  (command ".mleader"
            "_O" "_C" "_M"
            "_L" "_S"
            "_M" "2"
	    "_X" pause pause "." "")
	  (setq mleader (entlast))
	  (if
	    (= (vla-get-objectname (setq mleaderObj (vlax-ename->vla-object mleader)))
	       "AcDbMLeader")
	     (progn (vlax-put-property mleaderObj 'TextString key)
		    (kb:putKeyNotexdata (entlast) key note "KEYLEADER" nscale)
		    (vlax-put-property mleaderobj 'DoglegLength 0.125)))))))
  (princ))

;;;								;
;;;	Place a Keyed Note and Leader				;
;;;	Mleader and Mtext					;
;;;								;
;;;pgp: kbPlaceNote,		*kbPlaceNote
(defun c:kbPlaceNote  (/ *Error* text key note mleader mleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (kb:GetKeynoteSelection))
  (if (and text (/= text ""))
    (progn
      (setq key	   (kb:ReturnKey text)
	    note   (kb:ReturnNote text)
	    width  (kb:TextWidthValue)
	    nscale (rtos (kb:cannoscale) 2 1)) ;(if (not width)(setq width 96.0))
      (if (and key note)
	(progn
	  (command ".mleader"
            "_O" "_C" "_M"
            "_L" "_S"
            "_M" "2"
	    "_X" pause pause "." "")
	  (setq mleader (entlast))
	  (if
	    (= (vla-get-objectname (setq mleaderObj (vlax-ename->vla-object mleader)))
	       "AcDbMLeader")
	     (progn (vlax-put-property mleaderObj 'TextString note)
		    (vlax-put-property mleaderobj 'DoglegLength 0.125)
		    (vlax-put-property mleaderObj 'TextWidth width)
		    (kb:putKeyNotexdata (entlast) key note "NOTELEADER" nscale)))))))
  (princ))

;;;								;
;;;	Place a Keyed Note Only					;
;;;	Mtext Only						;
;;;								;
;;;pgp: kbPlaceTextNote,		*kbPlaceTextNote
(defun c:kbPlaceTextNote  (/ text key note lname ent nscale)
  (setq text (kb:GetKeynoteSelection))
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	  (kb:ReturnKey text)
		   note	  (kb:ReturnNote text)
		   nscale (rtos (kb:cannoscale) 2 1))
	     (vl-cmdf ".mtext" pause pause note "")
	     (setq ent (vlax-ename->vla-object (entlast)))
	     (if (= (vla-get-ObjectName ent) "AcDbMText")
	       (kb:putKeyNotexdata (entlast) key note "MTEXT" nscale)))))
  (princ))

;;;*01								;
;;;	Keynote Creating Routines				;
;;;								;

;;;	Return Style Dogleg Length				;

;;;--------------------------------------------------------------------;
;;;  This function builds two VARIANTS from the two parameters.        ;
;;;  The first parameter is a list specifying the DXF group codes, the ;
;;;  second list specifies the DXF values.                             ;
;;;  After converting the parameters into safearrays, this function    ;
;;;  creates two variants containing the arrays.                       ;
;;;--------------------------------------------------------------------;
(defun kb:BuildArrays  (DxfTypes dxfValues / ListLength	Counter	Code VarValue ArrayTypes
			ArrayValues VarTypes VarValues Result)
  ;; Get length of the lists
  (setq ListLength (1- (length DxfTypes)))
  ;; Create the safearrays for the dxf group code and value
  (setq	ArrayTypes  (vlax-make-safearray vlax-vbInteger (cons 0 ListLength))
	ArrayValues (vlax-make-safearray vlax-vbVariant (cons 0 ListLength)))
  ;; Set the array elements
  (setq Counter 0)
  (while (<= Counter ListLength)
    (setq Code	   (nth Counter DxfTypes)
	  VarValue (vlax-make-variant (nth Counter DxfValues)))
    (vlax-safearray-put-element ArrayTypes Counter Code)
    (vlax-safearray-put-element ArrayValues Counter VarValue)
    (setq counter (1+ counter))) ;_ end of while
  ;; Create the two VARIANTs
  (setq	VarTypes  (vlax-make-variant ArrayTypes)
	VarValues (vlax-make-variant ArrayValues))
  ;; Create a (Lisp) list which contains the two safearrays and
  ;; return this list.
  (setq Result (list VarTypes VarValues))
  Result) ;_ end of defun

;;;								;
;;;	putKeyNoteData:						;
;;;		KeyValue: the key - "01.001"			;
;;;(kb:putKeyNotexdata (car(entsel)) "99-002")			;
;;;	use:							;
;;;	(kb:putKeyNotexdata (car(entsel)) "99-002" "This is a test" "KeyLeader" "96.0")			;
(defun kb:putKeyNotexdata
       (entity key note typeflag insScale / VlaxEntity DxfTypes DxfValues)
  (setq VlaxEntity (vlax-ename->vla-object entity))
  (if (/= VlaxEntity nil)
    (progn (setq xdatas	(kb:BuildArrays
			  '(1001 1000 1000 1000 1000)
			  (list "kbKeynotes" key note typeflag insScale)))
	   (setq DxfTypes  (nth 0 xdatas)
		 DxfValues (nth 1 xdatas))
	   (vla-setXData VlaxEntity DxfTypes DxfValues)))
  (princ))

    ;(kb:getKeyNotexdata(car(entsel)))
(defun kb:getKeyNotexdata  (ename / myData key note objtype insScale)
  (setq myData (cadr (assoc -3 (entget ename (list "kbKeynotes")))))
  (if myData
    (setq key	   (cdr (nth 1 myData))
	  note	   (cdr (nth 2 myData))
	  objtype  (cdr (nth 3 myData))
	  insScale (cdr (nth 4 myData))))
  (list key note objtype insScale))



;;;								;
;;;	Keynote Editing						;
;;;								;

;;;(setq obj(vlax-ename->vla-object(car(entsel))))
;;;								;
;;;	Change Keynote						;
;;;								;
;;;	used for changing all 3 types				;
;;	of Keynotes: Inserts, Mtext, Mleader			;
;;;								;

(defun kb:ChangeKeynote
       (ent key note kbknflag / obj oldnote oldkey oldkey xkey xdata nscale)
  (setq	obj   (vlax-ename->vla-object (car ent))
	xdata (kb:getKeyNotexdata (car ent)))
  (if xdata
    (progn
      (setq oldkey  (nth 0 xdata)
	    oldnote (nth 1 xdata)
	    objType (nth 2 xdata)
	    nscale  (nth 3 xdata))
      (if (and oldkey oldnote objType nscale)
	(progn
	  (cond
	    ((= objType "KEYLEADER") ;It's a KeyNote
	     (vla-put-textstring obj key)
	     (vlax-put obj "color" acByLayer)
	     (kb:putKeyNotexdata (car ent) key note objType nscale)
	     (if kbknflag
	       (progn
		 (vlax-for
			obj  (kb:getactivespace)
		   (if (setq xkey (kb:getKeyNotexdata (vlax-vla-object->ename obj)))
		     (progn (if	(= objType (nth 2 xkey))
			      (progn (if (= oldKey (nth 0 xkey))
				       (progn (vla-put-textstring obj key)
					      (vlax-put obj "color" acByLayer)
					      (kb:putKeyNotexdata
						(vlax-vla-object->ename obj)
						key
						note
						objType
						nscale)))))))))))
	    ((or (= objType "NOTELEADER") (= objType "MTEXT")) ;It's a LeaderNote or Mtext
	     (vla-put-textstring obj note)
	     (vlax-put obj "color" acByLayer)
	     (kb:putKeyNotexdata (car ent) key note objType nscale)
	     (if kbknflag
	       (progn
		 (vlax-for
			obj  (kb:getactivespace)
		   (if (setq xkey (kb:getKeyNotexdata (vlax-vla-object->ename obj)))
		     (progn (if	(= objType (nth 2 xdata))
			      (progn (if (= oldKey (nth 0 xkey))
				       (progn (vla-put-textstring obj note)
					      (vlax-put obj "color" acByLayer)
					      (kb:putKeyNotexdata
						(vlax-vla-object->ename obj)
						key
						note
						objType
						nscale)))))))))))))))
    (alert "No XDATA"))
  (princ))

;;;									;
;;;		Keynote Chart Functions					;
;;;									;

;;;									;
;;;	Gather KeyChart Data						;
;;;									;
;;;	(setq ret(kb:ReturnKeyChartData))				;
;;;	(setq legend nil)						;
;;;									;
(defun kb:ReturnKeyChartData  (/ xdata legend obj cnt num ss)
  (prompt "\nSelect Keynotes for Chart or <ENTER> for all:")
  (setq ss (ssget '((-4 . "<OR") (0 . "MULTILEADER") (0 . "MTEXT") (-4 . "OR>"))))
  (if ss
    (progn (setq num (sslength ss)
		 cnt 0)
	   (while (< cnt num)
	     (setq xdata (kb:getKeyNotexdata (ssname ss cnt))
		   cnt	 (+ 1 cnt))
	     (if (and (= (nth 2 xdata) "KEYLEADER")
		      (/= (nth 0 xdata) "")
		      (/= (nth 1 xdata) ""))
	       (if (not (member (strcat (nth 0 xdata) "\t" (nth 1 xdata)) legend))
		 (setq legend
			(append legend (list (strcat (nth 0 xdata) "\t" (nth 1 xdata)))))))))
    (progn
      (vlax-for
	     obj  (kb:getactivespace)
	(setq xdata (kb:getKeyNotexdata (vlax-vla-object->ename obj)))
	(if (and (= (nth 2 xdata) "KEYLEADER")
		 (/= (nth 0 xdata) "")
		 (/= (nth 1 xdata) ""))
	  (if (not (member (strcat (nth 0 xdata) "\t" (nth 1 xdata)) legend))
	    (setq legend
		   (append legend (list (strcat (nth 0 xdata) "\t" (nth 1 xdata))))))))))
  (acad_strlsort legend))




;;;									;
;;;	Add Xdata to KeyNote Charts!!!!!				;
;;;									;
(defun kb:MakeKeynoteChart  (/ lst str lsst tabs dim mobj ent)
  (setq	lsst   (kb:ReturnKeyChartData)
	dim    (* (getvar "dimscale") 0.5) ;(getvar "dimscale")
	tabs   (strcat "\\pi-"
		       (vl-princ-to-string (fix dim))
		       ",l"
		       (vl-princ-to-string (fix dim))
		       ";{\\LKEYNOTES:}\\P\\pt" ;";\\pt"
		       )
	str    (strcat (vl-princ-to-string (fix dim)) ";")
	nscale (kb:cannoscale))
  (foreach i lsst (setq str (strcat str "\\P" i)))
  (if lsst
    (progn (setq str (strcat tabs str))
	   (command "_.mtext" pause pause "." "")
	   (setq ent  (entlast)
		 mobj (vlax-ename->vla-object ent))
	   (kb:putKeyNotexdata ent nil nil "KEYNOTELEGEND" nscale)
	   (vlax-put mobj "TextString" str))))



;;;(setq chart(car(entsel)))
;;; takes an entity
(defun kb:kn:UpdateChart  (chart / lst str lsst tabs chobj pt1 pt2 p dim mobj ent)
  (if chart
    (progn (setq chobj (vlax-ename->vla-object chart))
	   (if (and (= (vla-get-objectname chobj) "AcDbMText")
		    (= (nth 2 (kb:getKeyNotexdata chart)) "KEYNOTELEGEND"))
	     (progn (vla-GetBoundingBox chobj 'p1 'p2)
		    (setq lsst	 (kb:ReturnKeyChartData)
			  pt1	 (vlax-safearray->list p1)
			  pt2	 (vlax-safearray->list p2)
			  dim	 (* (getvar "dimscale") 0.5)
			  tabs	 (strcat "\\pi-"
					 (vl-princ-to-string (fix dim))
					 ",l"
					 (vl-princ-to-string (fix dim))
					 ";{\\LKEYNOTES:}\\P\\pt" ;";\\pt"
					 )
			  str	 (strcat (vl-princ-to-string (fix dim)) ";")
			  nscale (kb:cannoscale))
		    (foreach i lsst (setq str (strcat str "\\P" i)))
		    (if	lsst
		      (progn (vla-delete chobj)
			     (setq str (strcat tabs str))
			     (command "_.mtext" pt1 pt2 "." "")
			     (setq ent	(entlast)
				   mobj	(vlax-ename->vla-object ent))
			     (kb:putKeyNotexdata ent "" "" "KEYNOTELEGEND" nscale)
			     (vlax-put mobj "TextString" str))))))))


    ;(setq chobj(vlax-ename->vla-object(car(entsel))))
;;;pgp: kbUpdateALLCharts,		*kbUpdateALLCharts
(defun c:kbUpdateALLCharts  (/ lst str lsst tabs chobj pt1 pt2 p dim mobj ent)
  (setq lsst (kb:ReturnKeyChartData))
  (vlax-for
	 chobj	(kb:getactivespace)
    (if	(and (= (vla-get-objectname chobj) "AcDbMText")
	     (=	(nth 2 (kb:getKeyNotexdata (vlax-vla-object->ename chobj)))
		"KEYNOTELEGEND"))
      (progn (vla-GetBoundingBox chobj 'p1 'p2)
	     (setq pt1	  (vlax-safearray->list p1)
		   pt2	  (vlax-safearray->list p2)
		   dim	  (* (getvar "dimscale") 0.5)
		   tabs	  (strcat "\\pi-"
				  (vl-princ-to-string (fix dim))
				  ",l"
				  (vl-princ-to-string (fix dim))
				  ";{\\LKEYNOTES:}\\P\\pt" ;";\\pt"
				  )
		   str	  (strcat (vl-princ-to-string (fix dim)) ";")
		   nscale (kb:cannoscale))
	     (foreach i lsst (setq str (strcat str "\\P" i)))
	     (if lsst
	       (progn (vla-delete chobj)
		      (setq str (strcat tabs str))
		      (command "_.mtext" pt1 pt2 "." "")
		      (setq ent	 (entlast)
			    mobj (vlax-ename->vla-object ent))
		      (kb:putKeyNotexdata ent "" "" "KEYNOTELEGEND" nscale)
		      (vlax-put mobj "TextString" str)))))))




;;;							;
;;;		Utility Functions			;
;;;							;

;;;Return key and note
(defun kb:ReturnKey  (text / key)
  (setq key (substr text 1 5) ;limit the key to 5 characters "05.01"
        )
  key)
(defun kb:ReturnNote (text / note) (setq note (substr text (+ 7))) note)


;;;Retrieves the keynote file data
;;; use: (kb:getKeynoteFileData(strcat (kb:returnprojectdir) "\\Project.key"))
;;;(setq file nil div nil key nil)
(defun kb:getKeynoteFileData  (file / ofile tx iniLst keys div)
  (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx))))
  (close ofile)
  (foreach
	 i  inilst
    (if	(= (VL-STRING-POSITION (ascii "*") i) 0) ; it's a division
      (setq div (append div (list (vl-string-trim "*" i))))
      (setq keys (append keys (list i)))))
  (list div keys))

(defun kb:getKeynoteFileData  (file / ofile tx iniLst keys div)
  (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx))))
  (close ofile)
  (foreach
	 i  inilst
    (cond((= (VL-STRING-POSITION (ascii "*") i) 0) ; it's a division
      (setq div (append div (list (vl-string-trim "*" i)))))
         ((/= i "")
      (setq keys (append keys (list i))))
         )
    )
  (list div keys))
;;;							;
;;;		File Name dictionary			;
;;;							;
    ;(kb:ReturnKeynoteFilename)
(defun kb:ReturnKeynoteFilename	 (/ KeyFile)
  (setq KeyFile (findfile (strcat (kb:returnprojectdir) "\\Project.key")))
  KeyFile)


;;;								;
;;;		Dynamic Keynotes				;
;;;(setq ret(kb:getKeyNoteFileForSyncing(strcat (kb:returnprojectdir) "\\Project.key")))								;
(defun kb:getKeyNoteFileForSyncing  (file / ofile key note inilst ret)
  (prompt
    (strcat "\nOpening " (vl-filename-base file) ", please wait . . ."))
  (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx)))) ;_ eofwhile
  (close ofile)
  (foreach
	 i  inilst
    (if	(and i (/= i "")(/= i "--") (/= (VL-STRING-POSITION (ascii "*") i) 0))
      (progn (setq key	(kb:ReturnKey text)
		   note	(kb:ReturnNote text))
	     (setq ret (append ret (list (cons key note)))))))
  ret)

(defun kb:getKeyNoteFileForSyncing  (file / ofile key note inilst ret)
  (prompt
    (strcat "\nOpening " (vl-filename-base file) ", please wait . . ."))
  (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx)))) ;_ eofwhile
  (close ofile)
  (foreach
	 i  inilst
    (if	(and i (/= i "")(/= i "--") (/= (VL-STRING-POSITION (ascii "*") i) 0));it's not a division
      (progn (setq key	(kb:ReturnKey i);limit the key to 5 characters "05.01"
		   note	(kb:ReturnNote i))
	     (setq ret (append ret (list (cons key note)))))))
  ret)
;;;		Keynotes are linked to the .key file.		;
;;;		When the key file is edited or a drawing	;
;;;		is opened containing keynotes the user		;
;;;		will be prompted to update keynotes.		;
;;;		A command will also be available to update	;
;;;		keynotes "kbSyncKeynotes".			;
;;;								;
    ;(setq i(vlax-ename->vla-object(car(entsel))))
(defun kb:SyncKeynoteFiletoDrawing  (/ file data key oldnote newnote keytype xdata ent)
  (princ "\nSyncing Keynote File, please wait . . ..")
  (setq file (kb:ReturnKeynoteFilename))
  (if file
    (progn
      (setq data (kb:getKeyNoteFileForSyncing file))
      (vlax-for
	     i	(kb:getactivespace)
	(setq ent   (vlax-vla-object->ename i)
	      xdata (kb:getKeyNotexdata ent))
	(if (nth 2 xdata)
	  (progn
	    (setq nscale  (nth 3 xdata)
		  keyType (nth 2 xdata)
		  oldnote (nth 1 xdata)
		  key	  (nth 0 xdata)
		  newnote (cdr (assoc key data)))
    ;if there is no new note then the key doesn't exist in the file
	    (if	newnote
	      (cond
		((= keyType "KEYLEADER")
		 (if (not (eq oldnote newnote))
		   (progn (vla-put-textstring i key)
			  (vlax-put i "color" acbylayer)
			  (kb:putKeyNotexdata ent key newnote "KEYLEADER" nscale))
		   (vla-put-textstring i key)))
		((= keyType "NOTELEADER")
		 (if (not (eq oldnote newnote))
		   (progn (vla-put-textstring i newnote)
			  (vlax-put i "color" acbylayer)
			  (kb:putKeyNotexdata ent key newnote "NOTELEADER" nscale))
		   (vla-put-textstring i newnote)))
		((= keyType "MTEXT")
		 (if (not (eq oldnote newnote))
		   (progn (vla-put-textstring i newnote)
			  (vlax-put i "color" acbylayer)
			  (kb:putKeyNotexdata ent key newnote "MTEXT" nscale))
		   (vla-put-textstring i newnote)))) ;no new note - key no longer exists.
	      (cond ((= keyType "KEYLEADER")
		     (vlax-put i "color" acred)
		     (kb:putKeyNotexdata ent "" "" "KEYLEADER" ""))
		    ((= keyType "NOTELEADER")
		     (vlax-put i "color" acred)
		     (kb:putKeyNotexdata ent "" "" "NOTELEADER" ""))
		    ((= keyType "MTEXT")
		     (vlax-put i "color" acred)
		     (kb:putKeyNotexdata ent "" "" "MTEXT" ""))
		    ((= keyType "KEYNOTELEGEND") (vlax-put i "color" 165))))))))))

;;;Automatically sync file when routine is loaded
(if kb:SyncKeynoteFiletoDrawing
  (kb:SyncKeynoteFiletoDrawing))


;;;							;
;;;		Key Functions				;
;;;							;


;;; Find Function
;;;(setq x(vlax-ename->vla-object(car(entsel))))
(defun kb:findKeyNote  (keynumber / ss ent xdata key)
  (setq ss (ssadd))
  (vlax-for
	 x  (vla-get-ModelSpace (vla-get-activedocument (vlax-get-acad-object)))
    (setq ent	(vlax-vla-object->ename x)
	  xdata	(kb:getKeyNotexdata ent)
	  key	(nth 0 xdata))
    (if	(= key keynumber)
      (ssadd ent ss)))
  (if ss
    (sssetfirst ss ss))
  (princ))


;;;*02						;
;;;	Keynotes Dialog Control			;
;;;						;

;;;						;
;;;	Support Subs				;
;;;	(kb:TextWidthValue)			;

(defun kb:TextWidthValue  (/ rValue nValue ret)
  (cond	((dcl_Form_IsActive Palette_Main)
	 (Setq rValue (dcl_ComboBox_GetTBText Palette_Main_05TextWidthComboBox)))
	((dcl_Form_IsActive Palette_Main)
	 (Setq rValue (dcl_ComboBox_GetTBText Palette_Main_05TextWidthComboBox))))
  (cond	((= (strcase rValue) "NARROW") (setq nValue 1.25))
	((= (strcase rValue) "STANDARD") (setq nValue 2.5))
	((= (strcase rValue) "EXTENDED") (setq nValue 3.75))
	(t (setq nValue 4.0)))
  (setq ret (* nValue (kb:cannoscale)))
  ret)



;;;						;
;;;	MainKeynote Form			;
;;;						;
;;;pgp: kbUPKEY,		*kbUPKEY
(defun c:kbUPKEY  (/ text key note)
  (setq	text (dcl_ListBox_GetText
	       Palette_Main_05KeynoteslistBox
	       (dcl_ListBox_GetCurSel Palette_Main_05KeynoteslistBox)))
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(kb:ReturnKey text)
		   note	(kb:ReturnNote text))
	     (dcl_SetCmdBarFocus)
	     (if (setq ent (entsel))
	       (progn (if (kb:getKeyNotexdata (car ent))
			(kb:ChangeKeynote ent key note nil)
			(alert "That is not a Keynote object!")))))))
  (princ)
  (princ))

;;;pgp: kbUPALLKEY,		*kbUPALLKEY
(defun c:kbUPALLKEY  (/ text key note)
  (setq	text (dcl_ListBox_GetText
	       Palette_Main_05KeynoteslistBox
	       (dcl_ListBox_GetCurSel Palette_Main_05KeynoteslistBox)))
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(kb:ReturnKey text)
		   note	(kb:ReturnNote text))
	     (dcl_SetCmdBarFocus)
	     (if (setq ent (entsel))
	       (progn (if (kb:getKeyNotexdata (car ent))
			(kb:ChangeKeynote ent key note t)
			(alert "That is not a Keynote object!")))))))
  (princ)
  (princ))

(defun c:Palette_Main_05UpdateAllKeysButton_OnClicked  (/)
  (vla-sendcommand
    (vla-get-activedocument (vlax-get-acad-object))
    "kbUPALLKEY ")
  (princ)
  (princ))



;;;*03						;
;;;	Form 01	- Keynote Info			;
;;;						;
(defun c:Annotation_Xdata_SELECT_OnClicked  (/)
  (setq ent (entsel))
  (if ent
    (progn (setq xdata	 (kb:getKeyNotexdata (car ent))
		 key	 (nth 0 xdata)
		 note	 (nth 1 xdata)
		 objtype (nth 2 xdata))
	   (if (and key note objtype)
	     (progn (dcl_Control_SetCaption Annotation_Xdata_Key key)
		    (dcl_Control_SetCaption Annotation_Xdata_Note note)
		    (dcl_Control_SetCaption Annotation_Xdata_ObjectType objtype))
	     (dcl_MessageBox "That is not a Keynote!" "Select Keynote")))))
(defun c:Annotation_Xdata_CLOSE_OnClicked  (/)
  (dcl_Form_Close Annotation_Xdata)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\Annotation_Xdata"
    "isFloating"
    "false")
  (princ))

(defun c:Annotation_Xdata_OnDocActivated (/) (c:Annotation_Xdata_OnInitialize))
(defun c:Annotation_Xdata_OnEnteringNoDocState	(/)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\Annotation_Xdata"
    "isFloating"
    "true")
  (dcl_Form_Close Annotation_Xdata)
  (princ))
(defun c:Annotation_Xdata_OnInitialize	(/)
  (dcl_Control_SetCaption Annotation_Xdata_Key "")
  (dcl_Control_SetCaption Annotation_Xdata_Note "")
  (dcl_Control_SetCaption Annotation_Xdata_ObjectType ""))

;;;pgp: kbKEYinfo,		*kbKEYinfo
(defun c:kbKeyInfo (/) (c:Palette_Main_XDATA_OnClicked) (princ))


;;;						;
;;;	Form 03	- MainKeynote Palette		;
;;;						;

    ;(setq data nil)
(defun kb:Keynotes_OnInitialize	(/ file data)
  (dcl_Control_SetTop Palette_Main_05splitter 150)
  (dcl_ComboBox_Clear Palette_Main_05TextWidthComboBox)
  (dcl_ComboBox_AddList
    Palette_Main_05TextWidthComboBox
    (list "Narrow" "Standard" "Extended"))
  (dcl_ComboBox_SetCurSel Palette_Main_05TextWidthComboBox 1)
  (if (= (dcl_Control_GetValue Palette_Main_05LeaderNoteCheckbox) nil)
    (dcl_Control_SetEnabled Palette_Main_05TextWidthComboBox 0))
  (dcl_Control_Setcaption Palette_Main_05KeynotePreview "")
;;; Project specific keynote file
  (setq file (kb:ReturnKeynoteFilename))
  (if file
    (setq data (kb:getKeynoteFileData file)))
  (if data
    (progn (dcl_ListBox_Clear Palette_Main_05DivisionListBox)
	   (dcl_ListBox_AddList Palette_Main_05DivisionListBox (car data))
	   (dcl_ListBox_Clear Palette_Main_05KeynoteslistBox)
	   (dcl_ListBox_AddList Palette_Main_05KeynoteslistBox (cadr data)))
    (progn (dcl_ListBox_Clear Palette_Main_05KeynoteslistBox)
	   (dcl_ListBox_Clear Palette_Main_05DivisionListBox)))
  (princ)
  (princ))


(defun c:Palette_Main_05FixWidthButton_OnClicked  (/)
  (dcl_SetCmdBarFocus)
  (vla-sendcommand
    (vla-get-ActiveDocument (vlax-get-acad-object))
    "kbFixWidth "))


(defun c:Palette_Main_05XdataButton_OnClicked  (/)
  (if (not (dcl_Form_isactive Annotation_Xdata))
    (dcl_Form_show Annotation_Xdata))
  (princ))

(defun c:Palette_Main_05SwapButton_OnClicked  (/)
  (dcl_SetCmdBarFocus)
  (vla-sendcommand
    (vla-get-ActiveDocument (vlax-get-acad-object))
    "kbSwapKeyandNote "))


(defun c:Palette_Main_05LeaderNoteCheckbox_OnClicked  (nValue /)
  (if (= nValue 1)
    (progn (dcl_Control_SetValue Palette_Main_05NoteOnlyCheckbox 0)
	   (dcl_Control_SetEnabled Palette_Main_05TextWidthComboBox 1)
	   (dcl_Control_SetEnabled Palette_Main_05FixWidthButton 1)))
  (princ)
  (princ))


(defun c:Palette_Main_05NoteOnlyCheckbox_OnClicked  (nValue /)
  (if (= nValue 1)
    (progn (dcl_Control_SetValue Palette_Main_05LeaderNoteCheckbox 0)
	   (dcl_Control_SetEnabled Palette_Main_05TextWidthComboBox 0)
	   (dcl_Control_SetEnabled Palette_Main_05FixWidthButton 0)))
  (princ)
  (princ))


(defun c:Palette_Main_05DivisionListBox_OnSelChanged  (nSelection sSelText / div data keys)
  (setq	div  (substr sSelText 1 2)
	data (kb:getKeynoteFileData
	       (findfile (strcat (kb:returnprojectdir) "\\project.key"))))
  (if data
    (progn (if (= div "00")
	     (progn (dcl_ListBox_Clear Palette_Main_05KeynoteslistBox)
		    (dcl_ListBox_AddList Palette_Main_05KeynoteslistBox (cadr data)))
	     (progn (foreach
			   i  (cadr data)
			(if 
			  (= (substr i 1 2) div)
			   (setq keys (append keys (list i)))))
		    (if	keys
		      (progn (dcl_ListBox_Clear Palette_Main_05KeynoteslistBox)
			     (dcl_ListBox_AddList Palette_Main_05KeynoteslistBox keys)))))))
  (princ)
  (princ))



(defun c:Palette_Main_05KeynoteslistBox_OnSelChanged	(nSelection sSelText /)
  (dcl_Control_Setcaption Palette_Main_05KeynotePreview sSelText)
  (princ)
  (princ))


(defun c:Palette_Main_05MakeChartButton_OnClicked  (/)
  (dcl_SetCmdBarFocus)
  (kb:SyncKeynoteFiletoDrawing)
  (kb:MakeKeynoteChart)
  (princ)
  (princ))

(defun c:Palette_Main_05UpdateKeyChart_OnClicked  (/ chart)
  (dcl_SetCmdBarFocus)
  (kb:SyncKeynoteFiletoDrawing)
  (setq chart (car (entsel "\nSelect KeyChart: ")))
  (if chart
    (kb:kn:UpdateChart chart))
  (princ)
  (princ))

;(startapp
 ; "\"C://Program Files//Microsoft Office//Office//winword.exe\""
 ; (kb:ReturnKeynoteFilename)
 ; )
(defun c:Palette_Main_05EditKeyFileButton_OnClicked  (/ file)
  (setq file (kb:ReturnKeynoteFilename))
  (if file
    (startapp "explorer.exe" (vl-filename-directory file))
    )
  (princ)
  (princ))


(defun c:Palette_Main_05SyncroniseButton_OnClicked  (/ nSelection sSelText)
  (setq nSelection(dcl_ListBox_GetCurSel Palette_Main_05DivisionListBox))
  (if (not nSelection)(setq nSelection 0))
   (setq sSelText(dcl_ListBox_GetItemText Palette_Main_05DivisionListBox nSelection))
  (if (wcmatch
	(strcase (getvar "dwgprefix"))
	(strcase (strcat (kb:returnprojectdir) "*")))
    (progn (c:Palette_Main_05DivisionListBox_OnSelChanged nSelection sSelText) (kb:SyncKeynoteFiletoDrawing))
    (dcl_messagebox
      "This drawing is not a member of the active project!"
      "Synch Key Dawing"
      2
      1))
  (princ)
  (princ))


(defun c:Palette_Main_05UpdateKeyButton_OnClicked  (/)
  (vla-sendcommand
    (vla-get-activedocument (vlax-get-acad-object))
    "kbUPKEY ")
  (princ)
  (princ))

(defun c:Palette_Main_05UpdateAllKeysButton_OnClicked  (/)
  (vla-sendcommand
    (vla-get-activedocument (vlax-get-acad-object))
    "kbUPALLKEY ")
  (princ)
  (princ))

;;;pgp: kbAddMLeader,		*kbAddMLeader
(defun c:kbAddMLeader  (/)
  (princ "\nSelect MLeader: ")
  (command "_.mleaderedit" pause "_add")
  (princ)
  (princ))
;;;pgp: kbRemoveMLeader,		*kbRemoveMLeader
(defun c:kbRemoveMLeader  (/)
  (princ "\nSelect MLeader: ")
  (command "_.mleaderedit" pause "_remove")
  (princ)
  (princ))

(defun c:Palette_Main_05AddLeaderButton_OnClicked  (/)
  (vla-sendcommand
    (vla-get-activedocument (vlax-get-acad-object))
    "kbAddMLeader ")
  (princ)
  (princ))

(defun c:Palette_Main_05RemoveLeaderButton_OnClicked  (/)
  (vla-sendcommand
    (vla-get-activedocument (vlax-get-acad-object))
    "kbRemoveMLeader ")
  (princ)
  (princ))

(defun c:Palette_Main_05FindButton_OnClicked  (/ text key)
  (setq	text (dcl_ListBox_GetText
	       Palette_Main_05KeynoteslistBox
	       (dcl_ListBox_GetCurSel Palette_Main_05KeynoteslistBox)))
  (if (and text (/= text ""))
    (if	text
      (progn (setq key (kb:ReturnKey text))
	     (kb:findkeynote key))))
  (princ)
  (princ))


(defun c:Palette_Main_05KeynoteslistBox_OnDblClicked	(/ text nflag lflag doc)
  (setq	text  (dcl_ListBox_GetText
		Palette_Main_05KeynoteslistBox
		(dcl_ListBox_GetCurSel Palette_Main_05KeynoteslistBox))
	lflag (dcl_Control_GetValue Palette_Main_05LeaderNoteCheckbox)
	nflag (dcl_Control_GetValue Palette_Main_05NoteOnlyCheckbox)
	doc   (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if (and text (/= text ""))
    (progn (dcl_SetCmdBarFocus)
	   (cond ((and (or (and (= nflag 1) (= lflag 0)) (and (= nflag t) (= lflag nil))))
		  (vla-sendcommand doc "kbPlaceTextNote "))
		 ((and (or (and (= nflag 0) (= lflag 1)) (and (= nflag nil) (= lflag t))))
		  (if (> (atoi(substr (getvar "ACADVER") 1 4)) 16)
		  (vla-sendcommand doc "kbPlaceNote ")
                    (vla-sendcommand doc "kbPlaceNoteQleader "))
                    )
		 ((and
		    (or (and (= nflag 0) (= lflag 0)) (and (= nflag nil) (= lflag nil))))
                  (if (> (atoi(substr (getvar "ACADVER") 1 4)) 16)
		  (vla-sendcommand doc "kbPlaceKeyNote ")
                    (vla-sendcommand doc "c:kbPlaceKeyNoteQleader "))
                    ))))
  (princ)
  (princ))



(princ "\nKeynotes loaded!")
(princ)


;;; 						;
;;;	Append Dimension Text			;
;;;						;

(defun kb:SelDim (/ ExLoop RetVal TmpVal)
  (while (not ExLoop)
    (setvar "ERRNO" 0)
    (setq RetVal (entsel "\nSelect a dimension to Restore text"))
    (cond
      ((= (getvar "ERRNO") 7) (princ "1 selected, 0 found. "))
      ((= (getvar "ERRNO") 52) ; enter
       (setq ExLoop T))
      ((and
	 (setq TmpVal (entget (car RetVal))) ; object type
	 '("DIMENSION")
	 (not (member (cdr (assoc 0 TmpVal)) (mapcar 'strcase '("DIMENSION"))))
       ) ; wrong type
       (princ
	 (strcat
	   "\nselected object is not of the type: "
	   (apply 'strcat
		  (cons
		    (car '("DIMENSION"))
		    (mapcar '(lambda (l) (strcat " or " l)) (cdr '("DIMENSION")))
		  ))". ")))
      ((and
	 (setq TmpVal (cdr (assoc 8 TmpVal)) ;layer name
	       TmpVal (entget (tblobjname "LAYER" TmpVal)))
	 (= (logand 4 (cdr (assoc 70 TmpVal))) 4))
       (princ "\nselected object is on a locked layer. "))
      ((setq ExLoop T)) ; good pick
    )
  )
  RetVal ; return value
)


(defun c:kbRestoreDimText(/ *Error* ent textobj)
  (defun *Error* (Msg)
    (cond  ((or (not Msg)
	   (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
           ((princ (strcat "\nError: " Msg))))
    ; re-sets go here
    (redraw)
    (princ)
  )
  (setq ent (kb:SelDim))
  (while ent
    (setq textobj(vlax-ename->vla-object (car ent)))
    (vla-put-TextOverride textobj "<>")
    (setq ent (kb:SelDim))
  )
  (princ)
)


(defun kb:AppendDims (prefix suffix under / *Error* string textobj)
  (defun *Error* (Msg)
    (cond  ((or (not Msg)
	   (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
           ((princ (strcat "\nError: " Msg))))
    ; re-sets go here
    (redraw)
    (princ)
  )
  (setq ent (kb:SelDim))
  (while ent
    (if	prefix
      (setq string (strcat prefix " <>"))
      (setq string "<>")
    )
    (if suffix
      (setq string(strcat string " " suffix)))

    (if under
    (setq string (strcat string"\\X" under)))


    (setq textobj(vlax-ename->vla-object (car ent)))
    (vla-put-TextOverride textobj string)
    (setq ent (kb:SelDim))
  )
  (princ)
)


;;;								;
;;;	OpenDCL Control Subs					;
;;;								;


(defun c:Annotation_AppendDims_OnEnteringNoDocState ( /)
     (dcl_form_close Annotation_AppendDims)
)


(defun c:Annotation_AppendDims_OnInitialize ( /)
     (if kb%PFX(dcl_Control_SetProperty Annotation_AppendDims_PFX "Text" kb%PFX))
  (if kb%SFX(dcl_Control_SetProperty Annotation_AppendDims_SFX "Text"kb%SFX))
  (if kb%UFX(dcl_Control_SetProperty Annotation_AppendDims_UFX "Text"kb%UFX))
)


(defun c:Annotation_AppendDims_SELECT_OnClicked ( /)
  (dcl_SetCmdBarFocus )
     (setq kb%SFX(dcl_Control_GetProperty Annotation_AppendDims_SFX "Text")
	kb%PFX(dcl_Control_GetProperty Annotation_AppendDims_PFX "Text")
        kb%UFX(dcl_Control_GetProperty Annotation_AppendDims_UFX "Text"))
  (kb:AppendDims kb%PFX kb%SFX kb%UFX)
)



(defun c:Annotation_AppendDims_REST_OnClicked ( /)
  (dcl_SetCmdBarFocus )
  (c:kbRestoreDimText)
)


(defun c:Annotation_AppendDims_CL_OnClicked ( /)
     (dcl_Form_Close Annotation_AppendDims)
)

(defun c:kbAppendDims (/)
  (setvar "cmdecho" 0)
  (if (not (member "Annotation" (dcl_GetProjects)))
    (dcl_Project_load "Annotation")
    )
  (if dcl_HideErrorMsgBox
    (progn (if (not (dcl_Form_IsActive Annotation_AppendDims))
	     (dcl_Form_Show Annotation_AppendDims)
	     )
	   )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  ) 

;;; 						;
;;;	General Annotation Related		;
;;;	Commands				;
;;;						;


;;;							;
;;;	Mleader Commands				;
;;;							;
;Enter an option [Leader type/leader lAnding/Content type/Maxpoints/First 
;angle/Second angle/eXit options] <eXit options>: l

;Select a leader type [Straight/sPline/None] <Straight>:
(defun kb:MleaderwithText( / width mleader mleaderobj)
  (setq width(kb:TextWidthValue)
 mleader (entlast))
	  (if
	    (= (vla-get-objectname (setq mleaderObj (vlax-ename->vla-object mleader)))
	       "AcDbMLeader")
	     (progn (vlax-put-property mleaderobj 'DoglegLength 0.125)
		    (if width(vlax-put-property mleaderObj 'TextWidth width))
            (command "ddedit" mleader""))
            )
  (princ)(princ))

(defun c:kbLeaderText( / width mleader mleaderobj)
  (command ".mleader"
           "_O" "_C" "_M"
           "_L" "_S"
           "_M" "2"
	   "_X" pause pause "." "")
  
  (kb:MleaderwithText)
  (princ)(princ))


(defun c:kbSplineLeaderText( / )
  (command ".mleader"
           "_O" "_C" "_M"
           "_L" "_P"
           "_M" "2"
	   "_X" pause pause "." "")
  (kb:MleaderwithText)
  (princ)(princ))
  
  
(defun c:kbLeader( / )
  (command ".mleader"
           "_O" "_C" "_N"
           "_L" "_S"
	   "_M" "2"
	   "_X")
  (princ)(princ))

(defun c:kbSplineLeader( / )
  (command ".mleader"
           "_O" "_C" "_N"
           "_L" "_P"
	   "_M" "2"
	   "_X")
  (princ)(princ))

(defun c:kbCenterLineSymb  (/ p dim p2 mt1 mt2)
  (setq	p   (getpoint "\nSelect text location: ")
	dim (getvar "dimscale")
	p2  (list (- (* 0.03125 dim) (car p))
		  (- (* 0.046875 dim) (cadr p))
		  (caddr p)))
  (if p
    (progn (setq mt1 (vla-addmtext (kb:getactivespace) (vlax-3d-point p) 1.0 "C")
		 mt2 (vla-addmtext (kb:getactivespace) (vlax-3d-point p) 1.0 "L"))
	   (vla-put-height mt1 (getvar "textsize"))
	   (vla-put-height mt2 (getvar "textsize"))
	   (vla-put-insertionpoint mt2 (vlax-3d-point p2)))))




(defun c:kbReplaceText	(/ *Error* string clone clone-ent ss cnt num e new_txt)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg)))) ;_ closes cond
    ; re-sets go here
    (if	clone
      (redraw (car clone) 4))
    (princ))
  (setq clone (kb:EntSel "\nSelect text to clone: " nil nil '("TEXT" "MTEXT") nil))
  (if clone
    (progn (redraw (car clone) 3)
	   (setq clone-ent (car clone))
	   (if (if (or (= (cdr (assoc 0 (entget clone-ent))) "TEXT")
		       (= (cdr (assoc 0 (entget clone-ent))) "MTEXT"))
		 T
		 nil)
	     (progn (setq string (cdr (assoc 1 (entget clone-ent)))
			  ss	 (ssget '((-4 . "<OR") (0 . "TEXT") (0 . "MTEXT") (-4 . "OR>"))))
		    (if	ss
		      (progn (redraw (car clone) 4)
			     (setq num (sslength ss)
				   cnt 0)
			     (while (< cnt num)
			       (setq e	     (ssname ss cnt)
				     ent     (entget e)
				     new_txt (subst (cons 1 string) (assoc 1 ent) ent))
			       (entmod new_txt)
			       (princ "\nText Replaced!")
			       (princ)
			       (setq cnt (1+ cnt)))
			     (princ "  Done... "))
		      (princ "  Nothing selected. ")))
	     (princ "  That's not TEXT or MTEXT! "))))
  (princ))


(defun c:kbRestoreDimText  (/ *Error* ent)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg)))) 
    
    (redraw)
    (princ))
  (setq	ent (kb:EntSel
	      "\nSelect a dimension to Restore text" nil nil '("DIMENSION") nil))
  (while ent
    (vlax-put-property
      (vlax-ename->vla-object (car ent))
      'TextOverride
      "<>")
    (setq ent (kb:EntSel
		"\nSelect a dimension to Restore text" nil nil '("DIMENSION") nil)))
  (princ))


;;;
;;; Creates a line on the active dim layer with the active
;;; dimstyle properties for an extension line
;;;

(defun c:kbDimLine  (/ *Error* clayer lcolor lwht p1 p2)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg)))) 
    
    (princ))
  (setq	cspace (kb:getactivespace)
	clayer (kb:SetLayerKey "DIMLINE")
	lcolor (getvar "DIMCLRE")
	lwht   (getvar "DIMLWE")
	p1     (getpoint "\nSelect first Extended Extension Line point: ")
	p2     (getpoint p1 "\nNext point: "))
  (if p2
    (progn (setq lineobj (vla-addline cspace (vlax-3d-point p1) (vlax-3d-point p2)))

      (vlax-put-property lineobj 'layer clayer)
      (vlax-put-property lineobj 'color lcolor)
	   (vlax-put-property lineobj 'lineweight lwht))
    (princ "\nOk, maybe later . . ."))
  (*Error* nil)
  (princ))


(defun c:kbCopyEdit  (/ *error* ent)
  (defun *Error*  (Msg)
    (cond
      ((or (not Msg)
	   (member Msg
		   '("console break"
		     "Function cancelled"
		     "quit / exit abort"))))
      ((princ (strcat "\nError: " Msg))))
    (princ)
    )
  (setvar "cmdecho" 0)
  (princ "\nSelect entities to Copy: ")
  (setq	ent (kb:entsel
	      "\nSelect text to Copy & Edit: "
	      nil
	      nil
	      (list "TEXT" "MTEXT")
	      nil))
  (while ent
    (progn
      (command "_.copy" ent "" (cdr (assoc 10 (entget (car ent)))) pause)
      (command "_.ddedit" (entlast))
      (vl-cmdf)
      (setq ent	(kb:entsel
		  "\nSelect text to Copy & Edit: "
		  nil
		  nil
		  (list "TEXT" "MTEXT")
		  nil))
      )
    )
  (princ)
  (princ)
  )


;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
