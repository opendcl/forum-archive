﻿namespace SyntaxCrawler
{
  partial class CrawlerDialog
  {
    /// <summary>
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Vom Windows Form-Designer generierter Code

    /// <summary>
    /// Erforderliche Methode für die Designerunterstützung.
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CrawlerDialog));
      this.txtFolder = new System.Windows.Forms.Label();
      this.edtFolder = new System.Windows.Forms.TextBox();
      this.pbFolder = new System.Windows.Forms.Button();
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.pbFunction = new System.Windows.Forms.Button();
      this.txtFunctions = new System.Windows.Forms.Label();
      this.lstFunctions = new System.Windows.Forms.ListBox();
      this.lstSyntax = new System.Windows.Forms.ListBox();
      this.txtSyntax = new System.Windows.Forms.Label();
      this.pbSyntax = new System.Windows.Forms.Button();
      this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.SuspendLayout();
      // 
      // txtFolder
      // 
      this.txtFolder.AutoSize = true;
      this.txtFolder.Location = new System.Drawing.Point(14, 20);
      this.txtFolder.Name = "txtFolder";
      this.txtFolder.Size = new System.Drawing.Size(95, 15);
      this.txtFolder.TabIndex = 0;
      this.txtFolder.Text = "Reference Folder";
      // 
      // edtFolder
      // 
      this.edtFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.edtFolder.Location = new System.Drawing.Point(125, 16);
      this.edtFolder.Name = "edtFolder";
      this.edtFolder.ReadOnly = true;
      this.edtFolder.Size = new System.Drawing.Size(330, 23);
      this.edtFolder.TabIndex = 1;
      // 
      // pbFolder
      // 
      this.pbFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.pbFolder.Location = new System.Drawing.Point(461, 14);
      this.pbFolder.Name = "pbFolder";
      this.pbFolder.Size = new System.Drawing.Size(27, 27);
      this.pbFolder.TabIndex = 2;
      this.pbFolder.Text = "...";
      this.pbFolder.UseVisualStyleBackColor = true;
      this.pbFolder.Click += new System.EventHandler(this.pbFolder_Click);
      // 
      // splitContainer1
      // 
      this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.splitContainer1.Location = new System.Drawing.Point(12, 45);
      this.splitContainer1.Name = "splitContainer1";
      this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.txtFunctions);
      this.splitContainer1.Panel1.Controls.Add(this.lstFunctions);
      this.splitContainer1.Panel1.Controls.Add(this.pbFunction);
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.pbSyntax);
      this.splitContainer1.Panel2.Controls.Add(this.lstSyntax);
      this.splitContainer1.Panel2.Controls.Add(this.txtSyntax);
      this.splitContainer1.Size = new System.Drawing.Size(476, 260);
      this.splitContainer1.SplitterDistance = 130;
      this.splitContainer1.TabIndex = 6;
      // 
      // pbFunction
      // 
      this.pbFunction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.pbFunction.Image = ((System.Drawing.Image)(resources.GetObject("pbFunction.Image")));
      this.pbFunction.Location = new System.Drawing.Point(449, 100);
      this.pbFunction.Name = "pbFunction";
      this.pbFunction.Size = new System.Drawing.Size(27, 27);
      this.pbFunction.TabIndex = 7;
      this.toolTip1.SetToolTip(this.pbFunction, "Export functions");
      this.pbFunction.UseVisualStyleBackColor = true;
      this.pbFunction.Click += new System.EventHandler(this.pbFunction_Click);
      // 
      // txtFunctions
      // 
      this.txtFunctions.AutoSize = true;
      this.txtFunctions.Location = new System.Drawing.Point(3, 3);
      this.txtFunctions.Name = "txtFunctions";
      this.txtFunctions.Size = new System.Drawing.Size(59, 15);
      this.txtFunctions.TabIndex = 6;
      this.txtFunctions.Text = "Functions";
      // 
      // lstFunctions
      // 
      this.lstFunctions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.lstFunctions.FormattingEnabled = true;
      this.lstFunctions.IntegralHeight = false;
      this.lstFunctions.ItemHeight = 15;
      this.lstFunctions.Location = new System.Drawing.Point(113, 3);
      this.lstFunctions.Name = "lstFunctions";
      this.lstFunctions.ScrollAlwaysVisible = true;
      this.lstFunctions.Size = new System.Drawing.Size(330, 124);
      this.lstFunctions.Sorted = true;
      this.lstFunctions.TabIndex = 5;
      // 
      // lstSyntax
      // 
      this.lstSyntax.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.lstSyntax.FormattingEnabled = true;
      this.lstSyntax.IntegralHeight = false;
      this.lstSyntax.ItemHeight = 15;
      this.lstSyntax.Location = new System.Drawing.Point(113, 3);
      this.lstSyntax.Name = "lstSyntax";
      this.lstSyntax.ScrollAlwaysVisible = true;
      this.lstSyntax.Size = new System.Drawing.Size(330, 120);
      this.lstSyntax.Sorted = true;
      this.lstSyntax.TabIndex = 9;
      // 
      // txtSyntax
      // 
      this.txtSyntax.AutoSize = true;
      this.txtSyntax.Location = new System.Drawing.Point(3, 3);
      this.txtSyntax.Name = "txtSyntax";
      this.txtSyntax.Size = new System.Drawing.Size(41, 15);
      this.txtSyntax.TabIndex = 8;
      this.txtSyntax.Text = "Syntax";
      // 
      // pbSyntax
      // 
      this.pbSyntax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.pbSyntax.Image = ((System.Drawing.Image)(resources.GetObject("pbSyntax.Image")));
      this.pbSyntax.Location = new System.Drawing.Point(449, 96);
      this.pbSyntax.Name = "pbSyntax";
      this.pbSyntax.Size = new System.Drawing.Size(27, 27);
      this.pbSyntax.TabIndex = 10;
      this.toolTip1.SetToolTip(this.pbSyntax, "Export syntax");
      this.pbSyntax.UseVisualStyleBackColor = true;
      this.pbSyntax.Click += new System.EventHandler(this.pbSyntax_Click);
      // 
      // CrawlerDialog
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(500, 317);
      this.Controls.Add(this.splitContainer1);
      this.Controls.Add(this.pbFolder);
      this.Controls.Add(this.edtFolder);
      this.Controls.Add(this.txtFolder);
      this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "CrawlerDialog";
      this.Text = "SyntaxCrawler";
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel1.PerformLayout();
      this.splitContainer1.Panel2.ResumeLayout(false);
      this.splitContainer1.Panel2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
      this.splitContainer1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label txtFolder;
    private System.Windows.Forms.TextBox edtFolder;
    private System.Windows.Forms.Button pbFolder;
    private System.Windows.Forms.SplitContainer splitContainer1;
    private System.Windows.Forms.Label txtFunctions;
    private System.Windows.Forms.ListBox lstFunctions;
    private System.Windows.Forms.ListBox lstSyntax;
    private System.Windows.Forms.Label txtSyntax;
    private System.Windows.Forms.Button pbFunction;
    private System.Windows.Forms.ToolTip toolTip1;
    private System.Windows.Forms.Button pbSyntax;
  }
}

