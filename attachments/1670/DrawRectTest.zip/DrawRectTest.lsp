(defun c:DrawRectTest ()
  (command "_Opendcl")
  (dcl_Project_Load "DrawRectTest" 'T)
  (dcl_Form_Show DrawRectTest_Form1)
)

(defun c:DrawRectTest_Form1_OnInitialize (/)
  (print "c:DrawRectTest_Form1_OnInitialize")
  (DrawRectangles)
)


(defun c:DrawRectTest_Form1_PictureBox1_OnPaint (HasFocus /)
  (print "c:DrawRectTest_Form1_PictureBox1_OnPaint")
  (DrawRectangles)
)

(defun DrawRectangles ()
  (dcl_PictureBox_DrawSolidRect DrawRectTest_Form1_PictureBox1 '((0 0 120 80 -16)))
  (dcl_PictureBox_DrawRect DrawRectTest_Form1_PictureBox1 '((5 5 74 49 0)))
  (dcl_PictureBox_DrawRect DrawRectTest_Form1_PictureBox1 '((40 25 74 49 0)))
)

(princ "\nUse DrawRectTest to start ")
(princ)
