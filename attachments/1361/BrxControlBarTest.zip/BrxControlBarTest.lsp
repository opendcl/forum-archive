;;launch control bar test
(defun c:CBTEST ( / )
	;load opendcl
  (command "OPENDCL")
	;import project
	(dcl_project_load "BrxControlBarTest" T)
	;show the form
	(dcl_Form_Show BrxControlBarTest_ControlBarTest1)
);endfun