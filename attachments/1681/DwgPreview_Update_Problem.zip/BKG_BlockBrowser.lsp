(setvar 'cmdecho 0)
(vl-cmdf "_Opendcl")
(setvar 'cmdecho 1)

(defun c:BKG_BlockBrowser
  (
  
  /
    c:BkgBlockBrowser_Main_OnInitialize
  )
  (defun c:BkgBlockBrowser_Main_OnInitialize ()
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView0 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView1 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView2 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView3 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView4 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView5 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView6 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView7 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_SlideView8 'T)
  
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview0 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview1 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview2 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview3 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview4 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview5 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview6 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview7 nil)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview8 nil)
    
    (dcl_DWGPreview_LoadDwg BkgBlockBrowser_Main_DwgPreview0 "A000.dwg")
    (dcl_DWGPreview_LoadDwg BkgBlockBrowser_Main_DwgPreview1 "A001.dwg")
  )
  (defun c:BkgBlockBrowser_Main_btnReload_OnClicked ()
    ; (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview0 nil) ; required for ODCL 7.0.0.1
    (dcl_DWGPreview_LoadDwg BkgBlockBrowser_Main_DwgPreview0 "A002.dwg")
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview0 'T)
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview1 nil) ; required for ODCL 7.0.0.1
    (dcl_DWGPreview_LoadDwg BkgBlockBrowser_Main_DwgPreview1 "A003.dwg")
    (dcl_Control_SetVisible BkgBlockBrowser_Main_DwgPreview1 'T)
  )

  (dcl_Project_Load "BkgBlockBrowser" 'T)
  (dcl_Form_Show BkgBlockBrowser_Main)
  (princ)
)
