
<?php

//get variables from URL
$myFile = $_GET['file'];
$temp1 = $_GET['temp1'];
$temp2 = $_GET['temp2'];

//Open file & write to it
$fh = fopen($myFile, 'w') or die("can't open file");
$stringData = $temp1 . "/t";
fwrite($fh, $stringData);
$stringData = $temp2 . "/t";
fwrite($fh, $stringData);
fclose($fh);

//echo variables for debugging in the browser, not returned to Lisp
echo $myFile . "/t";
echo $temp1 . "/t";
echo $temp2 . "/t";

?>
