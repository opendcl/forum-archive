;;;							;
;;;	Layer Commands					;
;;;	include files:					;
;;;	Layers_LayerStates				;
;;;(setq xreflist nil doclist nil dbxllist nil)
(vl-load-com)

(if (not (vl-bb-ref 'kbLayerTools))
  (vl-bb-set
    'kbLayerTools
    (dcl_project_import
      '("YWt6AzpgAABk/qsMBuKTJRUWIjtqQM8TxBdIA4e+1B6q2HFL5BKNFgKquCiv5sgX1dZW5rMYrdin"
"WF8jy+j89SpvUzg/VHu7QXRcFGsCaF87P5RhJb/hPAGGWZ6N6Xohj+INCZHDDZiQksOno0rloLej"
"owUYsOJHTQ3ATQ2x41LlgBFkzOGUEPa9Le76T0Z+aX++p7t+SysG/fvVJV940ybGb0g+fIFk33MN"
"JI6t9qFT5qX5CQ+alrmFOBa8oUZKnRFsAUleOUWgiSfzM+26ZnIeN2UAyV8xbaiXPhcP2jccQZgk"
"bOXOGGWgu8wJs7ap+mIPqttjFSg9U3dbO+meedD+NmuVsXf16ERjpXMXwjGdg3+W/29m+7bBVr40"
"K1pYjMTe4W6KXz8xdYQ5P0HXrtVtDnXGeYRPTheJZpL+H8ZpQf3mQfbbV4JA+mLvqTpFOWsEkzKk"
"p/iJ8R0g7JHgnsei/41Pfu/BOxV5ewNkKJg4QkWK7yPOTuk7DW0H5AFGM9x7OsD8OzSHNNkC6pZ7"
"KxSDseIM6IH33kELlgDcQQiWrTqBnZa9gqlXOMyWEJKMZpI5jfQC1eo+GuNU97PzMvOz0z3kJdOJ"
"PgVzrztuz6sPc7EhSkJ145+fjGMwh1s6oZyu1fYQaaOFLq5h95cmXBZHY7002dylzk2Lhqf14zef"
"IUMSu5FDbkeXlo9Vl5PkuDk3sE+vsCNuK4rEKjId8ebItd4oV/H3AMt2h0X7wnMcYiU7g+HrACCo"
"9whhOfLbjsVxwe2mLRk8latXE24TE2lYAuE9zRCj/AHlVpFsm2PcEaxOqfQMH9bvRHvbMz8D/AnX"
"m1XIjJYSHwHq/l+Ia+9tvFXCUZZxeoPg3i0IAcZh718/kcmFKYtZp6T2VqFZlnn7gml7g87e6XWE"
"Lz+BFPHBO4GZyrmdgeUWgWkm0q7VO4Oh44CuaUVo1L9owSBE6PtxnzJat2WFCVtas5NEJrMUqyGT"
"GDZZD2StFp4IXc2eXuj/+f1Wmm4ifoFiSn6h34hY8NiUitdgcwXmyzIOMOzXSpio3Wdx3XdZr45X"
"SbNLrVaXV9Y9OQFl5IVmEpy7T7OiFyb1KsN81uVq6a511DUmcNQ1nqBnInytIxyQPtL0FfoFdZ5c"
"JuHWHJwV/MT2orYkMD/G/cRMvSW8B8iet3XmeLHkMMgFiZZ7flQR97I+I6zne+isumL+l2nevOqH"
"I07jWAdUMtHHYUtmGn5Dt9UTVHW/eqBDsD7SmaMQNP/RrI1c3rhDRsEuxV9WqgqNxB4+OWILOtPv"
"3iWYCIlHRZeYw2WbeXveH60zqwPQ4jsSw+fBeu4jNAwQbgwj7ps5dmkaQXhrzHn3UIkkaH4+yf94"
"3sfJo2quzjPpWD1Jo9tE3hm1DsMp7HROpRk/S6VT3uSTuy7ip4QkaXzmE20q4KekX8F/Fpl+ZXuC"
"hA4XzzwOg2LoFf8olr4sdK7LXctPZYz1HxBsR0ROWfjhaMINPAB9VtfnjW3mMR+8GJrzzeJoIMBs"
"Us/rJRM65FqJXylVrGX+lMkcByPf7iHzHaZxjEgc1qZua43FUus9MltyL8M9Cjc8KlLXxtaYS9jD"
"NxA+DQ/+b+LqMCB8eUcI7MiIXxQiqmbxKlugu3Eg6jGFv0POYyXOJA8IO3vc0imFEbM5Eku+FkZv"
"KtlpQmQUCoik5zZyZO0b9u5DTzoQ6G4nPEWORpDAkTqHFwB2YHDMkoJfYCbEPyUYsKHszFYBEucJ"
"QPj5Z1QOUU8RbwOioMokBCOXrjcu6d7pP/U3VjVstQlTN8MuojD0l341bIlBRG0OBGfymV22YiGe"
"GJvv+1oOZjF9IIqQEpL3IvN8QAsoqIXl6wKsvOevGVgKEQ5H1pDzo+u/w3P8lKBwvaIJEUh+Ry7Z"
"f048vk5+0b+BlGJ8UHpi5n8JXdb+HX5nfkl+VJ6IPHt/8P0KZJ4U0nPVfwy4iXAQtjdHX5Y8rv9w"
"xLPe/PA/Gn5j6cU+CUEqbpZGwtYRTWE+HtqGxwfWeqWyAqw8fvh+emP+ct5gP2V+xnkqfhD4dHxe"
"w5GKds4KaXjhsVkRUTdfjjye/3BCILcEeu5yvqV5VI4GxSRXvt2pR0SOlAiPFaZPAAXAqXrBlYO/"
"UcHCbvpfdj95H3gqbtB9TXaHG64wX8H6XhqDtH+8awY9YcYqJYMIG7E7uodbcOPsFlCY00jBuwjn"
"NGmG5gSp6g8Dva88ABVYsXDF+OKdGKX713iOBdIhbz0whKd5sQduy/2ZC5QvfEQj6zgRS3x59UcC"
"UHngedzy+bHnwXo5d4arBW/5sadeNAaG4rUle8F/nSn/FA6JfuKpfZtCYJSfzDjBxakCGGdgW8mX"
"DMP93G1PhGjXyG04j/EwSemWi1Hp1TWJXNnvNCK6xyOXbnL1RuEMC0d+gHFufb4FPntGlU31OZRI"
"bNOQ+amHfcrJj/oFn77ZKWkRv49lPTVmzYBpz7ww9OuO7lyRFpm0sKGbWoa+3p8+nBh+Q65Sfbcb"
"ekOteK4NB87JS8slRq4FvgJEv9nVjuhrxPSOz0cpkHyt1d7894dzVZAAjqYMsY+5GAQC3TeTmYxk"
"JsaV2aQpuMElj7gxjlCiiYewKmTeE3++46WW5SxlJn/6m6cxa0H8HyR+JEQLH9klyyruoT4oegHe"
"gLCFOrY06Hsn2bGATonRJg2ycaXYpUljQQhiUUYPvMS/4gKyI4ks1lMIiAXCjmdZBX3+hweHubnv"
"Lce4uY2PYQeY9hqYdY0LmO+f79BRMByXViEQALK5LCNnNRNVx4dPoS1bNeFtAmuqedE6IXxYWNqA"
"bW3mkbehrq7+3ckUDGxRmrKgfh4AwFcmC4fU3VFiu3Ww480QTrmxOjndryznaF8VHoBe1f/tMRj6"
"q7rpTv9WjvlRkqrFkY4ooSGR7pOFkZ6zXoLdgfDxXLQCjsHziOe3GrNM7bcZ6KiLs6mhYt/z8rXs"
"8zPCAZaOkKAg+8HJiY7fvYeGYSfBYAcEhoytek5mWwaNjUnCikwyMODn4EAdTeFHHeAWZOKhgSYP"
"kGIg9lFBtvRAiYKNr1YgW79pXxXxfyer8tIUcRpTDV+V0sN146ujHng5UTGMmhllisCY+QI14AGH"
"/KE1PV/OUoIQgy8ZfYFXyy2HeCgRu051QG1f+3xSa/dqQ3sUZEfZ2B60CWsVFIJJT12H5/yoG9sy"
"8KcZa5gJ1GpOHuvHHmvfMj/r2Hy0qdWGZ9xXQEvuV+9LbCx4mXEs/NjyQUNTCerLYdAcDi5I8SUA"
"2O59svQLA2mqRz024qylbLLoQCeYMsj0xVG7tuH3gL+5Wa6GlSTrWm8siCtILBI1rlExAIqNf4k2"
"aegC0OwP6XQMiIcT4GK4TRgY2XRZQbJ7bV8btv7qThTT2j5fJ0klrlYPv1SbmEFrLgHlU3InJffu"
"63Tvm0l7OyjeiT//INfq5UHWgNz0YZiH43YnhT0a60ALD6yRdSiPt2I2jHKasT6BTsetgc3c9vQ=")
      )
    )
  )
;;;pgp: kbSetZeroCurrent,		*kbSetZeroCurrent
(defun c:kbSetZeroCurrent  (/ doc lobj)
  (setq	doc  (vla-get-activedocument (vlax-get-acad-object))
	lobj (vla-item (vla-get-layers doc) "0"))
  (if (= (vlax-get lobj 'LayerOn) 0)
    (vlax-put lobj 'LayerOn -1))
  (if (= (vlax-get lobj 'Freeze) -1)
    (vlax-put lobj 'Freeze 0))
  (vlax-put doc 'activelayer lobj)
  (princ "\nThe current layer is now '0'")
  (princ))


;;; Isolate the current Layer
;;;pgp: kbIsolateCurrentLaye		*kbIsolateCurrentLayer
(defun c:kbIsolateCurrentLayer  (/)
  (vl-cmdf ".-layer" "off" "*" "n" "")
  (princ
    (strcat "\nThe current layer: " (getvar "clayer") " has been isolated!"))
  (princ))

;;;pgp: kbNormaltoBlack,		*kbNormaltoBlack
(defun c:kbNormaltoBlack	 (/ layers l)
  (setq layers (vla-get-layers (vla-get-ActiveDocument (vlax-get-acad-object))))
  (vlax-for
	 l  layers
    (progn (if (= (vlax-get-property l 'PlotStyleName) "Normal")
	     (vlax-put-property l 'PlotStyleName "Black")))))

;;;pgp: kb0p,		*kb0p
(defun c:kb0p  (/ ss num cnt)
  (setq ss (ssget))
  (if ss
    (progn (setq num (sslength ss)
		 cnt 0)
	   (while (< cnt num)
	     (setq e (vlax-ename->vla-object (ssname ss cnt)))
	     (vlax-put-property e 'layer "0")
	     (vlax-put-property e 'color acByLayer)
	     (vlax-put-property e 'Linetype "ByLayer")
	     (vlax-put-property e 'Lineweight acLnWtByLayer)
	     (vlax-put-property e 'PlotStyleName "ByLayer")
	     (princ)
	     (setq cnt (1+ cnt)))
	   (princ "  Done... ")))
  (princ))

;;;pgp: kbBackofCurb,		*kbBackofCurb
(defun c:kbBackofCurb  (/ *Error* off_lay dist ent p1 ent_set lobj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (if	ent
      (redraw ent 4))
    (princ))
  (if (not (tblsearch "Layer" "C-Road-Boc"))
    (progn (setq lobj (vla-add (vla-get-layers kbThisdrawing) "C-Road-Boc"))
	   (vlax-put-property lobj 'color 8)
	   (vlax-put-property lobj 'lineweight aclnwt000)))
  (setq	off_lay	"C-Road-Boc"
	dist	6.0
	ent_set	(kb:entsel "\nSelect object to offset: " nil nil nil nil))
  (while ent_set
    (setq ent (car ent_set))
    (redraw ent 3)
    (setq p1 (getpoint "\nSide to offset? "))
    (redraw ent 4)
    (command "_.offset" dist ent_set p1 "")
    (vlax-put-property (vlax-ename->vla-object (entlast)) 'layer off_lay)
    (setq ent_set (kb:entsel "\nSelect object to offset or <exit>: " nil nil nil nil))))

;;;pgp: kbBylayer,		*kbBylayer
(defun c:kbBylayer  (/ *Error* ss cnt num obj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq ss (ssget))
  (if ss
    (progn (setq num (sslength ss)
		 cnt 0)
	   (while (< cnt num)
	     (setq obj (vlax-ename->vla-object (ssname ss cnt)))
	     (if (vlax-property-available-p obj 'color)
	     (vla-put-color obj acbylayer))
	     (vlax-put-property obj 'Linetype "ByLayer")
	     (vlax-put-property obj 'PlotStyleName "ByLayer")
	     (if (vlax-property-available-p obj 'Lineweight)
	     (VL-CATCH-ALL-ERROR-P  (vla-put-Lineweight obj acLnWtByLayer)))
	     (setq cnt (1+ cnt)))))
  (princ))




;;; CHANGES ENTITIES TO DEFPOINTS
;;;pgp: kbChangetoDEfpoints,		*kbChangetoDEfpoints
(defun c:kbChangetoDEfpoints( / *Error* ss num cnt obj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  ;check to see if defpoints exists
  (if (not(tblsearch "layer" "defpoints"))
    (vla-add(vla-get-layers kbthisdrawing)"defpoints"))

  (setq ss (ssget))
  (if ss
    (progn (setq num (sslength ss)
		 cnt 0)
	   (while (< cnt num)
	     (setq obj (vlax-ename->vla-object (ssname ss cnt)))
	     (vlax-put-property obj 'layer "defpoints")
	     (setq cnt (1+ cnt)))))
  (princ))

;;;							;
;;;	Utility Functions				;
;;;							;
(defun kb:striplayername (string / pos ret)
  (if (vl-string-position (ascii "|") string)
    (setq pos (+ (vl-string-position (ascii "|") string) 2)
	  ret (substr string pos (+ (- (strlen string) pos) 1))
	  )
    (setq ret string)
    )
  ret
  )



(defun kb:GetLayerList (xref / layers ret)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
  (cond	((= xref "*") ;gets all layers
	 (vlax-for x layers (setq ret (append ret (list (vla-get-name x)))))
	 )
	((= xref nil) ;gets only active doc layers
	 (vlax-for
		x
		 layers
	   (if (not (vl-string-search "|" (vla-get-name x)))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	((= xref "xr") ;gets all xref layers
	 (vlax-for
		x
		 layers
	   (if (vl-string-search "|" (vla-get-name x))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	(t ;gets a specific xref's layers
	 (vlax-for
		x
		 layers
	   (if (vl-string-search (strcat xref "|") (vla-get-name x))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	)
  ret
  )


(defun kb:load-plotstyle (dbxDoc lpltstyle / tempobj doc)
  (if (not (member (cons 3 lpltstyle)
		   (dictsearch (namedobjdict) "ACAD_PLOTSTYLENAME")
		   )
	   )
    (setq newln
	   (vl-catch-all-apply
	     'vla-CopyObjects
	     (list
	       dbxDoc
	       (vlax-safearray-fill
		 (vlax-make-safearray vlax-vbObject '(0 . 0))
		 (list (vla-item
			 (vla-item (vla-get-Dictionaries dbxDoc) "ACAD_PLOTSTYLENAME")
			 lpltstyle
			 )
		       )
		 )
	       (vla-item
		 (vla-get-Dictionaries (vla-get-activedocument (vlax-get-acad-object)))
		 "ACAD_PLOTSTYLENAME"
		 )
	       )
	     )
	  )
    )
  newln
  )

;;;							;
;;;	Layer States					;
;;;							;

(defun kb:LayerStateEngine (lstatename	  dwgname	layerlist     /
			    dbxdoc	  dbxdict	dict	      dbxplotstyles
			    dbxlayernames dbxlinetypes
			    )
  (setvar "clayer" "0")
  (princ "\nSetting the current layer to 0")
  (princ)
  (setq dbxdoc (kb:OpenDbxDocument DwgName))
  (if dbxdoc
    (progn (setq lstateobj (kb:getlayerobject))
	   (if lstateobj
	     (progn (vla-setdatabase lstateobj (vla-get-database dbxdoc))
		    (vlax-invoke lstateobj 'restore lstatename)
		    (setq dbxlayers (vla-get-layers dbxdoc)
			  layers    (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
			  )
    ;get a list of layers in the dbxdoc - because there's no "has" method!
		    (vlax-for
			   x
			    (vla-get-layers dbxdoc)
		      (setq dbxlayernames
			     (append dbxlayernames (list (strcase (vla-get-name x))))
			    )
		      )
    ;(setq n "X_Base43|A-Wall-Patt")
    ;(setq n(nth 3 layerlist))
		    (foreach
			   n
			    layerlist
		      (if (and (not (= n "0"))
			       (member (strcase (kb:striplayername n)) dbxlayernames)
			       )
			(progn (setq lobj    (vla-item layers n)
				     lobjdbx (vla-item dbxlayers (kb:striplayername n))
				     )
			       (foreach
				      property
					      (list "Freeze"	  "LayerOn"	"Lineweight"
						    "Lock"	  "Plottable"	"color"
						    )
				 (vlax-put lobj property (vlax-get lobjdbx property))
				 )
    ;set plotstyle
			  (if (= (getvar "pstylemode")0)
			    (progn
			       (setq ps (vlax-get lobjdbx "PlotStyleName"))
			       (kb:load-plotstyle dbxdoc ps)
			       (vlax-put lobj "PlotStyleName" ps)
			      )
			    )
    ;set linetype
			       (setq ln (vlax-get lobjdbx "Linetype"))
			       (if (not (tblsearch "ltype" ln))
				 (setq newln
					(vl-catch-all-apply
					  'vla-CopyObjects
					  (list	dbxDoc
						(vlax-safearray-fill
						  (vlax-make-safearray vlax-vbObject '(0 . 0))
						  (list (vla-item (vla-get-linetypes dbxDoc) ln))
						  )
						(vla-get-linetypes (vla-get-activedocument (vlax-get-acad-object)))
						)
					  )
				       )
				 )
			       (if (tblsearch "ltype" ln)
				 (vlax-put lobj "Linetype" ln)
				 )
			       )
			)
		      )
		    )
	     )
	   (kb:CloseDbxDocument dbxdoc)
	   (vlax-release-object lstateobj)
	   )
    )
  (vla-regen
    (vla-get-activedocument (vlax-get-acad-object))
    acActiveViewport
    )
  )

;;;(kb:ReturnDBXLayerStates)
(defun kb:ReturnDBXLayerStates (/		  dbxdoc	    lstate-dict-object
				lstate-dict	  named-obj-dict    ldict
				acad_lstate	  acad_lstate_defs
				)
  (setq file (kb:ReturnLayerStandardsFile))
  (if file
    (progn
      (setq dbxdoc (kb:opendbxdocument (findfile file)))
      (if dbxdoc
	(progn
	  (setq	lstate-dict-object
		 (vla-GetExtensionDictionary (vla-get-layers dbxdoc))
		lstate-dict
		 (entget (vlax-vla-object->ename lstate-dict-object))
    ;(vlax-dump-Object lstate-dict-object)
		named-obj-dict
		 (vlax-vla-object->ename (vla-get-Dictionaries dbxdoc))
		)
	  (if lstate-dict
	    (progn
	      (if (setq ldict (member (cons 3 "ACAD_LAYERSTATES") lstate-dict))
		(progn (setq acad_lstate (cdr (assoc 360 ldict)))
		       (foreach
			      x
			       (entget acad_lstate)
			 (if (and (eq 3 (car x)))
			   (setq acad_lstate_defs (append acad_lstate_defs (list (cdr x))))
			   )
			 )
		       (vlax-release-object lstate-dict-object)
		       )
		)
	      )
	    )
	  (kb:CloseDbxDocument dbxdoc)
	  )
	)
      )
    )
  acad_lstate_defs
  )

(defun kb:00-restore (lsname xrefname /)
  (cond	((= xrefname (getvar "dwgname"))
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList nil)
	   )
	 )
	((= xrefname "All Xrefs")
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList "xr")
	   )
	 )
	((= xrefname "All Layers")
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList "*")
	   )
	 )
	(t
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList xrefname)
	   )
	 )
	)
  (princ)
  (princ)
  )

;;;								;
;;;	OpenDCL Subs						;
;;;								;

;;;								;
;;;	LayerStatesPop Form Controls				;
;;;								;

(defun c:Layers_LayerStatesPop_OnInitialize (/ dbxLlist)

  (dcl_ListBox_Clear Layers_LayerStatesPop_LayerStates)


  (setq dbxLlist (kb:ReturnDBXLayerStates))
  (if dbxLlist
    (dcl_ListBox_AddList Layers_LayerStatesPop_LayerStates dbxLlist)
    (dcl_ListBox_AddList
      Layers_LayerStatesPop_LayerStates
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
  (princ)
  (princ)
  )

(defun c:Layers_LayerStatesPop_OnMouseMovedOff (/)
  (dcl_Form_Close Layers_LayerStatesPop)
  (princ)
  (princ)
  )

(defun c:Layers_LayerStatesPop_LayerStates_OnDblClicked
       (/ lsname xref layers xname xrefname xobj)
  (setq	lsname (dcl_ListBox_GetText
		 Layers_LayerStatesPop_LayerStates
		 (dcl_ListBox_GetCurSel Layers_LayerStatesPop_LayerStates)
		 )
	xref   (dcl_Control_GetValue Layers_LayerStatesPop_Xref)
	layers (dcl_Control_GetValue Layers_LayerStatesPop_AllLayers)
	)
  (dcl_setcmdbarfocus)
  (cond	((= xref 1)
	 (dcl_Form_Close Layers_LayerStatesPop)
	 
	 (setq xname (entsel "\nSelect Xref:"))
	 (if xname
	   (progn
	     (setq xobj (vlax-ename->vla-object (car xname)))
	     (if (vlax-property-available-p xobj 'path)
	       (setq xrefname (vla-get-name xobj))
	       )
	     )
	   )
	 )
	((= layers 1)
	 (setq xrefname "All Layers")
	 )
	((and (= xref 0) (= layers 0))
	 (setq xrefname (getvar "dwgname"))
	 )
	)
  (if (and lsname xrefname)
    (kb:00-restore lsname xrefname)
      
    )
  (princ)
  (princ)
  )

(defun c:Layers_LayerStatesPop_Xref_OnClicked (nValue /)
  (if (= nValue 1)
    (dcl_Control_SetValue Layers_LayerStatesPop_AllLayers 0)
    )
  )

(defun c:Layers_LayerStatesPop_AllLayers_OnClicked (nValue /)
  (if (= nValue 1)
    (dcl_Control_SetValue Layers_LayerStatesPop_Xref 0)
    )
  )

;;;								;
;;;	Command Interface					;
;;;								;
;;;pgp: kbLayerToolsPop,		*kbLayerToolsPop
(defun c:kbLayerToolsPop (/ pt x y)
  (if (not (member "Layers" (dcl_GetProjects)))
    (dcl_Project_load "Layers")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (setq pt (dcl_getmousecoords)
	    x  (-(nth 0 pt)10)
	    y  (-(nth 1 pt)10)
	    )
      (dcl_Form_Show Layers_LayerStatesPop (fix x) (fix y))
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;								;
;;;	LayerWalk Form						;
;;;								;
;(setq prop "freeze" retlist nil bool t)
(defun kb:LayerWalkPropListBox(prop / retList)
  (dcl_ListBox_Clear Layers_LayerWalk_LayersListBox)
  (vlax-for x (vla-get-layers(vla-get-ActiveDocument(vlax-get-acad-object)))
(cond
    ((= prop "on")
    (if(=(vla-get-LayerOn x)  :vlax-true)
     (setq retList(append retList(list(vla-get-name x))))))
    ((= prop "off")
    (if(=(vla-get-LayerOn x) :vlax-false)(setq retList(append retList(list(vla-get-name x))))))
    ((= prop "thaw")
    (if(=(vla-get-freeze x) :vlax-false)(setq retList(append retList(list(vla-get-name x))))))
    ((= prop "freeze")
    (if(=(vla-get-freeze x) :vlax-true)(setq retList(append retList(list(vla-get-name x))))))
    ((= prop "lock")
    (if(=(vla-get-Lock x) :vlax-true)(setq retList(append retList(list(vla-get-name x))))))
    ((= prop "unlock")
    (if(=(vla-get-Lock x) :vlax-false)(setq retList(append retList(list(vla-get-name x))))))
   ))
  (if retList
    (dcl_ListBox_AddList Layers_LayerWalk_LayersListBox retList)
    )
  (princ)
  (princ)
  )
;(dcl_form_show Layers_LayerWalk)
;(dcl_Control_GetEnabled Layers_LayerWalk_FreezeButton)
;(setq ret nil)
;(kb:ReturnCurrentProp)
(defun kb:LayerWalk_FixLayers(lname prop / layCol)
  (setq layCol(vla-get-layers(vla-get-ActiveDocument(vlax-get-acad-object)))
	layObj(vla-item layCol lname))
  (cond
    ((= prop "on")
    (vla-put-LayerOn layObj  :vlax-false))
    ((= prop "off")
    (vla-put-LayerOn layObj  :vlax-true))
    ((= prop "thaw")
    (vla-put-freeze layObj  :vlax-true))
    ((= prop "freeze")
    (vla-put-freeze layObj  :vlax-false))
    ((= prop "lock")
    (vla-put-Lock layObj  :vlax-false))
    ((= prop "unlock")
    (vla-put-Lock layObj  :vlax-true))
    )
  (princ)
  )


(defun kb:LayerWalk_EnableButtons( / )
  (foreach x
(dcl_Form_GetControls Layers_LayerWalk)
    (dcl_Control_SetEnabled x t))
      
    )

  
;;;								;
;;;	OpenDCL Subs						;
;;;								;
(defun c:Layers_LayerWalk_OnInitialize (/)
  (kb:LayerWalk_EnableButtons)
  (dcl_Control_SetCaption Layers_LayerWalk_CurProp "")
 (dcl_ListBox_Clear Layers_LayerWalk_LayersListBox)
  (dcl_ListBox_AddString Layers_LayerWalk_LayersListBox "Select a Layer Property to Continue")
)


(defun c:Layers_LayerWalk_OnEnteringNoDocState (/)
  (dcl_Form_Close Layers_LayerWalk)
)

(defun c:Layers_LayerWalk_OnDocActivated (/ prop)
  (setq prop(dcl_Control_GetCaption Layers_LayerWalk_CurProp))
  (cond((= prop "thaw")
	(c:Layers_LayerWalk_ThawButton_OnClicked))
       ((= prop "freeze")
	(c:Layers_LayerWalk_FreezeButton_OnClicked))
       ((= prop "on")
	(c:Layers_LayerWalk_OnButton_OnClicked))
       ((= prop "off")
	(c:Layers_LayerWalk_OffButton_OnClicked))
       ((= prop "unlock")
	(c:Layers_LayerWalk_UnlockButton_OnClicked))
       ((= prop "lock")
	(c:Layers_LayerWalk_LockButton_OnClicked))
       (t (c:Layers_LayerWalk_OnInitialize))
       )
  
)

;;;								;
;;;	Botton Controls						;
;;;								;


(defun c:Layers_LayerWalk_CloseButton_OnClicked (/)
  (dcl_Form_Close Layers_LayerWalk)
)


(defun c:Layers_LayerWalk_ThawButton_OnClicked (/)
  (kb:LayerWalk_EnableButtons)
  (dcl_Control_SetEnabled Layers_LayerWalk_ThawButton nil)
  (dcl_Control_SetCaption Layers_LayerWalk_CurProp "thaw")
  (kb:LayerWalkPropListBox "thaw")
)
(defun c:Layers_LayerWalk_FreezeButton_OnClicked (/)
  (kb:LayerWalk_EnableButtons)
  (dcl_Control_SetEnabled Layers_LayerWalk_FreezeButton nil)
  (kb:LayerWalkPropListBox "freeze")
  (dcl_Control_SetCaption Layers_LayerWalk_CurProp "freeze")
)
(defun c:Layers_LayerWalk_OnButton_OnClicked (/)
  (kb:LayerWalk_EnableButtons)
  (dcl_Control_SetEnabled Layers_LayerWalk_OnButton nil)
  (kb:LayerWalkPropListBox "on")
  (dcl_Control_SetCaption Layers_LayerWalk_CurProp "on")
)
(defun c:Layers_LayerWalk_OffButton_OnClicked (/)
  (kb:LayerWalk_EnableButtons)
  (dcl_Control_SetEnabled Layers_LayerWalk_OffButton nil)
  (kb:LayerWalkPropListBox "off")
  (dcl_Control_SetCaption Layers_LayerWalk_CurProp "off")
)
(defun c:Layers_LayerWalk_UnlockButton_OnClicked (/)
  (kb:LayerWalk_EnableButtons)
  (dcl_Control_SetEnabled Layers_LayerWalk_UnlockButton nil)
  (kb:LayerWalkPropListBox "unlock")
  (dcl_Control_SetCaption Layers_LayerWalk_CurProp "unlock")
)
(defun c:Layers_LayerWalk_LockButton_OnClicked (/)
  (kb:LayerWalk_EnableButtons)
  (dcl_Control_SetEnabled Layers_LayerWalk_LockButton nil)
  (kb:LayerWalkPropListBox "lock")
  (dcl_Control_SetCaption Layers_LayerWalk_CurProp "lock")
)

;(c:Layers_LayerWalk_RefreshButton_OnClicked)
(defun c:Layers_LayerWalk_RefreshButton_OnClicked (/ prop)
  (setq Prop(dcl_Control_GetCaption Layers_LayerWalk_CurProp))
  (cond
    ((= prop "on")
    (c:Layers_LayerWalk_OnButton_OnClicked))
    ((= prop "off")
    (c:Layers_LayerWalk_OffButton_OnClicked))
    ((= prop "thaw")
    (c:Layers_LayerWalk_ThawButton_OnClicked))
    ((= prop "freeze")
    (c:Layers_LayerWalk_FreezeButton_OnClicked))
    ((= prop "lock")
    (c:Layers_LayerWalk_LockButton_OnClicked))
    ((= prop "unlock")
    (c:Layers_LayerWalk_UnLockButton_OnClicked))
    )
  (princ)
  (princ)
)

;(c:Layers_LayerWalk_ApplyButton_OnClicked)
(defun c:Layers_LayerWalk_ApplyButton_OnClicked (/)
 (setq CurProp(dcl_Control_GetCaption Layers_LayerWalk_CurProp)
  layList(dcl_ListBox_GetSelectedItems Layers_LayerWalk_LayersListBox))

  (if layList
    (progn
    (foreach x layList
      (kb:LayerWalk_FixLayers x CurProp)
      )
    (vla-regen(vla-get-ActiveDocument(vlax-get-acad-object))acActiveViewport)
    (c:Layers_LayerWalk_RefreshButton_OnClicked)
    )
    (alert "Select some Layers!")
    )
  
)

(defun c:Layers_LayerWalk_LayersListBox_OnDblClicked (/)
  (c:Layers_LayerWalk_ApplyButton_OnClicked)
)


;;;								;
;;;	Tray Functions						;
;;;								;
(defun c:Layers_LayerWalk_Close_OnClicked ( / rValue ht wd)
  (vl-bb-set 'kb100Floating "false")

  (setq rValue (dcl_Form_GetControlArea Layers_LayerWalk)
	wd(car rValue)
	ht(cadr rValue))
  (if (> ht 20)
  (kb:SaveFormSize "Layers_LayerWalk" wd ht))
  (dcl_form_close Layers_LayerWalk)
  (princ)
)

(defun Layers_LayerWalk_RollUp (/ rValue ht wd)
  (Setq	rValue (dcl_Form_GetControlArea Layers_LayerWalk)
	wd     (car rValue)
	ht     (cadr rValue)
	)
  (kb:SaveFormSize "Layers_LayerWalk" wd ht)
  (dcl_Control_SetVisible Layers_LayerWalk_ApplyButton nil)
  (dcl_Control_SetVisible Layers_LayerWalk_LayersListBox nil)
  (dcl_Form_Resize Layers_LayerWalk wd 22)
  )


(defun Layers_LayerWalk_RollDown ( / rValue ht wd)
  (setq	rValue (kb:GetFormSize "Layers_LayerWalk")
  	wd     (car rValue)
	ht     (cadr rValue)
	)
  (dcl_Control_SetVisible Layers_LayerWalk_ApplyButton t)
  (dcl_Control_SetVisible Layers_LayerWalk_LayersListBox t)
  (dcl_Form_Resize Layers_LayerWalk wd ht)
  )


(defun c:Layers_LayerWalk_Tray_OnClicked ( / )
  (cond((=(dcl_Control_GetPicture Layers_LayerWalk_Tray)101)
	(Layers_LayerWalk_RollUp t))
	((=(dcl_Control_GetPicture Layers_LayerWalk_Tray)100)
	 (Layers_LayerWalk_RollDown t)
	)
       )
(princ)
  (princ)
  )

(defun c:Layers_LayerWalk_OnMouseEntered (/)
  (Layers_LayerWalk_RollDown)
  (princ)
  (princ)
  )


(defun c:Layers_LayerWalk_OnMouseMovedOff (/)
  (dcl_setcmdbarfocus)
  (Layers_LayerWalk_RollUp)
  (princ)
  (princ)
  )


;;;								;
;;;	Command Interface					;
;;;								;
;;;pgp: kbLayerWalk,		*kbLayerWalk
(defun c:kbLayerWalk (/ pt x y)
  (if (not (member "Layers" (dcl_GetProjects)))
    (dcl_Project_load "Layers")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (setq pt (dcl_getmousecoords)
	    x  (-(nth 0 pt)10)
	    y  (-(nth 1 pt)10)
	    )
      (dcl_Form_Show Layers_LayerWalk (fix x) (fix y))
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ pt)
  (princ)
  )

(if (dcl_form_isactive Layers_LayerWalk)
(c:Layers_LayerWalk_OnInitialize))

;;;								;
;;;	LayerStates Form Controls				;
;;;								;


(defun kb:LayerStates_OnInitialize (/ dbxLlist xrefList doclist)

  (dcl_ListBox_Clear Palette_Main_01LayerStatesListBox)
  (dcl_ListBox_Clear Palette_Main_01DocumentsListBox)

  (setq xrefList (kb:listxrefs))
  (if xreflist
    (setq doclist (append (list "All Layers" (getvar "dwgname")) xreflist))
    (setq doclist (list "All Layers" (getvar "dwgname")))
    )
  (dcl_Listbox_AddList Palette_Main_01DocumentsListBox doclist)

  (setq dbxLlist (kb:ReturnDBXLayerStates))
  (if dbxLlist
    (dcl_ListBox_AddList Palette_Main_01LayerStatesListBox dbxLlist)
    (dcl_ListBox_AddList
      Palette_Main_01LayerStatesListBox
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
  (princ)
  (princ)
  )

(defun c:Palette_Main_01RefreshButton_OnClicked (/)
  (dcl_ListBox_Clear Palette_Main_01DocumentsListBox)

  (setq xrefList (kb:listxrefs))
  (if xreflist
    (setq doclist (append (list "All Layers" (getvar "dwgname")) xreflist))
    (setq doclist (list "All Layers" (getvar "dwgname")))
    )
  (dcl_Listbox_AddList Palette_Main_01DocumentsListBox doclist)

)

(defun c:Palette_Main_01RestoreButton_OnClicked (/ lsname xrefname)
  (setq	lsname	 (dcl_ListBox_GetText
		   Palette_Main_01LayerStatesListBox
		   (dcl_ListBox_GetCurSel Palette_Main_01LayerStatesListBox)
		   )
	xrefname (dcl_ListBox_GetSelectedItems Palette_Main_01DocumentsListBox)
	)
  (if (not xrefname)
    (progn (setq xrefname (list "All Layers"))
	   (dcl_ListBox_SetCurSel Palette_Main_01DocumentsListBox 0)
	   )
    )
  (if (and lsname (/= lsname ""))
    (cond ((= (vl-list-length xrefname) 1)
	   (kb:00-restore lsname (nth 0 xrefname))
	   )
	  ((> (vl-list-length xrefname) 1)
	   (foreach
		  x
		   xrefName
	     (kb:00-restore lsname x)
	     )
	   )
	  )
    (alert "Select a Layer Display!")
    )
  (progn
	  (foreach i
	  (dcl_ListBox_GetSelectednths Palette_Main_01DocumentsListBox)
	    (dcl_ListBox_SelItemRange Palette_Main_01DocumentsListBox i i nil))
    (dcl_ListBox_SetCurSel Palette_Main_01LayerStatesListBox -1))
  (princ)
  (princ)
  )


(defun c:Palette_Main_01EditModeButton_OnClicked (/)
  (setq acadObj(vlax-get-acad-object)
        acDoc(vla-get-activedocument acadObj)
        bgColor(vlax-variant-value
           (vlax-variant-change-type
             (vlax-get-property
               (vla-get-display (vla-get-preferences acadObj))
               'GraphicsWinModelBackgrndColor
               )
             vlax-vblong
             )
           )
        layerCollection(vla-get-layers acDoc)
        displayprefs(vla-get-preferences acadObj)
        )
  (if (= bgColor 0)
    (progn (setvar "lwdisplay" 1)
      (vlax-put
             (vla-get-display (vla-get-Preferences acadObj))
             'GraphicsWinModelBackgrndColor
             16777215
             )
      (setvar "clayer" "0")
           (vlax-for x layerCollection (princ (vla-put-color x acWhite)))
      (vla-put-freeze(vla-item layerCollection "defpoints"):vlax-true)
      (vla-regen acDoc acAllViewports)
           )
    ;reset to normal mode
    (progn
      (setvar "lwdisplay" 0)
      (if (dcl_ListBox_GetCurSel Palette_Main_01LayerStatesListBox)
	(progn
      (setq	lsname	 (dcl_ListBox_GetText
		   Palette_Main_01LayerStatesListBox
		   (dcl_ListBox_GetCurSel Palette_Main_01LayerStatesListBox)
		   )
	xrefname (dcl_ListBox_GetSelectedItems Palette_Main_01DocumentsListBox)
	)

      (if (not xrefname)
    (progn (setq xrefname (list "All Layers"))
	   (dcl_ListBox_SetCurSel Palette_Main_01DocumentsListBox 0)
	   )
    )
  (if (and lsname (/= lsname ""))
    (progn
    (cond ((= (vl-list-length xrefname) 1)
	   (kb:00-restore lsname (nth 0 xrefname))
	   )
	  ((> (vl-list-length xrefname) 1)
	   (foreach
		  x
		   xrefName
	     (kb:00-restore lsname x)
	     )
	   )
	  )
    (vlax-put
             (vla-get-display (vla-get-Preferences acadObj))
             'GraphicsWinModelBackgrndColor
             0
             )
    ))
      )
    (alert "Select a Layer Display!")
    )   
           )
    )
  (princ "\nEdit Mode switched!")
  (princ)
  )

(defun c:Palette_Main_01ThawVPButton_OnClicked (/)
  (if (= (getvar "tilemode") 0)
    (command "vplayer" "_thaw" "*" "current" "" "")
    (not (dcl_MessageBox "Not allowed in Model Space!" "Thaw VP Layers" 2 1)
	 )
    )
  (princ)
  (princ)
  )


(defun c:Palette_Main_01LayerStatesListBox_OnDblClicked (/ path layerlist)
  (c:Palette_Main_01RestoreButton_OnClicked)
  (princ)
  (princ)
  )


(princ "\nLayer Commands loaded!")
(princ)
 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 0 T T nil T)
;*** DO NOT add text below the comment! ***|;
