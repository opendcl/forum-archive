(defun c:HtmlTest (/)
	(command "opendcl")
	(dcl_Project_Load "HtmlTest" T)
	(dcl_Form_Show HtmlTest_HtmlTest)
);endfun


(defun c:HtmlTest_HtmlTest_OnInitialize (/)
  (dcl_Html_Navigate HtmlTest_HtmlTest_Html1 "http://opendcl.com/wordpress/")
);endfun


;;INVESTIGATION 1 -  dcl_Html_ReplaceText added to On navigation complete event 
;;Changing the text from "Facebook users" to "Testbook users".
;;;(defun c:HtmlTest_HtmlTest_Html1_OnNavigationComplete (URL /)
;;;  (if (= URL "http://opendcl.com/wordpress/")
;;;		(dcl_Html_ReplaceText HtmlTest_HtmlTest_Html1 "Facebook users" "Testbook users");then
;;;	);endif
;;;);endfun


;;INVESTIGATION 2 - TechJunkie 80's javascript code added to on navigation complete event
;;to change see http://www.opendcl.com/forum/index.php?topic=1602.0
(defun c:HtmlTest_HtmlTest_Html1_OnNavigationComplete (URL /)
  (if (= URL "http://opendcl.com/wordpress/")
		(dcl_Html_Navigate
			HtmlTest_HtmlTest_Html1
			"javascript:(function(){var a=document.getElementsByTagName('a');for(var i=0;i<a.length;i++){a.target='_top';}})();"
		)
	);endif
);endfun

(princ "\nType \"HtmlTest\" to test..")



