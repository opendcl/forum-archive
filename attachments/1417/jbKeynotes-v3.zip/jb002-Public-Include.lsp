;;; Return Active Space Object
;;;(setq view(jb:GetActiveSpace))
(defun jb:GetActiveSpace( / act ret)
  (setq act(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'activespace))
  (cond((= act 1);modelspace
    (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'modelspace)))
       ((= act 0)
        (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'paperspace)))
       (t (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'modelspace))))
  ret)

;;; Returns the Current Project Directory
(defun jb:ReturnProjectDir( / entry ret)
  (if (not
        (setq entry(vl-registry-read
(strcat "HKEY_CURRENT_USER\\"
		  (vlax-product-key)
		  "\\Recent Project List\\")"Project1")))
        (setq ret(getvar "dwgprefix"))
        (setq ret(vl-filename-directory entry)))
  ret
)

;;;Return CANNOSCALE in drawing units
;;;(jb:Cannoscale)
(defun jb:Cannoscale  (/ annoscale ret)
  (setq annoscale (vlax-invoke
                    (vla-get-ActiveDocument (vlax-get-acad-object))
                    'getvariable
                    "CANNOSCALEVALUE")
        ret       (/ 12 (* annoscale 12.0)))
  ret)
