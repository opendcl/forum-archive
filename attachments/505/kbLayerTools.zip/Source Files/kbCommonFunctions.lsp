;;;								;
;;;								;
;;; This is a collection of commonly used utilities by many of  ;
;;; kbCadTools applications.  It should be kept in an "include" ;
;;; folder for access while compiling.                          ;
;;;								;
;;;								;

(vl-load-com)

;;; Returns the drawing specific Layer Display Definition drawing
;;; 
(defun kb:ReturnLayerStandardsFile  (/ kbDataDwg)
  (setq kbDataDwg (findfile "LayerStandard.dwg"))

  (if (not kbDataDwg)
    (setq kbDataDwg(findfile "LayerStandard.dwg"))
    )
  kbDataDwg)
;;;	Return File Systime				;
    (defun kb:ReturnFileTime (filename / time hour ampm minutes filetimeStr)
      (setq time (vl-file-systime filename))
      (if time
	(progn (if (> (nth 4 time) 12)
		 (setq hour (itoa (- (nth 4 time) 12))
		       ampm "PM"
		       )
		 (setq hour (itoa (nth 4 time))
		       ampm "AM"
		       )
		 )
	       (if (< (nth 5 time) 10)
		 (setq minutes (strcat "0" (itoa (nth 5 time))))
		 (setq minutes (itoa (nth 5 time)))
		 )
	       (setq filetimeStr
		      (strcat (itoa (nth 3 time))
			      "/"
			      (itoa (nth 1 time))
			      "/"
			      (itoa (nth 0 time))
			      " "
			      hour
			      ":"
			      minutes
			      " "
			      ampm
			      )
		     )
	       )
	)
      filetimeStr
      )
;;;Return CANNOSCALE in drawing units
;;;(kb:Cannoscale)
(defun kb:Cannoscale (/ annoscale ret)
  (setq annoscale (vlax-invoke
                    (vla-get-ActiveDocument (vlax-get-acad-object))
                    'getvariable
                    "CANNOSCALEVALUE"
                    )
        ret       (/ 12 (* annoscale 12.0))
        )
  ret
  )


;;;(kb:GetAcadDim)
(defun kb:GetAcadDim (/ xr cod itm reply)
  (setq xr (dictsearch (namedobjdict) "AcadDim"))
  (if (not xr)
    (progn (setq cur (append '((0 . "XRECORD")
                               (100 . "AcDbXrecord")
                               (90 . 990106)
                               (3 . "")
                               (40 . 0.0)
                               (60 . 0)
                               (61 . 0)
                               (62 . 1)
                               (63 . 1)
                               (64 . 0)
                               (65 . 0)
                               (67 . 2)
                               (68 . 1)
                               (69 . 0)
                               (70 . 0)
                               (72 . 0)
                               )
                             )
                 )
           (setq xr (entget (dictadd (namedobjdict) "AcadDim" (entmakex cur))))
           )
    )
  (if xr
    (progn
      (foreach
             cod (list 3 40 60 61 62 63 64 65 66 67 68 69 70 71 72 170 340)
        (if (setq itm (assoc cod xr))
          (setq reply (append reply (list itm)))
          )
        reply
        )
      )
    )
  reply
  )

;; 3: user arrowhead block name (default="")
;; 40: default text width (default=0.0)
;; 60: annotation type (default=0)
;; 0=MText
;; 1=copy object
;; 2=Tolerance
;; 3=block
;; 4=none
;; 61: annotation reuse (default=0)
;; 0=none
;; 1=reuse next
;; 62: left attachment point (default=1)
;; 63: right attachment point (default=3)
;; 0=Top of top line
;; 1=Middle of top line
;; 2=Middle of multiline text
;; 3=Middle of bottom line
;; 4=Bottom of bottom line
;; 64: underline bottom line (default=0)
;; 65: use splined leader line (default=0)
;; 66: no limit on points (default=0)
;; 67: maximum number of points (default=3)
;; 68: prompt for MText width (word wrap) (default=1)
;; 69: always left justify (default=0)
;; 70: allowed angle, first segment (default=0)
;; 71: allowed angle, second segment (default=0)
;; 0=Any angle
;; 1=Horizontal
;; 2=90deg
;; 3=45deg
;; 4=30deg
;; 5=15deg
;; 72: frame text (default=0)
;; 170: active tab (default=0)
;; 0=Annotation
;; 1=Leader Line & Arrow
;; 2=Attachment
;; 340: object ID for annotation reuse
;;
(defun kb:SetAcadDim (arg / cur prm)
  (setq cur (kb:GetAcadDim))
  (while arg
    (setq prm (car arg)
          arg (cdr arg)
          cur (subst prm (assoc (car prm) cur) cur)
          )
    )
  (dictremove (namedobjdict) "AcadDim")
  (setq cur (append '((0 . "XRECORD") (100 . "AcDbXrecord") (90 . 990106)) cur))
  (dictadd (namedobjdict) "AcadDim" (entmakex cur))
  (kb:GetAcadDim)
  (princ "\nAcadDim updated!")
  (princ)
  )

(defun kb:SaveFormSize (formname wd ht /)
  (vl-registry-write
    (strcat "HKEY_CURRENT_USER\\Software\\kbTools2009\\" formname)
    "w"
    wd
    )
  (vl-registry-write
    (strcat "HKEY_CURRENT_USER\\Software\\kbTools2009\\" formname)
    "h"
    ht
    )
  (princ)
  )

(defun kb:GetFormSize (formname / wd ht)
  (setq wd (vl-registry-read
             (strcat "HKEY_CURRENT_USER\\Software\\kbTools2009\\" formname)
             "w"
             )
        ht (vl-registry-read
             (strcat "HKEY_CURRENT_USER\\Software\\kbTools2009\\" formname)
             "h"
             )
        )
  (if (not wd)
    (setq wd 250)
    )
  (if (not ht)
    (setq ht 400)
    )
  (list wd ht)
  )



    ;(setq formname "kb001_00")
(defun kb:GetOpenDCLFormSize (formname / wd ht)
  (setq wd (vl-registry-read
             (strcat "HKEY_CURRENT_USER\\"
                     (vlax-product-key)
                     "\\Profiles\\"
                     (vla-get-ActiveProfile
                       (vla-get-profiles (vla-get-Preferences (vlax-get-acad-object)))
                       )
                     "\\OpenDCL\\Dialogs\\"
                     formname
                     )
             "Width"
             )
        ht (vl-registry-read
             (strcat "HKEY_CURRENT_USER\\"
                     (vlax-product-key)
                     "\\Profiles\\"
                     (vla-get-ActiveProfile
                       (vla-get-profiles (vla-get-Preferences (vlax-get-acad-object)))
                       )
                     "\\OpenDCL\\Dialogs\\"
                     formname
                     )
             "Height"
             )
        )
  (list wd ht)
  )

(defun kb:strParse (Str del / srch len ret n char)
  (setq srch Str
        len  (strlen srch)
        ret  '()
        )
  (while (> len 0)
    (setq n    1
          char (substr srch 1 1)
          )
    (while (and (/= char del) (/= char ""))
      (setq n    (1+ n)
            char (substr srch n 1)
            )
      )
    (setq ret  (cons (substr srch 1 (1- n)) ret)
          srch (substr srch (1+ n) len)
          len  (strlen srch)
          )
    )
  (reverse ret)
  )




;;;			 ADT Variable Function			;
;;;		Layer Standard Drawing (kb:GetADTVar 5)		;
;;; 		Layer Standard  (kb:GetADTVar 9)		;
;;; 		Drawing Scale(kb:GetADTVar 40)			;
;;; 		Annotation size (kb:GetADTVar 42)		;
;;;								;


;;;		Return ADT Variable Value			;

(defun kb:GetADTVar (var / dict vars ret)
    ;check to see if the dict exists, if not initialize it . . .
  (if (not (cdar (dictsearch (namedobjdict) "AEC_VARS")))
    (aeclayerkeylist)
    )
  (setq dict (dictsearch
               (cdar (dictsearch (namedobjdict) "AEC_VARS"))
               "AEC_VARS_DWG_SETUP"
               )
        vars (member '(100 . "AecDbVarsDwgSetup") dict)
        ret  (cdr (assoc var vars))
        )
  ret
  )


;;;								;
;;;		Create a POP0 menu				;
;;;								;
;;;	Use: (kb:DynamicPop (some list) "kb40")			;
(defun kb:DynamicPop (ulist menugrp / acadobj menugrps menu menus shortcut)
  (setq acadobj  (vlax-get-acad-object)
        menugrps (vla-get-menugroups acadobj)
        menu     (vl-catch-all-apply 'vla-item (list menugrps menugrp))
        )
  (if (not (vl-catch-all-error-p menu))
    (progn (setq menus (vla-get-menus menu))
           (vlax-for
                  i menus
             (if (= (vla-get-shortcutmenu i) :vlax-true)
               (setq shortcut i)
               )
             )
           (if shortcut
             (progn (vlax-for ii shortcut (vla-delete ii))
                    (setq cnt 0)
                    (foreach
                           x ulist
                      (vlax-invoke shortcut 'addmenuitem cnt (car x) (cdr x))
                      (setq cnt (1+ cnt))
                      )
                    )
             )
           )
    )
  shortcut
  )



(defun kb:Return40Pop (cmd / acadobj menugrps menu menus shortcut xreflist)
  (setq acadobj  (vlax-get-acad-object)
        menugrps (vla-get-menugroups acadobj)
        menu     (vl-catch-all-apply 'vla-item (list menugrps "kb00"))
        )
  (if (not (vl-catch-all-error-p menu))
    (progn (setq menus (vla-get-menus menu))
           (vlax-for
                  i menus
             (if (= (vla-get-shortcutmenu i) :vlax-true)
               (setq shortcut i)
               )
             )
           (if shortcut
             (progn (vlax-for ii shortcut (vla-delete ii))
                    (setq xreflist
                           (kb:ListXrefs)
                          cnt 0
                          )
                    (foreach
                           x xreflist
                      (vlax-invoke
                        shortcut
                        'addmenuitem
                        cnt
                        x
                        (strcat cmd (chr 34) x (chr 34) " ")
                        )
                      (setq cnt (1+ cnt))
                      )
                    )
             )
           )
    )
  )


;;; Open a drawing
;;; Requires a full path - checks if file exists
(defun kb:OpenDrawing (name / docs)
  (if (not (member "acvba.arx" (arx)))
    (arxload (findfile "AcVBA.arx"))
    )
  (if (findfile name)
    (if (not (setq docs (member (strcase name) (kb:doclist))))
      (progn (command
               "vbastmt"
               (strcat "AcadApplication.Documents.Open " (chr 34) name (chr 34))
               )
             (vla-activate (cadr docs))
             )
      (vla-activate (cadr docs))
      )
    )
  )



;;;(kb:att:GetAttributes(car(entsel)))
(defun kb:GetAttributes (ent / lst x)
  (if (safearray-value
        (setq lst (vlax-variant-value (vla-getattributes (vlax-ename->vla-object ent))))
        )
    (mapcar '(lambda (x) (list (vla-get-tagstring x) (vla-get-textstring x)))
            (vlax-safearray->list lst)
            )
    )
  )

;;;
(defun kb:ChangeAttributeValue (obj tag text / lst)
  (setq lst (vlax-safearray->list (vlax-variant-value (vla-getattributes obj))))
  (foreach
         x lst
    (if (= tag (vlax-get x 'tagstring))
      (vlax-put x 'textstring text)
      )
    )
  )





;;; Loads the AecLayerManager.arx for the appropriate release of ADT
;;; (kb:loadAECLayerARX)
;;;
(defun kb:loadAECLayerARX (/ file)
  (if (and (null AecSetLayerKeyOverride)
           (setq file (vl-directory-files
                        (vla-get-path (vlax-get-acad-object))
                        "AecLMgrLisp*.arx"
                        1
                        )
                 )
           )
    (arxload
      (strcat (vla-get-path (vlax-get-acad-object)) "\\" (car file))
      []
      )
    (princ "\nUnable to locate the AECLayerLisp ARX!")
    )
  (princ)
  )


;;; ObjectDBX functions
;;;
;;;

(if (< (atoi (getvar "AcadVer")) 16)
  (cond ((vl-registry-read "HKEY_CLASSES_ROOT\\ObjectDBX.AxDbDocument\\CLSID"))
        ((not (setq dbxserver (findfile "AxDb15.dll")))
         (alert "Error: Can't locate ObjectDBX Library (AxDb15.dll)")
         )
        (t
         (startapp "regsvr32.exe" (strcat "/s \"" dbxserver "\""))
         (or (vl-registry-read "HKEY_CLASSES_ROOT\\ObjectDBX.AxDbDocument\\CLSID")
             (alert "Error: Failed to register ObjectDBX ActiveX services.")
             )
         )
        )
  )

;;;(setq dwgname(findfile "AecLayerStd.dwg"))
;;; 		Open a dbxDoc						;
;;; 		use (setq dbxDocument(kb:OpenDbxDocument dwgname)) ;
(defun kb:OpenDbxDocument (DwgName / app doc dbxopen dbxDoc)
  (setq app (vlax-get-acad-object)
        doc (vla-get-ActiveDocument app)
        )
  (if (/= dwgname (vla-get-fullname doc))
    (progn (cond ((= (substr (getvar "ACADVER") 1 5) "15.06")
                  (setq dbxDoc  (vla-GetInterfaceObject app "ObjectDBX.AxDbDocument")
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName))
                        )
                  )
                 (t
                  (setq dbxDoc  (vla-GetInterfaceObject
                                  app
                                  (strcat "ObjectDBX.AxDbDocument." (substr (getvar "acadver") 1 2))
                                  )
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName))
                        )
                  )
                 )
           (if (vl-catch-all-error-p dbxopen)
             (setq dbxDoc nil)
             )
           )
    )
  dbxDoc
  )

;;; (vlax-dump-Object dbxDoc t)
;;; Close dbxDoc
;;; (kb:CloseDbxDocument dbxDocument)
(defun kb:CloseDbxDocument (dbxdoc)
  (if (= (type dbxDoc) 'VLA-OBJECT)
    (progn (vlax-release-object dbxDoc) (setq dbxDoc nil))
    )
  )


;;;
(defun kb:DwgHasXrefs (/ xrefyes)
  (setq xrefyes nil)
  (while (setq xrecord (tblnext "block" (not xrecord)))
    (progn (if (cdr (assoc 1 xrecord))
             (setq xrefyes T)
             )
           )
    )
  xrefyes
  )

;;;
(defun kb:ListXrefs (/ xreflist)
  (vlax-for
         x (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
    (if (= (vlax-get-property x 'isxref) :vlax-true)
      (setq xreflist (append xreflist (list (vlax-get-property x 'name))))
      )
    )
  xreflist
  )

;;;(kb:ListBlocks)
(defun kb:ListBlocks (/ llist)
  (vlax-for
         x (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
    (if (and (= (vlax-get-property x 'isxref) :vlax-false)
             (= (vlax-get-property x 'islayout) :vlax-false)
             (not (vl-string-search "|" (vla-get-name x)))
             (not (vl-string-search "*" (vla-get-name x)))
             )
      (setq llist (append llist (list (vlax-get-property x 'name))))
      )
    )
  llist
  )

;;;(vlax-dump-Object xx)
;;;delete a block
;;;(kb:DeleteBlock "SC_ROOM_FINISH")
(defun kb:DeleteBlock (bname / blocks)
  (setq blocks (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object))))
  (vlax-for
         x blocks
    (vlax-for
           xx x
      (if (and (= (vlax-get-property xx 'ObjectName) "AcDbBlockReference")
               (not (vl-string-search "|" (vla-get-name xx)))
               (not (vl-string-search "*" (vla-get-name xx)))
               )
        (if (= (strcase (vlax-get-property xx 'name)) (strcase bname))
          (vla-delete xx)
          )
        )
      )
    )
  )



;;;
(defun kb:doclist (/ doc docs1)
  (vlax-for
         doc (vla-get-documents (vlax-get-acad-object))
    (if (= (vla-get-fullname doc) "")
      (setq docs1 (cons (strcase (vla-get-name doc)) docs1)
            docs1 (cons doc docs1)
            )
      (setq docs1 (cons (strcase (vla-get-fullname doc)) docs1)
            docs1 (cons doc docs1)
            )
      )
    )
  (reverse docs1)
  )

;;; Return Active Space Object
;;;(setq view(kb:GetActiveSpace))
(defun kb:GetActiveSpace (/ act ret)
  (setq act (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'activespace))
  (cond ((= act 1) ;modelspace
         (setq ret (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'modelspace))
         )
        ((= act 0)
         (setq ret (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'paperspace))
         )
        (t
         (setq ret (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'modelspace))
         )
        )
  ret
  )

;;; Return Active Space Object
;;;(setq view(kb:GetActiveSpace))
(defun kb:GetViewport (/ act ret)
  (setq act (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'activespace))
  (cond ((= act 1) ;modelspace
         (setq ret (vlax-get
                     (vla-get-activedocument (vlax-get-acad-object))
                     'activeviewport
                     )
               )
         )
        ((= act 0)
         (setq ret (vlax-get
                     (vla-get-activedocument (vlax-get-acad-object))
                     'activepviewport
                     )
               )
         )
        (t
         (setq ret (vlax-get
                     (vla-get-activedocument (vlax-get-acad-object))
                     'activeviewport
                     )
               )
         )
        )
  ret
  )


;;;
;;;Check to make sure ObjectDCL is loaded
;;;(setq go(kb:LoadODCL))
(defun kb:LoadODCL (/)
  (if (not
        (member (strcat "kb00." (substr (getvar "acadver") 1 2) ".ARX") (arx))
        )
    (arxload
      (strcat "kb00." (substr (getvar "acadver") 1 2) ".ARX")
      "Unable to load the correct kb00 ARX"
      )
    )
  )

;;; Degrees to Radians
(defun kb:D->R (numberOfDegrees) (* pi (/ numberOfDegrees 180.0)))
(defun kb:findblock (blkname / ss)
  (setq ss (ssadd))
  (vlax-for
         x (kb:GetActiveSpace)
    (if (vlax-property-available-p x "EffectiveName")
      (if (= (vla-get-EffectiveName x) blkname)
        (ssadd (vlax-vla-object->ename x) ss)
        )
      )
    )
  (if ss
    (sssetfirst ss ss)
    (alert "No Block found!")
    )
  (princ)
  )


(princ)
(princ)

 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
