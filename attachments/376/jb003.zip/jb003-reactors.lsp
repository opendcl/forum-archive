;;;								;
;;;		jbTools Xref Reactor Functions			;
;;;								;

;;;								;
;;;		Command Reactors				;
;;;								;


;;;		Support Functions				;
;;;		Only used by Routines in this File		;


;;;		Puts all Xrefs on layer "XREF"			;
;;;(jb:FixXrefLayers)(setq x(vlax-ename->vla-object(car(entsel))))
(defun jb:FixXrefLayers( / lo blks)
  (if(not(vl-string-search"\\Sheets\\"(getvar "dwgprefix")))
    (progn
  (if(not(tblsearch "layer" "xref"))
    (setq lo(vla-add(vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))"XREF"))
    (setq lo(vla-item(vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))"XREF")))
  (setq blks(vla-get-blocks (vla-get-activedocument(vlax-get-acad-object))))
  (if lo
   (progn 
     (vlax-for x(vla-get-blocks (vla-get-activedocument(vlax-get-acad-object)))
       (vlax-for xx x
           (if(=(vla-get-Objectname xx)"AcDbBlockReference")
             (if(and(=(vla-get-isxref(vla-item blks (vla-get-name xx))):vlax-true)
                    (not(vl-string-search"|"(vla-get-layer xx)))
                    (not(=(vla-get-layer xx)"XREF")))
               (vlax-put xx 'layer "XREF"))))))))));<---


;;;		Call-back Functions				;

;;;		Command Will Start				;
 (defun jb:XrefCommandWillStart(calling-reactor commands / lname)
   (cond
     ((member (car commands) (list"PLOT" "PRINT" "PREVIEW" "REGEN" "REGENALL"))
	 (jb:FixXrefLayers))

        ((member (car commands) (list  "MVIEW" "VPORTS" "-VPORTS"));"PLACEVIEW"
	 (setq lname "Defpoints"))

        ((member (car commands) (list "IMAGE" "-IMAGE")) ;"-XREF" "XREF" "XATTACH"
	 (setq lname "XREF"))

        
        
         )
   (if lname(jb:setclayer lname T)))

;;;		Command Ended					;
 (defun jb:XrefCommandEnded(calling-reactor commands / dwgdimscale)
   (cond
	((member (car commands) (list "MVIEW" "VPORTS" "-VPORTS"
                                      "IMAGE" "-IMAGE" ))
         (jb:resetclayer))
        )
   )

;;;		Command Cancelled					;
 (defun jb:XrefCommandCancelled(calling-reactor commands / )
   (cond((member (car commands) (list "MVIEW" "VPORTS" "-VPORTS"
                                       "IMAGE" "-IMAGE"
                                      ))
         (jb:resetclayer))
	)
   )


;;;		Construct the Command Reactor				;
(defun jb::XrefConstructCommandReactor  (/)
  (if (= (type *jbXrefCommandReactor*) 'VLR-Command-Reactor)
    (progn (vlr-remove *jbXrefCommandReactor*) (setq *jbXrefCommandReactor* nil)))
  (if (/= (type *jbXrefCommandReactor*) 'VLR-Command-Reactor)
    (setq *jbXrefCommandReactor*
           (VLR-Command-Reactor
             "jbTools Xref Command Reactor" ; Data associated with the editor reactor
             ;; call backs
             '
              ((:VLR-commandWillStart . jb:XrefCommandWillStart)
               (:VLR-commandEnded . jb:XrefCommandEnded)
               (:VLR-commandCancelled . jb:XrefCommandCancelled)
	       )) ;_ end of vlr-editor-reactor
          ))

  (if (not (vlr-added-p *jbXrefCommandReactor*))
    (progn
    (vlr-add *jbXrefCommandReactor*)
    (vlr-set-notification *jbXrefCommandReactor* 'active-document-only)));added 09.26.2003
  (princ))

;;; Loaded in jb-48-01b.fas



;;;				load reactors				;

    
(if jb::XrefConstructCommandReactor
  (jb::XrefConstructCommandReactor))





;;;									;
;;;			XREF Reactor					;
;;;	Uses the modelspace reactor to re-set clayer			;
;;;									;

;;;			Xref Call Back functions			;

;;;			Begin Attach					;
(defun jb:beginAttach  (reactor vla-object /)
  (if (not (tblsearch "layer" "XREF"))(vla-add (vla-get-layers (vla-get-activedocument(vlax-get-acad-object))) "XREF"))
  (setq jb%XrefAttach T)
  (if (tblsearch "layer" "XREF")(jb:setclayer "XREF" T))
  (princ)
  )


;;;			Construct Xref Reactor				;
(defun jb::ConstructXrefReactor  (/)
  (if (= (type *jbXrefReactor*) 'VLR-Xref-Reactor)
    (progn (vlr-remove *jbXrefReactor*)
	   (setq *jbXrefReactor* nil)))
  (if (/= (type *jbXrefReactor*) 'VLR-Xref-Reactor)
    (setq *jbXrefReactor*
	   (VLR-Xref-Reactor
	     "jbTools Xref Reactor" ; Data associated with the editor reactor
	     ;; call backs
	     '
	      ((:VLR-beginAttach . jb:beginAttach)
               )) ;_ end of vlr-xref-reactor
	  ))
  (if (not (vlr-added-p *jbXrefReactor*))
    (progn (vlr-add *jbXrefReactor*)
	   (vlr-set-notification *jbXrefReactor* 'active-document-only)))
  (princ))


;;;				load reactor				;


(if jb::ConstructXrefReactor
  (jb::ConstructXrefReactor))



;;;									;
;;;			ModelSpace Reactor				;
;;;	Uses the modelspace reactor to re-set clayer			;
;;;									;



(defun jb::StartResetReactor( / )
(if *jbMSReactor* (vlr-remove *jbMSReactor*))
(setq *jbMSReactor* (vlr-object-reactor (list (vla-get-modelspace (vla-get-activedocument(vlax-get-acad-object)))) nil '((:vlr-objectClosed . jb:resetXrefLayer))))
(if *jbPSReactor* (vlr-remove *jbPSReactor*))
(setq *jbPSReactor* (vlr-object-reactor (list (vla-get-paperspace (vla-get-activedocument(vlax-get-acad-object)))) nil '((:vlr-objectClosed . jb:resetXrefLayer))))

  )

(defun jb:resetXrefLayer (owner reactor_object reactor_list  /)
  (if jb%XrefAttach
    (progn
      (if dcl_HideErrorMsgBox
	   (if (dcl_Form_IsActive jb001_00)
	     (c:jb001_00_Refresh_OnClicked))
         )
      (jb:resetclayer)
      (setq jb%XrefAttach nil)))
  
  )

;;;				load reactor				;


(if jb::StartResetReactor
  (jb::StartResetReactor))

;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 T T nil T)
;*** DO NOT add text below the comment! ***|;
