;;;							;
;;;		Key Functions				;
;;;							;


;;; Find Function
;;;(setq x(vlax-ename->vla-object(car(entsel))))
(defun jb:findKeyNote (keynumber / ss ent xdata key)
  (setq	ss (ssadd))
  (vlax-for
	 x
	  (vla-get-ModelSpace (vla-get-activedocument (vlax-get-acad-object)))
    (setq ent(vlax-vla-object->ename x)
	  xdata (jb:getKeyNotexdata ent)
	  key(nth 0 xdata))
    (if (= key keynumber)
	       (ssadd ent ss)
	     )
      )
  (if ss
    (sssetfirst ss ss)
  )
  (princ)
)



 ;|�Visual LISP� Format Options�
(94 2 4 2 nil "end of " 72 6 0 0 1 T T nil T)
;*** DO NOT add text below the comment! ***|;
