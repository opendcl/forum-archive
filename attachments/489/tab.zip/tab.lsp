(defun c:tabtest (/ isInit intCondition intLatestTab c:tab_tabtest_OnInitialize
		    c:tab_tabtest_chb_acceptcondition c:tab_tabtest_tab_OnSelChanging
		    c:tab_tabtest_tab_OnChanged c:tab_tabtest_pb_close)

  (dcl_project_load "tab" T)

  (defun c:tab_tabtest_OnInitialize ( /)
    (dcl_Control_SetValue tab_tabtest_chb_acceptcondition (setq intCondition 0))
    (dcl_Tab_SetCurSel tab_tabtest_tab 1)
    (setq isInit nil)
  ); c:tab_tabtest_OnInitialize

  (defun c:tab_tabtest_chb_acceptcondition (intValue /)
    (setq intCondition intValue)
  ); c:tab_tabtest_chb_acceptcondition

  (defun c:tab_tabtest_tab_OnSelChanging (intSelIndex /)
    (if (not isInit)
      (setq intLatestTab intSelIndex)
    ); if
  ); c:tab_tabtest_tab_OnSelChanging

  (defun c:tab_tabtest_tab_OnChanged (intSelIndex /)
    (cond
      (isInit nil)
      ((not intLatestTab) nil) ;; don't know where to change
      ((and (= intLatestTab 1) (= intSelIndex 0))
       (if (/= intCondition 1)
	 (progn
	   (dcl_messagebox (strcat "You have to accept the conditions before changing the tab, " (getvar "LOGINNAME") "!") "Conditions not accepted" 2 4)
	   (setq isInit T)
	   (dcl_Tab_SetCurSel tab_tabtest_tab 1)
	   (dcl_Control_SetFocus tab_tabtest_chb_acceptcondition)
	   (setq isInit nil)
	 ); progn
       ))
    ); cond
    (setq intLatestTab nil)
  ); c:tab_tabtest_tab_OnChanged

  (defun c:tab_tabtest_pb_close ( /)
    (dcl_form_close tab_tabtest)
  ); c:tab_tabtest_pb_close

  (setq isInit T)
  (dcl_form_show tab_tabtest)

  (princ)
); tabtest