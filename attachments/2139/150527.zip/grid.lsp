;;;
;;; GRID Beispiel
;;;
;;; Dieses Beispiel demonstriert das Datenblatt mit all seinen Ereignissen.
;;;

;; Hauptprogramm
(defun c:Grid (/ cmdecho c:grid/Schriftinfo#OnInitialize)

  ;; Stellt sicher, dass die Laufzeitumgebung im Hintergrund geladen wird
  (setq cmdecho (getvar "CMDECHO"))
  (setvar "CMDECHO" 0)
  (command "_OPENDCL")
  (setvar "CMDECHO" cmdecho)

  ;; L�dt das Projekt
  (dcl-Project-Load "D:\\Service\\Support\\OpenDCL\\150527\\Grid.odcl" T)

  (defun c:grid/Schriftinfo#OnInitialize()
    (dcl-Grid-AddRow grid/Schriftinfo/Schriftinfo2 "ich" "du")
    (dcl-Grid-AddString grid/Schriftinfo/Schriftinfo2 "OpenDCL\twww.opendcl.com" "\t")
  ); c:grid/Schriftinfo#OnInitialize

  ;; Zeigt den Hauptdialog an
  (dcl-Form-Show Grid/Schriftinfo)

  ;; Dies ist ein modaler Dialog, so dass das Programm nach (dcl-Form-Show)
  ;; erst fortf�hrt, wenn der Dialog geschlossen wurde. In der Zwischenzeit
  ;; behandeln die Ereignisse den Dialog.

  (princ)
)

;|�OpenDCL Event Handlers�|;

