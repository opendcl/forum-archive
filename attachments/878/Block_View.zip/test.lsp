(defun see ()
  (dcl_project_load "D:/Test" T)
  (dcl_form_show Test_Form1)
  (princ)
)



(defun c:Test_Form1_OnInitialize (/)
  (dcl_BlockView_DisplayDwg Test_Form1_BlockView1 "D:/Block.dwg" 0 0.95)
)


(defun c:test ()
  (command "_zoom" "_e")
  (see)
  (command "_zoom" "_c" '(0 0) 20)
  (see)
  (princ)
)  
  