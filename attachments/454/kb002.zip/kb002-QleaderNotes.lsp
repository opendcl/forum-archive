;;;								;
;;;	Fix Width when scale changes				;
;;;								;

(defun kb:FixWidth(ent / obj xdata key note objtype owidth newwidth nscale oscale)
  (setq obj(vlax-ename->vla-object ent)
            xdata(kb:getKeyNotexdata ent)
	    key(nth 0 xdata)
	    note(nth 1 xdata)
	    objtype(nth 2 xdata)
            oscale(distof(nth 3 xdata)2)
            owidth(vla-get-TextWidth obj)
            nscale(kb:cannoscale)
            newWidth(/ nscale oscale))
  (if (/= oscale nscale)
    (progn
      
      (vla-put-TextWidth obj (* newwidth owidth))
      (kb:putKeyNotexdata ent key note objtype nscale)
      )
    )
      )
    
(defun c:kbFixWidth( / *Error* doc ss cnt num snt)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq doc(vla-get-activedocument(vlax-get-acad-object))
      ss (ssget'((-4 . "<OR")(0 . "MULTILEADER")(0 . "MTEXT")(-4 . "OR>"))))
  (vla-StartUndoMark doc)
  (if ss
    (progn
    (setq cnt 0 num(sslength ss))
    (while(< cnt num)
      (setq ent (ssname ss cnt))
            (kb:FixWidth ent)
            (setq cnt(1+ cnt))
      )
    )
    )
  (vla-EndUndoMark doc)
  (princ)(princ)
  )
            
            


;;;								;
;;;	Change between a KEYLEADER type and a			;
;;;	NOTELEADER type						;
;;;								;
;;;(setq obj(vlax-ename->vla-object(car(entsel))))		;
(defun c:kbSwapKeyandNote( / *Error* ss cnt num ent obj xdata key note objtype width nscale kb%mtextFlag)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq doc(vla-get-activedocument(vlax-get-acad-object))
      ss (ssget'((-4 . "<OR")(0 . "MULTILEADER")(0 . "MTEXT")(-4 . "OR>"))))
  (vla-StartUndoMark doc)
  (if ss
    (progn
    (setq cnt 0 num(sslength ss))
    (while(< cnt num)
      (setq ent (ssname ss cnt)
            obj(vlax-ename->vla-object ent)
            xdata(kb:getKeyNotexdata  ent)
	    key(nth 0 xdata)
	    note(nth 1 xdata)
	    objtype(nth 2 xdata)
            width(kb:TextWidthValue)
            nscale(rtos(kb:cannoscale)2 1)
	    )
      	    
      (if (not width)
        (setq width 2.5)
        )
      
      (cond ((= objtype "NOTELEADER")
             (progn (vlax-put-property obj 'TextString key)
                 (kb:putKeyNotexdata ent key note "KEYLEADER" nscale))
             )
            ((= objtype "KEYLEADER")
             (progn (vlax-put-property obj 'TextString note)
               (if (=(vlax-get-property obj 'TextWidth)0.0)
               (vlax-put-property obj 'textwidth width))
                 (kb:putKeyNotexdata ent key note "NOTELEADER" nscale))
             )
            ((= objtype "MTEXT")
             (if (not kb%mtextFlag)
               (progn
             (dcl_messagebox "Sorry, you can't change MTEXT objects" "Swap Keys and Notes" 2 1)
             (setq kb%mtextFlag T)))
             (princ "\nCan't change an MTEXT object, Dude")
             )
            )
      (setq cnt(1+ cnt))
      )
    )
    )
  (vla-EndUndoMark doc)
  (princ)
  )


;;;								;
;;;	Place a KeyNote and Qleader				;
;;;	Qleader and Mtext					;
;;;	NOTE USED						;


(defun c:kbPlaceKeyNoteQleader  (/ *Error* text p1 p2 key note qleader qleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (dcl_ListBox_GetText
               kb002_00_KEYLIST
               (dcl_ListBox_GetCurSel kb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq key  (substr text 1 (vl-string-position (ascii "\t") text))
            note (substr text (+ 2 (vl-string-position (ascii "\t") text)))
            doc (vla-get-ActiveDocument (vlax-get-acad-object)))
      (if (and key note)
        (progn 
               (vla-StartUndoMark doc)
               (kb:SetAcadDim
                 '((3 . "")(40 . 0.0)(60 . 0)(61 . 0)
                   (62 . 1)(63 . 1)(64 . 0)(65 . 0)
                   (67 . 2)(68 . 1)(69 . 0)(70 . 0)
                   (72 . 0)))
               (prompt "\nSpecify first leader point: ")
               (vl-cmdf "_.qleader" pause)
               (prompt "\nSpecify next point: ")
               (vl-cmdf pause)
               ;(prompt "\nSpecify text width: ")
               (vl-cmdf "" "." "")
        (setq qleader (entlast))
        (if (= (vla-get-objectname (setq qleaderObj (vlax-ename->vla-object qleader)))
               "AcDbMText")
          (progn (vlax-put-property qleaderObj 'TextString key)
                 (kb:putKeyNotexdata (entlast) key note "KEYLEADER" nscale)))
          (vla-EndUndoMark doc)
          )
        )
      )
    )
  (princ)
  )

;;;								;
;;;	Place a Keyed Note and Qleader				;
;;;	Qleader and Mtext					;
;;;	NOT USED						;

(defun c:kbPlaceNoteQleader  (/ *Error* text p1 p2 key note qleader qleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (dcl_ListBox_GetText
               kb002_00_KEYLIST
               (dcl_ListBox_GetCurSel kb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq key  (substr text 1 (vl-string-position (ascii "\t") text))
            note (substr text (+ 2 (vl-string-position (ascii "\t") text)))
            doc (vla-get-ActiveDocument (vlax-get-acad-object)))
      (if (and key note)
        (progn 
               (vla-StartUndoMark doc)
               (kb:SetAcadDim
                 '((3 . "")(40 . 0.0)(60 . 0)(61 . 0)
                   (62 . 1)(63 . 1)(64 . 0)(65 . 0)
                   (67 . 2)(68 . 1)(69 . 0)(70 . 0)
                   (72 . 0)))
               (prompt "\nSpecify first leader point: ")
               (vl-cmdf "_.qleader" pause)
               (prompt "\nSpecify next point: ")
               (vl-cmdf pause)
               (prompt "\nSpecify text width: ")
               (vl-cmdf pause "." "")
        (setq qleader (entlast))
        (if (= (vla-get-objectname (setq qleaderObj (vlax-ename->vla-object qleader)))
               "AcDbMText")
          (progn (vlax-put-property qleaderObj 'TextString note)
                 (kb:putKeyNotexdata (entlast) key note "NOTELEADER" nscale)))
          (vla-EndUndoMark doc)
          )
        )
      )
    )
  (princ)
  )
;;;								;
;;;	Place a KeyNote and Leader				;
;;;	Mleader and Mtext					;
;;;								;

(defun c:kbPlaceKeyNote	 (/ *Error* text key note mleader mleaderObj gap)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq	text (dcl_ListBox_GetText
	       kb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel kb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq  key	 (substr text 1 (vl-string-position (ascii "\t") text))
	    note (substr text (+ 2 (vl-string-position (ascii "\t") text)))
	    nscale(rtos(kb:cannoscale)2 1))
      (if (and key note)
	(progn
	  (command
	    ".mleader"
	    "_O"
	    "_C" "_M";make sure the content is mtext
	    "_X"
	    pause pause "." "")
	  
	  (setq mleader (entlast))
	  (if
	    (= (vla-get-objectname (setq mleaderObj (vlax-ename->vla-object mleader)))
	       "AcDbMLeader")
	     (progn 
	       (vlax-put-property mleaderObj 'TextString key)
	       (kb:putKeyNotexdata (entlast) key note "KEYLEADER" nscale)
	       (vlax-put-property mleaderobj 'DoglegLength 0.125)
	       )
	    )
	  )
	)
      )
    )
  (princ))

;;;								;
;;;	Place a Keyed Note and Leader				;
;;;	Mleader and Mtext					;
;;;								;

(defun c:kbPlaceNote  (/ *Error* text p1 p2 key note mleader mleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq	text (dcl_ListBox_GetText
	       kb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel kb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq key	 (substr text 1 (vl-string-position (ascii "\t") text))
	    note (substr text (+ 2 (vl-string-position (ascii "\t") text)))
	    width(kb:TextWidthValue)
            nscale(rtos(kb:cannoscale)2 1)
	    )
      ;(if (not width)(setq width 96.0))
      (if (and key note)
	(progn
	  (command
	    ".mleader"
	    "_O"
	    "_C" "_M";make sure the content is mtext
	    "_X"
	    pause pause ".")
	  (setq mleader (entlast))
	  (if
	    (= (vla-get-objectname (setq mleaderObj (vlax-ename->vla-object mleader)))
	       "AcDbMLeader")
	     (progn (vlax-put-property mleaderObj 'TextString note)
		    (vlax-put-property mleaderobj 'DoglegLength 0.125)
	       (vlax-put-property mleaderObj 'TextWidth width)
		    (kb:putKeyNotexdata (entlast) key note "NOTELEADER" nscale)))))))
  (princ))

;;;								;
;;;	Place a Keyed Note Only					;
;;;	Mtext Only						;
;;;								;

(defun c:kbPlaceTextNote  (/ text key note lname ent nscale)
  (setq	text (dcl_ListBox_GetText
	       kb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel kb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(substr text 1 (vl-string-position (ascii "\t") text))
		   note	(substr text (+ 2 (vl-string-position (ascii "\t") text)))
                   nscale(rtos(kb:cannoscale)2 1)
	    )
	     (vl-cmdf ".mtext" pause pause note "")
	     (setq ent (vlax-ename->vla-object (entlast)))
	     (if (= (vla-get-ObjectName ent) "AcDbMText")
	       (kb:putKeyNotexdata (entlast) key note "MTEXT" nscale)))))
  (princ))


;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
