;;;								;
;;;	KB Layer Tools						;
;;;								;

CUI and FAS files compiled under AutoCAD 2009

Kb Layer Tools is a suite of ObjectDBX derived Layer Standard tools.  KB Layer Tools uses a remote file; "LayerStandard.dwg".  This file contains all standard Layer Names and Standard Layer States.  "LayerStandard.dwg" MUST be in AutoCAD's Search Path.

Instructions for use:

Unzip "kbLayerTools.zip".  The "Program" folder contains all the run-time files to create the commands in AutoCAD.  If this program is to deployed via a network, copy this folder to a network path that is in AutoCAD's Search Path.  It is VERY important that kbnLayerTools is in a place AutoCAd can find.

The "Source Files" folder contains all the files used to compile the kbLayerTools program.  This can remain on an administrators machine, or in a program developement folder on a network.  These files need to be protected so that later compilation into later releases of AutoCAD can be completed.

The "Images" folder contains bitmaps of toolbar button images.  These bitmaps have been compiled into the resource dll "kb001.dll" for use with the cui / mns files.

Menu Driven application:

In the "Program" folder is "kb001.mns".  This is a legacy AutoCAD menu file that can be loaded in any version of AutoCAD.  Once the menu file is loaded, the "kb001.mnl" file handles loading all files required to run kbLayerTools.  Sometimes, when a menu is first loaded, the customization files don't get loaded in the active drawing.  Once a new drawing is opened, all customization files are loaded and active.

Program driven application:

Using the AutoCAD "appload" command, load the "kb001.fas" file into AutoCAD to access the commands via the command line.

Defined Commands:

kbLayerTools - This command brings up a composite OpenDCL modeless (floating) form which has two states: a toolbar like form with a drop down for changing Layer States, and a floating form with more options, including Importing Layers.

kbLayerToolsp - This is a palette form that contains all the controls to manipulate Layer States and Import Layers.  Note that Xref Layer States can be set independantlty.

kbLayerToolsPop - This is a simple "pop-up" style form with a list of Layer States to set and options for selecting an xref to set independantly.  This can also be set up as a cursor pop-up: just set "kbLayerToolsPop" up in the "ACAD.pgp" file as a shortcut command and the form will apprear at the cursor - just like a right-click menu.

OpenDCL

This program requires OpenDCL, which is a free open source program available at http://sourceforge.net/projects/opendcl/.  Download and Install the Latest build before using kbLayerTools.  If using the menu driven program, the .mnl file loads OpenDCL automatically.  If using appload, make sure to have OpenDCL loaded.