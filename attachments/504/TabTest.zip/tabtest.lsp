(defun c:TabTest_Form1_TabStrip1_OnSelChanging (ItemIndex /)
  (/= 1 (dcl_Control_GetValue (nth ItemIndex (list tabtest_Form1_CheckBox1 tabtest_Form1_CheckBox2 tabtest_Form1_CheckBox3))))
)

(defun c:TabTest ()
  (command "._OPENDCL")
  (dcl_Project_Load "TabTest" T)
  (dcl_Form_Show tabtest_form1)
)
