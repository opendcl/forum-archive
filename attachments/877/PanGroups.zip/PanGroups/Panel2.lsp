;;; Roll Down / Roll Up
(defun c:PanGroups_Panel2_Roll_OnClicked (/) (@:Set_FormState "PanGroups" "Panel2" "Roll"))
;;; Move Panel Group
(defun c:PanGroups_Panel2_OnMouseMovedOff (/) (@:Move_PanGroup "PanGroups" "Panel2"))
;;; Corner Magnets
(defun c:PanGroups_Panel2_BLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel2" "BLMag"))
(defun c:PanGroups_Panel2_BRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel2" "BRMag"))
(defun c:PanGroups_Panel2_TLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel2" "TLMag"))
(defun c:PanGroups_Panel2_TRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel2" "TRMag"))