;;; BC 11.4.6
;;; ODCL 6.0.2.5
;;; Win XP


;;; Problem:
;;; dcl_BlockView_DisplayBlock does not display a block that is not inserted.
    ; : ._OPEN
    ; Drawing name: D:/LispTools/test.dwg
    ; : 
    ; : 
    ; : (LOAD "D:/LispTools/DwgBrowser.lsp")C:DWGBROWSER
    ; : DWGBROWSER
    ; : OPENDCL
    ; OpenDCL Runtime [6.0.2.5] loaded
    ; : (dcl_BlockView_DisplayBlock DwgBrowser_Form1_BlockView1 "Square" 0 0.95)     <<<<<< Paste code on command line.
    ; T                                                                              <<<<<< T but block does not display.
;;;
;;; Do the same with test_inserted.dwg => block does display.


(defun c:DwgBrowser ( / )
  (command "OPENDCL")
  (dcl_Project_Load "DwgBrowser" T)
  (dcl_Form_Show DwgBrowser_Form1)
  (princ)
)
