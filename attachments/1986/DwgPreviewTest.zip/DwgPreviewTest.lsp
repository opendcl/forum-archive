(setq kcs#symsched_path "C:\\_KCS\\Kcs_SymSched\\");***** SET HERE **** (TEMP) *********
;============================================================================|

(defun c:DPTEST (/ path )
  (setq dwg (strcat kcs#symsched_path "VERTBRDR.dwg"))
  (kcs_opendcl) ; "OpenDCL Runtime [8.0.0.4] loaded" (first time)
  (dcl_Project_Load (strcat kcs#symsched_path "DwgPreviewTest.odcl") t) ; T forces reload
  (setq return (dcl_Form_Show kcs#SS_SymSelect))
  (princ)
)

;============================================================================|
; ODCL Form functions
;============================================================================|
(defun c:kcs#SS_SymSelect#OnInitialize (/)
  (dcl-DWGPreview-LoadDwg kcs#SS_DwgImage dwg)
)
