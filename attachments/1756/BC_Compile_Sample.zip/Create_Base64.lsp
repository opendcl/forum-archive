(setvar 'cmdecho 0)
(command "OPENDCL")
(setvar 'cmdecho 1)

; (Create_Base64 "BC_Compile_Sample" "MYPASS" (strcat (getvar 'dwgprefix) "BC_Compile_Sample_Base64.txt"))
; project  - ODCL project as string.
; password - Password as string.
; file     - File with full path as string.
(defun Create_Base64 (project password file)
  (dcl_Project_Load project T)
  (setq file (open file "w"))
  (write-line (dcl_Project_Export project password) file)
  (close file)
)
