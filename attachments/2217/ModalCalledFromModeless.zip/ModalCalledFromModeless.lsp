(if (not dcl-GetVersion)
  (progn
    (princ "\nLoading... ")
    (setvar 'cmdecho 0)
    (vl-cmdf "_Opendcl")
    (setvar 'cmdecho 1)
  )
)

(defun c:Test ( / ret)
  (dcl-Project-Load "ModalCalledFromModeless" T)
  (setq ret (dcl-Form-Show ModalCalledFromModeless/diaMain))
  (princ)
)

(defun c:ModalCalledFromModeless/diaMain#OnMouseEntered (/)
  (dcl-Control-SetFocus ModalCalledFromModeless/diaMain)
  (princ)
)

(defun c:ModalCalledFromModeless/diaMain/btnNext#OnClicked (/)
  (dcl-Form-Show ModalCalledFromModeless/diaSub)
)

(defun c:ModalCalledFromModeless/diaMain/btnOK#OnClicked (/)
  (dcl-Form-Close ModalCalledFromModeless/diaMain 1)
  (princ)
)

(defun c:ModalCalledFromModeless/diaMain/btnCancel#OnClicked (/)
  (dcl-Form-Close ModalCalledFromModeless/diaMain 0)
  (princ)
)

(defun c:ModalCalledFromModeless/diaSub/btnOK#OnClicked (/)
  (dcl-Form-Close ModalCalledFromModeless/diaSub 1)
  (princ)
)

(defun c:ModalCalledFromModeless/diaSub/btnCancel#OnClicked (/)
  (dcl-Form-Close ModalCalledFromModeless/diaSub 0)
  (princ)
)
