;			*************************************************************************
(setq x:last_time (getvar "cdate"))
(while x:myreactor (setq x:myreactor (vlr-remove x:myreactor)))
(setq x:myreactor (vlr-command-reactor 'nil (list (cons :vlr-commandwillstart 'p:request_project_unload))))
;			*************************************************************************
(defun c:VLIDE|demo_Demo_OnMouseEntered (/)
  (p:add_string "Mouse In")
)
;			*************************************************************************
(defun c:VLIDE|demo_Demo_OnMouseMovedOff (/)
  (p:add_string "Mouse Out")
)
;			*************************************************************************
(defun c:VLIDE|demo_Demo_Listenfeld1_OnMouseMove (intFlags intX intY /)
  (p:add_string_1sec "Mouse Moved in List")
)
;			*************************************************************************
(defun c:VLIDE|demo_Demo_OnClose (intUpperLeftX intUpperLeftY /)
  (p:request_form_close VLIDE|demo_Demo)
)
;			*************************************************************************
;			*************************************************************************
(defun p:add_string (s)
  (dcl_ListBox_AddString VLIDE|demo_Demo_Listenfeld1 (strcat (rtos (getvar "cdate") 2 8 ) "\t" s))
  (dcl_ListBox_SetCurSel VLIDE|demo_Demo_Listenfeld1 (1- (length (dcl_Control_GetList VLIDE|demo_Demo_Listenfeld1))))
)
;			*************************************************************************
(defun p:add_string_1sec (s / )
  (cond ((> (getvar "cdate")
	    (+ x:last_time 0.000001))
	 (setq x:last_time (getvar "cdate"))
	 (p:add_string s)
	 ))
)
;			*************************************************************************
;			*************************************************************************
(defun c:odcl_vlide_error (/ p)
  (cond ((setq p (dcl_project_load (findfile "VLIDE demo.odcl") 'T))
	 (setq x:active_forms (append x:active_forms (list (list VLIDE|demo_Demo p))))
	 (dcl_Form_Show VLIDE|demo_Demo)
	 ))
)
;			*************************************************************************
;			*************************************************************************
(defun p:request_form_close (form / l)
  (cond ((setq p (cadr (assoc form x:active_forms)))
	 (setq l x:active_forms
	       x:active_forms (list))
	 (foreach x l
	   (if (not (equal (car x) form))
	     (setq x:active_forms (append (list x))))
	   )
	 (cond ((not (member p (mapcar 'reverse x:active_forms)))
		(setq x:unload_requested (cons p x:unload_requested))
		))
	 ))
)
;			*************************************************************************
(defun p:request_project_unload (a b / r)
  (setq r (list))
  (foreach p x:unload_requested
    (if (not (member p (mapcar 'reverse x:active_forms)))
      (if (member p (dcl_getprojects))
	(dcl_project_unload p))
      (setq r (cons p r))))
  (setq x:unload_requested r)
)
;			*************************************************************************
;			*************************************************************************
