;;; Roll Down / Roll Up
(defun c:PanGroups_Panel3_Roll_OnClicked (/) (@:Set_FormState "PanGroups" "Panel3" "Roll"))
;;; Move Panel Group
(defun c:PanGroups_Panel3_OnMouseMovedOff (/) (@:Move_PanGroup "PanGroups" "Panel3"))
;;; Corner Magnets
(defun c:PanGroups_Panel3_BLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel3" "BLMag"))
(defun c:PanGroups_Panel3_BRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel3" "BRMag"))
(defun c:PanGroups_Panel3_TLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel3" "TLMag"))
(defun c:PanGroups_Panel3_TRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel3" "TRMag"))