;;;							;
;;;	kbWorkingStates v2.0				;
;;;	include files:					;
;;;		kbCommonFunctions			;
;;;		kbCommonLayerFunctions			;
;;;							;

(vl-load-com)

(if (not (vl-bb-ref 'kbLayerTools))
  (vl-bb-set
    'kbLayerTools
    (dcl_project_import
      '("YWt6A+PRAAB85pCeBuKTQ3USYqkPDdxaLNxbVDBTueGmiln38jxQBzUv2mu632p1gJZpN9Dt3vME"
"gtKz9ux2N0ij3mFIC3PLc65qO2JipNwX5do2rNrQlcoX3agqY2YIA3ZySs59qngsdtZ9qQ/aACJf"
"FM3j5wMNxQmNCBGREJG2XYlj8cVJhUCNmLOyhbIFzWV/voX3WaFLOR9ieI5NdkOGmtsQ/hBtXZkh"
"EWO+Zgem8KFCuaL0qRMGC44QdjgebAERu0bdTn9QoDMcopMGSXYthttqPYYPgmxDtK+/invyQb6P"
"+EYzf9H94p1OmEf8CV0GSfQxyJwLdi1yHGcqdKMzDPTLzkD61foVx3hHJlt+8s70rl6OjQ5bqnZq"
"k17S6OFHfYSr3u5hHkt2ivHO2ESfdWu7TJa0Xp+5DQDS0OK0gBFUlL7eERauIZXC4HA+QUjPgEm+"
"IGygLP+p5KMOfDC8T9paQ6LczYZBWtA/LpSPeWSKNnuWtHfGfXwARLypXc5h8L1Q5r9sMV85Lswx"
"KFrFWESn+U6vevKfiUoyHRd7wjAfrU31KBoMHQpYCZ/p7OO6UvC9/c5xTYtNQPoOQTW0jisjwcd0"
"rquvG6L9oRc4zP5L47hkhAcAMJmHF3PE0j/xKPz6sdcj29MAuLyZ1XFdlfC/OYevaze2Unf8COQ4"
"tGJT7YdRShAhrd7RFa7hFa4y51HHcHpE1D+5tEuywxN6k/rwi3dzhBMjnHG1qlf9bBT+K9JxtUE9"
"rAG/XstBfpNNzMYoNYHtJGiBLFXpi2RqLFB8RCDvg2sF7/+Fj4VuSKhyAITv0xnuv1eUoXu2g66e"
"ZdHkSOdM4K7mItuLrn/TT/SCwVyoC38WtP5AYloCvf6olvSAOl2P6NidwSkqFp0/Gm1fvXdqo50G"
"WQTw3MHXb8Ir7Zo5xMyRr94DJHGh2R2Tr97DZArReMMxqQE1Gy1bK3YVCF9ohe83kLTmwXTHxOch"
"Zoj+MGaxglBWmOkmV0+BhN79IzwyUZbZu4rELcWooNd7MsFcxEsveHrqmpHLVv0L+e9RdI71NuN8"
"rPJ6Oe0Kj7eNQbPsWUtTyUTusCtYKDO7yd9hOw5x7ee44oNGvES/Q63XqircWhL5NIIXI5IrRCg2"
"W/ToclfFQBYXOVRq1CXZgnV6Y5c4/gwzE8zNgE61slASNOQw4ppYE+KniBWU2qCYj3PCve6F/cR5"
"NEiepWv+Qr0sqRaYyIoHHUSo48Tc6BBOukFBe/QBkKuCXXdlmGG2VyqdJzT2TacIQ4YwJilQ7+0z"
"FmoQ/iB/bxWu1kfS10D645pX5jsydwj0y6dD9q9ScVYwKZZLIeWj9uM5Vj10I3jhACtoKrEae0Gl"
"vsuFXoigxf+AYfzFJUgGY5CCv9X2PIKei6E+d8xa8mHCMD3VedHXcyrtV3s3ptz/1F4vR9TEoEAu"
"0xqMa08mW+5W/urp6S21tbny6OVZToNOQIuNDm9M/MFWSfwyj0xLm0+6MTlOCGANY7qVeoAMjrce"
"ukyL1FRHsBOxK40skBM2QK2RiMeWToyuP02lMbL8P8xrvfzTljKo/NNNv/jnvJCMSgncLbXOFYdE"
"1tCbEDasy2J7q8sK/ZQkesLWI7XFDdQVx2islSRaKAKpTHjrlD6UHi15FXEdXfK/fY7NplAkZyJp"
"G3N2bBvUXnZX1/zz+S9QdU75LDdqqJ2Xm9tmqP4scmlf9xyGela7Dnjo5xxuLmT0/7iW3GYQ+B4c"
"C/M7T9JBuk1CzCiEKK8/HXvIUn0kmpnBrCQQdXe1zXgKT35DFD6B3z9pfHDuxxjM2+0G6Gj3M7jB"
"6FBVumq5P0+7da5eLbrSMLpNe1O6dy2uK9YB+ftXBInOb4ZQYn2sJg5ywUpU2vZlVGSCaAXBHzFQ"
"OIIPmsnwkDlgNlpkYaveM7NskW4VlSOiE66Ye1+gscvZGW2g8CF2wa/+kHY+qWauCNP2RdvxhVw6"
"iA8J6+nDtCs22EhI6Wm7tHeN5GI9xDr1wA/K+KXYjRTaDaJsyVam8U2jAJq8bY5OdUgnYlm0vKOx"
"jeIA4JcqsAeslhIx/6zVPJL4KQP5S0s81CgE+y8zuJqkiSTtb0OaZKHNWemVPK4UKm4DjqPp4PkL"
"wvgwH5mgH+1RI8l+066FOPzib637UPZ2jYJ5jY2A+0AGzc7OfnXRUL77AYRs0RNulY55ARKgwmfQ"
"wYAExoeY5Z/IpRD9hZHBYYiQo3VFCZD6r68v5oFbcXBijp6JnhuOoFK/DVGBdiAAgwuGsunB+Avd"
"orbGI7oRd0YNtKo/5v1O+R7gYbs7xvVJULwj+sXg4dL2jly89Ybd9o7cuSc/d59b+uluIDw+d59g"
"gIiOySmcEkPQ+/WhXAA1yni6Vkdwq3Of9v39RkZm5y88YmK6vz9iYrq/P2JmM7q/P2Jiur8/YmK6"
"/y85YmK6vz9iYrq/P2JiUr4/QmK6vR9CQsEE8ncD9IZTn6mN1fLGxibG9XvH5tf1xk5njt/1SVCc"
"nFxQMmi6vTtCIrq9U2yyjTf7Bsb2/fVGxvZ977A7QiK6vztiNCoRgrFaugyCMbfuqR/y9HCDiAIs"
"Hac7utf2+2jP/lycKrrM9YbO9udq9erpmUl56fMOUsH2m2nPAhTcXOghWkacLjpi9OC5s5jJ+rXb"
"bRiqwlu63/qb627JbJwvvIzGF3dx2j93j1ZvYCZPEBAyKjwiNPY1d+9WH/+yfPY1d23oTix3f1u6"
"+6bcOsYe5epu6Wyv/Q9fEN4oVkxVB/b9+UYG9v35Rgb2fc1tnC48YkK6vz1iNPZ9zWacnl9wYJye"
"X3BgnP4nnWmf9v35Rgb2/SncM9PmeRiYHzxxXcdQy2/I3TkbLqBqufvlzjVHDJp2srOzv53xQXAx"
"Qo96woac9Y6qLTG/VdHCfNHDiGTiQQFgoAadc8YGj1wixAp3UCKInnXhgUK0TzdKTUPnpYJ1A0LI"
"wCsW/81iSlpikoT9jUeVOVFVWrJDSC9WT4Hji02ul1969lWhsT7bedHyAlKA2Lirl08Hc4IzGrD7"
"reFDZdrZmo+GBR9qgnrpsDQEAGrxwTQxyjLywR4guMbiILYnSYAABI1VXi7HQMusBQAE0eThvrA0"
"5IDYAjWMWpNhoii40buBmzZIx/fp4dQ8HDwLguMFQR6QliSnlYUd9DldNBzsi1MKDzUjw64L9/6p"
"Uwoj3hqRIJYEg0x/aMTgmaaxCwP4zQXf1eWfmXKCogtAgiJpMdSfIol8camwi7OJD4RlB+pxgRfq"
"86EsxVMtt0thTyjTPZcyPwCSW6f1XXfB2nkbt5hlwa/4M0YB20/PMj/grM88zWxPuYDXuJr1RJ8p"
"iuyjKX0uwX97JXm+2csbtI0Z89CKA0evGhgguYRtI71BqDVB9cSGWatwszmMR0th70c6dakHdoqN"
"BDe+zNqJM3Ok3j8X0LNiF4UMs8ZQj/J4J2gLAE2vRLERF66RWSRzhOZ4WyW5J5SIjGKZSPeufLDZ"
"txzA4/EOE5n9JMDDAuxxD4eIjH+w035wYZjkvpFOAI12250jQxPP6cENQbJcFLk9SOaOINmj1hcZ"
"sqw722YT90R46lrFstZo+oYAoRwqxb/Khsyh0qvOn5JfLkOSFXjqrBjTiYZVrC0CWNFhB8NBCsYR"
"bAHH+K0bWw5ECH0fhQQfN6bcPUeqzp8Dhix5pSCcq3kG64GQ1kDEzes/VQihNdLuTMbby7Q+bMgs"
"Z7awkYZDiEn+LHihfVuYEedsJVppM/MwvdgX1xdcrQqg4qQgQq2KVXhqTDMBsv5ErUpTpvnmPAT2"
"ux/0JJ3KoAXOtn3CQ48Otiqk1E/4A52wpI4mUGUR6j/oYwKhfkug7vrz8klIKWA+RmtkA4ad8yjy"
"Vui62OCJZS7bjJXJsUCSPMxcGGU3azdh43lzLRlpovGBF88MYbxL1xHL7URA5Ws/jIhUoSDkDOKY"
"97i9VphZB+TDYquOYf8svXE+bEuCXjoIg1fXn6VxZ5FXgKpQ0vjZhzYam+epd6DQigDq4+2Of4JD"
"sNfwXwrskQo1UOUzpHneDKXjKrXIkxATBpVpQxCPLBIZEu3F34hIx1vPR1DnG9SD5Z1aH1VrpKE8"
"2jwlFOWdWqhI485vMwYLm3wmBoZXNSCr7ftKCqVvLsTTuyWhWoXYyMDv/X73Bdk7fSBvNosQ2qVg"
"oIJUpE7nO7XcTUHAolIkwd41UhYuvQjRGiSkHMDUKqJvfZjWWCBCW+ASUT+jZXlaKEVCR0LYtYbq"
"ePtKiOZ/Vx2B0XsPoH8z0GiCBMO4AH8BRePjtWW8/S6hmAhEm8t/l8I99CaSLIkXZMummFE4LGzA"
"L2rCfGE+YBmtVOcVOS+5cWWNVWMYoPTuPx32W1HkmgPtrK4vG0y8aE5wm5fP4bAf+vCM5uPyyj0S"
"wlNeRzlGOUyr8MwHBmKN5x4m/8MILJIvSG3xXLK75Kqf2Q3OYMdA1mdcc0HjKecmF4aXaq6tZCqt"
"MZkrHwhwwiusNj3CdIu9MPrg0hjuGIIGTJbtZCqtnZgeZUIQNGc1u50YEa46n3gUwhH0IV9vSJIe"
"1SnMy27nRPlE53XuGlMabCrBjVTWy+4YGH6RXDzini3CCEEhg/YL/5l22bXCoFw5AtzXpBWWqF0P"
"tcyKXnGDErzPXKg2O/+uFjVgciZqNnHHakX46kX/5IJ61N+4K/kbckVm/kBzN0r+/iyNTVhiJIk0"
"/7uQU/wCBdbcx7a7/RnLXvnq/PKuUhmYBIqKnlgjuTujB1TeaNV8rn3eBpNeiIx5ywISItyV7+Xs"
"VswUXxMIkGRgILYPwHaBwx+xlzNxV5ZirzRjLIJJVvtcNF4ANp9nWiSZfNPU50U2PbrVfd8RM9HD"
"wPJ3cyi6fv8+CiOVIRHb06ktkkQS+pMZJYepauy3AVW42ucTMZ7DQe3Z06jKWwW8srVZBw0LTgFZ"
"1vW6U45iAeatEr2xbpmWvE7RbPKcgX+wD/4fB+DDaQZrH+Zj3gsrsqGp5TQiEy8pRgGxTcaY5V+M"
"88NnPOxLixj2AmWY14cqmNfxFC5UEU7v55uhFUMTZ3W4VSEnFJaswCytJlLvkhH35AgpBSbQJHt3"
"RYZrqNO1vxGYtEu86xWdfeyDxPkWzYkdJzX2iQASJ5foPzqjoPFb0UrCYSUIiHQg9ZSD5tZkYKf0"
"wlsKjiWtIRsAm8QyE7scnME8NTmAc1JbyhaaUWtzt8/mD5QIAFLMyariYVmtd+zOu7DxO3/aQtAz"
"U1FhzXzU6h/IKROdWSWPxKOic+tTI0r44Jy973t93cmpE5ljXoBFlKgkubnV1PbtBa1uWQr4jwUu"
"2bzSCo7lR88zMzsCf+r0Nq33k+wub4F+NDtS8G2lxESFa5jiRNJwGqbjtr8RmLjIA9kdIPla1L+c"
"uIgpHufXeH/bm7go1Xj11ZSCNAorY0A7Vy2LxGKCSEMpaa0EeYaXa3/TpTHRthKFcD0AYRIiYbtq"
"K/kivVlzSOZ5C0SGs+K6SK/9kvi2YNqQA468zeOfWkjL0NmDMCPRTt7ECcgBof4UhLqwGUDPbWCI"
"F/4GsyWjFxbNrypYDbblR5oLTfnC5z2gsl8RKofnPaCyXxGY7on9zlJijBgQPHvKkqL6GMDoKdbR"
"GydHJh/A6IFnqkz/MpMlwijJqpOlwD0gDLBFdhqbYLuRdsHcCGVReYVRzrNlScK9gsSk00Y8UZ5N"
"DKSVjjCud0BdRCab7skriJNEYozIvKqL8vfLkkm9ShKwzEbpa3ciFJjSGrQ8bMiL2uK7AwpADWFj"
"ePujlrQ0BjNJxBOMRIUTFtfo7vo1rJWSCT63AUzRzXP1IFUSFONVVHNl/rvzEK14Hk+TCP5JIpes"
"lIj4VUVK6HrNWEl+LX8cftCt8xCz7aKH65MeSquQWw1Lop6WrcyxjNXOSjnhNRxNa8dxcFX583ig"
"3hWisqNV+Uo7n83eOl8zCdHjU3T8FCRQJws5GY8o6bGiRSkRVJVNcWzH0bMi1EjfShpSpH8lt1oo"
"NFArLa1Ikwns5IwozDCtW9ONhiLDd1LT0yHlxg5BohevF89wF00R3T9n9ZYTKsqlHAVlMzMRJwL0"
"9Efcg8jTspXM/kSolQzbjDKhlczmfNcK6aF/RLpYOIHD4FBlbHmmtuYZLVhH8NtGpfOd51dIJ3DO"
"Bw/6M+8fyc0atLJljZpeZVi5h8aT7k8lcM2FpA9SG/rxlHAdwm9IBfDpoSsknj/zsxJnnwioHw6V"
"ottM1m85TDDN8BpSoOhascNWdnHNjWPEBfqlG0ER5NsSFEU3090x8ok5XcTEEJlN7VgoZOAEG+Rm"
"DECNyn+riqrFGEnRpmNNOdM8FIsn1gJh9o7fEzyrw/mjyOJwB/zSqs1oGThwtQRGJwi6Hu14U6Bw"
"VPdrZI23hK6MRHVbjC2Jeig+eVTb+D4XMh5bKJWwPBNgHWkarZIQF6LCXVe0CQkk/Th/k62kzjvt"
"I3+rQ6dzlT4EWhME5Tt50IB2UYfE6P/Zu2FiF0E3bstIGWfUUIRsJVS0mHkENyMYNehbi57jSx90"
"UcCk7oN2CzF9GxNHWpQM3slvX8DNhLOouT3alElRR0X6MXdMu8Gac6m5h8sYzbgsL56BTVaCZe7C"
"jGzKLbjUPx3Gic/tjs6p+qUtLXXc+z0UP8TlaAV4ANGo0bch65g1xWESFB+jZg0ky9n3NHsfJzlc"
"e9/tGNRcNCvSYU1sIzOXMC9qwXI0L5L4tk8/XfScWAwBTLNcQrkDgPIvfG0Gic4HvR+/vn17rPRp"
"q0hSkiynGpjLSvrjZP+ofPc9WUe0RCYDjgKRkYCwCaCP+ZmfVQ6hSUFCDWT5XiMKhhimYtdjeIGO"
"81KlmJ4jgH2176X7m2YIkqYvKRpBqmtHB+xSUps+7EvrNyho1D197KD+JCa4RPpatbNaVYMOUXkD"
"IU03vLYLm6I+gHOe4fsOXrcETjjMoHjs0snzykLcWrVhD7AVv0wfoAFGQZEhlk2RRR7Xm74fMDzJ"
"AX8N45Pgm+KZxAXB+98FEOhQMbCzi0C3jqcRDzpigwwSwo2dsbArvYOyGbMx8KojUAvwVo0uchug"
"HLTCG98yIfZML/mq3VY9Kl+Uui+Y8nfiM3EgY3J9GbCKCK8zsefAWQM+kRthronyMeegtWZOAKFN"
"Zo6kBacxQbFHrGP7B8CI4peflQLHSvr/AVpJA1OCgjWh04lR7NBvRz22Iz0q9vchsM6CTVgAqwNH"
"HySPC5rWhitvFKgpOdDEEUAAZo1Ucu3KKUb5VAD293H0uRyclbaPgqh+iSiD7xrvnb0SAu1WWtJp"
"OAWSLfGfYcjKx/cwJpid9MEWZISnlEH6SWHB8vefN/srKoBEAFSGSj7h+xqKAZCnmdJ33YzSSe4a"
"Y/Pv0qjyEZSXu/2e6fyDTcsfseeHNXq94UACgOxxefb8rZs87qKCmjZDxErcsjLYDURSks77ap0Z"
"34eOgfot4oI=")
      )
    )
  )


;;;							;
;;;	Utility Functions				;
;;;							;
(defun kb:striplayername (string / pos ret)
  (if (vl-string-position (ascii "|") string)
    (setq pos (+ (vl-string-position (ascii "|") string) 2)
	  ret (substr string pos (+ (- (strlen string) pos) 1))
	  )
    (setq ret string)
    )
  ret
  )



(defun kb:GetLayerList (xref / layers ret)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
  (cond	((= xref "*") ;gets all layers
	 (vlax-for x layers (setq ret (append ret (list (vla-get-name x)))))
	 )
	((= xref nil) ;gets only active doc layers
	 (vlax-for
		x
		 layers
	   (if (not (vl-string-search "|" (vla-get-name x)))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	((= xref "xr") ;gets all xref layers
	 (vlax-for
		x
		 layers
	   (if (vl-string-search "|" (vla-get-name x))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	(t ;gets a specific xref's layers
	 (vlax-for
		x
		 layers
	   (if (vl-string-search (strcat xref "|") (vla-get-name x))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	)
  ret
  )


(defun kb:load-plotstyle (dbxDoc lpltstyle / tempobj doc)
  (if (not (member (cons 3 lpltstyle)
		   (dictsearch (namedobjdict) "ACAD_PLOTSTYLENAME")
		   )
	   )
    (setq newln
	   (vl-catch-all-apply
	     'vla-CopyObjects
	     (list
	       dbxDoc
	       (vlax-safearray-fill
		 (vlax-make-safearray vlax-vbObject '(0 . 0))
		 (list (vla-item
			 (vla-item (vla-get-Dictionaries dbxDoc) "ACAD_PLOTSTYLENAME")
			 lpltstyle
			 )
		       )
		 )
	       (vla-item
		 (vla-get-Dictionaries (vla-get-activedocument (vlax-get-acad-object)))
		 "ACAD_PLOTSTYLENAME"
		 )
	       )
	     )
	  )
    )
  newln
  )

;;;							;
;;;	Layer States					;
;;;							;

(defun kb:LayerStateEngine (lstatename	  dwgname	layerlist     /
			    dbxdoc	  dbxdict	dict	      dbxplotstyles
			    dbxlayernames dbxlinetypes
			    )
  (setvar "clayer" "0")
  (princ "\nSetting the current layer to 0")
  (princ)
  (setq dbxdoc (kb:OpenDbxDocument DwgName))
  (if dbxdoc
    (progn (setq lstateobj (kb:getlayerobject))
	   (if lstateobj
	     (progn (vla-setdatabase lstateobj (vla-get-database dbxdoc))
		    (vlax-invoke lstateobj 'restore lstatename)
		    (setq dbxlayers (vla-get-layers dbxdoc)
			  layers    (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
			  )
    ;get a list of layers in the dbxdoc - because there's no "has" method!
		    (vlax-for
			   x
			    (vla-get-layers dbxdoc)
		      (setq dbxlayernames
			     (append dbxlayernames (list (strcase (vla-get-name x))))
			    )
		      )
    ;(setq n "X_Base43|A-Wall-Patt")
    ;(setq n(nth 3 layerlist))
		    (foreach
			   n
			    layerlist
		      (if (and (not (= n "0"))
			       (member (strcase (kb:striplayername n)) dbxlayernames)
			       )
			(progn (setq lobj    (vla-item layers n)
				     lobjdbx (vla-item dbxlayers (kb:striplayername n))
				     )
			       (foreach
				      property
					      (list "Freeze"	  "LayerOn"	"Lineweight"
						    "Lock"	  "Plottable"	"color"
						    )
				 (vlax-put lobj property (vlax-get lobjdbx property))
				 )
    ;set plotstyle
			       (setq ps (vlax-get lobjdbx "PlotStyleName"))
			       (kb:load-plotstyle dbxdoc ps)
			       (vlax-put lobj "PlotStyleName" ps)
    ;set linetype
			       (setq ln (vlax-get lobjdbx "Linetype"))
			       (if (not (tblsearch "ltype" ln))
				 (setq newln
					(vl-catch-all-apply
					  'vla-CopyObjects
					  (list	dbxDoc
						(vlax-safearray-fill
						  (vlax-make-safearray vlax-vbObject '(0 . 0))
						  (list (vla-item (vla-get-linetypes dbxDoc) ln))
						  )
						(vla-get-linetypes (vla-get-activedocument (vlax-get-acad-object)))
						)
					  )
				       )
				 )
			       (if (tblsearch "ltype" ln)
				 (vlax-put lobj "Linetype" ln)
				 )
			       )
			)
		      )
		    )
	     )
	   (kb:CloseDbxDocument dbxdoc)
	   (vlax-release-object lstateobj)
	   )
    )
  (vla-regen
    (vla-get-activedocument (vlax-get-acad-object))
    acActiveViewport
    )
  )

;;;(kb:ReturnDBXLayerStates)
(defun kb:ReturnDBXLayerStates (/		  dbxdoc	    lstate-dict-object
				lstate-dict	  named-obj-dict    ldict
				acad_lstate	  acad_lstate_defs
				)
  (setq file (kb:ReturnLayerStandardsFile))
  (if file
    (progn
      (setq dbxdoc (kb:opendbxdocument (findfile file)))
      (if dbxdoc
	(progn
	  (setq	lstate-dict-object
		 (vla-GetExtensionDictionary (vla-get-layers dbxdoc))
		lstate-dict
		 (entget (vlax-vla-object->ename lstate-dict-object))
    ;(vlax-dump-Object lstate-dict-object)
		named-obj-dict
		 (vlax-vla-object->ename (vla-get-Dictionaries dbxdoc))
		)
	  (if lstate-dict
	    (progn
	      (if (setq ldict (member (cons 3 "ACAD_LAYERSTATES") lstate-dict))
		(progn (setq acad_lstate (cdr (assoc 360 ldict)))
		       (foreach
			      x
			       (entget acad_lstate)
			 (if (and (eq 3 (car x)))
			   (setq acad_lstate_defs (append acad_lstate_defs (list (cdr x))))
			   )
			 )
		       (vlax-release-object lstate-dict-object)
		       )
		)
	      )
	    )
	  (kb:CloseDbxDocument dbxdoc)
	  )
	)
      )
    )
  acad_lstate_defs
  )



;;;								;
;;;	Import Layers 						;
;;;								;

;;;								;
;;;	Get a list of layers via ObjectDBX			;
;;;	filters out xref layers and 0, defpoints		;
;;;								;
(defun kb:GetMasterLayerList (dwg / lname llist dbxdoc)
  (if dwg
    (progn (setq dbxDoc (kb:OpenDbxDocument dwg))
	   (if dbxDoc
	     (progn (vlax-for
			   i
			    (vla-get-layers dbxDoc)
		      (setq lname (vla-get-name i))
		      (if (or
			    (not (wcmatch (strcase lname) "*|*"))
			    (not (wcmatch (strcase lname) "DEFPOINTS"))
			    (not (wcmatch (strcase lname) "0"))
			    )
			(setq llist (append llist (list lname)))
			)
		      )
		    (kb:CloseDbxDocument dbxDoc)
		    )
	     )
	   )
    )
  llist
  )

    ;(kb:FilterLayerList (kb:GetMasterLayerList nil) "A-Wall*")
(defun kb:FilterLayerList (llist fi / li)
  (foreach
	 i
	  llist
    (if	(wcmatch (strcase i) (strcase fi))
      (setq li (append li (list i)))
      )
    )
  li
  )

    ;(kb:GetLayerFilters kb%ImpLayFile)
    ;(setq dwg kb%ImpLayFile llist nil)
(defun kb:GetLayerFilters (dwg / dict lf lfdict flist llist dbxDoc)
  (if dwg
    (setq dbxDoc (kb:OpenDbxDocument dwg))
    (setq dbxDoc (vla-get-activedocument (vlax-get-acad-object)))
    )
  (setq	dict (vla-GetExtensionDictionary (vla-get-layers dbxDoc))
	lf   (vl-catch-all-apply 'vla-item (list dict "ACAD_LAYERFILTERS"))
	)
  (if (vl-catch-all-error-p lf)
    (setq llist nil)
    (progn (setq lfdict (vlax-vla-object->ename lf))
	   (foreach
		  i
		   (entget lfdict)
	     (if (= (car i) 3)
	       (setq flist (append flist (list (cdr i))))
	       )
	     )
	   (foreach
		  i
		   flist
	     (setq
	       llist (append llist
			     (list (cons i (list (cdr (nth 10 (dictsearch lfdict i))))))
			     )
	       )
	     )
	   )
    )
  (if dbxDoc
    (kb:CloseDbxDocument dbxDoc)
    )
  llist
  )


;;;*02								;
;;;	OpenDCL Subs						;
;;;								;

;;;								;
;;;	Import Layers						;
;;;								;

(defun kb:ImportLayers_OnInitialize
       (/ fileName fi layerlist st parent parent-list child-list misc-list)
  (if (not (setq fileName
		  (vl-registry-read
		    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"
		    "fileName"
		    )
		 )
	   )
    (setq fileName (kb:ReturnLayerStandardsFile))
    )
  (if fileName
    (progn
      (dcl_Tree_Clear kb001_00_LayerFilters)
      (dcl_Control_SetProperty kb001_00_SetLayerCurrent "Enabled" t)

      (dcl_Control_SetProperty kb001_00_PATH "Caption" fileName)
      (setq fi	      (kb:GetLayerFilters fileName)
	    layerlist (kb:GetMasterLayerList fileName)
	    )
      (dcl_ListBox_Clear kb001_00_Layers)
;;; If Layer List exists
      (if layerlist
	(progn (foreach
		      i
		       (list "Defpoints" "defpoints" "DEFPOINTS" "0")
		 (setq layerlist (vl-remove i layerlist))
		 )
	       (dcl_ListBox_AddList kb001_00_Layers layerlist)
	       )
	(dcl_ListBox_AddList
	  kb001_00_Layers
	  (list "The layer Standards file is opened!" "Contact IT")
	  )
	)
      (dcl_Tree_AddParent kb001_00_LayerFilters "All Layers" "*" 0 0 0) ;load parents
      (if fi
	(progn
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (if	(and (= (length st) 2) (= (cadr st) 42)) ; = "A*", or "S*" - New Parent
	      (progn (setq parent-list (append parent-list (list (cadr n))))
		     (dcl_tree_addchild kb001_00_LayerFilters "*" (car n) (cadr n) 0 0 0)
		     )
	      )
	    ) ;load children
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (cond
	      ((and (= (length st) 2) (= (cadr st) 42)))
	      ((member (setq parent (strcat (chr (car st)) "*")) parent-list)
	       (setq child-list (append child-list (list parent (cadr n))))
	       (dcl_tree_addchild kb001_00_LayerFilters parent (car n) (cadr n) 0 0 0)
	       )
	      (t
	       (setq misc-list (append misc-list (list "misc" (cadr n))))
	       (dcl_tree_addchild kb001_00_LayerFilters "*" (car n) (cadr n) 0 0 0)
	       )
	      )
	    ) ;expand tree
	  (dcl_Tree_ExpandItem kb001_00_LayerFilters "*" 1)
	  (Setq rValue (dcl_Tree_GetFirstChildItem kb001_00_LayerFilters "*"))
	  (dcl_Tree_ExpandItem kb001_00_LayerFilters rValue 1)
	  (dcl_Tree_EnsureVisible kb001_00_LayerFilters rValue)
	  (foreach
		 key
		    parent-list
	    (if	(dcl_Tree_ItemHasChildren kb001_00_LayerFilters key)
	      (progn (dcl_Tree_ExpandItem kb001_00_LayerFilters key 1)
		     (dcl_Tree_EnsureVisible
		       kb001_00_LayerFilters
		       (dcl_Tree_GetFirstChildItem kb001_00_LayerFilters key)
		       )
		     )
	      )
	    )
	  )
	)
      )

    (progn
      (dcl_Control_SetProperty kb001_00_PATH "Caption" "")
      (dcl_ListBox_AddString
	kb001_00_LAYERS
	"Select a Drawing to Import Layers"
	)
      (c:kb001_00_OpenLayerImportFile_OnClicked)
      )
    )
  )




(defun c:kb001_00_OpenLayerImportFile_OnClicked	(/ fileName)
  (setq	fileName
	 (getfiled
	   "Select a file"
	   (vl-filename-directory (kb:ReturnLayerStandardsFile))
	   "dwg"
	   0
	   )
	)
  (if fileName
    (progn

      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"
	"fileName"
	fileName
	)
      (kb:ImportLayers_OnInitialize)
      )
    )
  (princ)
  (princ)
  )

(defun c:kb001_00_LAYERFILTERS_OnSelChanged (sSelText SelKey / fileName)
  (setq fileName (dcl_Control_GetCaption kb001_00_PATH))
  (dcl_ListBox_Clear kb001_00_Layers)
  (dcl_ListBox_AddList
    kb001_00_Layers
    (kb:FilterLayerList (kb:GetMasterLayerList fileName) SelKey)
    )
  )


(defun c:kb001_00_IMPORTLAYER_OnClicked	(/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_00_Layers)
	fileName  (dcl_Control_GetCaption kb001_00_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (foreach
	     x
	      (dcl_ListBox_GetSelectedNths kb001_00_Layers)
	(dcl_ListBox_SetSel kb001_00_Layers x nil)
	)
      (foreach x layerList (princ (strcat "\n" x " has been imported!")))
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_00_SETLAYERCURRENT_OnClicked (/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_00_Layers)
	fileName  (dcl_Control_GetCaption kb001_00_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (kb:setclayer (car layerList) t)
      (dcl_form_close kb001_00)
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_00_Layers_OnSelChanged (nSelection sSelText /)
  (if (> nSelection 1)
    (dcl_Control_SetProperty kb001_00_SetLayerCurrent "Enabled" nil)
    (dcl_Control_SetProperty kb001_00_SetLayerCurrent "Enabled" t)
    )
  (princ)
  (princ)
  )




;;;*03								;
;;;	Working States						;
;;;								;
    ;(setq reportList nil)
(defun kb:WorkingStates_OnInitialize (/ dbxLlist xrefList)
  (dcl_ListView_Clear kb001_00_XREFS)

  (if(=(dcl_ListView_GetColumnCount kb001_00_XREFS)0)
  (dcl_ListView_AddColumns
    kb001_00_XREFS
    (list
      (list "Layer Containers"
	    1
	    (- (dcl_Control_GetWidth kb001_00_XREFS) 5)
	    0
	    )
      )
    )
    )
  
(dcl_ListBox_Clear kb001_00_LayerStates)
;;; layer states list control
  (dcl_ListView_AddItem
	kb001_00_XREFS
	(list 1 "All Layers")
	)

  (dcl_ListView_AddItem
	kb001_00_XREFS
	(list 0 (getvar "dwgname"))
	)

  (setq xrefList (kb:listxrefs)
	)

  (if xreflist
    (foreach
	   x xreflist
      (dcl_ListView_AddItem
	kb001_00_XREFS
	(list 2 x)
	)
      )
    )

  (setq dbxLlist (kb:ReturnDBXLayerStates))
  (if dbxLlist
    (dcl_ListBox_AddList kb001_00_LayerStates dbxLlist)
    (dcl_ListBox_AddList
      kb001_00_LayerStates
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
  (princ)
  (princ)
  )


(defun kb:00-restore (lsname xrefname /)
  (cond	((= xrefname (getvar "dwgname"))
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList nil)
	   )
	 )
	((= xrefname "All Xrefs")
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList "xr")
	   )
	 )
	((= xrefname "All Layers")
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList "*")
	   )
	 )
	(t
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList xrefname)
	   )
	 )
	)
  (princ)
  (princ)
  )


(defun c:kb001_00_LayerStates_OnSelChanged (nSelection sSelText /)
  (if kb:ChangeLayerKeys
    (kb:ChangeLayerKeys)
    )
  (princ)
  )


    ;(c:kb001_00_Restore_OnClicked)
(defun c:kb001_00_Restore_OnClicked (/ lsname xrefname)
  (setq	lsname	 (dcl_ListBox_GetText
		   kb001_00_LayerStates
		   (dcl_ListBox_GetCurSel kb001_00_LayerStates)
		   )
	xrefname (dcl_ListView_GetSelectedItems kb001_00_XREFS)
	)
  (if (not xrefname)
    (progn (setq xrefname (list "All Layers"))
	   (dcl_ListView_SetCurSel kb001_00_XREFS 0)
	   )
    )
  (if (and lsname (/= lsname ""))
    (cond ((= (vl-list-length xrefname) 1)
	   (kb:00-restore lsname (nth 0 xrefname))
	   )
	  ((> (vl-list-length xrefname) 1)
	   (foreach
		  x
		   xrefName
	     (kb:00-restore lsname x)
	     )
	   )
	  )
    (alert "Select a Layer Display!")
    )
  (princ)
  (princ)
  )


(defun c:kb001_00_ThawVP_OnClicked (/)
  (if (= (getvar "tilemode") 0)
    (command "vplayer" "_thaw" "*" "current" "" "")
    (not (dcl_MessageBox "Not allowed in Model Space!" "Thaw VP Layers" 2 1)
	 )
    )
  (princ)
  (princ)
  )


(defun c:kb001_00_LayerStates_OnDblClicked (/ path layerlist)
  (c:kb001_00_Restore_OnClicked)
  (princ)
  (princ)
  )

(defun c:kb001_00_OnClose (nUpperLeftX nUpperLeftY /)
  (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

  "isFloating"
	"false"
	)
  (princ)
  (princ)
  )

(defun c:kb001_00_OnInitialize (/)
  (kb:ImportLayers_OnInitialize)
  (kb:WorkingStates_OnInitialize)
  (princ)
  (princ)
  )



(defun c:kb001_00_OnDocActivated (/)
  (if (dcl_Form_IsActive kb001_00)
    (c:kb001_00_OnInitialize)
    )
  (princ)
  (princ)
  )


(defun c:kb001_00_Refresh_OnClicked (/)
  (c:kb001_00_OnInitialize)
  (princ)
  (princ)
  )

(defun c:kb001_00_OnEnteringNoDocState (/)
  (dcl_form_close kb001_00)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

    "isFloating"
    "true"
    )
  (princ)
  (princ)
  )


;;;								;
;;;	Tray Functions						;
;;;								;
(defun c:kb001_00_Close_OnClicked (/)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

    "isFloating"
    "false"
    )
  (dcl_form_close kb001_00)
  (princ)
  )


;; show toolbar
(defun c:kb001_00_Tray_OnClicked (/ rValue)
  (Setq rValue (dcl_Form_GetRectangle kb001_00))
  (dcl_form_close kb001_00)

    ;show at same location
    ;(if (not (dcl_Form_IsActive kb001_01))
    ;  (dcl_Form_Show kb001_01 (nth 0 rValue) (nth 1 rValue))
    ; )


    ;show at saved location - registry
  (if (not (dcl_Form_IsActive kb001_01))
    (dcl_Form_Show kb001_01)
    )
  (princ)
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;								;

(defun c:kbLayerTools (/)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive kb001_01))
	(if (not (dcl_Form_IsActive kb001_00))
	  (dcl_Form_Show kb001_00)
	  )
	)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;*04								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:001_00_IsFloating (/)
  (if dcl_HideErrorMsgBox
    (if	(and (not (dcl_Form_IsActive kb001_00))
	     (=	(vl-registry-read
		  "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

		  "isFloating"
		  )
		"true"
		)
	     )
      (c:kbLayerTools)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

(kb:001_00_IsFloating)

;;;								;
;;;	LayerStates Tool Bar					;
;;;								;

(defun c:kb001_01_OnInitialize (/)
  (dcl_ComboBox_Clear kb001_01_ComboBox)
  (dcl_ComboBox_AddList
    kb001_01_ComboBox
    (kb:ReturnDBXLayerStates)
    )
  (dcl_ComboBox_SetCurSel kb001_01_ComboBox 0)
  )

(defun c:kb001_01_OnEnteringNoDocState (/)
  (dcl_form_close kb001_01)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_01"

    "isFloating"
    "true"
    )
  (princ)
  (princ)
  )

(defun c:kb001_01_LayerStates_OnClicked	(/ rValue)
  (Setq rValue (dcl_Form_GetRectangle kb001_01))
  (dcl_form_close kb001_01)
    ;show at same location
    ;(if (not (dcl_Form_IsActive kb001_00))
    ;  (dcl_Form_Show kb001_00 (nth 0 rValue) (nth 1 rValue))
    ;  )

    ;show at saved location - registry
  (if (not (dcl_Form_IsActive kb001_00))
    (dcl_Form_Show kb001_00)
    )
  )


(defun c:kb001_01_ComboBox_OnSelChanged	(nSelection sSelText /)
  (princ sSelText)
  (princ)

  (kb:LayerStateEngine
    sSelText
    (kb:ReturnLayerStandardsFile)
    (kb:GetLayerList "*")
    )

  )


(defun c:kb001_01_Close_OnClicked (/)
  (dcl_form_close kb001_01)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_01"

    "isFloating"
    "false"
    )
  (princ)
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;	(dcl_Form_GetRectangle kb001_01)816 74			;
;;;								;
(defun c:kbLayerToolsTB	(/)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive kb001_00))
	(if (not (dcl_Form_IsActive kb001_01))
	  (dcl_Form_Show kb001_01) ; 816 74)
	  )
	)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:001_01_IsFloating (/)
  (if dcl_HideErrorMsgBox
    (if	dcl_HideErrorMsgBox
      (if (and (not (dcl_Form_IsActive kb001_01))
	       (= (vl-registry-read
		    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_01"

		    "isFloating"
		    )
		  "true"
		  )
	       )
	(c:kbLayerToolsTB)
	)
      (alert "The OpenDCL arx module did not load!")
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )


(kb:001_01_IsFloating)


;;;								;
;;;	OpenDCL Subs - Palette					;
;;;								;

;;;								;
;;;	Import Layers						;
;;;								;

(defun kb:ImportLayers_02_OnInitialize
       (/ fileName fi layerlist st parent parent-list child-list misc-list)
  (if (not (setq fileName
		  (vl-registry-read
		    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"
		    "fileName"
		    )
		 )
	   )
    (setq fileName (kb:ReturnLayerStandardsFile))
    )
  (if fileName
    (progn
      (dcl_Tree_Clear kb001_02_LayerFilters)
      (dcl_Control_SetProperty kb001_02_SetLayerCurrent "Enabled" t)

      (dcl_Control_SetProperty kb001_02_PATH "Caption" fileName)
      (setq fi	      (kb:GetLayerFilters fileName)
	    layerlist (kb:GetMasterLayerList fileName)
	    )
      (dcl_ListBox_Clear kb001_02_Layers)
;;; If Layer List exists
      (if layerlist
	(progn (foreach
		      i
		       (list "Defpoints" "defpoints" "DEFPOINTS" "0")
		 (setq layerlist (vl-remove i layerlist))
		 )
	       (dcl_ListBox_AddList kb001_02_Layers layerlist)
	       )
	(dcl_ListBox_AddList
	  kb001_02_Layers
	  (list "The layer Standards file is opened!" "Contact IT")
	  )
	)
      (dcl_Tree_AddParent kb001_02_LayerFilters "All Layers" "*" 0 0 0) ;load parents
      (if fi
	(progn
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (if	(and (= (length st) 2) (= (cadr st) 42)) ; = "A*", or "S*" - New Parent
	      (progn (setq parent-list (append parent-list (list (cadr n))))
		     (dcl_tree_addchild kb001_02_LayerFilters "*" (car n) (cadr n) 0 0 0)
		     )
	      )
	    ) ;load children
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (cond
	      ((and (= (length st) 2) (= (cadr st) 42)))
	      ((member (setq parent (strcat (chr (car st)) "*")) parent-list)
	       (setq child-list (append child-list (list parent (cadr n))))
	       (dcl_tree_addchild kb001_02_LayerFilters parent (car n) (cadr n) 0 0 0)
	       )
	      (t
	       (setq misc-list (append misc-list (list "misc" (cadr n))))
	       (dcl_tree_addchild kb001_02_LayerFilters "*" (car n) (cadr n) 0 0 0)
	       )
	      )
	    ) ;expand tree
	  (dcl_Tree_ExpandItem kb001_02_LayerFilters "*" 1)
	  (Setq rValue (dcl_Tree_GetFirstChildItem kb001_02_LayerFilters "*"))
	  (dcl_Tree_ExpandItem kb001_02_LayerFilters rValue 1)
	  (dcl_Tree_EnsureVisible kb001_02_LayerFilters rValue)
	  (foreach
		 key
		    parent-list
	    (if	(dcl_Tree_ItemHasChildren kb001_02_LayerFilters key)
	      (progn (dcl_Tree_ExpandItem kb001_02_LayerFilters key 1)
		     (dcl_Tree_EnsureVisible
		       kb001_02_LayerFilters
		       (dcl_Tree_GetFirstChildItem kb001_02_LayerFilters key)
		       )
		     )
	      )
	    )
	  )
	)
      )

    (progn
      (dcl_Control_SetProperty kb001_02_PATH "Caption" "")
      (dcl_ListBox_AddString
	kb001_02_LAYERS
	"Select a Drawing to Import Layers"
	)
      (c:kb001_02_OpenLayerImportFile_OnClicked)
      )
    )
  )




(defun c:kb001_02_OpenLayerImportFile_OnClicked	(/ fileName)
  (setq	fileName
	 (getfiled
	   "Select a file"
	   (vl-filename-directory (kb:ReturnLayerStandardsFile))
	   "dwg"
	   0
	   )
	)
  (if fileName
    (progn

      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"
	"fileName"
	fileName
	)
      (kb:ImportLayers_OnInitialize)
      )
    )
  (princ)
  (princ)
  )

(defun c:kb001_02_LAYERFILTERS_OnSelChanged (sSelText SelKey / fileName)
  (setq fileName (dcl_Control_GetCaption kb001_02_PATH))
  (dcl_ListBox_Clear kb001_02_Layers)
  (dcl_ListBox_AddList
    kb001_02_Layers
    (kb:FilterLayerList (kb:GetMasterLayerList fileName) SelKey)
    )
  )


(defun c:kb001_02_IMPORTLAYER_OnClicked	(/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_02_Layers)
	fileName  (dcl_Control_GetCaption kb001_02_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (foreach
	     x
	      (dcl_ListBox_GetSelectedNths kb001_02_Layers)
	(dcl_ListBox_SetSel kb001_02_Layers x nil)
	)
      (foreach x layerList (princ (strcat "\n" x " has been imported!")))
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_02_SETLAYERCURRENT_OnClicked (/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_02_Layers)
	fileName  (dcl_Control_GetCaption kb001_02_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (kb:setclayer (car layerList) t)
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_02_Layers_OnSelChanged (nSelection sSelText /)
  (if (> nSelection 1)
    (dcl_Control_SetProperty kb001_02_SetLayerCurrent "Enabled" nil)
    (dcl_Control_SetProperty kb001_02_SetLayerCurrent "Enabled" t)
    )
  (princ)
  (princ)
  )




;;;*03								;
;;;	Working States						;
;;;								;
    ;(setq reportList nil)
(defun kb:WorkingStates_02_OnInitialize	(/ dbxLlist xrefList reportList)
  (dcl_ListView_Clear kb001_02_XREFS)
  
  (if(=(dcl_ListView_GetColumnCount kb001_02_XREFS)0)
  (dcl_ListView_AddColumns
    kb001_02_XREFS
    (list
      (list "Layer Containers"
	    1
	    (- (dcl_Control_GetWidth kb001_02_XREFS) 5)
	    0
	    )
      )
    )
    )

(dcl_ListBox_Clear kb001_02_LayerStates)
;;; layer states list control
(dcl_ListView_AddItem
	kb001_02_XREFS
	(list 1 "All Layers")
	)

  (dcl_ListView_AddItem
	kb001_02_XREFS
	(list 0 (getvar "dwgname"))
	)

  (setq xrefList (kb:listxrefs)
	)

  (if xreflist
    (foreach
	   x xreflist
      (dcl_ListView_AddItem
	kb001_02_XREFS
	(list 2 x)
	)
      )
    )
  (setq dbxLlist (kb:ReturnDBXLayerStates)
	)
  (if dbxLlist
    (dcl_ListBox_AddList kb001_02_LayerStates dbxLlist)
    (dcl_ListBox_AddList
      kb001_02_LayerStates
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
  (princ)
  (princ)
  )





(defun c:kb001_02_LayerStates_OnSelChanged (nSelection sSelText /)
  (if kb:ChangeLayerKeys
    (kb:ChangeLayerKeys)
    )
  (princ)
  )


    ;(c:kb001_02_Restore_OnClicked)
(defun c:kb001_02_Restore_OnClicked (/ lsname xrefname)
  (setq	lsname	 (dcl_ListBox_GetText
		   kb001_02_LayerStates
		   (dcl_ListBox_GetCurSel kb001_02_LayerStates)
		   )
	xrefname (dcl_ListView_GetSelectedItems kb001_02_XREFS)
	)
  (if (not xrefname)
    (progn (setq xrefname (list "All Layers"))
	   (dcl_ListView_SetCurSel kb001_02_XREFS 0)
	   )
    )
  (if (and lsname (/= lsname ""))
    (cond ((= (vl-list-length xrefname) 1)
	   (kb:00-restore lsname (nth 0 xrefname))
	   )
	  ((> (vl-list-length xrefname) 1)
	   (foreach
		  x
		   xrefName
	     (kb:00-restore lsname x)
	     )
	   )
	  )
    (alert "Select a Layer Display!")
    )
  (princ)
  (princ)
  )


(defun c:kb001_02_ThawVP_OnClicked (/)
  (if (= (getvar "tilemode") 0)
    (command "vplayer" "_thaw" "*" "current" "" "")
    (not (dcl_MessageBox "Not allowed in Model Space!" "Thaw VP Layers" 2 1)
	 )
    )
  (princ)
  (princ)
  )


(defun c:kb001_02_LayerStates_OnDblClicked (/ path layerlist)
  (c:kb001_02_Restore_OnClicked)
  (princ)
  (princ)
  )

(defun c:kb001_02_OnClose ( / )
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"
    "isFloating"
    "false"
    )
  (princ)
  (princ)
  )
  

(defun c:kb001_02_OnInitialize (/ nUpperLeftX nUpperLeftY)
  (kb:ImportLayers_02_OnInitialize)
  (kb:WorkingStates_02_OnInitialize)
  (princ)
  (princ)
  )



(defun c:kb001_02_OnDocActivated (/)
  (if (dcl_Form_IsActive kb001_02)
    (c:kb001_02_OnInitialize)
    )
  (princ)
  (princ)
  )


(defun c:kb001_02_Refresh_OnClicked (/)
  (c:kb001_02_OnInitialize)
  (princ)
  (princ)
  )

(defun c:kb001_02_OnEnteringNoDocState (/)
  (dcl_form_close kb001_02)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"

    "isFloating"
    "true"
    )
  (princ)
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;								;

(defun c:kbLayerToolsP (/)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive kb001_02))
	(dcl_Form_Show kb001_02)
	)
      )

    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:001_02_IsFloating (/)
  (if dcl_HideErrorMsgBox
    (if	(and (not (dcl_Form_IsActive kb001_02))
	     (=	(vl-registry-read
		  "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"

		  "isFloating"
		  )
		"true"
		)
	     )
      (c:kbLayerToolsp)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

(kb:001_02_IsFloating)

;;;							;
;;;	02						;
;;;							;

(defun c:kb001_03_OnInitialize ( / dbxLlist)
     (setq dbxLlist (kb:ReturnDBXLayerStates))
  (if dbxLlist
    (dcl_ListBox_AddList kb001_03_ListBox dbxLlist)
    (dcl_ListBox_AddList
      kb001_03_ListBox
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
)

(defun c:kb001_03_OnMouseMovedOff ( /)
     (dcl_Form_Close kb001_03)
)

(defun c:kb001_03_ListBox_OnDblClicked (/ lsname xref layers xname xrefname xobj)
  (setq	lsname (dcl_ListBox_GetText
		 kb001_03_ListBox
		 (dcl_ListBox_GetCurSel kb001_03_ListBox)
		 )
	xref   (dcl_Control_GetValue kb001_03_Xref)
	layers (dcl_Control_GetValue kb001_03_AllLayers)
	)
  (cond	((= xref 1)
	 (dcl_setcmdbarfocus)
	 (setq xname (entsel "\nSelect Xref:"))
	 (if xname
	   (progn
	     (setq xobj (vlax-ename->vla-object (car xname)))
	     (if (vlax-property-available-p xobj 'path)
	       (setq xrefname (vla-get-name xobj))
	       )
	     )
	   )
	 )
	((= layers 1)
	 (setq xrefname "All Layers")
	 )
	((and (= xref 0) (= layers 0))
	 (setq xrefname (getvar "dwgname"))
	 )
	)
  (if (and lsname xrefname)
    (progn
      (dcl_Form_Close kb001_03)
      (kb:00-restore lsname xrefname)
      )
    )
  )




(defun c:kb001_03_Xref_OnClicked (nValue /)
     (if(= nValue 1)
  (dcl_Control_SetValue kb001_03_AllLayers 0)
       )
)

(defun c:kb001_03_AllLayers_OnClicked (nValue /)
  (if(= nValue 1)
     (dcl_Control_SetValue kb001_03_Xref 0))
)

;;;								;
;;;	Command Interface					;
;;;								;

(defun c:kbLayerToolsPop (/ pt x y)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (setq pt(dcl_getmousecoords)
	    x(nth 0 pt)
	    y(nth 1 pt))
      (if (not (dcl_Form_IsActive kb001_03))
	(dcl_Form_Show kb001_03 (fix x)(fix y))
	)
      )

    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )







(princ "\nkbWorkingStates v2.0 loaded!")
(princ)
 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 0 T T nil T)
;*** DO NOT add text below the comment! ***|;
