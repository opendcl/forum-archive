
(defun Start ()
  (command "_OPENDCL")  
	(dcl_Project_Load "DropInAcad.odcl" T)

	;-------------------------------------
	(defun c:DropInAcad_Form1_SlideView1_OnDragnDropToAutoCAD (DropPoint Viewport /)
		(dcl_Form_Hide DropInAcad_Form1 T)

		(vl-cmdf "_.insert" "DropInAcad" PAUSE "" "" "")

		(dcl_Form_Hide DropInAcad_Form1 nil)
	)
	;-------------------------------------
  (dcl_Form_Show DropInAcad_Form1)

)
