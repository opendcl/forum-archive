(princ "\nOFSET  ")

 (command "opendcl")

(defun rgus_error ()
  (setq varList '("SNAPMODE" "DYNMODE" "BLIPMODE" "PICKBOX" "CLAYER" "CECOLOR" "HIGHLIGHT" "MENUECHO" "OSMODE" "ORTHOMODE"))
  (setq varList (mapcar (function (lambda (a) (list 'setvar a (getvar a)))) varList))
  (setq temperr *error*)
  (setq *error* rgus_exit)
  (princ)
)

(defun rgus_exit (errmsg)
  (command nil nil nil)
(mapcar 'eval varList)
(setq *error* temperr)
)

(defun C:LOffset ()
 (if (not (equal pp (entlast))) (progn
 (setq pp (entlast))
 (setq list1 (entget pp))
 (setq list1 (subst(cons 8 (getvar "CLAYER")) (assoc 8 list1) list1)
       list1 (subst '(6 . "BYLAYER")(assoc 6 list1) list1)
       list1 (append list1 '((62 . 256)))
 )
 (entmod list1)
 ))
 (princ)
 )

(defun rtd (a) (/ (* a 180.0) pi))
(defun dtr (a) (* pi (/ a 180.0)))

(defun make_unique (Lst / Lst1 tmp)
  (setq Lst1 '())
  (foreach tmp Lst
    (if	(not (member tmp Lst1))
      (setq Lst1 (cons tmp Lst1))
    )
  )
  (reverse Lst1)
)

					;   Preset Offset Distances

(defun c:DclForm1_ListBox1_SelectionChanged (Selection sSelText /)

  (setq pp (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox1"))
  (cond
    ((= pp 0) (setq pp 10))
    ((= pp 1) (setq pp 20))
    ((= pp 2) (setq pp 25))
    ((= pp 3) (setq pp 50))
    ((= pp 4) (setq pp 75))
    ((= pp 5) (setq pp 100))
    ((= pp 6) (setq pp 150))
    ((= pp 7) (setq pp 200))
    ((= pp 8) (setq pp 250))
    ((= pp 9) (setq pp 300))
    ((= pp 10) (setq pp 500))
    ((= pp 11) (setq pp 600))
    ((= pp 12) (setq pp 900))
    ((= pp 13) (setq pp 1000))
    ((= pp 14) (setq pp 1200))
    ((= pp 15) (setq pp 1500))
    ((= pp 16) (setq pp 1800))
    ((= pp 17) (setq pp 2000))
  )
(C:which_offset)
)

					; Bar Offset Distances

(defun c:DclForm1_ListBox2_SelectionChanged (Selection sSelText /)

  (setq pp (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox2"))
  (cond
    ((= pp 0) (setq pp 12))
    ((= pp 1) (setq pp 14))
    ((= pp 2) (setq pp 18))
    ((= pp 3) (setq pp 23))
    ((= pp 4) (setq pp 27))
    ((= pp 5) (setq pp 29))
    ((= pp 6) (setq pp 32))
    ((= pp 7) (setq pp 36))
    ((= pp 7) (setq pp 45))
  )
(C:which_offset)
)

					; Half Bar Offset Distances

(defun c:DclForm1_ListBox3_SelectionChanged (Selection sSelText /)

  (setq pp (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox3"))
  (cond
    ((= pp 0) (setq pp 6.0))
    ((= pp 1) (setq pp 7.0))
    ((= pp 2) (setq pp 9.0))
    ((= pp 3) (setq pp 11.5))
    ((= pp 4) (setq pp 13.5))
    ((= pp 5) (setq pp 14.5))
    ((= pp 6) (setq pp 16.0))
    ((= pp 7) (setq pp 18.0))
    ((= pp 8) (setq pp 22.5))
  )
(C:which_offset)
)

					; Bar Bend Offset Distances

(defun c:DclForm1_ListBox4_SelectionChanged (Selection sSelText /)

  (setq pp (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox4"))
  (cond
    ((= pp 0) (setq pp 150.0))
    ((= pp 1) (setq pp 190.0))
    ((= pp 2) (setq pp 250.0))
    ((= pp 3) (setq pp 310.0))
    ((= pp 4) (setq pp 385.0))
    ((= pp 5) (setq pp 400.0))
    ((= pp 6) (setq pp 450.0))
    ((= pp 7) (setq pp 515.0))
  )
(C:which_offset)
)

					; 'D' Bar Lap Offset Distances

(defun c:DclForm1_ListBox5_SelectionChanged (Selection sSelText /)

  (setq pp (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox5"))
  (cond
    ((= pp 0) (setq pp 450.0))
    ((= pp 1) (setq pp 600.0))
    ((= pp 2) (setq pp 700.0))
    ((= pp 3) (setq pp 800.0))
    ((= pp 4) (setq pp 960.0))
    ((= pp 5) (setq pp 1000.0))
    ((= pp 6) (setq pp 1150.0))
    ((= pp 7) (setq pp 1300.0))
  )
(C:which_offset)
)

					; 'YD' Bar Lap Offset Distances - BLOCKWORK

(defun c:OFSET_BIG_DclForm1_ListBox8_OnSelChanged
       (nSelection sSelText /)
  (setq pp (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox8"))
  (cond
    ((= pp 0) (setq pp 700.0))
    ((= pp 1) (setq pp 850.0))
    ((= pp 2) (setq pp 1150.0))
    ((= pp 3) (setq pp 1400.0))
    ((= pp 4) (setq pp 1700.0))
    ((= pp 5) (setq pp 1750.0))
    ((= pp 6) (setq pp 2000.0))
    ((= pp 7) (setq pp 2250.0))
  )
(C:which_offset)
)

					; 'YD' Bar Lap Offset Distances - CONCRETE

(defun c:OFSET_BIG_DclForm1_ListBox9_OnSelChanged
       (nSelection sSelText /)
  (setq pp (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox9"))
  (cond
    ((= pp 0) (setq pp 1000.0))
    ((= pp 1) (setq pp 1000.0))
    ((= pp 2) (setq pp 1150.0))
    ((= pp 3) (setq pp 1400.0))
    ((= pp 4) (setq pp 1700.0))
    ((= pp 5) (setq pp 1750.0))
    ((= pp 6) (setq pp 2000.0))
    ((= pp 7) (setq pp 2250.0))
  )
(C:which_offset)
)

(defun c:DclForm1_ListBox6_SelectionChanged (Selection sSelText /)
  (setq index (dcl_ListBox_GetCurSel "OFSET_BIG" "DclForm1" "ListBox6"))
  (setq	pp (dcl_ListBox_GetText 	     "OFSET_BIG" 	     "DclForm1" 	     "ListBox6" 	     index))
  (setq pp (atof pp))
  (c:which_offset)
)

(defun c:doff ()
  (setq ang90 (dtr 90))
  (setq pp (/ pp 2.0))

  (while
    (setq ent (entsel "\nSelect line: "))
     (setq elist (entget (car ent)))
     (setq angent (angle (cdr (assoc 11 elist)) (cdr (assoc 10 elist))))
     (setq p0 (cdr (assoc 11 elist)))
     (setq p1 (cdr (assoc 10 elist)))
     (setq pt1 (mapcar '(lambda (ord1 ord2) (/ (+ ord1 ord2) 2.0)) p0 p1)
	   pt1 (reverse (cdr (reverse pt1)))
     )
     (setvar "lastpoint" pt1)

    (setq ang1 (+ angent ang90))
     (setq ang2 (- angent ang90))
     (setq dir1 (polar pt1 ang1 pp))
     (setq dir2 (polar pt1 ang2 pp))

(command "offset" "ERASE" "NO" "LAYER" "CURRENT" pp ent dir1 "")
(command "offset" "ERASE" "NO" "LAYER" "CURRENT" pp ent dir2 "")
  )
)

(defun c:doff_delete ()
  (setq ang90 (dtr 90))
  (setq pp (/ pp 2.0))

  (while
    (setq ent (entsel "\nSelect line: "))
     (setq elist (entget (car ent)))
     (setq angent (angle (cdr (assoc 11 elist)) (cdr (assoc 10 elist))))
     (setq p0 (cdr (assoc 11 elist)))
     (setq p1 (cdr (assoc 10 elist)))
     (setq pt1 (mapcar '(lambda (ord1 ord2) (/ (+ ord1 ord2) 2.0)) p0 p1)
	   pt1 (reverse (cdr (reverse pt1)))
     )
     (setvar "lastpoint" pt1)

     (setq ang1 (+ angent ang90))
     (setq ang2 (- angent ang90))
     (setq dir1 (polar pt1 ang1 pp))
     (setq dir2 (polar pt1 ang2 pp))

 (command "offset" "ERASE" "NO" "LAYER" "CURRENT" pp ent dir1 "")
 (command "offset" "ERASE" "YES" "LAYER" "CURRENT" pp ent dir2 "")
    )
(setq pp (* pp 2))
)

(defun c:which_offset ()
  (dcl_Form_Close "OFSET_BIG" "DclForm1")
  (cond
    ((and (= off_type "single") (= original_type "leave"))
      (command "offset" "ERASE" "NO" "LAYER" "CURRENT" pp)
    )
    ((and (= off_type "single") (= original_type "delete"))
      (command "offset" "ERASE" "YES" "LAYER" "CURRENT" pp)
    )
    ((and (= off_type "double") (= original_type "leave"))
      (c:doff)
    )
    ((and (= off_type "double") (= original_type "delete"))
      (c:doff_delete)
    )
  )
)

(defun c:do_bks	()
  (setq new_number (substr new_number 1 (- (strlen new_number) 1)))
  (if (= new_number "")
    (progn (setq new_number " "
		 pp	    (atof new_number)
	   )
    )
  )
  (dcl_ListBox_InsertString     "OFSET_BIG"	"DclForm1" "ListBox7" 0	new_number)   (setq pp (atof new_number))
)

(defun c:do_offset ( / ent pt)
  (dcl_Form_Close "OFSET_BIG" "DclForm1")
  (setq current_layer (getvar "clayer"))
  (while
    (and
      (setq ent (entsel "\n Select object to offset: "))
      (setq pt (getpoint "\n Specify point on side to offset: "))
    )
     (command "offset" pp ent "_non" pt "")
     (command "change" "L" "" "P" "LA" current_layer "C" "bylayer" "LT" "bylayer" "")
  )
)

(defun c:do_offset_delete ()
  (dcl_Form_Close "OFSET_BIG" "DclForm1")
  (while
    (and
      (setq Sel (entsel "\n Select object to offset: "))
      (not (redraw (car Sel) 3))
      (setq OfPt (getpoint "\n Specify point on side to offset: "))
    )
     (command "offset" pp Sel "_non" OfPt "")
    (command "offset" "LAYER" "CURRENT" pp Sel "_non" OfPt "")
     (entdel (car Sel))
  )
)

(defun c:pik_it	()
  (command "osnap" "nea")
  (setq p1 (getpoint "\nPick First Point: "))
  (command "osnap" "perp")
  (setq p2 (getpoint p1 "\nPick Second Point: "))
  (command "osnap" "none")
  (setq pp (distance p1 p2))
  (setq off3 (append off3 (list (rtos pp 2 2))))
  (setq off3 (make_unique off3))
  (setq off3 (vl-sort off3 '<))
  (dcl_ListBox_AddList "OFSET_BIG" "DclForm1" "ListBox6" off3)
  (c:which_offset)
)

(defun c:DclForm1_DclForm1_OnInitialize	()
  (setq off3 (vl-sort off3 '<))
  (setq off3 (make_unique off3))
  (dcl_ListBox_Clear     "OFSET_BIG" "DclForm1" "ListBox6")
  (dcl_ListBox_AddList "OFSET_BIG" "DclForm1" "ListBox6" off3)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "TextButton16" 1)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "TextButton19" 1)

  (setq off_type "single")
  (setq original_type "leave")
  (setq new_number "")

  (if (= off_type nil)     (setq off_type "single")   )
  (if (= original_type nil)     (setq original_type "leave")   )
  (if (/= pp nil)
  (dcl_ListBox_InsertString   "OFSET_BIG" "DclForm1" "ListBox7" 0 (rtos pp 2 2))
  )
  (setq	pp (dcl_ListBox_GetText "OFSET_BIG" "DclForm1" "ListBox7" 0))
  (setq pp (atof pp))
  )

  (defun c:put_number ()
  (setq	new_number (strcat new_number number) pp (atof new_number))
  (dcl_ListBox_InsertString     "OFSET_BIG"	"DclForm1" "ListBox7" 0	new_number)
  )


(defun c:DPC_OnClicked (/)
	(rgus_error)
(dcl_Form_Close "OFSET_BIG" "DclForm1")
  (while
  (setq oldlayer (getvar "clayer"))
    (and
      (setq Sel (entsel "\n Select object to offset: "))
      (not (redraw (car Sel) 4))
      (setq OfPt (getpoint "\n Pick point on side to offset: "))
    )
  (command "-layer" "m" "INSITU - DPM" "c" 9 "INSITU - DPM" "lt" "hidden2" "INSITU - DPM" "p" "P" "INSITU - DPM" "")
  (command "offset" "layer" "current" 10 sel OfPt "")
  (command "change" "L" "" "P" "C" "bylayer" "LT" "bylayer" "")
  )
  (rgus_exit)
)

(defun c:OFSET_BIG_DclForm1_DO_OFFSET_OnClicked (/)
  (setq off3 (append off3 (list (rtos pp 2 2))))
  (setq off3 (make_unique off3))
  (setq off3 (vl-sort off3 '<))
  (dcl_ListBox_AddList "OFSET_BIG" "DclForm1" "ListBox6" off3)
  (c:which_offset)
)

(defun c:OFSET_BIG_DclForm1_TextButton1_OnClicked (/)
  (setq number "7")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton2_OnClicked (/)
  (setq number "8")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton3_OnClicked (/)
  (setq number "9")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton12_OnClicked (/)
  (setq number "BKS")
  (c:do_bks)
)

(defun c:OFSET_BIG_DclForm1_TextButton4_OnClicked (/)
  (setq number "4")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton5_OnClicked (/)
  (setq number "5")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton6_OnClicked (/)
  (setq number "6")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton13_OnClicked (/)
  (setq	new_number  ""	pp "")
  (dcl_ListBox_Clear "OFSET_BIG" "DclForm1" "ListBox7")
)

(defun c:OFSET_BIG_DclForm1_TextButton7_OnClicked (/)
  (setq number "1")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton8_OnClicked (/)
  (setq number "2")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton9_OnClicked (/)
  (setq number "3")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton14_OnClicked (/)
  (dcl_ListBox_Clear OFSET_DclForm1_ListBox6)
  (setq off3 nil)
)

(defun c:OFSET_BIG_DclForm1_TextButton10_OnClicked (/)
  (setq number "0")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton11_OnClicked (/)
  (setq number ".")
  (c:put_number)
)

(defun c:OFSET_BIG_DclForm1_TextButton15_OnClicked (/)
  (if (= (dos_clipboard) nil)
    (dcl_MessageBox
      "Nothing on the ClipBoard to PASTE"
      "ClipBoard ERROR"
      2
      4
    )
    (progn
      (dcl_ListBox_Clear "OFSET_BIG" "DclForm1" "ListBox7")
      (setq ofdist (dos_clipboard))
      (dcl_ListBox_InsertString
	"OFSET_BIG" "DclForm1" "ListBox7" 0 ofdist)
      (setq pp	       (atof ofdist)
	    new_number ofdist
      )
    )
  )
)

(defun c:METRIC_OnClicked (/)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "METRIC" 0)
  (setq unittype "IMPERIAL")
)

(defun c:IMPERIAL_OnClicked (/)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "IMPERIAL" 0)
  (setq unittype "METRIC")
)

(defun c:OFSET_BIG_DclForm1_TextButton19_OnClicked (/)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "TextButton19" 0)
  (setq original_type "delete")
)

(defun c:OFSET_BIG_DclForm1_TextButton20_OnClicked (/)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "TextButton20" 0)
  (setq original_type "leave")
)

(defun c:OFSET_BIG_DclForm1_TextButton17_OnClicked (/)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "TextButton17" 0)
  (setq off_type "single")
)

(defun c:OFSET_BIG_DclForm1_TextButton16_OnClicked (/)
  (dcl_Control_ZOrder "OFSET_BIG" "DclForm1" "TextButton16" 0)
  (setq off_type "double")
)

(defun c:OFSET_BIG_DclForm1_TextButton18_OnClicked (/)
  (dcl_Form_Close "OFSET_BIG" "DclForm1")
  (c:pik_it)
)

(defun c:OFSET_BIG_DclForm1_TextButton21_OnClicked (/)
  (dcl_Form_Close "OFSET_BIG" "DclForm1")
)

(defun c:OFSET ()
  (rgus_error)
  (dcl_LoadProject "OFSET_BIG")
  (dcl_Form_Show "OFSET_BIG" "DclForm1")
  (setq sel nil)
  (princ)
)
