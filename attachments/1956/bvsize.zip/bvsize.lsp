(defun c:bvsize/Form1#OnInitialize (/)
  (dcl-BlockView-PreLoadDwg bvsize/Form1/BlockView1 "AllControls.dwg")
  (dcl-BlockView-DisplayBlock bvsize/Form1/BlockView1 "Block List")
)

(defun c:bvsize/Form1#OnSize (NewWidth NewHeight /)
  (princ "\nbvsize/Form1#OnSize(")
  (princ NewWidth)
  (princ ", ")
  (princ NewHeight)
  (princ ")\n")
)


(defun c:test ()
  (dcl-project-load "bvsize" T)
  (dcl-form-show bvsize/Form1)
)
(c:test)
