
;;;
;;; Transparent commands
;;;
;;;pgp: kbZoomScaled,		*kbZoomScaled
(defun c:kbZoomScaled( / )
(vla-ZoomScaled
	(vlax-get-acad-object)
	0.2
	acZoomScaledRelative
      )
  (princ)
    )
;;;pgp: kbZoomOut,		*kbZoomOut
(defun c:kbZoomOut (/)
      (vla-ZoomScaled
	(vlax-get-acad-object)
	0.5
	acZoomScaledRelative
      )
      (princ)
    )
;;;pgp: kbZoomExtents,		*kbZoomExtents
(defun c:kbZoomExtents (/)
      (vla-zoomextents (vlax-get-acad-object))
      (princ)
    )
;;;pgp: kbZoomPrevious,			*kbZoomPrevious
(defun c:kbZoomPrevious (/)
      (vla-ZoomPrevious (vlax-get-acad-object))
      (princ)
    )


;;;pgp: kbZoomAll,		*kbZoomAll
(defun c:kbZoomAll (/)
      (vla-zoomall (vlax-get-acad-object))
    )
;;;pgp: kbZoomLimits,		*kbZoomLimits
(defun c:kbZoomLimits (/ l)
      (setq l (vlax-get (vla-get-ActiveDocument (vlax-get-acad-object))'limits))
      (vla-zoomwindow (vlax-get-acad-object)
	(vlax-3d-point (list(car l)(cadr l)))
	(vlax-3d-point(list(caddr l)(cadddr l))))
      (princ)
    )


;;;
;;; Design Center and Explorer Utilities
;;;
;;;pgp: kbShowProjectPDF,		*kbShowProjectPDF
(defun c:kbShowProjectPDF( / )
  (startapp "explorer.exe" (strcat(kb:ReturnProjectDir)"\\PDF"))
  (princ)
  (princ)
  )
;;;pgp: kbAdcCurrentDir,		*kbAdcCurrentDir
(defun c:kbAdcCurrentDir( / )
  (command "_adcenter")
  (command "_adcnavigate" (getvar "dwgprefix"))
  (princ "\nThere ya go!")
  (princ)
  )
;;;pgp: kbExploreCurrentDir,		*kbExploreCurrentDir
(defun c:kbExploreCurrentDir( / )
  (startapp "explorer.exe" (getvar "dwgprefix"))
  (princ)
  (princ)
  )
;;;pgp: kbAecPurgeAll,		*kbAecPurgeAll
(defun c:kbAecPurgeAll (/ ITEM)
 (foreach ITEM  '("-MaskDefine"
                  "-ProfileDefine"
                  "-NameDef"
                  "-GroupTemplate"
                  "-CalculationModifierStyle"
                  "-AreaGroupStyle"
                  "-MemberStyle"
                  "-AecPolygonStyle"
                  "-AecDimStyle"
                  "-WallStyle"
                  "-DoorStyle"
                  "-WindowStyle"
                  "-StairStyle"
                  "-RailingStyle"
                  "-SpaceStyle"
                  "-AecMvBlockDefine")
  (progn (if (vl-cmdf ITEM "p" "*" "n")
          (vl-cmdf))
         (vl-cmdf)))
 (princ "\nAll Styles have been purged!")
 (princ))

;;;pgp: kbacre,		*kbacre
(defun c:kbacre( / ent num ret)
  (setq ent(ssget ":s" '((0 . "LWPOLYLINE") )))
  (if ent
    (progn
      (setq num(vla-get-area(vlax-ename->vla-object(ssname ent 0))))
  (setq ret(cvunit num "sq in" "acre"))))
  (princ (strcat "The area is " (rtos ret 2) " acres"))(princ))


;;;pgp: kbEditPGP,		*kbEditPGP
(defun c:kbEditPGP  (/ file)
  (if (setq file (findfile "Acad.pgp"))
    (startapp "notepad.exe" file)))

;;;pgp: kbdump,		*kbdump
(defun c:kbdump  (/)
  (vlax-dump-object (vlax-ename->vla-object (car (entsel)))))

;;;pgp: kbMakeTheaterSeats,		*kbMakeTheaterSeats
(defun c:kbMakeTheaterSeats  (/ ent obj len num cnt numx)
  (setq ss (ssget '((0 . "ARC") )))
  (if ss
    (progn
    (setq num(sslength ss)
          cnt 0)
    (while (< cnt num)
	     (setq ent(ssname ss cnt)
                   obj (vlax-ename->vla-object ent)
                   len (vla-get-ArcLength obj))
           (setq numx (fix (/ len 22.0)))
           (command "divide" ent "block" "seata" "Y" numx)
	     
	     (setq cnt (1+ cnt)))
    )
    )
  (princ)
)

;;;pgp: kbBlockLabel,		*kbBlockLabel
(defun c:kbBlockLabel ( / *Error* old-cmddia ent desc)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	   (member Msg
		   '("console break"
		     "Function cancelled"
		     "quit / exit abort"))))
      ((princ (strcat "\nError: " Msg))))
    (setvar "cmddia" old-cmddia)
    (princ))
  
  (setq old-cmddia(getvar "cmddia")
	ent(entsel"\nSelect a block to Label"))
  (while ent
    (progn
  (cond
    ((= (cdr (assoc 0 (entget (car ent)))) "INSERT")
     (setq desc (vla-get-EffectiveName(vlax-ename->vla-object (car ent))))
     )
    ((= (cdr (assoc 0 (entget (car ent)))) "AEC_MVBLOCK_REF")
     (setq desc (vla-get-stylename(vlax-ename->vla-object (car ent))))))
  (if desc
    (progn
      (command ".mtext" pause pause desc ""))
  (prompt "\nNot a block!"))
  (setvar "cmddia" 0)
  (setq ent nil desc nil)
  (setq ent(entsel"\nSelect a block to Label"))))
  (*Error* nil)
  (princ)
)

;;;2009 Image fade bug fixer
;;;pgp: kbFade,		*kbFade
(defun c:kbFade( / )
  (vlax-put(vlax-ename->vla-object(car(entsel)))'fade 0)
  (princ "Fixed!")
  (princ)
  )