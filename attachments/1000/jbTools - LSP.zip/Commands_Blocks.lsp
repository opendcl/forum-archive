;;							;
;;;		Insert All Blocks!			;
;;;							;
;;;pgp: kbInsertAllBlocks,		*kbInsertAllBlocks
(defun c:kbInsertAllBlocks (/ doc blocks ins space name)
  (if (= (dcl_MessageBox
	   "Do you really want to Insert all blocks?"
	   "Insert All Blocks"
	   5
	   4
	   )
	 6
	 )
    (progn (setq ins	(vlax-3d-point 0 0)
		 space	(kb:GETACTIVESPACE)
		 doc	(vla-get-ActiveDocument (vlax-get-acad-object))
		 blocks	(vla-get-blocks doc)
		 )
	   (vlax-for
		  x blocks
	     (setq name (vla-get-name x))
	     (if (and (= (vlax-get-property x 'isxref) :vlax-false)
		      (= (vlax-get-property x 'islayout) :vlax-false)
		      (not (vl-string-search "|" name))
		      (not (vl-string-search "*" name))
		      )
	       (vla-InsertBlock space ins name 1.0 1.0 1.0 0.0)
	       )
	     )
	   )
    )
  (princ)
  )


(defun kb:InsertSomeBlocks (wildcard / doc blocks ins space name)
  (setq	ins    (vlax-3d-point 0 0)
	space  (kb:GETACTIVESPACE)
	doc    (vla-get-ActiveDocument (vlax-get-acad-object))
	blocks (vla-get-blocks doc)
	)
  (vlax-for
	 x blocks
    (setq name (vla-get-name x))
    (if	(and (= (vlax-get-property x 'isxref) :vlax-false)
	     (= (vlax-get-property x 'islayout) :vlax-false)
	     (not (vl-string-search "|" name))
	     (not (vl-string-search "*" name))
	     (wcmatch name wildcard)
	     )
      (vla-InsertBlock space ins name 1.0 1.0 1.0 0.0)
      )
    )
  (princ)
  )

;;;							;
;;;		Swap Block 				;
;;;							;
(defun kb:swapblock  (ent newBlockName / new_blk)
  (setq new_blk (subst (cons 2 newBlockName) (assoc 2 ent) ent))
  (entmod new_blk)
  (princ "\nBlock swapped!"))

(defun kb:Swap  (newBlockName / *error* a x SS NUM CNT e blk ANS new_blk)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if newBlockName
    (progn (setq x (tblsearch "block" newBlockName))
           (if x
             (progn (prompt "\nSelect blocks to be swapped: ")
                    (setq SS (ssget '((0 . "INSERT"))))))))
  (if SS
    (progn
      (setq NUM (sslength SS)
            CNT 0)
      (while (< CNT NUM)
        (setq e (ssname SS CNT))
        (cond
          ((= (vlax-property-available-p (vlax-ename->vla-object e) 'IsDynamicBlock)
              :vlax-false)
           (if (= (vlax-get (vlax-ename->vla-object e) 'IsDynamicBlock) :vlax-false)
             (kb:swapblock (entget e) newBlockName)))
          (t (kb:swapblock (entget e) newBlockName)))
        (setq CNT (1+ CNT)))
      (princ "  Done... "))
    (princ "  Nothing selected. "))
  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (princ))

;;;pgp: kbSwap,		*kbSwap
(defun c:kbSwap	(/ newBlockName blockent newName ss num cnt ent entList obj newblk)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (setq newBlockName (entsel "\nSelect Block to Clone:"))
  (if (and newBlockName (= (cdr (assoc 0 (entget(car newBlockName)))) "INSERT"))
    (progn (setq blockent (car newBlockName)
		 newName  (cdr (assoc 2 (entget blockent)))
		 )
	   (prompt "\nSelect blocks to be swapped: ")
	   (setq ss (ssget '((0 . "INSERT"))))
	   (if ss
	     (progn (setq num (sslength ss)
			  cnt 0
			  )
		    (while (< cnt num)
		      (setq ent (ssname ss cnt)
			    entList(entget ent)
			    obj(vlax-ename->vla-object ent))
		      (setq newblk (subst (cons 2 newName) (assoc 2 entList) entList))
		      (entmod newblk)
		      (if (=(vla-get-HasAttributes obj):vlax-true)
			(command "attsync" "select" ent "yes")
			)
		      (princ "\nBlock swapped!")
		      (setq cnt (1+ cnt))
		      )
		    )
	     )
	   )
    (dcl_messagebox (strcat "That is not a block insert!"
		      (strcat "\nIt's a "(cdr (assoc 0 (entget(car newBlockName)
							      )
						     )
					      )"   "
			)
		      )
      "Swap Block" 2 1
      )
    )
  (princ)
  (princ)
  )

;;;							;
;;;		WClip	 				;
;;;							;

;;;pgp: kbWclip,		*kbWclip
(defun c:kbwclip( / insPoint)
  (if (not (setq insPoint(getpoint (strcat "\nSelect insert point or <enter> for origin"))))
	   (setq insPoint "0,0,0"))
  (command "_copybase" insPoint pause)
  (princ))

;;;pgp: kbWclipInsert,		*kbWclipInsert
(defun c:kbWclipInsert( / insPoint)
  (if (not (setq insPoint(getpoint (strcat "\nSelect insert point or <enter> for origin"))))
	   (setq insPoint (list 0.0 0.0 0.0)))
  (command "_pasteclip" insPoint)
  (princ))
    
	
  
;;;							;
;;;	XREF UTILITIES					;
;;;							;
;;;
;;;(setq ret(kb:Return40Pop))

;;;pgp: kbUnloadXrefPop,		*kbUnloadXrefPop
(defun c:kbUnloadXrefPop (/)
  (kb:Return40Pop "-xref _unload ")
  (progn (menucmd "P0=kb00.POP0") (menucmd "P0=*"))
  )
;;;pgp: kbReloadXrefPop,		*kbReloadXrefPop
(defun c:kbReloadXrefPop (/)
  (kb:Return40Pop "-xref _reload ")
  (progn (menucmd "P0=kb00.POP0") (menucmd "P0=*"))
  )
;;;pgp: kbDetachXrefPop,		*kbDetachXrefPop
(defun c:kbDetachXrefPop (/)
  (kb:Return40Pop "-xref _detach ")
  (progn (menucmd "P0=kb00.POP0") (menucmd "P0=*"))
  )

;;;pgp: kbReloadAll,		*kbReloadAll
(defun c:kbReloadAll (/ *Error*)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (if (kb:DwgHasXrefs)
    (progn (vl-cmdf "_.-xref" "_reload" "*")
	   (prompt "\nAll External references have been reloaded.")
	   )
    (alert "There are no External References to Reload!   ")
    )
  (princ)
  )
;;;pgp: kbUnloadAll,		*kbUnloadAll
(defun c:kbUnloadAll (/ xrefyes *Error*)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (if (kb:DwgHasXrefs)
    (progn (vl-cmdf "_.-xref" "_Unload" "*")
	   (prompt "\nAll External references have been reloaded.")
	   )
    (alert "There are no External References to Unload!   ")
    )
  (princ)
  )

;;;pgp: kbDetachAll,		*kbDetachAll
(defun c:kbDetachAll (/ xrefyes *Error*)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (if (kb:DwgHasXrefs)
    (if	(= (dcl_MessageBox
	     "Do you really want to detach ALL Xrefs?"
	     "Detach Xrefs"
	     5
	     4
	     )
	   6
	   )
      (progn (vl-cmdf "_.-xref" "_detach" "*")
	     (prompt "\nAll External references have been detached.")
	     )
      )
    (alert "There are no External References to Detach!   ")
    )
  (princ)
  )

;;;pgp: kbDetachXref,		*kbDetachXref
(defun c:kbDetachXref (/ ent obj)
  (if (and (setq ent (kb:entsel "\nSelect an Xref to Detach:" nil nil (list "INSERT") nil)
		 obj (vlax-ename->vla-object (car ent))
		 )
	   (vlax-property-available-p obj 'path)
	   )
    (progn (vla-detach
	     (vla-item
	       (vla-get-blocks (vla-get-activedocument (vlax-get-acad-object)))
	       (vla-get-name obj)
	       )
	     )
	   (if (dcl_Form_IsActive Palette_Main)
	     (c:Palette_Main_01RefreshButton_OnClicked))
	   )
    )
  )
;;;pgp: kbUnloadXref,		*kbUnloadXref
(defun c:kbUnloadXref (/ ent obj)
  (if (and (setq ent (kb:entsel "\nSelect an Xref to Unload:" nil nil (list "INSERT") nil)
		 obj (vlax-ename->vla-object (car ent))
		 )
	   (vlax-property-available-p obj 'path)
	   )
    (vla-unload
      (vla-item
	(vla-get-blocks (vla-get-activedocument (vlax-get-acad-object)))
	(vla-get-name obj)
	)
      )
    )
  )
;;;pgp: kbReloadXref,		*kbReloadXref
(defun c:kbReloadXref (/ ent obj)
  (if (and (setq ent (kb:entsel "\nSelect an Xref to Reload:" nil nil (list "INSERT") nil)
		 obj (vlax-ename->vla-object (car ent))
		 )
	   (vlax-property-available-p obj 'path)
	   )
    (vla-reload
      (vla-item
	(vla-get-blocks (vla-get-activedocument (vlax-get-acad-object)))
	(vla-get-name obj)
	)
      )
    )
  )

;;;pgp: kbCountBlock,		*kbCountBlock
(defun c:kbCountBlock (/ *Error* a blk_name ss ss1 cnt num)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (setq	a (entsel
	    "\nSelect block to count: <you must re-select to add to selection!>"
	    )
	)
  (if a
    (progn (cond ((= (cdr (assoc 0 (entget (car a)))) "AEC_MVBLOCK_REF")
		  (setq	ss	 (ssadd)
			blk_name (vla-get-stylename (vlax-ename->vla-object (car a)))
			ss1	 (ssget (list (cons 0 "AEC_MVBLOCK_REF")))
			num	 (sslength ss1)
			cnt	 0
			)
		  (while (< cnt num)
		    (if	(= (vla-get-stylename (vlax-ename->vla-object (ssname ss1 cnt)))
			   blk_name
			   )
		      (setq ss (ssadd (ssname ss1 cnt) ss))
		      )
		    (setq cnt (1+ cnt))
		    )
		  )
		 ((= (cdr (assoc 0 (entget (car a)))) "INSERT")
		  (setq	blk_name (cdr (assoc 2 (entget (car a))))
			ss	 (ssget (list (cons 0 "INSERT") (cons 2 blk_name)))
			)
		  )
		 (t (setq ss nil) (alert "Not a Block or Multiview Block!"))
		 )
	   (if ss
	     (progn (alert (strcat "There are "
				   (itoa (sslength ss))
				   " instances of block "
				   blk_name
				   " in your selection."
				   )
			   )
		    (princ (sslength ss))
		    )
	     )
	   )
    )
  (princ)
  )

