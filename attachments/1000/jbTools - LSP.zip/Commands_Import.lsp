;;;							;
;;;	Import Commands					;
;;;							;
(vl-load-com)


;;;						;
;;;	Utility Subs				;
;;;						;


;;;								;
;;;	Get a list of layers via ObjectDBX			;
;;;	filters out xref layers and 0, defpoints		;
;;;								;
(defun kb:GetMasterLayerList (dwg / lname llist dbxdoc)
  (if dwg
    (progn (setq dbxDoc (kb:OpenDbxDocument dwg))
	   (if dbxDoc
	     (progn (vlax-for i (vla-get-layers dbxDoc)
		      (setq lname (vla-get-name i))
		      (if (or
			    (not (wcmatch (strcase lname) "*|*"))
			    (not (wcmatch (strcase lname) "DEFPOINTS"))
			    (not (wcmatch (strcase lname) "0"))
			    )
			(setq llist (append llist (list lname)))
			))
		    (kb:CloseDbxDocument dbxDoc)
		    ))))
  llist
  )

    ;(kb:FilterLayerList (kb:GetMasterLayerList nil) "A-Wall*")
(defun kb:FilterLayerList (llist fi / li)
  (foreach i llist
    (if	(wcmatch (strcase i) (strcase fi))
      (setq li (append li (list i)))
      ))
  li
  )

    ;(kb:GetLayerFilters kb%ImpLayFile)
    ;(setq dwg kb%ImpLayFile llist nil)
(defun kb:GetLayerFilters  (dwg / dict lf lfdict flist llist dbxDoc)
  (if dwg
    (setq dbxDoc (kb:OpenDbxDocument dwg))
    (setq dbxDoc (vla-get-activedocument (vlax-get-acad-object)))
    )
  (setq	dict (vla-GetExtensionDictionary (vla-get-layers dbxDoc))
	lf   (vl-catch-all-apply 'vla-item (list dict "ACAD_LAYERFILTERS"))
	)
  (if (vl-catch-all-error-p lf)
    (setq llist nil)
    (progn (setq lfdict (vlax-vla-object->ename lf))
	   (foreach i (entget lfdict)
	     (if (= (car i) 3)
	       (setq flist (append flist (list (cdr i))))
	       ))
	   (foreach i flist
	     (setq llist (append llist
			     (list (cons i (list (cdr (nth 10 (dictsearch lfdict i))))))
			     )
	       )))
    )
  (if dbxDoc
    (kb:CloseDbxDocument dbxDoc)
    )
  llist
  )

(defun kb:Import_Propogate_Listbox(objType / ObjectList dwgName)
  (setq dwgName(dcl_Control_GetProperty Palette_Main_03dwgName "Caption"))
  (if dwgName
    (progn
  (dcl_ListBox_Clear Palette_Main_03ImportList)
  (setq ObjectList(kb:ReturnDBXCollectionObjects dwgName objType))
    (if ObjectList
      (dcl_ListBox_addlist Palette_Main_03ImportList ObjectList))
      ))
  )



;;;						;
;;;	Import Manager Initialize		;
;;;						;
(defun kb:ImportManager_OnInitialize (/ dwgName ObjectList)
  (dcl_ComboBox_Clear Palette_Main_03CollectionsComboBox)
  (dcl_ListBox_Clear Palette_Main_03ImportList)
  (dcl_ComboBox_AddList Palette_Main_03CollectionsComboBox
    (list  "BLOCKS" "VIEWS" "UCS" "DIMSTYLE" "TEXTSTYLE"))
  (dcl_ComboBox_SetCurSel Palette_Main_03CollectionsComboBox 0)
  (setq dwgName(vl-registry-read
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\ImportManager"
	"dwgName"
	)
	)
  (if dwgName
    (progn
      (dcl_Control_SetProperty Palette_Main_03dwgName "Caption" dwgName)
      (kb:Import_Propogate_Listbox "BLOCKS"))
    )
  (princ)
  (princ)
)

(defun c:Palette_Main_03ImportList_OnSelChanged (ItemIndex Value /)
  (princ)
)


(defun c:Palette_Main_03CollectionsComboBox_OnSelChanged (ItemIndex Value /)
  (cond((= Value "BLOCKS")(kb:Import_Propogate_Listbox "BLOCKS"))
       ((= Value "VIEWS")(kb:Import_Propogate_Listbox "VIEWS"))
       ((= Value "UCS")(kb:Import_Propogate_Listbox "UCS"))
       ((= Value "DIMSTYLE")(kb:Import_Propogate_Listbox "DIMSTYLE"))
       ((= Value "TEXTSTYLE")(kb:Import_Propogate_Listbox "TEXTSTYLE"))
       )
  (princ)
  (princ)

)

;;;						;
;;;	Button Events				;
;;;						;
(defun c:Palette_Main_03OpenImportFileButton_OnClicked (/ dwgName)
  (setq	dwgName
	 (getfiled
	   "Select a file"
	   (strcat(kb:ReturnProjectDir)"\\")
	   "dwg;dws"
	   0
	   )
	)
  (if dwgName
    (progn
(dcl_Control_SetProperty Palette_Main_03dwgName "Caption" dwgName)
      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\ImportManager"
	"dwgName"
	dwgName
	)
      (kb:ImportManager_OnInitialize)
      )
    )
  (princ)
  (princ)
  )


(defun c:Palette_Main_03ImportButton_OnClicked (/ ImportList ImportType DwgName)
  (setq ImportList(dcl_ListBox_GetSelectedItems Palette_Main_03ImportList)
	ImportType(dcl_ComboBox_GetLBText Palette_Main_03CollectionsComboBox(dcl_ComboBox_GetCurSel Palette_Main_03CollectionsComboBox))
	DwgName(dcl_Control_GetProperty Palette_Main_03dwgName "Caption")
	)
  (if (and DwgName ImportType ImportList)
    (progn
      (dcl_ListBox_SelItemRange Palette_Main_03ImportList 0 (dcl_ListBox_GetCount Palette_Main_03ImportList) nil)
	(kb:ImportCollectionObjects DwgName ImportType ImportList)
      )
    )
)

(defun c:Palette_Main_03ProjectButton_OnClicked (/ dwgname)
  (if (setq dwgName(kb:ReturnProjectAECStylesStandardsFile))
    (progn
(dcl_Control_SetProperty Palette_Main_03dwgName "Caption" dwgName)
      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\ImportManager"
	"dwgName"
	dwgName
	)
      (kb:ImportManager_OnInitialize)
      )
    )
)

;;;							;
;;;	Import Layers					;
;;;							;

(defun kb:ImportLayers_OnInitialize (/ fileName fi layerlist st parent parent-list child-list misc-list)
  (if (not (setq fileName
		  (vl-registry-read
		    "HKEY_CURRENT_USER\\Software\\kbTools2009\\ImportLayers"
		    "fileName"
		    )
		 )
	   )
    (setq fileName (kb:ReturnLayerStandardsFile))
    )
  (if fileName
    (progn
      (dcl_Tree_Clear Palette_Main_02LayerFilterTree)
      (dcl_Control_SetProperty Palette_Main_02SetButton "Enabled" t)

      (dcl_Control_SetProperty Palette_Main_02dwgName "Caption" fileName)
      (setq fi	      (kb:GetLayerFilters fileName)
	    layerlist (kb:GetMasterLayerList fileName)
	    )
      (dcl_ListBox_Clear Palette_Main_02ImportList)
;;; If Layer List exists
      (if layerlist
	(progn (foreach
		      i
		       (list "Defpoints" "defpoints" "DEFPOINTS" "0")
		 (setq layerlist (vl-remove i layerlist))
		 )
	       (dcl_ListBox_AddList Palette_Main_02ImportList layerlist)
	       )
	(dcl_ListBox_AddList
	  Palette_Main_02ImportList
	  (list "The layer Standards file is opened!" "Contact IT")
	  )
	)
      (dcl_Tree_AddParent Palette_Main_02LayerFilterTree "All Layers" "*" 0 0 0) ;load parents
      (if fi
	(progn
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (if	(and (= (length st) 2) (= (cadr st) 42)) ; = "A*", or "S*" - New Parent
	      (progn (setq parent-list (append parent-list (list (cadr n))))
		     (dcl_tree_addchild Palette_Main_02LayerFilterTree "*" (car n) (cadr n) 0 0 0)
		     )
	      )
	    ) ;load children
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (cond
	      ((and (= (length st) 2) (= (cadr st) 42)))
	      ((member (setq parent (strcat (chr (car st)) "*")) parent-list)
	       (setq child-list (append child-list (list parent (cadr n))))
	       (dcl_tree_addchild Palette_Main_02LayerFilterTree parent (car n) (cadr n) 0 0 0)
	       )
	      (t
	       (setq misc-list (append misc-list (list "misc" (cadr n))))
	       (dcl_tree_addchild Palette_Main_02LayerFilterTree "*" (car n) (cadr n) 0 0 0)
	       )
	      )
	    ) ;expand tree
	  (dcl_Tree_ExpandItem Palette_Main_02LayerFilterTree "*" 1)
	  (Setq rValue (dcl_Tree_GetFirstChildItem Palette_Main_02LayerFilterTree "*"))
	  (dcl_Tree_ExpandItem Palette_Main_02LayerFilterTree rValue 1)
	  (dcl_Tree_EnsureVisible Palette_Main_02LayerFilterTree rValue)
	  (foreach
		 key
		    parent-list
	    (if	(dcl_Tree_ItemHasChildren Palette_Main_02LayerFilterTree key)
	      (progn (dcl_Tree_ExpandItem Palette_Main_02LayerFilterTree key 1)
		     (dcl_Tree_EnsureVisible
		       Palette_Main_02LayerFilterTree
		       (dcl_Tree_GetFirstChildItem Palette_Main_02LayerFilterTree key)
		       )
		     )
	      )
	    )
	  )
	)
      )

    (progn
      (dcl_Control_SetProperty Palette_Main_02dwgName "Caption" "")
      (dcl_ListBox_AddString
	Palette_Main_02ImportList
	"Select a Drawing to Import Layers"
	)
      (c:Palette_Main_02OpenImportFileButton_OnClicked)
      )
    )
  )  



(defun c:Palette_Main_02LayerFilterTree_OnSelChanged (Label Key / filename)
  (setq fileName (dcl_Control_GetCaption Palette_Main_02dwgName))
  (dcl_ListBox_Clear Palette_Main_02ImportList)
  (dcl_ListBox_AddList
    Palette_Main_02ImportList
    (kb:FilterLayerList (kb:GetMasterLayerList fileName) Key)
    )
  (princ)
  (princ)
  )

(defun c:Palette_Main_02ImportList_OnSelChanged (ItemIndex Value  / )
  (if (> ItemIndex 1)
    (dcl_Control_SetProperty Palette_Main_02SetButton "Enabled" nil)
    (dcl_Control_SetProperty Palette_Main_02SetButton "Enabled" t)
    )
  (princ)
  (princ)
  )

(defun c:Palette_Main_02SetButton_OnClicked (/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems Palette_Main_02ImportList)
	fileName  (dcl_Control_GetCaption Palette_Main_02dwgName)
	)
  (if fileName
    (progn
      (kb:ImportCollectionObjects fileName "LAYERS" layerList)
      (kb:setclayer (car layerList) t)
       )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

  
(defun c:Palette_Main_02ImportButton_OnClicked (/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems Palette_Main_02ImportList)
	fileName  (dcl_Control_GetCaption Palette_Main_02dwgName)
	)
  (if fileName
    (progn
      (kb:ImportCollectionObjects fileName "LAYERS" layerList)
      (foreach
	     x
	      (dcl_ListBox_GetSelectedNths Palette_Main_02ImportList)
	(dcl_ListBox_SetSel Palette_Main_02ImportList x nil)
	)
      (foreach x layerList (princ (strcat "\n" x " has been imported!")))
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:Palette_Main_02OpenImportFileButton_OnClicked (/ fileName)
  (setq	fileName
	 (getfiled
	   "Select a file"
	   (vl-filename-directory (kb:ReturnLayerStandardsFile))
	   "dwg"
	   0
	   )
	)
  (if fileName
    (progn

      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\ImportLayers"
	"fileName"
	fileName
	)
      (kb:ImportLayers_OnInitialize)
      )
    )
  (princ)
  (princ)
  )
(defun c:Palette_Main_02ProjectButton_OnClicked (/ fileName)
  (if (setq fileName(kb:ReturnLayerStandardsFile))
    (progn

      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\ImportLayers"
	"fileName"
	fileName
	)
      (kb:ImportLayers_OnInitialize)
      )
    )
  (princ)
  (princ)
  )
;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 T T nil T)
;*** DO NOT add text below the comment! ***|;
