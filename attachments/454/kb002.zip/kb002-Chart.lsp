;;;									;
;;;		Keynote Chart Functions					;
;;;									;

;;;									;
;;;	Gather KeyChart Data						;
;;;									;
;;;	(setq ret(kb:ReturnKeyChartData nil))				;
;;;	(setq legend nil)						;
;;;									;
(defun kb:ReturnKeyChartData  ( / xdata legend obj cnt num ss)
  (prompt "\nSelect Keynotes for Chart or <ENTER> for all:")
    (setq ss (ssget '((-4 . "<OR") (0 . "MULTILEADER") (0 . "MTEXT") (-4 . "OR>"))))
  (if ss
    (progn (setq num (sslength ss)
		 cnt 0)
	   (while (< cnt num)
	     (setq xdata (kb:getKeyNotexdata (ssname ss cnt))
		   cnt	 (+ 1 cnt))
	     (if (and(= (nth 2 xdata) "KEYLEADER")
		     (/=(nth 0 xdata)"")
		     (/=(nth 1 xdata)""))
	       (if (not (member(strcat (nth 0 xdata) "\t" (nth 1 xdata)) legend))
	       (setq legend (append legend (list (strcat (nth 0 xdata) "\t" (nth 1 xdata)))))))))
    (progn
      (vlax-for
	     obj  (kb:getactivespace)
	(setq xdata (kb:getKeyNotexdata (vlax-vla-object->ename obj)))
	(if (and(= (nth 2 xdata) "KEYLEADER")
		     (/=(nth 0 xdata)"")
		     (/=(nth 1 xdata)""))
	       (if (not (member(strcat (nth 0 xdata) "\t" (nth 1 xdata)) legend))
	       (setq legend (append legend (list (strcat (nth 0 xdata) "\t" (nth 1 xdata)))))))))
    )
  (acad_strlsort legend))




;;;									;
;;;	Add Xdata to KeyNote Charts!!!!!				;
;;;									;
(defun kb:MakeKeynoteChart  (/ lst str lsst tabs dim mobj ent)
  (setq	lsst  (kb:ReturnKeyChartData)
	dim   (* (getvar "dimscale") 0.5) ;(getvar "dimscale")
	tabs  (strcat "\\pi-"
		      (vl-princ-to-string (fix dim))
		      ",l"
		      (vl-princ-to-string (fix dim))
		      ";{\\LKEYNOTES:}\\P\\pt" ;";\\pt"
		      )
	str   (strcat (vl-princ-to-string (fix dim)) ";")
	nscale(kb:cannoscale))
  
  (foreach i lsst (setq str (strcat str "\\P" i)))
  (if lsst
    (progn (setq str (strcat tabs str))
	   (command "_.mtext" pause pause "." "")
	   (setq ent  (entlast)
		 mobj (vlax-ename->vla-object ent))
	   (kb:putKeyNotexdata ent nil nil "KEYNOTELEGEND" nscale)
	   (vlax-put mobj "TextString" str)
      )))



;;;(setq chart(car(entsel)))
;;; takes an entity
(defun kb:kn:UpdateChart  (chart / lst str lsst tabs chobj pt1 pt2 p dim mobj ent)
  (if chart
    (progn
      (setq chobj (vlax-ename->vla-object chart))
    (if	(and (= (vla-get-objectname chobj) "AcDbMText")
	     (=	(nth 2 (kb:getKeyNotexdata chart))
		"KEYNOTELEGEND"))
      (progn 
	     (vla-GetBoundingBox chobj 'p1 'p2)
	     (setq lsst	 (kb:ReturnKeyChartData)
		   pt1	 (vlax-safearray->list p1)
		   pt2	 (vlax-safearray->list p2)
		   dim	 (* (getvar "dimscale") 0.5)
		   tabs	 (strcat "\\pi-"
				 (vl-princ-to-string (fix dim))
				 ",l"
				 (vl-princ-to-string (fix dim))
				 ";{\\LKEYNOTES:}\\P\\pt" ;";\\pt"
				 )
		   str	 (strcat (vl-princ-to-string (fix dim)) ";")
		   nscale(kb:cannoscale))
	     (foreach i lsst (setq str (strcat str "\\P" i)))
	     (if lsst
	       (progn (vla-delete chobj)
		      (setq str (strcat tabs str))
		      (command "_.mtext" pt1 pt2 "." "")
		      (setq ent	 (entlast)
			    mobj (vlax-ename->vla-object ent))
		      (kb:putKeyNotexdata ent "" "" "KEYNOTELEGEND" nscale)
		      (vlax-put mobj "TextString" str)
		      )))))))


    ;(setq chobj(vlax-ename->vla-object(car(entsel))))
(defun c:kbUpdateALLCharts  (/ lst str lsst tabs chobj pt1 pt2 p dim mobj ent)
  (setq lsst (kb:ReturnKeyChartData))
  (vlax-for
	 chobj	(kb:getactivespace)
    (if	(and (= (vla-get-objectname chobj) "AcDbMText")
	     (=	(nth 2 (kb:getKeyNotexdata (vlax-vla-object->ename chobj)))
		"KEYNOTELEGEND"))
      (progn (vla-GetBoundingBox chobj 'p1 'p2)
	     (setq pt1	 (vlax-safearray->list p1)
		   pt2	 (vlax-safearray->list p2)
		   dim	 (* (getvar "dimscale") 0.5)
		   tabs	 (strcat "\\pi-"
				 (vl-princ-to-string (fix dim))
				 ",l"
				 (vl-princ-to-string (fix dim))
				 ";{\\LKEYNOTES:}\\P\\pt" ;";\\pt"
				 )
		   str	 (strcat (vl-princ-to-string (fix dim)) ";")
		   nscale(kb:cannoscale))
	     (foreach i lsst (setq str (strcat str "\\P" i)))
	     (if lsst
	       (progn (vla-delete chobj)
		      (setq str (strcat tabs str))
		      (command "_.mtext" pt1 pt2 "." "")
		      (setq ent	 (entlast)
			    mobj (vlax-ename->vla-object ent))
		      (kb:putKeyNotexdata ent "" "" "KEYNOTELEGEND" nscale)
		      (vlax-put mobj "TextString" str)
		      ))))))




;;;							;
;;;		Utility Functions			;
;;;							;


;;;Retrieves the keynote file data
;;; use: (kb:getKeynoteFileData(kb:GetKeynoteFile NIL))
;;;(setq file nil div nil key nil)
(defun kb:getKeynoteFileData  (file / ofile tx iniLst keys div)
  (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx))))
  (close ofile)
  (foreach
	 i  inilst
    (if	(= (VL-STRING-POSITION (ascii "*") i) 0) ; it's a division
      (setq div (append div (list (vl-string-trim "*" i))))
      (setq keys (append keys (list i)))))
  (list div keys))





 ;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
