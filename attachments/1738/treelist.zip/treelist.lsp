(defun c:test (/ DRAGKEY
				c:dclInitialize c:dclDragBegin c:dclDragEnd
				)
	(defun c:dclDragBegin ()
		(setq DRAGKEY (dcl_Tree_GetSelectedItem treelist_form1_treecontrol1))
	) ; DragBegin
	(defun c:dclDragEnd (project form control key)
		(dcl_MessageBox (strcat 
			"You just dragged " DRAGKEY " onto " key ".\n"
			"But I don't know if you were holding CTRL for Copy."
		)) ; strcat
	) ; DragEnd
	(defun c:dclInitialize (/ i key)
		(setq i 1)
		(repeat 10 
			(setq key (strcat "key" (itoa i)))
			(dcl_Tree_AddParent treelist_form1_treecontrol1
				(list 
					(list key key)
				) ; list
			) ; addparent
		(setq i (1+ i))
		) ; repeat
	) ; Initialize

	(command "OPENDCL")

	(dcl_project_load "treelist" t)
	
	(dcl_form_show treelist_form1)

(princ)
) ; test

(c:test)
