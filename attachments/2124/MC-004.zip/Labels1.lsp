(defun c:labelcolors1 ( / c:MC-004/frmPlotManager#OnInitialize c:MC-004/frmPlotManager/cmdCancel#OnClicked)
  (command "_opendcl")
;;;  (dcl-project-load "D:\\Service\\Support\\OpenDCL\\150421\\labels.odcl")
  (dcl-project-load "D:\\Users\\Workstation3\\Downloads\\MC-004.odcl")

  (defun c:MC-004/frmPlotManager#OnInitialize (/)
;;;    (dcl-Control-SetForeColor labels/Dialog1/Bezeichnung5 1)
;;;    (dcl-Control-SetForeColor labels/Dialog1/Bezeichnung6 16810239)
;;;    (dcl-Control-SetForeColor labels/Dialog1/Bezeichnung7 -14)
   (princ)
  ); c:labels/Dialog1#OnInitialize

  (defun c:MC-004/frmPlotManager/cmdCancel#OnClicked (/)
   (dcl-form-close MC-004/frmPlotManager)
   (princ)
  )

  (dcl-form-show MC-004/frmPlotManager)

  (princ)
); c:labelcolors1