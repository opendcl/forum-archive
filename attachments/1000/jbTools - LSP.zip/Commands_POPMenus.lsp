;;;								;
;;;	USC Tools						;
;;;								;

;;;								;
;;;	USC Pop list Tool					;
;;;								;



;;; Return a list of UCSs
;;; use(setq l(kb:ListUCSs))
(defun kb:ListUCSs  (/ ucslist)
  (setq ucslist(list
(cons "World" "ucs World ")		 
(cons "Bottom" "ucs orthoGraphic Bottom ")
(cons "Front" "ucs orthoGraphic Front ")
(cons "Back" "ucs orthoGraphic Back ")
(cons "Left" "ucs orthoGraphic Left ")
(cons "Right" "ucs orthoGraphic Right ")
(cons "45" "ucs _z 45 ")
(cons "Origin" "ucs _o ")
(cons "Object" "ucs _ob ")
))
  (vlax-for
         x  (vla-get-UserCoordinateSystems (vla-get-ActiveDocument (vlax-get-acad-object)))
    
      (setq ucslist (append ucslist (list (cons (vlax-get-property x 'name)(strcat"ucs restore "(vlax-get-property x 'name)" ")
						)))))
  ucslist)


;;;pgp: kbUCSPop,		*kbUCSPop
(defun c:kbUCSPop( / ret)
  (if(kb:DynamicPop (kb:ListUCSs) "kb00")
  (progn (menucmd "P0=kb00.POP0")
	 (menucmd "P0=*")
	 )))



(defun kb:ActivateDocument(docStr / )
  (vla-activate(vla-item(vla-get-documents(vlax-get-acad-object)) docStr))
  )

;;;
;;;(kb:DocPop)
;;;
(defun kb:DocPop (/ vlist ret addstr)
  (setq addstr nil)
(vlax-for v (vla-get-documents(vlax-get-acad-object))
  (if addstr
    (setq vlist(append vlist (list (vla-get-name v)))))
  (setq addstr t)
  )(foreach
	 x vlist
    (setq ret (append ret
		      (list (cons x (strcat "(kb:ActivateDocument " (chr 34) x (chr 34) ") ")))
		      )
	  )
    )
  )

;;;pgp: kbDocPop,		*kbDocPop
(defun c:kbDocPop (/ vlist)
  (if (kb:DynamicPop (kb:DocPop) "kb00")
    (progn (menucmd "P0=kb00.POP0") (menucmd "P0=*"))
    )
  )


;;;
;;;
;;;
(defun kb:ViewPop (/ vlist ret)
  (vlax-for
	 v (vlax-get (vla-get-activedocument (vlax-get-acad-object)) "views")
    (setq vlist (append vlist (list (vla-get-name v))))
    )
  (foreach
	 x vlist
    (setq ret (append ret
		      (list (cons x (strcat "-view " "_restore " (chr 34) x (chr 34) " ")))
		      )
	  )
    )
  )

;;;pgp: kbRestoreViewPop,		*kbRestoreViewPop
(defun c:kbRestoreViewPop (/ vlist)
  (if (kb:DynamicPop (kb:ViewPop) "kb00")
    (progn (menucmd "P0=kb00.POP0") (menucmd "P0=*"))
    )
  )
;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 0 T nil nil T)
;*** DO NOT add text below the comment! ***|;
