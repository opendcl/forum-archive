(vl-load-com)

(if (not (vl-bb-ref 'BlockList))
  (vl-bb-set
    'BlockList
    (dcl_project_import
      '("YWt6A+8OAACHXgRHBuKT6EURbT9q+7FEDzzy3/be/jYvWvw+POicaXg0/FZsZX1QFu7cpmZOTw+f"
"dlxkWiQWFjxvVGA8Qn1s8eB0RAB+QX73GX07/uZF7WexEPB3eid22pIUCRnBwwmYsJJDCQlD/rg8"
"vWBDBS87c1syXvV0lOb8WWjRxP8QHZdTIHkt9l1fOWy5ziXQTwPhqtPqknfq2yvqKGRnF1saQfBf"
"zza0x1Idapu2UvCiLkPEmTuDQlgJF5fD2gUyHSKIZgi3zeqQBdnK7bydDOqbUNOdN95tbyHS1NPI"
"swR4YDyYIGf6+Bp2+8HdtS4xh1cK669nOJlmS2bDGAror2s46WYDG0qzlnsEj/Uz52Pou8zQeOOp"
"U8PD74ncrg366STDctLdOMOwD6gmCwaqg00ZG/0GvJZX3bnywA+KJXwPO81E57lb13meLMXQM8nF"
"cJn/GLCKv5sy2DuwOiZcDxNom8nO8K9i3YXyYE7Eudak4sEZ6Rr8r5eYQsNRmPuoppRq3VzxBvqv"
"OzjN8vBMBKEiqOsYE3YVgsnA8uNJbZKa8rNF1QD9YAyAOmaHzKHwRmeyzGJ07CF74upMKqvHyDGw"
"WQA9Vq3YvZVCuDPwmvANoh6uI/l4cuQfuSXySES5zj95Y4QSrhOZFp1EuvCpIopf/RCO+mhG9nGi"
"gyUg0QmEYs5kGtXxImHIDNZ5YuRPFqpfZSnohbTPq3YlE51HhLSyWcZMrV+py/iRFosXtDUeIiiE"
"NKZ90D4dLiHMT1ZZC+C6zqYqyjMnQN+BJ5sXLy2kKFOM4moj/+uRVxZn1UHuVye85FKY7BwfxQTK"
"rIQfL6WU+VN9U0qRbQZ7Wo61XkvxnGGul3vuMEn/ChRjzVK0YiXzzmuGuRoHl5A5LsQvvSU3SULS"
"iyfpybd8kCEgvrALK7gQhW1nUQd1k+7RC4K1jON9t6kUy7u5BivAQe/RpAB+ClD3bg==")
      )
    )
  )

(defun c:BlockList_00_OK_OnClicked ( /)
     (Setq Value (dcl_ListView_GetItemText BlockList_00_BlockList1 
	(dcl_BlockList_GetCurSel BlockList_00_BlockList1)))
  (if Value
    (alert(strcat Value " is the currently selected block"))
    )
)

(defun c:BlockList_00_Close_OnClicked ( /)
     (dcl_form_close BlockList_00)
)

;;;							;
;;;		Command Interface			;
;;;							;

(defun c:BlockList (/)
  (if (not (member "BlockList" (dcl_GetProjects)))
    (dcl_Project_load "BlockList")
    )
  (if dcl_HideErrorMsgBox
    (dcl_Form_Show BlockList_00)
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )