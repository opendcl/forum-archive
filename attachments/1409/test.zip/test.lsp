(defun c:test (/
				)

		(defun c:test_form1_OnInitialize (/ imgwidth imgheight symx)
			(setq imgwidth (dcl_Control_GetWidth test_form1_slideview1)
				imgheight (dcl_Control_GetHeight test_form1_slideview1)
				symx "DIM"
			) ; setq

			(dcl_SlideView_SlideImage test_form1_slideview1 
				(list (list 0 0 imgwidth imgheight "SITEITEM~LEADERS.slb" symx))
			) ; slideimage

		) ; oninitialize


	(command "_.OPENDCL")
	(dcl_Project_Load "test" t)
	(dcl_Form_Show test_form1) ; fires initialize

(princ)
) ; test
