Const msiOpenDatabaseModeDirect = 2
Const msiReinstallModeFileEqualVersion = 8
Const msiUILevelNone = 2
Const sOpenDCLRuntimeMSIUpgradeCode = "{A3675613-313B-47AC-8DD2-8707F33610AB}"

Set oInst = CreateObject("WindowsInstaller.Installer")
oInst.UILevel = msiUILevelNone
Set oProducts = oInst.ProductsEx("","",7)

On Error Resume Next
For Each oProduct in oProducts
  sLocalPkg = oProduct.InstallProperty("LocalPackage")
  Set oDB = oInst.OpenDataBase(sLocalPkg, msiOpenDatabaseModeDirect)
  sQuery = "SELECT `Value` FROM `Property` WHERE `Property` = 'UpgradeCode'"
  Set oView = oDB.OpenView(sQuery)
  oView.Execute
  Set oRecord = oView.Fetch
  sUpgradeCode = oRecord.StringData(1)
  Set oRecord = Nothing
  Set oView = Nothing
  Set oDB = Nothing
  If UCase(sUpgradeCode) = sOpenDCLRuntimeMSIUpgradeCode Then
    oInst.ReinstallProduct oProduct.ProductCode, msiReinstallModeFileEqualVersion
    Exit For
  End If
Next

Set oProducts = Nothing
Set oInst = Nothing
