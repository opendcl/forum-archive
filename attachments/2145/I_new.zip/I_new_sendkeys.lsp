(defun C:III ()
  (setvar "SDI" 0) ; Turn on multiple document interface.
  (command "OPENDCL")
  (dcl-Project-Load "I_new")
  (dcl-Form-Show I_new/Main)
  (princ)
)

(defun c:I_new/Main/DrawingsListBox#OnDblClicked ( / docObj fptr path shellObj)
  (setq path (car (dcl-ListBox-GetSelectedItems I_new/Main/DrawingsListBox)))
  (setq path (strcat (getvar 'dwgprefix) path ".dwg"))
  (setq shellObj (vlax-get-or-create-object "WScript.Shell"))
  (print "Start")
  (cond
    ((= (strcase path) (strcase (strcat (getvar 'dwgprefix) (getvar 'dwgname))))
      (print "a")
      nil
    )
    (
      (setq docObj
        (vl-some
          '(lambda (obj) (if (= (strcase path) (strcase (vla-get-fullname obj))) obj))
          (vle-collection->list (vla-get-documents (vlax-get-acad-object)))
        )
      )
      (print "b")
      (vla-activate docObj)
    )
    (T
      (print "c")
      (vlax-invoke shellObj 'appactivate (vla-get-caption (vlax-get-acad-object)))
      (cond
        ((setq fptr (open path "a"))
          (close fptr)
          (vlax-invoke shellObj 'sendkeys (strcat "FILEDIA 0\n_.OPEN \"" path "\"\nFILEDIA 1\n"))
        )
        (
          (=
            1
            (vle-alert
              "Drawing cannot be opened in read-write mode"
              (strcat "Open " path " read only?")
              33
            )
          )
          (vlax-invoke shellObj 'sendkeys (strcat "FILEDIA 0\n_.OPEN \"" path "\"\n\nFILEDIA 1\n")) ; Extra enter.
        )
      )
      
      (print "c1")
    )
  )
  (vlax-invoke shellObj 'appactivate (vla-get-caption (vlax-get-acad-object)))
  (if shellObj (vlax-release-object shellObj))
  (print "End")
)

(defun c:I_new/Main/DrawingsRefresh#OnClicked ( / lst)
  (setq lst
    (vl-sort
      (mapcar
        'vl-filename-base
        (vl-directory-files (strcat (getvar "dwgprefix"))  "*.dwg")
      )
      '<
    )
  )
  (dcl-ListBox-Clear I_new/Main/DrawingsListBox)
  (dcl-ListBox-AddList I_new/Main/DrawingsListBox lst)
)

(princ "\nIII Loaded ")
(princ)