;;;								;
;;;								;
;;; This is a collection of commonly used utilities by many of  ;
;;; jbCadTools applications.  It should be kept in an "include" ;
;;; folder for access while compiling.                          ;
;;;								;
;;;								;

(vl-load-com)


(defun jbLoadARX( / )
    ;;; load layer arx
(if (null AecSetLayerKeyOverride)
  (cond ((= (substr (getvar "ACADVER") 1 5) "15.06")
         (arxload
           (strcat (vla-get-path (vlax-get-acad-object))
                   "\\AecLayerManagerUI30.arx")))
        ((= (substr (getvar "ACADVER") 1 4) "16.0")
         (arxload
           (strcat (vla-get-path (vlax-get-acad-object)) "\\AecLMgrLisp40.arx")))
        ((= (substr (getvar "ACADVER") 1 4) "16.1")
         (arxload
           (strcat (vla-get-path (vlax-get-acad-object)) "\\AecLMgrLisp45.arx")))
        ((= (substr (getvar "ACADVER") 1 4) "16.2")
         (arxload
           (strcat (vla-get-path (vlax-get-acad-object)) "\\AecLMgrLisp47.arx")))
        ((= (substr (getvar "ACADVER") 1 4) "17.1")
         (arxload
           (strcat (vla-get-path (vlax-get-acad-object)) "\\AecLMgrLisp.arx")))))

;;; load opendcl arx

(if (not
      (member (strcat "jb00" (substr (getvar "acadver") 1 2) ".arx") (arx)))
  (arxload
    (strcat "jb00" (substr (getvar "acadver") 1 2) ".ARX")
    "Unable to load the correct jb00 ARX"))
(dcl_HideErrorMsgBox))


(if jbLoadARX (jbLoadARX))



(defun jb:strParse  (Str del / srch len ret n char)
  (setq srch Str
        len  (strlen srch)
        ret  '())
  (while (> len 0)
    (setq n    1
          char (substr srch 1 1))
    (while (and (/= char del) (/= char ""))
      (setq n    (1+ n)
            char (substr srch n 1)))
    (setq ret  (cons (substr srch 1 (1- n)) ret)
          srch (substr srch (1+ n) len)
          len  (strlen srch)))
  (reverse ret))




;;;			 ADT Variable Function			;
;;;		Layer Standard Drawing (jb:GetADTVar 5)		;
;;; 		Layer Standard  (jb:GetADTVar 9)		;
;;; 		Drawing Scale(jb:GetADTVar 40)			;
;;; 		Annotation size (jb:GetADTVar 42)		;
;;;								;


;;;		Return ADT Variable Value			;

(defun jb:GetADTVar  (var / dict vars ret)
    ;check to see if the dict exists, if not initialize it . . .
  (if (not (cdar (dictsearch (namedobjdict) "AEC_VARS")))
    (aeclayerkeylist))
  (setq dict (dictsearch
               (cdar (dictsearch (namedobjdict) "AEC_VARS"))
               "AEC_VARS_DWG_SETUP")
        vars (member '(100 . "AecDbVarsDwgSetup") dict)
        ret  (cdr (assoc var vars)))
  ret)


;;;								;
;;;		Create a POP0 menu				;
;;;								;
;;;	Use: (jb:DynamicPop (some list) "jb40")			;
;;;
(defun jb:DynamicPop  (ulist menugrp / acadobj menugrps menu menus shortcut)
  (setq	acadobj	 (vlax-get-acad-object)
	menugrps (vla-get-menugroups acadobj)
	menu	 (vl-catch-all-apply 'vla-item (list menugrps menugrp)))
  (if (not (vl-catch-all-error-p menu))
    (progn (setq menus (vla-get-menus menu))
	   (vlax-for
		  i  menus
	     (if (= (vla-get-shortcutmenu i) :vlax-true)
	       (setq shortcut i)))
	   (if shortcut
	     (progn (vlax-for ii shortcut (vla-delete ii))
		    (setq cnt 0)
		    (foreach
			   x  ulist
		      (vlax-invoke
			shortcut
			'addmenuitem
			cnt
			(car x)
			(cdr x))
		      (setq cnt (1+ cnt)))))))
 shortcut)



(defun jb:Return40Pop  (cmd / acadobj menugrps menu menus shortcut xreflist)
  (setq	acadobj	 (vlax-get-acad-object)
	menugrps (vla-get-menugroups acadobj)
	menu	 (vl-catch-all-apply 'vla-item (list menugrps "jb00")))
  (if (not (vl-catch-all-error-p menu))
    (progn (setq menus (vla-get-menus menu))
	   (vlax-for
		  i  menus
	     (if (= (vla-get-shortcutmenu i) :vlax-true)
	       (setq shortcut i)))
	   (if shortcut
	     (progn (vlax-for ii shortcut (vla-delete ii))
		    (setq xreflist
			   (jb:ListXrefs)
			  cnt 0)
		    (foreach
			   x  xreflist
		      (vlax-invoke
			shortcut
			'addmenuitem
			cnt
			x
			(strcat cmd (chr 34) x (chr 34) " "))
		      (setq cnt (1+ cnt))))))))

;;;							;
;;;	Return jb00.dat file data			;
;;;							;
;;;	(jb:getjbToolsData)				;
;;;	02.01.2007 added project specific location	;
;;;							;
(defun jb:getjbToolsData  ( / file ofile key note inilst ret)
  (if (not(setq file(findfile(strcat(jb:returnprojectdir)"\\jb00.dat"))))
       (setq file(findfile "jb00.dat")))
  (if file
    (progn
      (setq ofile (open file "r"))
  (while (setq tx (read-line ofile))
    (setq iniLst (append iniLst (list tx)))) ;_ eofwhile
  (close ofile)
  (foreach
	 i  inilst
    (if	(and i (/= i "") (/= (VL-STRING-POSITION (ascii ";") i) 0))
      (progn (setq key	(substr i 1 (vl-string-position (ascii "\t") i))
		   note	(substr i (+ 2 (vl-string-position (ascii "\t") i))))
	     (setq ret (append ret (list (cons key note))))))))
    (princ "\nUnable to locate jb00.dat")
    )
  ret)


;;;	Return Propertyset File
;;;	Use with tag routines!
;;;	(jb:ReturnPropertySetFile)

(defun jb:ReturnPropertySetFile  (/ data ret file)
  (setq data(jb:getjbToolsData))
  (if data
      (foreach x data
        (if (=(car x)"PropertySetFile")
  (setq file (cdr x)))))
  (if file
    (if (not(setq ret(findfile(strcat(jb:returnprojectdir)"\\"file))))
       (setq ret(findfile file))))
   ret)



;;;	Return Active Project AEC Style Standards File
;;;	(jb:ReturnProjectAECStylesStandardsFile)

(defun jb:ReturnProjectAECStylesStandardsFile  (/ data ret file)
  (setq data(jb:getjbToolsData))
  (if data
      (foreach x data
        (if (=(car x)"StandardADTStylesFile")
  (setq file (cdr x)))))
  (if file
    (if (not(setq ret(findfile(strcat(jb:returnprojectdir)"\\"file))))
       (setq ret(findfile file))))
   ret)

;(getvar "users1")
;;; (setq dir nil file nil ofile nil iniLst nil str nil str2 nil str3 nil ret nil)
;;;	Return Active Project Layer Standards File
;;;	Use with Layer Display Routines!!!
;;;(jb:ReturnProjectLayerStandardsFile)
(defun jb:ReturnProjectLayerStandardsFile  (/ data ret)
  (setq data(jb:getjbToolsData))
  (if data
      (foreach x data
        (if (=(car x)"StandardLayerFile")
  (setq file (cdr x)))))
  (if file
    (if (not(setq ret(findfile(strcat(jb:returnprojectdir)"\\"file))))
       (setq ret(findfile file))))
   ret)

;;; Returns the drawing specific Layer Display Definition drawing
;;; If none is saved it defaults to the aec standard layer file.
(defun jb:ReturnLayerStandardsFile  (/ jbDataDwg)
  (setq jbDataDwg (jb:ReturnProjectLayerStandardsFile))
  (if (not jbDataDwg)
    (setq jbDataDwg (jb:GetADTVar 5)))
  jbDataDwg)


;;; Returns the Current Project Directory
(defun jb:ReturnProjectDir( / entry ret)
  (if (not
        (setq entry(vl-registry-read
(strcat "HKEY_CURRENT_USER\\"
		  (vlax-product-key)
		  "\\Recent Project List\\")"Project1")))
        (setq ret(getvar "dwgprefix"))
        (setq ret(vl-filename-directory entry)))
  ret
)
;;;(jb:GetAcadDim)
(defun jb:GetAcadDim (/ xr cod itm reply)
  (setq xr (dictsearch (namedobjdict) "AcadDim"))
  (if (not xr)
    (progn
    (setq cur (append '((0 . "XRECORD") (100 . "AcDbXrecord") (90 . 990106)
	      (3 . "")(40 . 0.0)(60 . 0)(61 . 0)(62 . 1)
      (63 . 1)(64 . 0)(65 . 0)(67 . 2)(68 . 1)
      (69 . 0)(70 . 0)(72 . 0))))
    (setq xr(entget(dictadd (namedobjdict) "AcadDim" (entmakex cur))))))
     
    (if xr
      (progn
      (foreach cod (list 3 40 60 61 62 63 64 65 66 67 68 69 70 71 72 170 340)
	(if (setq itm (assoc cod xr))
	  (setq reply (append reply (list itm)))) reply))
    )
  reply
)
;;;	Set ACADDIM dictionary			;
(defun jb:SetAcadDim (arg / cur prm)
  (setq cur(jb:GetAcadDim))
(while arg
  (setq	prm (car arg)
	arg (cdr arg)
	cur (subst prm (assoc (car prm) cur) cur)))
(dictremove (namedobjdict) "AcadDim")
(setq cur (append '((0 . "XRECORD") (100 . "AcDbXrecord") (90 . 990106)) cur))
(dictadd (namedobjdict) "AcadDim" (entmakex cur))
(jb:GetAcadDim)
  (princ "\nAcadDim updated!")
  (princ)
)


;;; Open a drawing
;;; Requires a full path - checks if file exists
(defun jb:OpenDrawing(name / docs)
  (if(not(member "acvba.arx" (arx)))
         (arxload (findfile "AcVBA.arx")))
  (if (findfile name)
    (if (not (setq docs (member (strcase name) (jb:doclist))))
      (progn
        (command "vbastmt"
           (strcat "AcadApplication.Documents.Open "
                        (chr 34)
                        name
                        (chr 34)))
        (vla-activate (cadr docs)))
      (vla-activate (cadr docs))
      )))



;;;(jb:att:GetAttributes(car(entsel)))
(defun jb:GetAttributes	(ent / lst x)
  (if (safearray-value
	(setq lst (vlax-variant-value
		 (vla-getattributes (vlax-ename->vla-object ent)))))
    (mapcar '(lambda (x)
	       (list (vla-get-tagstring x)
		     (vla-get-textstring x)
		     ))
	    (vlax-safearray->list lst)))
)

;;;
(defun jb:ChangeAttributeValue  (obj tag text / lst)
  (setq lst (vlax-safearray->list (vlax-variant-value (vla-getattributes obj))))
  (foreach
         x  lst
    (if (= tag (vlax-get x 'tagstring))
    (vlax-put x 'textstring text))))





;;; Loads the AecLayerManager.arx for the appropriate release of ADT
;;; (jb:loadAECLayerARX)
;;;
(defun jb:loadAECLayerARX  (/ file)
  (if (and (null AecSetLayerKeyOverride)
           (setq file(vl-directory-files (vla-get-path (vlax-get-acad-object))"AecLMgrLisp*.arx" 1)))
    (arxload (strcat (vla-get-path (vlax-get-acad-object))"\\" (car file)) [])
  (princ "\nUnable to locate the AECLayerLisp ARX!"))
  (princ))
  
 
;;; ObjectDBX functions
;;;
;;;

(if (< (atoi (getvar "AcadVer")) 16)
  (cond ((vl-registry-read "HKEY_CLASSES_ROOT\\ObjectDBX.AxDbDocument\\CLSID"))
        ((not (setq dbxserver (findfile "AxDb15.dll")))
         (alert "Error: Can't locate ObjectDBX Library (AxDb15.dll)"))
        (t
         (startapp "regsvr32.exe" (strcat "/s \"" dbxserver "\""))
         (or (vl-registry-read "HKEY_CLASSES_ROOT\\ObjectDBX.AxDbDocument\\CLSID")
             (alert "Error: Failed to register ObjectDBX ActiveX services.")))))

;;;(setq dwgname(findfile "AecLayerStd.dwg"))
;;; 		Open a dbxDoc						;
;;; 		use (setq dbxDocument(jb:OpenDbxDocument dwgname)) ;
(defun jb:OpenDbxDocument  (DwgName / app doc dbxopen dbxDoc)
  (setq app (vlax-get-acad-object)
        doc (vla-get-ActiveDocument app))
  (if (/= dwgname (vla-get-fullname doc))
    (progn (cond ((= (substr (getvar "ACADVER") 1 5) "15.06")
                  (setq dbxDoc  (vla-GetInterfaceObject app "ObjectDBX.AxDbDocument")
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName))))
                 (t
                  (setq dbxDoc  (vla-GetInterfaceObject
                                  app
                                  (strcat "ObjectDBX.AxDbDocument." (substr (getvar "acadver") 1 2)))
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName)))))
           (if (vl-catch-all-error-p dbxopen)
             (setq dbxDoc nil))))
  dbxDoc)

;;; (vlax-dump-Object dbxDoc t)
;;; Close dbxDoc
;;; (jb:CloseDbxDocument dbxDocument)
(defun jb:CloseDbxDocument  (dbxdoc)
  (if (= (type dbxDoc) 'VLA-OBJECT)
    (progn (vlax-release-object dbxDoc) (setq dbxDoc nil))))


;;;
(defun jb:DwgHasXrefs  (/ xrefyes)
  (setq xrefyes nil)
  (while (setq xrecord (tblnext "block" (not xrecord)))
    (progn (if (cdr (assoc 1 xrecord))
             (setq xrefyes T))))
  xrefyes)


;;;
(defun jb:ListXrefs  (/ xreflist)
  (vlax-for
         x  (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
    (if (= (vlax-get-property x 'isxref) :vlax-true)
      (setq xreflist (append xreflist (list (vlax-get-property x 'name))))))
  xreflist)

;;;(jb:ListBlocks)
(defun jb:ListBlocks  (/ llist)
  (vlax-for
         x  (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
    (if (and(= (vlax-get-property x 'isxref) :vlax-false)
            (= (vlax-get-property x 'islayout) :vlax-false)
            (not(vl-string-search "|"(vla-get-name x)))
            (not(vl-string-search "*"(vla-get-name x)))
            )
      (setq llist (append llist (list (vlax-get-property x 'name))))))
  llist)

;;;(vlax-dump-Object xx)
;;;delete a block
;;;(jb:DeleteBlock "SC_ROOM_FINISH")
(defun jb:DeleteBlock(bname / blocks)
  (setq blocks(vla-get-blocks(vla-get-ActiveDocument(vlax-get-acad-object))))
        
  (vlax-for x blocks
    (vlax-for xx x
    (if (and
            (= (vlax-get-property xx 'ObjectName) "AcDbBlockReference")
            (not(vl-string-search "|"(vla-get-name xx)))
            (not(vl-string-search "*"(vla-get-name xx)))
            )
      (if(= (strcase(vlax-get-property xx 'name))(strcase bname))
        (vla-delete xx)))))
  
  )



;;;
(defun jb:doclist (/ doc docs1)
  (vlax-for doc	(vla-get-documents (vlax-get-acad-object))
    (if (=(vla-get-fullname doc) "")
      (setq docs1 (cons (strcase (vla-get-name doc)) docs1)
	  docs1	(cons doc docs1)
    )
    (setq docs1	(cons (strcase (vla-get-fullname doc)) docs1)
	  docs1	(cons doc docs1)
    ))
  )
  (reverse docs1)
)

;;; Return Active Space Object
;;;(setq view(jb:GetActiveSpace))
(defun jb:GetActiveSpace( / act ret)
  (setq act(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'activespace))
  (cond((= act 1);modelspace
    (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'modelspace)))
       ((= act 0)
        (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'paperspace)))
       (t (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'modelspace))))
  ret)

;;; Return Active Space Object
;;;(setq view(jb:GetActiveSpace))
(defun jb:GetViewport( / act ret)
  (setq act(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'activespace))
  (cond((= act 1);modelspace
    (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'activeviewport)))
       ((= act 0)
        (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'activepviewport)))
       (t (setq ret(vlax-get (vla-get-activedocument(vlax-get-acad-object)) 'activeviewport))))
  ret)


;;;
;;;Check to make sure ObjectDCL is loaded
;;;(setq go(jb:LoadODCL))
(defun jb:LoadODCL( / )
  (if (not
      (member (strcat "jb00." (substr (getvar "acadver") 1 2) ".ARX") (arx)))
  (arxload
    (strcat "jb00." (substr (getvar "acadver") 1 2) ".ARX")
    "Unable to load the correct jb00 ARX")))

;;; Degrees to Radians
(defun jb:D->R (numberOfDegrees)
  (* pi (/ numberOfDegrees 180.0))
)
(defun jb:findblock(blkname / ss)
  (setq ss (ssadd))
  (vlax-for
	 x  (jb:GetActiveSpace)
    (if	(vlax-property-available-p x "EffectiveName")
      (if (= (vla-get-EffectiveName x) blkname)
      (ssadd (vlax-vla-object->ename x) ss))))
  (if ss
    (sssetfirst ss ss)
    (alert "No Block found!"))
  (princ))


(princ)(princ)

;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
