;;;							;
;;;	kbInsert v1.0					;
;;;	include files:					;
;;;							;
;;;							;
;;;							;

(vl-load-com)

(if (not (vl-bb-ref 'kbInsert))
  (vl-bb-set
    'kbInsert
    (dcl_project_import
      '("YWt6A/1MAAC6xar7BuKTJZcRZStuYa2qp0g3o2ikDHd7Vjnf6mJbM1Tw1AsX/6DXPl5aNm1Zc/pI"
"rq46dqp2Oxzf3v56NuLhhvpG/Lovj7tvNnbA3oB/Anz6bjmP2VRc/ufnGZHAScWgk1gIEv2piMDj"
"iZgjTY3lScWF4raA7fuiUcBr+J5Wiry9DnIcfg7EYB532CrGyHWEn1gW//Ou8Jlwxn9wHzBF2o4U"
"XeAF3/mNpE/Jc9FE79V5xE7Bc9EqkwiCDhknFM9jDUg/VYqfx+mVyh81U+Y1U8gc4z2iHGmYCZwr"
"QSALnMdpJRe7wjO257yVK64+86z26awWqf5r/Y1eCR4v3UXPo0bYXYZlvuTx/4tJug0STxS8BC2u"
"uXuDe1KwrQrMwG2b3XgDO1ESeCPWcT7f70J+Be/EfQH9TvzBYJpl+lnOsvS5skAYO+Ed/IBkKJiZ"
"4G38C36UjCdKEJX6ZEBjQd1Q0utQ47pVlU3pmIThdoQtv4HPNTFug+mWkWfWCao/gyMX1tm3azTN"
"Kq5JeFkmqeRDz5wpXs90hlpqwYp+ZZh2yUf+w9quzoJ6CmAmsJraDpRi403Fy6lTweqW2xzMrDhK"
"nyA+ilTpAO2WAyQBOpEJFxSmxDTVMbyjnaxTKgDpLrBQP5EIF2Ch4/zoXMA4sjlth/He9+LPCFBc"
"EYm02rpUdm6HYE47oG9NO4B1aimaMrE9msU+bQd9m+L1tqVUN5oSu+S2ufu2RR3rW4zj3vfC9wyw"
"O5rT22qHxCbOtmk/Su+t9N/1gjxOO8BASEG5vJtvOoA6oOkt8zi0p147oN5R2sUujvkulj0eS/Sb"
"Ec8mUEFqm5F1hH0/wWnMmnFHzS6KvfwAuucrklIXi9ZWATauWTsBwUXNKIpBUEE1k/LWgeXNyFQE"
"09aB+UVgUOHFLwzHGOrBb2NJXdMj0lz0IOTztrnkDOuxkwJa8j9kiW/No6Ou81MIvR8oRMvguo1+"
"JuHFnYcj+ky11+OVu4ZL7q7aC+5CVz681Y/RvPZLru7hrj+NaVJSFiB4c0q1Vrl95LgDZjrbnka4"
"7Fdm07+40yFApo6MaFFif+VU1TqewnNYDgB8bUbCBHt+2WcyntJzJxMGIH91Qq0Ndx3XOPwMQr7P"
"kJiF8WQe3oL+nx64erK0vMnys3bjKCoWNTs8WVJOhXD8361cHB3wy2lOSAB5SpYumUD/JEm01XlL"
"r/XsrX4qLHGk1gmk8v20gVSvdrx8cXDS9JZB51Acno9cr0sBZrdhTBYo/UxwxEFJP826CxYJmSkA"
"V5/Ye+iGQ9yCez9BVRZXr5l6A9HekW2Kg2vFPIM8eIvWfja+kwRlry9j8Zg+wFmED8kDUAErjvlD"
"OQKj0zFp4H6Ta0/A3it5utTNvn9le+ZyXixOQ+v/C2w+92ryv0791nGfzfNjSL8XVZjy+/2XQZgQ"
"XGYJ+PjRZ5EbnicjlcllvFOn5GcenEoFo7rhbBWYU88ebSBTfNlzLvq+dxyYBtFoFQB6baF85PfN"
"lEJYwBJRuEn9Vrk/cgkVeCAyffGV3FP5B5F5rcKl+weBd6sToCPuTRFM7I1XmSgXoDMEdgFutuHx"
"mvNFOqdJ9PAldMGRgk2aN0UjOyDEKXa/sqseRDvBjNv0St7WSeSV+7wRbooL3IFRe1ORL1BpeM6/"
"U+FHL6Lu/JfOBeZQT6D2cS1DbwsmesOy3iXdwpBREpIUVb4IIhcXVX6HB4vsV/tHW4mc+bpyEz+1"
"BfwqtkO+ZRvwj4WzgKZ7L/WClty7jZYcZZWVZrQEVULwrGE/lPYiJdHx3BmBaOvwyY9YcdS7xNOj"
"P+kUu4kH/MamK7L8Q1wkUpCWvKLFmLDJujIJ4NqMqaITS0KQNbpIZcftWr5j0WmPfcFu4LljYOmx"
"W4JbcKCynX8ZnWOOdqD6Yjsm83q/DQNqBmgUjYF4LphRYT6ngjo20NXYZF4EZDL2AHK/bmN6Tdxk"
"f3E65Qpn9mmUZAZnomQGyTry2+bguZ3nU97/6eAPBL/FimDwHXoO9RROKx9aefthmU5GvjZw/Rda"
"wom0SuyNjdyrc9pns5Vm4HGYtBDl6b/6BwXYXWZyNbeKpKk7j6QAuCqNpq9DyH2kSzoHPwVFQXGX"
"dSQTXZez0cPkoLTDrCj7nWJs8O19qn65R36eozQTRLD4wkdoERtT+90KPjQtiPwKN2w4D8h/biNp"
"e9ygqBR+U0k+le3W5GAqsl5BdtR4xkBxWCIZXmbQAx68i2oGnsT4gGMN8rPqHOOTgrby1l3Hg9gD"
"2OpUSz7A9gzCFRNJ8MJ5/YMc08sAk6veIhBWqZurLHNemHOwZPYR8Hv9xmEybo34Fs+YmJkhWwnN"
"aS3wod1WqWtrkS/qAeWBSa7MQFR0yg8jS6t+IqHpAX++M/93Ivgivq2c9P9Wg3mPbLSnkgflEoAj"
"9uD4RhHtaQRdI8+/WiG8Nw638wi1c8Rb9C1UUjub6MSn9Ls1tLSjtmmIiAFdr+Uj5BxLFe1+AmcI"
"ao3NGneGk5ThDLBGvGK+FIuBL/nBM7Id3RYhwJMRacVzEGyCf3CdAE5jeBEuqmJ4qeG5pQBQ8YbI"
"4Qnq/8SL9r9s1kWOPb017aHQBpV5BmmQRMsBFnpewHYelRBEra//wRU/E5g3DlPAW/mtMMGkL2mA"
"g5S10eJR7KfZs1FghxW70ikPh2NIk7yfqlE8panV+owFwVDliU4l7oL7ReRpAf+gw90l3o+yM0D7"
"5YsRgeKHXQN3V9d+2uJ7PLSn4o9hqe7M4hVXVvCFfnuMWypGQNBshC5o4NjZ2Xevgrs31/pAJwCz"
"c8gF8v27F1xDu5qSklK+jqYGROMwGsblpzoYhroqBHQXUhO2GsxnUuP8OuiWJ3J49zAxL7TwGhhi"
"pd8QPtt3VTkNCZY/EuwyAf4asM4asIY2WN83GNLK7FcCQs2tyO03QpPeak1YTqPnNVkqxK0wDMcz"
"Uh3fM+w6eFSjKDYBtCSSxjS5Yao2qkkPPdAsfHP8JlgXH1DipOic3cTUTU6EWrdi0Hy3mpqd++0b"
"VUYnSIk5Sr23zGvi7vWeGlcQaGe/t6gW1JkRTf1b6jLkwe4w1fpABj8sX5d6NxhKCQ5N5txXGk3i"
"sKbnbzAxG+y3r/oTsV7DXU/nQPubRWxZE+Wttze7AQxs42/coOAyqnEZTXcUZS0SywAKRt2EZ7Cq"
"1aqXCOpajS7+GkRGOJeO9y/qGiryfPXCTOfQjL0JUOAnMEYhUuMGBLxFD+uXmkWyMP37hAvmCwDB"
"T4byOo6FSJBj8tZsROxHjTkb4H2ByuIGdo1ihv3xAX+gjQmQ"))))

;;;							;
;;;	Common Files					;
;;;							;

;;;		Set a layer current				;
;;;		If pclayer is T the previous clayer string	;
;;;		is saved in the variable "kb%oldClayer"		;
;;;								;
(defun kb:setclayer  (lname pclayer / layer)
  (if pclayer
    (setq kb%oldClayer (getvar "clayer")))
  (if (tblsearch "layer" lname)
    (setq layer (vla-item
                  (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
                  lname))
    (setq layer (vla-add
                  (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
                  lname)))
  (vla-put-LayerOn layer 1)
  (vlax-put-property layer 'lock :vlax-false)
  (vl-catch-all-apply 'vla-put-Freeze (list layer :vlax-false))
  (vla-put-ActiveLayer
    (vla-get-activedocument (vlax-get-acad-object))
    layer))

;;;		ReSet kb%oldClayer				;
;;;		sets kb%oldClayer to nil			;
(defun kb:resetclayer  (/ layer doc)
  (if (and kb%oldClayer (tblsearch "layer" kb%oldClayer))
    (progn (setq layer (vla-item
                         (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
                         kb%oldClayer))
           (vla-put-LayerOn layer 1)
           (vlax-put-property layer 'lock :vlax-false)
           (vl-catch-all-apply 'vla-put-Freeze (list layer :vlax-false))
           (vla-put-ActiveLayer
             (vla-get-activedocument (vlax-get-acad-object))
             layer)))
  (setq kb%oldClayer nil))


;;;(kb:ListBlocks)
(defun kb:ListBlocks  (/ llist)
  (vlax-for
         x  (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
    (if (and (= (vlax-get-property x 'isxref) :vlax-false)
             (= (vlax-get-property x 'islayout) :vlax-false)
             (not (vl-string-search "|" (vla-get-name x)))
             (not (vl-string-search "*" (vla-get-name x))))
      (setq llist (append llist (list (vlax-get-property x 'name))))))
  llist)

;;; Return Active Space Object
;;;(setq view(kb:GetActiveSpace))
(defun kb:GetActiveSpace  (/ act ret)
  (setq act (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'activespace))
  (cond ((= act 1) ;modelspace
         (setq ret (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'modelspace)))
        ((= act 0)
         (setq ret (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'paperspace)))
        (t
         (setq ret (vlax-get (vla-get-activedocument (vlax-get-acad-object)) 'modelspace))))
  ret)

(defun kb:findblock  (blkname / ss)
  (setq ss (ssadd))
  (vlax-for
         x  (kb:GetActiveSpace)
    (if (vlax-property-available-p x "EffectiveName")
      (if (= (vla-get-EffectiveName x) blkname)
        (ssadd (vlax-vla-object->ename x) ss))))
  (if ss
    (sssetfirst ss ss)
    (alert "No Block found!"))
  (princ))


;;;							;
;;;	Control Subs					;
;;;							;

(defun kb:ReturnBlocksListBoxCurSel( / ret sel)
  (setq sel(dcl_ListBox_GetCurSel Blocks_BlockManager_BlocksListBox))
  (if sel 
(setq ret(dcl_ListBox_GetItemText Blocks_BlockManager_BlocksListBox sel))
    (dcl_messagebox "Select a Block!" "Insert" 2 1))
  ret)

;;;							;
;;;	Insert Block					;
;;;	called from form				;
(defun kb:InsertBlock(flag / blkName XValue OValue)
  (if flag
  (setq blkName(kb:ReturnBlocksListBoxCurSel))
    (setq blkName(getfiled "Select a file" (getvar "dwgprefix") "dwg;dws" 0)))
  (if blkName
    (progn
      (setq
        XValue(dcl_Control_GetValue Blocks_BlockManager_explodeCheckBox)
        OValue(dcl_Control_GetValue Blocks_BlockManager_OriginCheckBox))
      (dcl_Form_Close Blocks_BlockManager)
  (kb:setclayer "0" t)
      (if(= OValue 1)
        (vl-cmdf "_insert" blkName "_scale" 1 "0,0,0" 0)
        (vl-cmdf "_insert" blkName "_scale" 1 pause 0))
      (if (= XValue 1)
        (vla-explode(vlax-ename->vla-object(entlast))))
      (kb:resetClayer)
      )
    )
)

;;;							;
;;;	Form Events					;
;;;							;

(defun c:Blocks_BlockManager_OnInitialize (/ BlockList)
  (dcl_Control_SetText Blocks_BlockManager_SearchTextBox "")
  (dcl_BlockView_Clear Blocks_BlockManager_BlockView)
  (dcl_ListBox_Clear Blocks_BlockManager_BlocksListBox)
  (setq BlockList(kb:ListBlocks))
  (if BlockList(dcl_ListBox_AddList Blocks_BlockManager_BlocksListBox BlockList))
  (if blkName
    (progn
      (dcl_ListBox_SelectString Blocks_BlockManager_BlocksListBox blkName)
      (dcl_BlockView_DisplayBlockToScale Blocks_BlockManager_BlockView blkName)
      (setq blkName nil))
      )
  )

;;;							;
;;;	Control Events					;
;;;							;

(defun c:Blocks_BlockManager_BlocksListBox_OnSelChanged (ItemIndexOrCount Value /)
  (dcl_Control_SetText Blocks_BlockManager_SearchTextBox "")
  (dcl_BlockView_DisplayBlockToScale Blocks_BlockManager_BlockView Value)
)

(defun c:Blocks_BlockManager_InsertButton_OnClicked (/)
  (kb:InsertBlock t)
)
  

(defun c:Blocks_BlockManager_SwapButton_OnClicked (/ blkName)
  (setq blkName(kb:ReturnBlocksListBoxCurSel))
  (if blkName(progn
    (dcl_Form_Close Blocks_BlockManager)
  (kb:swap blkname)))
)

(defun c:Blocks_BlockManager_DwgButton_OnClicked (/)
  (kb:InsertBlock nil)
)

(defun c:Blocks_BlockManager_FindButton_OnClicked (/ blkName)
  (setq blkName(kb:ReturnBlocksListBoxCurSel))
  (if blkName
  (kb:findblock blkname))
)

(defun c:Blocks_BlockManager_WhatButton_OnClicked (/ ss)
  (dcl_Form_Close Blocks_BlockManager)
  (setq ss(ssget ":s" '((0 . "INSERT"))))
  (if ss
    (setq blkName(cdr(assoc 2(entget(ssname ss 0))))))
  (dcl_sendString "kbInsert ")
)

(defun c:Blocks_BlockManager_ImportButton_OnClicked (/)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\Import_ImportManager"
    "CollectionName" "BLOCKS"
    )
  (dcl_Form_Close Blocks_BlockManager)
  (if (dcl_Form_isActive Import_ImportManager)
    (c:Import_ImportManager_OnInitialize)
    (dcl_sendString "kbImportManager ")
    )
)

(defun c:Blocks_BlockManager_SearchTextBox_OnEditChanged (NewValue / sel)
  (dcl_ListBox_SetCurSel Blocks_BlockManager_BlocksListBox
    (dcl_ListBox_FindString Blocks_BlockManager_BlocksListBox
      (dcl_Control_GetText Blocks_BlockManager_SearchTextBox)))

  (setq sel(dcl_ListBox_GetCurSel Blocks_BlockManager_BlocksListBox))
  (if sel 
  (dcl_BlockView_DisplayBlockToScale Blocks_BlockManager_BlockView
    (dcl_ListBox_GetItemText Blocks_BlockManager_BlocksListBox
      sel)))
)


(defun c:Blocks_BlockManager_CloseButton_OnClicked (/)
  (dcl_Form_Close Blocks_BlockManager)
)

;;;							;
;;;		Command Interface			;
;;;							;
;;;pgp: kbInsert,		*kbInsert
(defun c:kbInsert	(/)
  (if (not (member "Blocks" (dcl_GetProjects)))
    (dcl_Project_load "Blocks")
    )
  (if dcl_HideErrorMsgBox
      (dcl_Form_Show Blocks_BlockManager)
	
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;							;
;;;		Insert All Blocks!			;
;;;							;
;;;pgp: kbInsertAllBlocks,		*kbInsertAllBlocks
(defun c:kbInsertAllBlocks (/ doc blocks ins space name)
  (if (= (dcl_MessageBox
	   "Do you really want to Insert all blocks?"
	   "Insert All Blocks"
	   5
	   4
	   )
	 6
	 )
    (progn (setq ins	(vlax-3d-point 0 0)
		 space	(kb:GETACTIVESPACE)
		 doc	(vla-get-ActiveDocument (vlax-get-acad-object))
		 blocks	(vla-get-blocks doc)
		 )
	   (vlax-for
		  x blocks
	     (setq name (vla-get-name x))
	     (if (and (= (vlax-get-property x 'isxref) :vlax-false)
		      (= (vlax-get-property x 'islayout) :vlax-false)
		      (not (vl-string-search "|" name))
		      (not (vl-string-search "*" name))
		      )
	       (vla-InsertBlock space ins name 1.0 1.0 1.0 0.0)
	       )
	     )
	   )
    )
  (princ)
  )


(defun kb:InsertSomeBlocks (wildcard / doc blocks ins space name)
  (setq	ins    (vlax-3d-point 0 0)
	space  (kb:GETACTIVESPACE)
	doc    (vla-get-ActiveDocument (vlax-get-acad-object))
	blocks (vla-get-blocks doc)
	)
  (vlax-for
	 x blocks
    (setq name (vla-get-name x))
    (if	(and (= (vlax-get-property x 'isxref) :vlax-false)
	     (= (vlax-get-property x 'islayout) :vlax-false)
	     (not (vl-string-search "|" name))
	     (not (vl-string-search "*" name))
	     (wcmatch name wildcard)
	     )
      (vla-InsertBlock space ins name 1.0 1.0 1.0 0.0)
      )
    )
  (princ)
  )

;;;							;
;;;		Swap Block 				;
;;;							;
(defun kb:swapblock  (ent newBlockName / new_blk)
  (setq new_blk (subst (cons 2 newBlockName) (assoc 2 ent) ent))
  (entmod new_blk)
  (princ "\nBlock swapped!"))

(defun kb:Swap  (newBlockName / *error* a x SS NUM CNT e blk ANS new_blk)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if newBlockName
    (progn (setq x (tblsearch "block" newBlockName))
           (if x
             (progn (prompt "\nSelect blocks to be swapped: ")
                    (setq SS (ssget '((0 . "INSERT"))))))))
  (if SS
    (progn
      (setq NUM (sslength SS)
            CNT 0)
      (while (< CNT NUM)
        (setq e (ssname SS CNT))
        (cond
          ((= (vlax-property-available-p (vlax-ename->vla-object e) 'IsDynamicBlock)
              :vlax-false)
           (if (= (vlax-get (vlax-ename->vla-object e) 'IsDynamicBlock) :vlax-false)
             (kb:swapblock (entget e) newBlockName)))
          (t (kb:swapblock (entget e) newBlockName)))
        (setq CNT (1+ CNT)))
      (princ "  Done... "))
    (princ "  Nothing selected. "))
  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (princ))

;;;pgp: kbSwap,		*kbSwap
(defun c:kbSwap	(/ newBlockName blockent newName ss num cnt ent entList obj newblk)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (setq newBlockName (entsel "\nSelect Block to Clone:"))
  (if (and newBlockName (= (cdr (assoc 0 (entget(car newBlockName)))) "INSERT"))
    (progn (setq blockent (car newBlockName)
		 newName  (cdr (assoc 2 (entget blockent)))
		 )
	   (prompt "\nSelect blocks to be swapped: ")
	   (setq ss (ssget '((0 . "INSERT"))))
	   (if ss
	     (progn (setq num (sslength ss)
			  cnt 0
			  )
		    (while (< cnt num)
		      (setq ent (ssname ss cnt)
			    entList(entget ent)
			    obj(vlax-ename->vla-object ent))
		      (setq newblk (subst (cons 2 newName) (assoc 2 entList) entList))
		      (entmod newblk)
		      (if (=(vla-get-HasAttributes obj):vlax-true)
			(command "attsync" "select" ent "yes")
			)
		      (princ "\nBlock swapped!")
		      (setq cnt (1+ cnt))
		      )
		    )
	     )
	   )
    (dcl_messagebox (strcat "That is not a block insert!"
		      (strcat "\nIt's a "(cdr (assoc 0 (entget(car newBlockName)
							      )
						     )
					      )"   "
			)
		      )
      "Swap Block" 2 1
      )
    )
  (princ)
  (princ)
  )

;;;							;
;;;		WClip	 				;
;;;							;

;;;pgp: kbWclip,		*kbWclip
(defun c:kbwclip( / insPoint)
  (if (not (setq insPoint(getpoint (strcat "\nSelect insert point or <enter> for origin"))))
	   (setq insPoint "0,0,0"))
  (command "_copybase" insPoint pause)
  (princ))

;;;pgp: kbWclipInsert,		*kbWclipInsert
(defun c:kbWclipInsert( / insPoint)
  (if (not (setq insPoint(getpoint (strcat "\nSelect insert point or <enter> for origin"))))
	   (setq insPoint (list 0.0 0.0 0.0)))
  (command "_pasteclip" insPoint)
  (princ))
    
	
  
;;;							;
;;;	XREF UTILITIES					;
;;;							;
;;;pgp: kbReloadAll,		*kbReloadAll
(defun c:kbReloadAll (/ *Error*)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (if (kb:DwgHasXrefs)
    (progn (vl-cmdf "_.-xref" "_reload" "*")
	   (prompt "\nAll External references have been reloaded.")
	   )
    (alert "There are no External References to Reload!   ")
    )
  (princ)
  )
;;;pgp: kbUnloadAll,		*kbUnloadAll
(defun c:kbUnloadAll (/ xrefyes *Error*)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (if (kb:DwgHasXrefs)
    (progn (vl-cmdf "_.-xref" "_Unload" "*")
	   (prompt "\nAll External references have been reloaded.")
	   )
    (alert "There are no External References to Unload!   ")
    )
  (princ)
  )

;;;pgp: kbDetachAll,		*kbDetachAll
(defun c:kbDetachAll (/ xrefyes *Error*)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (if (kb:DwgHasXrefs)
    (if	(= (dcl_MessageBox
	     "Do you really want to detach ALL Xrefs?"
	     "Detach Xrefs"
	     5
	     4
	     )
	   6
	   )
      (progn (vl-cmdf "_.-xref" "_detach" "*")
	     (prompt "\nAll External references have been detached.")
	     )
      )
    (alert "There are no External References to Detach!   ")
    )
  (princ)
  )


;;;pgp: kbCountBlock,		*kbCountBlock
(defun c:kbCountBlock (/ *Error* a blk_name ss ss1 cnt num)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (princ)
    )
  (setq	a (entsel
	    "\nSelect block to count: <you must re-select to add to selection!>"
	    )
	)
  (if a
    (progn (cond ((= (cdr (assoc 0 (entget (car a)))) "AEC_MVBLOCK_REF")
		  (setq	ss	 (ssadd)
			blk_name (vla-get-stylename (vlax-ename->vla-object (car a)))
			ss1	 (ssget (list (cons 0 "AEC_MVBLOCK_REF")))
			num	 (sslength ss1)
			cnt	 0
			)
		  (while (< cnt num)
		    (if	(= (vla-get-stylename (vlax-ename->vla-object (ssname ss1 cnt)))
			   blk_name
			   )
		      (setq ss (ssadd (ssname ss1 cnt) ss))
		      )
		    (setq cnt (1+ cnt))
		    )
		  )
		 ((= (cdr (assoc 0 (entget (car a)))) "INSERT")
		  (setq	blk_name (cdr (assoc 2 (entget (car a))))
			ss	 (ssget (list (cons 0 "INSERT") (cons 2 blk_name)))
			)
		  )
		 (t (setq ss nil) (alert "Not a Block or Multiview Block!"))
		 )
	   (if ss
	     (progn (alert (strcat "There are "
				   (itoa (sslength ss))
				   " instances of block "
				   blk_name
				   " in your selection."
				   )
			   )
		    (princ (sslength ss))
		    )
	     )
	   )
    )
  (princ)
  )

