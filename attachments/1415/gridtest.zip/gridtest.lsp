(defun c:test (/
				c:gridtest_Form1_TextButton1_OnClicked
				)

	(defun c:gridtest_Form1_TextButton1_OnClicked (/)
		(alert (strcat 
			"Grid Row 0, Column 1 value is '"
			(dcl_Grid_GetCellText gridtest_Form1_Grid1 0 1)
			"'"
		)) ; strcat alert
	) ; onclicked

	(defun c:gridtest_Form1_OnInitialize (/)
		(while (> (dcl_Grid_GetRowCount gridtest_form1_Grid1) 0)
			(dcl_Grid_DeleteRow gridtest_form1_Grid1 0)
		) ; while
		(while (> (dcl_Grid_GetColumnCount gridtest_form1_Grid1) 0)
			(dcl_Grid_DeleteColumn gridtest_form1_Grid1 0)
		) ; while
		 ; add a default row
		(dcl_grid_addrow gridtest_form1_Grid1 "")
		 ; now pad columns
		 ; first our dummy read-only column
		(dcl_grid_addcolumns gridtest_form1_Grid1 (list
			(list "" 0 0)
		)) ; list addcolumns
		(dcl_grid_addcolumns gridtest_form1_Grid1 (list
			(list "Col1" 0 100) ; adding the title for the column
		)) ; list addcolumns
		(dcl_Grid_SetCellStyle gridtest_form1_Grid1 0 1 36) ; set to combobox
	) ; oninitialize


(command "_.OPENDCL")
(dcl_Project_Load "gridtest" t)
(dcl_Form_Show gridtest_form1)

(princ)
) ; test
