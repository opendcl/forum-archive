;;; Roll Down / Roll Up
(defun c:PanGroups_Panel1_Roll_OnClicked (/) (@:Set_FormState "PanGroups" "Panel1" "Roll"))
;;; Move Panel Group
(defun c:PanGroups_Panel1_OnMouseMovedOff (/) (@:Move_PanGroup "PanGroups" "Panel1"))
;;; Corner Magnets
(defun c:PanGroups_Panel1_BLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel1" "BLMag"))
(defun c:PanGroups_Panel1_BRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel1" "BRMag"))
(defun c:PanGroups_Panel1_TLMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel1" "TLMag"))
(defun c:PanGroups_Panel1_TRMag_OnDragnDropFromControl (ProjectName FormName ControlName DropPoint /)
  (@:Magnetize ProjectName FormName ControlName "Panel1" "TRMag"))
;;; Test Button
(defun c:PanGroups_Panel1_TextButton1_OnClicked (/) (command "text"))