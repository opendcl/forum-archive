;;;							;
;;;	Backup Tools	v2.0 				;
;;;	Utility Functions				;
;;;							;
;;;		include files:				;
;;;							;

(vl-load-com)

(if (not (vl-bb-ref 'kbdbak))
  (vl-bb-set
    'kbdbak
    (dcl_project_import
      '("YWt6A8UiAACFkpA7BuKTJ7MRKitqgXPjyOkwH4Zu/cYX2nR3F9qy2jvFVfi6rM9TI/Zh2qxMLc4d"
"NdrI82VZT/gvaJS4utZ1SxY6qpx5bElmKcRPgn9SNg4/KtRVaShnsUeRs6KJsDIZhNhTHk2Zi8OF"
"AImiBZDHieChB5Ez3cflR8YZPUnwHnodBn9ZbnwOx29O0hrfzMt9BdY3bDnP6fBmpE7yRusCadmE"
"WkSWkF8UrTAZZavJrc95V9TxL2fdxWojG77iHQ9Jy/EvlcYWpNYD4hTsHE87pAjP5tzv+NtQUF0I"
"LDNZi2TYlXajSVy8OKeVWIiIEOZuqL5rLPttqoRGuB8AutgCw6W+YjpGIbtosjUs9iJZQbNY9THP"
"gCX124FJdCEuk8HIhnPETYHWjzDvgQcpB8KTQKmpBYnbe0LvD0Q5F+/g+Ye3qWgY2WSVIUqa+WyD"
"xXQxV4J9lEPQvyIvhBdhoEj8+Z+LEXaH+2A8YSNh241GWJdC/EojIVrRs8LMR525zOuJbiS5K0WL"
"KEiIrcLt5lwVNzK9SlUVlWqAPJ+xaoAinw1rKJoP20HTjq10oVYGkZ7l+6Nxt5CxJ1KIAVE6/f0l"
"K4FBdEWSljV6imTmAutJ5gGbnnRp2F2zM+GrERhCFf0thOEpv6TazvliWWbB24ol0gDoD8G7KWdx"
"JqK7hklrroklQ2VI8SeCTJ19aLUGw3RZakcFaqh6pN+CiW6UcuNs4qIdQ6lCLmriMvhPiq0LbLn8"
"ErALy0fckS3tFy6weKPSDyGBmHp4V91y7N03HBnkkGHflVayCQiiZVR9jMKzUJuZaMvW4DPoUpqn"
"GljICS0ZnqGqVoLlVIgEazDWC5cvRr7YMM0BRPlSCbA2VfDxV4Lim4ohwqBtNIHSvNk1GrLOxQYG"
"LnkbGmGTlHowrFAJLejg2h0c/zmffL+HWUXbTftBZpWTXslSUpUrZgS8ilDqsTv5PIBOo7WEyZP9"
"JpKj1Y7+dM1Mx5Rnhr0EebT5C9sia0rSRS9qqKW1Q9I1+faNbqFZ8RCQu5EAgUkM0op9JrYpOUll"
"ZpOsmhWI0AZuhAeWiGr0lmhgWs0tVTfI2+xXfifIvDHod1LzUvxvjIXFSozK6F2xPCUi3TF+hBIa"
"Kjrh2EAkrVrTHOuq7y4sqrflInOq14owUo3Ew6rH0YI5HI+IqBbNNqQS3WVfvAAzZc3hqFAzVak1"
"mzckqX5RBQFRmE2PXWt869aKtEwvlVVLsOl0lbGvcatVnGergNLclNloyU6g8st7wQw7OoAGHxz1"
"C4NjisCL+C3ghzoHnV+AUfJNNIH/5LNMAFL1w0yhK9xx7nawT0DSNp8xclObbP1wnuw3n5x0gYhN"
"CvXtts5kUdXOgJOXq3TBO8PYjkV0Qd+O7cmJyVIgIjA3OdscU7x50TugAoOZ85EjvSdixkbu4HpE"
"9kajd8DMCv4BXwqgw0k20dPwvKsFm4WrViMjI/9kRWzWj5zFqpowaBgozLjS5BbX/Jcr2vsr4j3m"
"J9dkzeghBDr0kVUIJxqdPujVziH7gUuPdE0VynLNmL6y5A2nTJsfKCoER9HdTbu6DFtdAbYa4vxx"
"0Nx1czBLR4fdMUHZnl1Zgds5qE8eTE/EGJU06Z4sursqkLDsqitWn+i4GqIPzNCO9GLFTSm668LB"
"ngetUlwLzH6nltItb+cJVNzpGNsXGuD6pDlR7y5n5wmEGZ7S+h1LXdvfa28qZlPlg3EdgZVt")
      )
    )
  )

;;;pgp: kbbak,		*kbbak
(defun c:kbbak (/ file dirs dir)
  (setq dirs (vl-directory-files (getvar "dwgprefix") nil -1))
  (if (not (or (member "BAK" dirs) (member "bak" dirs) (member "Bak" dirs)))
    (setq dir (vl-mkdir (strcat (getvar "dwgprefix") "BAK")))
    (setq dir t)
    )
  (if dir
    (progn
      (setq file (strcat
		   (getvar "dwgprefix")
		   "BAK\\"
		   (vl-filename-base (getvar "dwgname"))
		   "-"
		   (menucmd "M=$(edtime,$(getvar,date),YYYY.MO.DD.HH.MM.SS)")
		   ".dwg"
		   )
	    )
      (while (findfile file)
	(setq file (strcat
		     (getvar "dwgprefix")
		     "BAK\\"
		     (vl-filename-base (getvar "dwgname"))
		     "-"
		     (menucmd "M=$(edtime,$(getvar,date),YYYY.MO.DD.HH.MM.SS)")
		     ".dwg"
		     )
	      )
	)
      (if file
	
	  (command "save" file)
	  
	  	)
      )
    )
  (princ file)
  (princ)
  file
  )



(defun c:Backup_Main_OnInitialize	(/ dir dwgFiles filesizeStr systimeStr col0 col1 col2 col3)
  (setq dir (strcat (getvar "dwgprefix") "BAK\\")
	col0(vl-registry-read
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\Backup_Main" 
 "col0")
	col1(vl-registry-read
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\Backup_Main" 
 "col1")
	col2(vl-registry-read
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\Backup_Main" 
 "col2")
	)
  (if (= (dcl_ListView_GetColumnCount Backup_Main_FileList) 4)
    (dcl_ListView_DeleteColumns Backup_Main_FileList (list 0 1 2 3)))
  (dcl_ListView_AddColumns
    Backup_Main_FileList
    (list (list "Name" 1 200)
	  (list "Size" 1 80)
	  (list "Date Modified" 1 80)
	  ))
  (setq dwgFiles (vl-directory-files dir "*.dwg" 1))

      (if dwgFiles
	(progn
	  (foreach
		 x
		  dwgfiles
	    (setq filesizeStr (strcat (itoa (/ (vl-file-size (strcat dir "\\" x)) 1000)) " KB")
		  systimeStr  (kb:ReturnFileTime (strcat dir "\\" x))
		  )
	    (if	(and filesizeStr systimeStr)
	      (dcl_ListView_AddItem Backup_Main_FileList (list x filesizeStr systimeStr))
	      )
	    )
	  )
	)
  (if col0(dcl_ListView_SetColWidth Backup_Main_FileList 0 col0))
  (if col1(dcl_ListView_SetColWidth Backup_Main_FileList 1 col1))
  (if col2(dcl_ListView_SetColWidth Backup_Main_FileList 2 col2))
  
  (princ)(princ))


(defun c:Backup_Main_FileList_OnClicked (nRow nCol / path Value)
  (setq path (strcat (getvar "dwgprefix") "BAK\\")
   Value (dcl_ListView_GetItemText Backup_Main_FileList 
	(dcl_ListView_GetCurSel Backup_Main_FileList)
		)
	)
  (dcl_DwgPreview_LoadDwg Backup_Main_Preview (strcat path Value))
  (dcl_Control_SetEnabled Backup_Main_openBackup t)
  
)



(defun c:Backup_Main_BackupButton_OnClicked (/ file filesizeStr systimeStr)
  (setq file(c:kbbak))
  (if file
    (progn
      (setq filesizeStr (strcat (itoa (/ (vl-file-size file) 1000)) " KB")
		  systimeStr  (kb:ReturnFileTime file)
		  )
	    (if	(and filesizeStr systimeStr)
	      (dcl_ListView_AddItem Backup_Main_FileList
		(list (strcat(vl-filename-base file)".dwg") filesizeStr systimeStr))
	      )
      )
    )
  (princ)
  (princ)
  )


(defun c:Backup_Main_OpenButton_OnClicked (/ rValue)
  (setq rValue (dcl_ListView_GetItemText Backup_Main_FileList 
	(dcl_ListView_GetCurSel Backup_Main_FileList)
		)
	)
  (if rValue(progn
	      (dcl_form_close Backup_Main)
    (kb:OpenDrawing (strcat (getvar "dwgprefix") "BAK\\" rValue))
	      )
    )
  (princ)
  (princ)
  )



;;;								;
;;;								;
(defun c:Backup_Main_CloseButton_OnClicked ( / col0 col1 col2 col3)
  (Setq col0 (dcl_ListView_GetColWidth Backup_Main_FileList 0)
	col1(dcl_ListView_GetColWidth Backup_Main_FileList 1)
	col2(dcl_ListView_GetColWidth Backup_Main_FileList 2)
	col3(dcl_ListView_GetColWidth Backup_Main_FileList 3))
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\Backup_Main"
 "col0"
 col0
  )
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\Backup_Main"
 "col1"
 col1
  )
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\Backup_Main"
 "col2"
 col2
  )
  (vl-registry-write
 "HKEY_CURRENT_USER\\Software\\kbTools2009\\Backup_Main"
 "col3"
 col3
  )(dcl_form_close Backup_Main)
 (princ)
  (princ)
  )





;;;							;
;;;		Command Interface			;
;;;							;
;;;pgp: kbdbak,		*kbdbak
(defun c:kbdbak	(/)
  (if (not (member "Backup" (dcl_GetProjects)))
    (dcl_Project_load "Backup")
    )
  (if dcl_HideErrorMsgBox
      (dcl_Form_Show Backup_Main)
	
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

(princ "\nBackup Tools loaded!")
(princ)

 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 0 T T nil T)
;*** DO NOT add text below the comment! ***|;
