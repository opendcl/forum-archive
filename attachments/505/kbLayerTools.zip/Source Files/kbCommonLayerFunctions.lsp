;;;								;
;;;		Common Layer Functions				;
;;;		Layers, Layer States, Layer Filters		;
;;;								;
;;;								;

;|
(foreach i (kb:ListBlocks)
  (kb:BlockLayerZero i)
  (princ(strcat i " has been changed!"))
  )
|;  

(defun kb:BlockLayerZero(nameStr / )
  (if (tblsearch "block" nameStr)
    (progn
(vlax-for x (vla-item (vla-get-blocks (vla-get-activedocument(vlax-get-acad-object))) nameStr)
  (vlax-put-property x 'layer "0")
  (vlax-put-property x 'color acByLayer)
  (princ "\nLayer changed!")
  ))
    (alert (strcat "\n" NameStr " not found!")))
  (princ))

;;; only sets the layerkey - local routine
;;; must deal with re-setting the previous layer
;;;(SETQ LKEY "ANNOBJ")
(defun kb:SetLayerKey  (lkey / lname)
  (if (not AecSetLayerKeyOverride)
    (kb:loadAECLayerARX))
  (if AecSetLayerKeyOverride
  (if (member lkey (aeclayerkeylist))
    (setq lname (AecGenerateLayerKey lkey))
    (setq lname (getvar "clayer")))
    (setq lname (getvar "clayer")))
  lname)



(defun kb:getlayers(filter / llist)
  (vlax-for x (vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))
    (if (vl-string-search filter (vla-get-name x) 0)
      (setq llist(append llist(list(vla-get-name x))))))
  (if llist(ACAD_STRLSORT llist))
  llist)

;;;		Set a layer current				;
;;;		If pclayer is T the previous clayer string	;
;;;		is saved in the variable "kb%oldClayer"		;
;;;								;
(defun kb:setclayer  (lname pclayer / layer)
  (if pclayer(setq kb%oldClayer(getvar "clayer")))
  (if (tblsearch "layer" lname)
    (setq layer(vla-item(vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))lname))
    (setq layer(vla-add(vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))lname)))
  (vla-put-LayerOn layer 1)
  (vlax-put-property layer 'lock :vlax-false)
  (vl-catch-all-apply 'vla-put-Freeze (list layer :vlax-false))
  (vla-put-ActiveLayer (vla-get-activedocument(vlax-get-acad-object)) layer))

;;;		ReSet kb%oldClayer				;
;;;		sets kb%oldClayer to nil			;
(defun kb:resetclayer  ( / layer doc)
  (if (and kb%oldClayer
  (tblsearch "layer" kb%oldClayer))
    (progn (setq layer (vla-item (vla-get-layers (vla-get-activedocument(vlax-get-acad-object))) kb%oldClayer))
           (vla-put-LayerOn layer 1)
           (vlax-put-property layer 'lock :vlax-false)
           (vl-catch-all-apply 'vla-put-Freeze (list layer :vlax-false))
           (vla-put-ActiveLayer (vla-get-activedocument(vlax-get-acad-object)) layer)))
  (setq kb%oldClayer nil)
  )
;;; Get the layer state object
;;; (setq layobj(kb:GetLayerObject))
;;; should be released after use!!
;;; (vlax-release-object ret)
(defun kb:GetLayerObject  (/ file ret)
  (cond
             ((= (substr (getvar "ACADVER") 1 5) "15.06")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager")))
             ((= (substr (getvar "ACADVER") 1 4) "16.0")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.16")))
             ((= (substr (getvar "ACADVER") 1 4) "16.1")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.16")))
    ((= (substr (getvar "ACADVER") 1 4) "16.2")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.16")))
    ((= (substr (getvar "ACADVER") 1 4) "17.0")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.17")))
    ((= (substr (getvar "ACADVER") 1 4) "17.1")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.17")))
    ((= (substr (getvar "ACADVER") 1 4) "17.2")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.17")))
    )
  
  ret)

(defun kb:DeleteLayerFilters  (/ extdict doc)
  (setq doc     (vla-get-activedocument (vlax-get-acad-object))
        extdict (vla-GetExtensionDictionary (vla-get-layers doc)))
  (vlax-for x (vla-item extdict "ACAD_LAYERFILTERS") (vla-delete x))
  (vlax-release-object extdict)
  (princ)
  (princ))


(defun kb:DeleteAllLayerStates  (/ extdict doc)
  (setq doc     (vla-get-activedocument (vlax-get-acad-object))
        extdict (vla-GetExtensionDictionary (vla-get-layers doc)))
  (vlax-for x (vla-item extdict "ACAD_LAYERSTATES") (vla-delete x))
  (vlax-release-object extdict)
  (princ))


;;; Make a layer
;;;use (kb:makelayer "Test" 7 "Hidden" 30  "black" -1)
(defun kb:makelayer  (lname color linetype lineweight plotstylename plottable / layers pstyle layer)
  (setq layers(vla-get-layers (vla-get-activedocument(vlax-get-acad-object))))
  (if (not (tblsearch "layer" lname))
    (setq layer (vla-add layers lname))
    (setq layer (vla-item layers lname)))
  (if layer
    (progn (vlax-put layer "color" color)
           (vlax-put layer "linetype" linetype)
           (vlax-put layer "lineweight" lineweight)
           (vlax-put layer "plotstylename" plotstylename)
           (vlax-put layer "plottable" plottable)))
  layer)


;(c:kbCreateAllLayerKeys)
(defun c:kbCreateAllLayerKeys ( / )
   (if aeclayerkeylist
   (mapcar 'aecgeneratelayerkey(aeclayerkeylist)))
 )



