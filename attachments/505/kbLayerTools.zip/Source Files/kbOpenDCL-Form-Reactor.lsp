;;;								;
;;;		kbTools OpenDCL Forms Reactor			;
;;;								;

;;;								;
;;;		Command Reactors				;
;;;								;

;;;		Support Functions				;
;;;		Only used by Routines in this File		;

;;;		Call-back Functions				;

;;;		Command Ended					;
(defun kb:OpenDCLCommandEnded (calling-reactor commands /)
  (cond	
	((member (car commands) (list "XREF" "XATTACH" "-XREF"))
	 (if dcl_HideErrorMsgBox
	   (progn
	   (if (dcl_Form_IsActive kb001_00)
	     (c:kb001_00_Refresh_OnClicked)
	     )
	   (if (dcl_Form_IsActive kb001_02)
	     (c:kb001_02_Refresh_OnClicked)
	     )
	   )
	 ))
	)
  (princ)
  )

;;;		Command Cancelled					;
(defun kb:OpenDCLCommandCancelled (calling-reactor commands /) (princ))


;;;		Construct the Command Reactor				;
(defun kb::ConstructOpenDCLCommandReactor (/)
  (if (= (type *kbOpenDCLCommandReactor*) 'VLR-Command-Reactor)
    (progn (vlr-remove *kbOpenDCLCommandReactor*)
	   (setq *kbOpenDCLCommandReactor* nil)
	   )
    )
  (if (/= (type *kbOpenDCLCommandReactor*) 'VLR-Command-Reactor)
    (setq *kbOpenDCLCommandReactor*
	   (VLR-Command-Reactor
	     "kbTools OpenDCL Forms Reactor" ; Data associated with the editor reactor
	     ;; call backs
	     '
	      ((:VLR-commandEnded . kb:OpenDCLCommandEnded)
	       (:VLR-commandCancelled . kb:OpenDCLCommandCancelled)
	       )
	     ) ;_ end of vlr-editor-reactor
	  )
    )
  (if (not (vlr-added-p *kbOpenDCLCommandReactor*))
    (progn (vlr-add *kbOpenDCLCommandReactor*)
	   (vlr-set-notification *kbOpenDCLCommandReactor* 'active-document-only)
	   )
    ) ;added 09.26.2003
  (princ)
  )

;;; Loaded in kb-48-01b.fas



;;;				load reactors				;


(if kb::ConstructOpenDCLCommandReactor
  (kb::ConstructOpenDCLCommandReactor)
  )


(defun c:kbRemoveOpenDCLReactor	()
  (progn (vlr-remove *kbOpenDCLCommandReactor*)
	 (setq *kbOpenDCLCommandReactor* nil)
	 )
  (prompt "OpenDCL Reactor removed!")
  (princ)
  )

;;;			End Attach					;
(defun kb:endAttach  (reactor vla-object /)
  ;(alert "Yes")
  (if dcl_HideErrorMsgBox
    (progn
	   (if (dcl_Form_IsActive kb001_00)
	     (c:kb001_00_Refresh_OnClicked)
	     )
	   (if (dcl_Form_IsActive kb001_02)
	     (c:kb001_02_Refresh_OnClicked)
	     )
	   )
    )
    (princ)
  )

;;;			Construct Xref Reactor				;
(defun kb::ConstructXrefReactor  (/)
  (if (= (type *kbXrefReactor*) 'VLR-Xref-Reactor)
    (progn (vlr-remove *kbXrefReactor*)
	   (setq *kbXrefReactor* nil)))
  (if (/= (type *kbXrefReactor*) 'VLR-Xref-Reactor)
    (setq *kbXrefReactor*
	   (VLR-Xref-Reactor
	     "kbTools Xref Reactor" ; Data associated with the editor reactor
	     ;; call backs
	     '((:VLR-xrefSubcommandDetachItem . kb:endAttach)
	      (:VLR-endAttach . kb:endAttach)
               )) ;_ end of vlr-xref-reactor
	  ))
  (if (not (vlr-added-p *kbXrefReactor*))
    (progn (vlr-add *kbXrefReactor*)
	   (vlr-set-notification *kbXrefReactor* 'active-document-only)))
  (princ))


;;;				load reactor				;


(if kb::ConstructXrefReactor
  (kb::ConstructXrefReactor))

 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
