;;;						;
;;;	Keynotes Dialog Control			;
;;;						;

;;;						;
;;;	Form 01	- Keynote Info			;
;;;						;
(defun c:jb002_01_SELECT_OnClicked ( /)
  (setq ent(entsel))
  (if ent
    (progn
      (setq xdata(jb:getKeyNotexdata (car ent))
	    key(nth 0 xdata)
	    note(nth 1 xdata)
	    objtype(nth 2 xdata))
      (if (and key note objtype)
	(progn
      (dcl_Control_SetCaption jb002_01_Key key)
      (dcl_Control_SetCaption jb002_01_Note note)
      (dcl_Control_SetCaption jb002_01_ObjectType objtype)
      )
	(dcl_MessageBox "That is not a Keynote!" "Select Keynote")
	)
      )
    )
      
)
(defun c:jb002_01_CLOSE_OnClicked ( /)
     (dcl_Form_Close jb002_01)
  (princ)
)

(defun c:jb002_01_OnDocActivated ( /)
     (c:jb002_01_OnInitialize)
)
(defun c:jb002_01_OnEnteringNoDocState ( /)
     (dcl_Form_Close jb002_01)
  (princ)
)
(defun c:jb002_01_OnInitialize ( /)
     (dcl_Control_SetCaption jb002_01_Key "")
      (dcl_Control_SetCaption jb002_01_Note "")
      (dcl_Control_SetCaption jb002_01_ObjectType "")
      
)
(defun c:jbKeyInfo( / )
  (c:jb002_00_XDATA_OnClicked)
  (princ))


;;;						;
;;;	Form 00	- MainKeynote Form		;
;;;						;

;(setq data nil)
(defun c:jb002_00_OnInitialize  (/ file data)
  (dcl_Control_Setcaption jb002_00_PREVIEW "")
  ;;; Project specific keynote file
  (setq file(jb:ReturnKeynoteFilename))
  (if file
    (setq data (jb:getKeynoteFileData file)))
  (if data
    (progn (dcl_ListBox_Clear jb002_00_DIV)
           (dcl_ListBox_AddList jb002_00_DIV (car data))
           (dcl_ListBox_Clear jb002_00_KEYLIST)
           (dcl_ListBox_AddList jb002_00_KEYLIST (cadr data)))
    (progn (dcl_ListBox_Clear jb002_00_KEYLIST)
           (dcl_ListBox_Clear jb002_00_DIV)))
  
(princ)(princ)
  )


(defun c:jb002_00_XDATA_OnClicked ( /)
     (if (not(dcl_Form_isactive jb002_01))(dcl_Form_show jb002_01))
  (princ)
)



(defun c:jb002_00_LEADER_OnClicked (nValue /)
     (if (= nValue 1)(dcl_Control_SetValue jb002_00_NOTE 0))
(princ)(princ)
  )


(defun c:jb002_00_NOTE_OnClicked  (nValue /)
  (if (= nValue 1)(dcl_Control_SetValue jb002_00_LEADER 0))
(princ)(princ)
  )



(defun c:jb002_00_DIV_OnSelChanged  (nSelection sSelText / div data keys)
  (setq div  (substr sSelText 1 2)
        data (jb:getKeynoteFileData (findfile(strcat(jb:returnprojectdir)"\\kb.key"))))
  (if data
    (progn
      (if (= div "00")
        (progn (dcl_ListBox_Clear jb002_00_KEYLIST)
                    (dcl_ListBox_AddList jb002_00_KEYLIST (cadr data)))
    (progn
      (foreach
                  i  (cadr data)
             (if (/= i "")
               (if ;(vl-string-search (strcat div ".") i 0)
                 (=(substr i 1 2)div)
                 (setq keys (append keys (list i))))))
           (if keys
             (progn (dcl_ListBox_Clear jb002_00_KEYLIST)
                    (dcl_ListBox_AddList jb002_00_KEYLIST keys)))))))
(princ)(princ)
  )
(defun c:jb002_00_KEYLIST_OnSelChanged  (nSelection sSelText /)
  (dcl_Control_Setcaption jb002_00_PREVIEW sSelText)
  (princ)(princ)
  )


(defun c:jb002_00_MAKE_OnClicked  (/)
  (dcl_SetCmdBarFocus)
  (jb:SyncKeynoteFiletoDrawing)
  (jb:MakeKeynoteChart)
(princ)(princ)
  )

(defun c:jb002_00_UPCHART_OnClicked  (/ chart)
  (dcl_SetCmdBarFocus)
  (jb:SyncKeynoteFiletoDrawing)
  (setq chart (car(entsel "\nSelect KeyChart: ")))
  (if chart
  (jb:kn:UpdateChart chart))
  (princ)(princ))


(defun c:jb002_00_EDIT_OnClicked  (/ file)
  (setq file(jb:ReturnKeynoteFilename))
  (if file
    (command "shell" (strcat "notepad.exe " file)))
  (princ)(princ))


(defun c:jb002_00_SYNC_OnClicked  (/)
  (if (wcmatch(strcase(getvar "dwgprefix"))(strcase(strcat(jb:returnprojectdir)"*")))
    (progn (c:jb002_00_OnInitialize)
           (jb:SyncKeynoteFiletoDrawing)
           )
    (dcl_messagebox
      "This drawing is not a member of the active project!"
      "Synch Key Dawing"
      2
      1))
  (princ)(princ)

  )
   

(defun c:jbUPKEY (/ text key note)
  (setq	text (dcl_ListBox_GetText
	       jb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel jb002_00_KEYLIST)
	     )
  )
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(substr text 1 (vl-string-position (ascii "\t") text))
		   note	(substr text (+ 2 (vl-string-position (ascii "\t") text)))
	     )
	     (dcl_SetCmdBarFocus)
	     (if (setq ent (entsel))
	       (progn
		 (if (jb:getKeyNotexdata (car ent))

		   (jb:ChangeKeynote ent key note nil)

		   (alert "That is not a Keynote object!")
		 )
	       )
	     )
      )
    )
  )
  (princ)
  (princ)
)

(defun c:jb002_00_UPKEY_OnClicked  (/ )
(vla-sendcommand(vla-get-activedocument(vlax-get-acad-object))"jbUPKEY ")
  (princ)(princ))


(defun c:jbUPALLKEY (/ text key note)
  (setq	text (dcl_ListBox_GetText
	       jb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel jb002_00_KEYLIST)
	     )
  )
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(substr text 1 (vl-string-position (ascii "\t") text))
		   note	(substr text (+ 2 (vl-string-position (ascii "\t") text)))
	     )
	     (dcl_SetCmdBarFocus)
	     (if (setq ent (entsel))
	       (progn
		 (if (jb:getKeyNotexdata (car ent))

		   (jb:ChangeKeynote ent key note t)

		   (alert "That is not a Keynote object!")
		 )
	       )
	     )
      )
    )
  )
  (princ)
  (princ)
)

(defun c:jb002_00_UPALLKEY_OnClicked  (/ )
(vla-sendcommand(vla-get-activedocument(vlax-get-acad-object))"jbUPALLKEY ")
  (princ)(princ))


(defun c:jb002_00_FIND_OnClicked  (/ text key)
  (setq text (dcl_ListBox_GetText
               jb002_00_KEYLIST
               (dcl_ListBox_GetCurSel jb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (if text
      (progn (setq key (substr text 1 (vl-string-position (ascii "\t") text)))
             (jb:findkeynote key))))
(princ)(princ)
  )

(defun c:jb002_00_KEYLIST_OnDblClicked  (/ text nflag lflag doc)
  (setq text (dcl_ListBox_GetText jb002_00_KEYLIST(dcl_ListBox_GetCurSel jb002_00_KEYLIST))
        lflag(dcl_Control_GetValue jb002_00_LEADER)
        nflag(dcl_Control_GetValue jb002_00_NOTE)
	doc(vla-get-ActiveDocument(vlax-get-acad-object)))
  (if (and text (/= text ""))
    (progn
      (dcl_SetCmdBarFocus)
      (cond
        ((and (= nflag 1)(= lflag 0))
	 (dcl_sendstring "jbPlaceTextNote ")
	 )
        ((and (= nflag 0)(= lflag 1))
	 ;(dcl_sendstring "jbPlaceNote ")
	 (vla-sendcommand doc "jbPlaceNote ")
	 )
        ((and (= nflag 0)(= lflag 0))
	 (dcl_sendstring "jbPlaceKeyNote ")
	 ))))
(princ)(princ)
  )

(defun c:jb002_00_REFRESH_OnClicked (/) (c:jb002_00_OnInitialize)(princ)(princ))


(defun c:jb002_00_OnDocActivated (/) (c:jb002_00_OnInitialize)(princ)(princ))

(defun c:jb002_00_OnEnteringNoDocState ( /)
     (dcl_form_close jb002_00)
      (vl-bb-set 'jb002Floating "true")
  (princ)(princ)
)

(defun c:jb002_00_OnClose  (nUpperLeftX nUpperLeftY / )
  
  (princ)(princ))

;;;								;
;;;	Tray Functions						;
;;;								;
(defun c:jb002_00_Close_OnClicked ( / rValue ht wd)
  (vl-bb-set 'jb002Floating "false")

  (setq rValue (dcl_Form_GetControlArea jb002_00)
	wd(car rValue)
	ht(cadr rValue))
  (if (> ht 20)
  (jb:SaveFormSize "jb002_00" (itoa wd) (itoa ht)))
  (dcl_form_close jb002_00)
  (princ)
)


(defun jb:002_RollUp (saveFlag / rValue ht wd)
  (Setq	rValue (dcl_Form_GetControlArea jb002_00)
	wd     (car rValue)
	ht     (cadr rValue)
	)
  (if saveFlag
    (progn ;(alert (itoa (cadr rValue)))
      (if (> ht 20);(> 160 20)
  (jb:SaveFormSize "jb002_00" (itoa wd) (itoa ht)))
      )
    )
  (foreach
	 x (dcl_Form_GetControls jb002_00)
    (dcl_Control_SetVisible x nil)
    )
  (foreach
	 x (list jb002_00_Tray
		 jb002_00_Close
		 jb002_00_TrayRectangle
		 jb002_00_TrayLabel
		 )
    (dcl_Control_SetVisible x T)
    )
  (dcl_Control_SetToolTipMainText jb002_00_Tray "Roll Down Form")
  (dcl_Control_SetMouseOverPicture jb002_00_Tray 100)
  (dcl_Control_SetPicture jb002_00_Tray 100)
  (dcl_Form_Resize jb002_00 wd 16)
  (princ (strcat (itoa wd) ";" (itoa ht)))
  )


(defun jb:002_RollDown (pictureFlag / rValue ht wd)
  (setq	rValue (jb:GetFormSize "jb002_00")
	wd     (atoi (car rValue))
	ht     (atoi (cadr rValue))
	)
  (foreach x (dcl_Form_GetControls jb002_00) (dcl_Control_SetVisible x t))
  (if pictureFlag
    (progn
  (dcl_Control_SetToolTipMainText jb002_00_Tray "Roll Up Form")
  (dcl_Control_SetMouseOverPicture jb002_00_Tray 101)
  (dcl_Control_SetPicture jb002_00_Tray 101)
  )
    )
  (dcl_Form_Resize jb002_00 wd ht)
  )


(defun c:jb002_00_Tray_OnClicked ( / )
  (cond((=(dcl_Control_GetPicture jb002_00_Tray)101)
	(jb:002_RollUp t))
	((=(dcl_Control_GetPicture jb002_00_Tray)100)
	 (jb:002_RollDown t)
	)
       )
(princ)
  (princ)
  )

(defun c:jb002_00_OnMouseEntered (/)
  (cond	((= (dcl_Control_GetPicture jb002_00_Tray) 101) ;it's rolled down - do nothing
	 (princ)
	 )
	((= (dcl_Control_GetPicture jb002_00_Tray) 100) ;it's rolled up - roll it down
	 (jb:002_RollDown nil)
	 )
	)
  (princ)
  (princ)
  )


(defun c:jb002_00_OnMouseMovedOff (/)
  (dcl_setcmdbarfocus)
  (cond	((= (dcl_Control_GetPicture jb002_00_Tray) 101) ;it's rolled down - do nothing
	 (princ)
	 )
	((= (dcl_Control_GetPicture jb002_00_Tray) 100) (jb:002_RollUp t))
	)
  (princ)
  (princ)
  )


;;;							;
;;;		Command Interface			;
;;;							;
(defun c:jbkeynotes  (/ )
  (if(not(member "jb002" (dcl_GetProjects)))
	 (dcl_Project_load "jb002")) 
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive jb002_00)) ;Forms always open rolled down!
	(dcl_Form_Show jb002_00)
	  )
      (if (=(cadr (dcl_Form_GetControlArea jb002_00))16);it's rolled up
	(c:jb002_00_Tray_OnClicked))
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)(princ))

;;;							;
;;;		Floating Form				;
;;;		Document Opened				;
;;;							;

(defun jb:jbkeynotes_IsFloating  (/ )
  
  (if (dcl_Form_IsActive jb002_00)
    (c:jb002_00_OnDocActivated))
  (princ)(princ))

(jb:jbkeynotes_IsFloating)


(princ "\n002 - jbTools Keynotes loaded!")
(princ)
;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
