
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;ControlBarTest
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun c:TEST ()
  (LoadRunTime)
  (dcl_LoadProject "ControlBarTest" T)
  (dcl_Form_Show ControlBarTest_DCLMaster)
)

(defun c:ControlBarTest_DCLMaster_TextButtonMinimise_OnClicked (/)
  (Setq *ControlAreaList* (dcl_Form_GetControlArea ControlBarTest_DCLMaster))
  (dcl_Form_Resize ControlBarTest_DCLMaster 296 100)
)

(defun c:ControlBarTest_DCLMaster_TextButtonMaximise_OnClicked (/)
  (if *ControlAreaList*
    (dcl_Form_Resize ControlBarTest_DCLMaster (nth 0 *ControlAreaList*)(nth 1 *ControlAreaList*));then
    (dcl_Form_Resize ControlBarTest_DCLMaster 296 779);else
  );endif
  (setq *ControlAreaList* nil)
)

