(IF (NOT *MasterDemo*)
  (princ "\nOpenDCL Beispiel-Programm.\nGeben Sie \"testGRD\" ein, um das Beispiel zu starten.\n")
)


;******************************************************************
(defun c:testgrd ( / 
  table_list table header data row 
  temp temp1 temp2 nRow ncol column_styles tname tabs 
  tablenr gridcontrol dialog
  )

  (or LoadRunTime (load "_OpenDclUtils.lsp") 
    (exit)
  )
  (LoadRunTime)
  (dcl_Project_Load "testGRID.odcl" T)
  (setq table_list (read_csv->list "c:/ibriess/projekte/geopus/brx10/test.csv"))

;;(alert (vl-princ-to-string table_list))  
  (dcl_FORM_SHOW testGRID_CSVDialog)
  (dcl_Control_SetTitleBarText testGRID_CSVDialog "mydialog")

;; tab caption from table-list
  (create_tab_caption_from_table_list table_list)

;;(alert (princ (strcat "\n" "testGRID_CSVDialog" "_GRID1=" (vl-princ-to-string testgrid_CSVDialog_GRID1))))
;;;  (setq tablenr 2)
;;;  (setq table (car table_list))
;;;  (progn
  (setq tablenr 0)
  (foreach table  table_list

;;    (create_cb_c:testgrid_CSVDialog_GRID<1,2,3...> "testGRID_CSVDialog" "_GRID" (itoa (1+ tablenr)) "_OnColumnClick")
;;(defun callback_c:testgrid_CSVDialog_GRID<1,2,3...> ( sdialog scontrol snr sevent / temp temp1 )
;;    (setq temp (strcat sdialog scontrol snr))
    (setq temp (strcat "testGRID_CSVDialog" "_GRID" (itoa (1+ tablenr))))
    (setq gridcontrol (eval (read temp)))
    (setq temp1 (strcat "c:" temp "_OnColumnClick"))
;; evaluate defun c:testgrid_CSVDialog_GRID<1,2,3...>_OnColumnClick ...
      (eval (read 
              (strcat 
  "(defun " temp1 " ( intColumn / ) (c:testgrid_CSVDialog_GRIDn_OnColumnClick " temp " intColumn))"
    )))

    (dcl_Grid_Clear gridcontrol)

    (dcl_Control_SetVisible gridcontrol (= 0 tablenr))

    (setq header (car table))
    (setq tname  (cadr header))
    (setq data   (cdr table))
    (setq row    (car data))

    (if (= (type (car header)) 'STR)
      (progn
        (setq temp nil)
        (foreach x header
          (setq temp (cons (list x) temp))
        )
        (setq header (reverse temp))
    ))
;;(alert (vl-princ-to-string header))

    (dcl_Grid_AddColumns gridcontrol header)
    (setq column_styles (set_column_styles_derived gridcontrol header))

(princ (strcat "\nheader= " (vl-prin1-to-string header)))
(princ (strcat "\n1 row=" (vl-prin1-to-string (car data))))
  
;;(alert (vl-princ-to-string data))
    (cond
      ((= (type row) 'STR)
        (foreach row data
          (setq nRow (dcl_Grid_AddString gridcontrol row ";"))
        )
      )
      ((= (type row) 'LIST)
;;(princ (strcat "\ndata=" (vl-prin1-to-string data)))
        (dcl_Grid_FillList gridcontrol data)
      )
      (T
(princ (strcat "\nskipped: " (vl-princ-to-string row)))   
      )
    )  
    (set_checkboxes_from_data gridcontrol column_styles)
    (create_layers_from_data gridcontrol column_styles)
    (setq tablenr (1+ tablenr))
  )

;; An dieser Stelle bleibt der Ablauf dieses Programms stehen bis der Dialog geschlossen wird
;; In der Zwischenzeit verwalten die Ereignisfunktionen den Dialog.
  (princ)

) ;;(defun c:testgrd ( / table_list table header data row temp nRow ncol column_styles)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun create_tab_caption_from_table_list ( table_list / table header tname tabs )
  (foreach table table_list
    (setq header (car table))
    (setq tname  (cadr header))
;;(alert (strcat "header=" (vl-prin1-to-string header) "\n tname=" tname))  
    (setq tabs   (cons tname tabs))
  )
  (setq tabs (reverse tabs))
;;(alert (strcat "tabs=" (vl-prin1-to-string tabs)))
  (dcl_Control_SetTabCaptionList testgrid_CSVDialog_TAB1 tabs)
  tabs
  
) ;; (defun create_tab_caption_from_table_list ( table_list / table header tname tabs ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun csv_parse1 ( fp / line1 line2 tok table x y pos1 pos2 rval ncol )

      (while (setq line1 (read-line fp))
;;(princ line1)      
        (setq line1 (vl-string-trim " \n\r\t\"" line1))
        (setq line2 nil)
        (setq ncol 0)
        (setq pos1 0)
        (while (setq pos2 (vl-string-search ";" line1 pos1))
          (setq ncol (1+ ncol))
          (setq tok (vl-string-trim " " (substr line1 (1+ pos1) (- pos2 pos1))))
          (if (= "." (substr tok 1 1))
            (setq tok (strcat "0" tok))
          )
          (cond
;;            ((or (= 5 ncol)(= 6 ncol)(= 7 ncol))
;;              (setq tok (strcat "\"" tok "\""))
;;            )
;;            ((/= tok (vl-princ-to-string (read tok)))
;;              (setq tok (strcat "\"" tok "\""))
;;             
;;            )
            (T
;; alle zu string machen
              (setq tok (strcat "\"" tok "\""))
            )
          )
          (setq tok (read tok))
          (setq line2 (cons tok line2))
          (setq pos1 (1+ pos2))
        )
        (setq line1 (reverse line2))
        
;;(setq prot (strcat "\n7 " (vl-prin1-to-string line1)))      
;;(princ prot)
;;(alert prot)

        (setq line2 nil)
        (foreach x (reverse line1)
          (cond
            ((and (not line2)(= "" x)))
;;            ((and (not line2)(not x)))
            ((and (= (type x) 'SYM)(/= (type x) 'LIST))
              (setq x (vl-prin1-to-string x))
              (setq line2 (cons x line2))
            )
            ((= "" x)
              (setq line2 (cons nil line2))
            )
            (T
              (setq line2 (cons x line2))
            )
          )
          
        )
        (setq line1 line2)

        (cond
          ((not table))
          ((= "KEYWORD" (car line1))
            (setq rval (cons (reverse table) rval))
            (setq table nil)

          )
        )
        (setq table (cons line1 table))

      )
      (if table
        (progn
          (setq rval (cons (reverse table) rval))
          (setq table nil)
      ))
;;(alert (strcat "\ncvs_parse1= " (vl-prin1-to-string (reverse rval))))
  rval

) ;; (defun csv_parse1 ( / ))      

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun csv_parse2 ( fp / line1 line2 tok table x y pos1 pos2 rval  )

      (while (setq line1 (read-line fp))
        (setq line1 (vl-string-trim " \n\r\t\";" line1))
        (cond
          ((wcmatch (strcase line1) "KEYWORD;*")
;; Header 
            (setq line2 nil)
            (setq pos1 0)
            (while (setq pos2 (vl-string-search ";" line1 pos1))
              (setq tok (vl-string-trim " " (substr line1 (1+ pos1) (- pos2 pos1))))
              (if (= "." (substr tok 1 1))
                (setq tok (strcat "0" tok))
              )
              (if (= "" tok)
                (setq tok " ")
              )
              (setq tok (strcat "\"" tok "\""))
              (setq tok (read tok))
              (setq line2 (cons tok line2))
;;              (setq line2 (cons (list tok) line2))
              (setq pos1 (1+ pos2))
            )
            (setq line1 (reverse line2))
            (if table
              (setq rval (cons (reverse table) rval))
            )
            (setq table nil)

          )
          (T
;; Data 
            (setq line2 "")
            (setq pos1 0)
            (while (setq pos2 (vl-string-search ";" line1 pos1))
              (setq tok (vl-string-trim " " (substr line1 (1+ pos1) (- pos2 pos1))))
              (if (= "." (substr tok 1 1))
                (setq tok (strcat "0" tok))
              )
              (if (= "" tok)
                (setq tok " ")
              )
;;              (setq tok (strcat "\"" tok "\""))
;;              (setq tok (read tok))
              (setq line2 (strcat line2 ";" tok))
              (setq pos1 (1+ pos2))
            )
            (setq line1 line2)
            
          )
        )

        (setq table (cons line1 table))

      )
      (if table
        (progn
          (setq rval (cons (reverse table) rval))
          (setq table nil)
      ))

;;(alert (strcat "\ncvs_parse2= " (vl-prin1-to-string (reverse rval))))
  rval

) ;; (defun csv_parse2 ( / ))      

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun read_csv->list ( fname / fp line1 rval line2 x rval table prot pos1 pos2)
  (cond
    ((not (setq fp (open fname "r")))
(alert (strcat "cant open file: " (vl-princ-to-string fname)))
    )
    (T
;;      (setq rval (csv_parse1 fp))
      (setq rval (csv_parse2 fp))
            
      (close fp)
     
    )
  )
  (setq rval (reverse rval))


  (cond
    ((not (setq fp (open (strcat (vl-filename-directory fname) "/" "out.txt") "w"))))
    (T
      (foreach x rval
        (princ "\n(" fp)
        (foreach y x
          (princ (strcat "\n" (vl-prin1-to-string y)) fp)
        )
        (princ "\n)" fp)
      )
      (close fp)
    )
  )
  rval
  
) ;; (defun read_csv->list ( fname / ))

(defun c:read_csv ( / fname rval )
  (cond
    ((not (setq fname (getfiled "csv input" "c:/ibriess/projekte/geopus/brx10/test.csv" "csv" 0))))
    (T 
      (setq rval (read_csv->list fname))
    )
  )
  rval
  
) ;; (defun c:read_csv ( / fname ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun set_column_styles_derived ( gridcontrol header / 
          head column_styles nCol
        )
      (setq column_styles nil)
      (setq nCol 0)
      (foreach head header
        (setq column_styles (cons 
        (cond
          ((= 0 nCol)
            0
          )
          ((wcmatch (car head) "*_LAY*")
            27
          )
          ((wcmatch (car head) "*_COL*")
            30
          )          
          ((wcmatch (car head) "*_LWT*")
            32
          )          
          ((wcmatch (car head) "*_LIN*")
            33
          )          
          ((wcmatch (car head) "*_ON*")
            1
          )          
          ((wcmatch (car head) "*_STL*")
            21
          )          
          (T
            6
          )
        )
          column_styles))
        (setq nCol (1+ nCol))
      )
      (setq column_styles (reverse column_styles))
(if nil
  (progn
(setq nCol 0)
(princ "\n")
(foreach head header
  (if (= 0 (rem nCol 4))
    (princ "\n")
  )
  (princ (strcat " (" (itoa nCol) " " (car head) " " (itoa (nth nCol column_styles)) ")"))
  (setq ncol (1+ ncol))
)
))
  (dcl_Control_SetColumnStyleList gridcontrol column_styles)
  column_styles
  
) ;; (defun set_column_styles_derived ( header / ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun set_checkboxes_from_data ( gridcontrol column_styles / 
              column_style 
              ncol nrow
              column_cell column_cells
            )
  (setq ncol 0)
  (foreach column_style column_styles
    (cond
      ((= column_style 1)
        (setq column_cells (dcl_Grid_GetColumnCells gridcontrol ncol))
        (setq nrow 0)
        (foreach column_cell column_cells
          (setq column_cell (vl-string-trim " \n\r\t" (strcase column_cell)))
          (cond
            ((wcmatch column_cell "0,OFF,")
              (dcl_Grid_SetCellCheckState gridcontrol nrow ncol 0)
              (dcl_Grid_SetCellText gridcontrol nrow ncol "OFF")
            )
            ((wcmatch column_cell "1,ON")
              (dcl_Grid_SetCellCheckState gridcontrol nrow ncol 1)
              (dcl_Grid_SetCellText gridcontrol nrow ncol "ON")
            )
          )
          (setq nrow (1+ nrow))
        )
      )
    )
    (setq ncol (1+ ncol))
  )

) ;; (defun set_checkboxes_from_data ( column_styles / column_style ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun c:testgrid_CSVDialog_GRID1_OnButtonClicked (Row Column /)
;;  (dcl_MessageBox "To Do: code must be added to event handler\r\nc:testgrid_CSVDialog_GRID1_OnButtonClicked" "To do")


)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun r:make_obj_tables ( / )
  (setq acad$Object       (vlax-get-acad-object))
  (setq acad$Document     (vla-get-ActiveDocument acad$Object))
  (setq acad$mSpace       (vla-get-ModelSpace acad$Document))
  (setq acad$pSpace       (vla-get-PaperSpace acad$Document))
  (setq acad$layers       (vla-get-Layers acad$Document))
  (setq acad$styles       (vla-get-textstyles acad$Document))
  (setq acad$blocks       (vla-get-blocks acad$Document))
  (setq acad$appids       (vla-get-registeredapplications acad$document))
  (setq acad$groups       (vla-get-groups acad$document))
  (setq acad$dictionaries (vla-get-dictionaries acad$document))
  (setq acad$linetypes    (vla-get-linetypes acad$document))
  (setq acad$utility      (vla-get-utility acad$document))

) ;; (defun r:make_obj_tables ( / ))


;;********************************
(defun r:vla_mod_layer ( layername Color LineType LayerOn Lock Freeze / ok obj ac_T_li ac_F_li)

  (cond
   ((= (type layername) 'STR)
     (setq layername (strcase layername))
   )
  )

    (cond
      ((not color))
      ((= (type color) 'STR)
        (if (= (itoa (atoi color)) color)
          (setq color (atoi color))
          (progn
            (setq color (strcase color))
            (cond
              ((member color '("ROT" "_RED")) (setq color acRed))
              ((member color '("GELB" "_YELLOW")) (setq color acYellow))
              ((member color '("GR�N" "_GREEN")) (setq color acGreen))
              ((member color '("CYAN" "_CYAN")) (setq color acCyan))
              ((member color '("BLAU" "_BLUE")) (setq color acBlue))
              ((member color '("MAGENTA" "_MAGENTA")) (setq color acMAgenta))
              ((member color '("WEI�" "_WHITE")) (setq color acWhite))
              (T
                (write-line (strcat "Farbfehler bei Layersteuerung (" color ")"))
                (setq color acWhite)
              )
            )
          )
        )
      )
      ((= (type color) 'INT)
        (if (or (< color 1)(> color 255))
          (progn
            (write-line (strcat "Farbfehler bei Layersteuerung (" (itoa color) ")"))
            (setq color nil)
          )
        )
      )
      ((= (type color) 'REAL)
        (write-line (strcat "Farbfehler bei Layersteuerung (" (rtos color 2 2) ")"))
        (setq color nil)
      )
      (T
        (write-line "Farbfehler bei Layersteuerung")
        (setq color nil)
      )
    )
  
  (setq ac_T_li (list acOn acTrue :vlax-true T))
  (setq ac_F_li (list acOff acFalse :vlax-false))
  
  (cond
    ((member layerOn ac_T_li) (setq layerOn acTrue))
    ((member layerOn ac_F_li) (setq layerOn acFalse))
    (T (setq layerOn nil))
  )
  
  (cond
    ((member Lock ac_T_li) (setq Lock acTrue))
    ((member Lock ac_F_li) (setq Lock acFalse))
    (T (setq Lock nil))
  )
  
  (cond
    ((member Freeze ac_T_li) (setq Freeze acTrue))
    ((member Freeze ac_F_li) (setq Freeze acFalse))
    (T (setq Freeze nil))
  )
  
  (if (and LineType (= (type LineType) 'STR))
    (if (not (tblsearch "LTYPE" LineType))
      (setq LineType nil)
    )
    (setq LineType nil)
  )
  
  (cond
    ((and (= (type layername) 'STR)
          (or (setq obj (tblsearch "LAYER" layername))
              (setq obj (vla-add acad$layers layername))
          )
     )
      (if Color
        (vla-put-color obj Color)
      )
    )
    (T
      (alert (strcat "cannot create Layer: " (vl-prin1-to-string layername)))

    )
  )
) ;; (defun r:vla_mod_layer ( layername Color LineType LayerOn Lock Freeze / ok obj ac_T_li ac_F_li))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun create_layers_from_data ( gridcontrol column_styles / 
            column_style 
            nrow ncol
        )

;;(alert (vl-princ-to-string column_styles))    
  (setq ncol 0)
  (foreach column_style column_styles
    (cond
      ((= 27 column_style)
        (setq column_cells (dcl_Grid_GetColumnCells gridcontrol ncol))
;;(alert (vl-princ-to-string column_cells))    
        (setq nrow 0)
        (foreach column_cell column_cells
          (cond
            ((= "" (setq column_cell (vl-string-trim " \t\r\n" column_cell))))
            ((tblsearch "LAYER" column_cell))
            (T
              (r:vla_mod_layer column_cell acWhite nil acTrue acFalse acFalse)
            )
          )

          (setq nrow (1+ nrow))
        )
        
      )
    )

    (setq ncol (1+ ncol))
  )
) ;; (defun create_layers_from_data ( gridcontrol column_styles / ))


;******************************************************************
(defun c:testgrid_CSVDialog_OK_BUTTON_OnClicked ( / )
  (alert "c:testGRID_CSVDialog_OK_BUTTON_OnClicked ")
  (dcl_Form_Close testgrid_CSVDialog)  
)

;******************************************************************
(defun c:testGRID_CSVDialog_OnInitialize ( / GridCellTypeList ImageComboBoxList x nRow)


  (alert "c:testGRID_CSVDialog_OnInitialize")
  (princ)

)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defun c:testgrid_CSVDialog_OnCancel (/)
  (dcl_MessageBox "2 Hier sollte etwas Sinnvolles passieren: An dieser Stelle k�nnen Sie nun den Quellcode zur Ereignisfunktion hinzuf�gen\r\nc:testgrid_CSVDialog_OnCancel" "Ereignisfunktion")
)


(defun c:testgrid_CSVDialog_OnInitialize (/)
  (dcl_MessageBox "3 Hier sollte etwas Sinnvolles passieren: An dieser Stelle k�nnen Sie nun den Quellcode zur Ereignisfunktion hinzuf�gen\r\nc:testgrid_CSVDialog_OnInitialize" "Ereignisfunktion")
)

(princ)

(if nil
  (progn
(defun c:testgrid_CSVDialog_GRID1_OnColumnClick ( intColumn / )
(alert "c:testgrid_CSVDialog_GRID1_OnColumnClick")
  (c:testgrid_CSVDialog_GRIDn_OnColumnClick testgrid_CSVDialog_GRID1 intColumn)
)
(defun c:testgrid_CSVDialog_GRID2_OnColumnClick ( intColumn / )
(alert "c:testgrid_CSVDialog_GRID2_OnColumnClick")
  (c:testgrid_CSVDialog_GRIDn_OnColumnClick testgrid_CSVDialog_GRID2 intColumn)
)
))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun c:testgrid_CSVDialog_GRIDn_OnColumnClick ( gridcontrol intColumn /
                                                 ColumnWidth ColumnText px_maxwidth )
                                                 
;;(setq gridcontrol testgrid_CSVDialog_GRID2)                                                
;;   (dcl_MessageBox (strcat "4 Hier sollte etwas Sinnvolles passieren: An dieser Stelle k�nnen Sie nun den Quellcode zur Ereignisfunktion hinzuf�gen"))
  (cond
    ((not (setq ColumnWidth (dcl_Grid_GetColumnWidth gridcontrol intColumn))))
    ((not (setq ColumnText  (dcl_Grid_GetColumnCells gridcontrol intColumn))))
    (T
      (setq px_maxwidth (- ColumnWidth 10))
      (foreach text (cdr ColumnText)
        (setq px_maxwidth (max px_maxwidth (dcl_Grid_CalcColumnWidth gridcontrol text)))
      )
(alert (strcat (itoa px_maxwidth) "\n" (vl-princ-to-string gridcontrol)))
      (dcl_Grid_SetColumnWidth gridcontrol intColumn (+ px_maxwidth 10))
;;      (dcl_Grid_SetColumnWidth gridcontrol intColumn (+ px_maxwidth 10))
    )
  )
)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun c:testgrid_CSVDialog_Grid1_OnButtonClicked ( Row Column / cstate cstyle)
(alert "testgrid_CSVDialog_GRID1_OnButtonClicked")
  (cond
    ((not setq cstyle (dcl_Grid_GetCellStyle testgrid_CSVDialog_GRID1 Row Column)))
    ((not (setq cstate (dcl_Grid_GetCellCheckState testgrid_CSVDialog_GRID1 Row Column))))
    ((= 0 cstate)
      (dcl_Grid_SetCellText testgrid_CSVDialog_GRID1 Row Column "Off")
    )
    ((= 1 cstate)
      (dcl_Grid_SetCellText testgrid_CSVDialog_GRID1 Row Column "On")
    )
  )
) ;; (defun c:testgrid_CSVDialog_GRID1_OnButtonClicked ( Row Column / )

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun c:testgrid_CSVDialog_GRID1_OnKillFocus ( / )
;;  (dcl_MessageBox "5 Hier sollte etwas Sinnvolles passieren: An dieser Stelle k�nnen Sie nun den Quellcode zur Ereignisfunktion hinzuf�gen\r\nc:testgrid_CSVDialog_GRID1_OnKillFocus" "Ereignisfunktion")
(princ)
)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun c:testgrid_CSVDialog_TAB1_OnSelChanging ( intItemIndex /)
;;   (dcl_MessageBox (strcat "1 Hier sollte etwas Sinnvolles passieren: An dieser Stelle k�nnen Sie nun den Quellcode zur Ereignisfunktion hinzuf�gen\r\nc:testgrid_CSVDialog_TAB1_OnSelChanging " (itoa intItemIndex) " Ereignisfunktion"))
   (cond
     ((= 0 intItemIndex)
       (dcl_Control_SetVisible testgrid_CSVDialog_GRID1 nil)
       (dcl_Control_SetVisible testgrid_CSVDialog_GRID2 T)

     )
     ((= 1 intItemIndex)
       (dcl_Control_SetVisible testgrid_CSVDialog_GRID2 nil)
       (dcl_Control_SetVisible testgrid_CSVDialog_GRID1 T)
     )
   )
   nil  
)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun c:testgrid_CSVDialog_TAB1_OnChanged ( intItemIndex /)

  (dcl_MessageBox (strcat "To Do: code must be added to event handler\r\nc:testgrid_CSVDialog_TAB1_OnChanged " (itoa intItemIndex) " To do"))

   (cond
     ((= 0 intItemIndex)
       (dcl_Control_SetVisible testgrid_CSVDialog_GRID1 T)
     )
     ((= 1 intItemIndex)
       (dcl_Control_SetVisible testgrid_CSVDialog_GRID2 T)
     )
   )
)

(r:make_obj_tables)

(princ)


