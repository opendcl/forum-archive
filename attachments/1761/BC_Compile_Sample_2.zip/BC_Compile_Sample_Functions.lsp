(princ "\nLoading... ")
(setvar 'cmdecho 0)
(command "OPENDCL")
(setvar 'cmdecho 1)

(defun c:BC_Compile_Sample_Form1_TextButton_Close_OnClicked ()
  (dcl_Form_Close BC_Compile_Sample_Form1)
)

(defun c:BC_Compile_Sample_Form1_OnCancelClose (Reason)
  (dcl_Form_Close BC_Compile_Sample_Form1)
)

(defun c:Test ()
  (if
    (not
      (or
        (dcl_Project_Import (load "BC_Compile_Sample"))
        (and
          (findfile "BC_Compile_Sample.odcl")
          (dcl_Project_Load "BC_Compile_Sample" T)
        )
      )
    )
    (progn
      (princ "\nError: odcl dialog not found ")
      (exit)
    )
  )
  (dcl_Form_Show BC_Compile_Sample_Form1)
)
