(setq docbarodcl
'("YWt6A9k0AQAeM7N6BuKTA3kCazuAhjxEF9Ha75rDmttuPj9eKouwoHtrzgVUdlZsf9uWB6Cx4YuK"
"EimA4OEtjqqF13n8djZHejoEkW423z2WO+rskrCCwaHnowPFhQiJ61pmghrmQsiysLCyyQGZRc3X"
"6i4/gDViXfJoYG94d136ufr/vH6fZ9/trif2aHofA+JeWsr+fVYoSjpmUgr7fCbWWWqRfvsEPo9Q"
"DqprYJdaCvnd/zxRH3aikX6peT7XYA7LZeJx/oHPql6AJPRL6Dzzw56wfoZjdglFdtsOAXaCjGQF"
"v61jnslN4nP/3V/S6D+Sw32f1sUCWTs2ujTP39OeMbZvnCV2U3tHv9MmE5mcW18owKt8YfVhGUZh"
"FUYBIAkghuYOxx5AGoRV8XYJdr37lafrFZ4Ryk4qZnUJOD3ReXePKikVxY4Uw3+AzuAZ3rCfvJ08"
"YVa/oapx0I0JuilnhI/SkKJpoGUR/8Hf0nF9+kyGA2Chjv+fcxGVsPW8BT0Rxkw4ZnuLnK8mSDQJ"
"fgr5do/PU4qR103CiUe9hwy/2z4hOP2GwHLfq2qBXD1pgYc8XzgJkIyhYfSZL1OKsbFMQkG9DkCt"
"DoDTnyJKytku+c7T0KlyMUByJjmG9SHfVV26yYuph2xiT1wWc1nXBtvj73acOTwj/R8eD445fJ+6"
"WZf401oKDmcVnH7C8F+4HbxO8J63xKSlqcmIlZ8A549jT3i65hw++rf4jdFzme1ymYlksKH06jaz"
"hW72nI9xZ6AGMvtnQVlU4E4muWFJ4mFrnAqZO/iZMdZGvJHl7jg1XyDH2lv1vb7and1zGg/5gUAc"
"J4JJeErglEG5/I/TcplkTB2ZZEzFeLGBH1bhkMGR/92GRYOZ/Y6AI/iIYk/uNs+BQCw4AmGBh+MG"
"AOX/UhFJ4olI4qEURknsGvcfQkpaBMneXy95IHc43NtzONzb8zTc28F8bFMTWK+E7ZZcPzHcjXtD"
"90w3BM/u1m3Rel2vUHM43CNk6zrFgnQ2yjVN96jhOmd3FDZK1fvgOmd3IVJa5Pwp/O8WmfVnIpID"
"ZA5DHX5pLfTkRsZk9D0IECpwp4cpvl9FSWdwtzZqNVqcJzllbGNTQmlg98wNZWzzvI0mo5WckOoh"
"SWoA4dNpf82MvQvLuSK9gk6WaffhnRF58Onoqu2Ogmw9M3M2lHF2BCwZi4PM2qCO+i0YPrUf+I3Z"
"ghYGcCeHdr2DWXOZEfswaHJtZPRSbmf87Dv+DKdC4O9VHJKCKbZIlNWuS3vI3+w7TCB3OGh/EO8Y"
"zBZYdSgtfcRc5GonTkVZZid6Rorlt9znUiYzc5Y6EUwa/1vmypYaWvXq5R7aeP5LinrNntAb6KoW"
"zv34+RkZ4jpywD2BFH22kawxrQt/ZJN6gUnbAXPy+DfD+wAuFUFmor/+9BsOAkOCQNA9tB1GDE+o"
"bdQXBhCdih6JSzaEalyTQSskmYubZrCRTEIR/brSwnj351IWOloYg61ej4NTUNLbuqARvdWxSj8g"
"02xH7QN/OmBDZlpguF1muE/ylnLbeC3ZLE1KCq4WJsgHL0xbuPqQSurJHzQ4t7SQSR/Y+oMv9/A7"
"7npuI6punwda8BgaHptLto4sbndLJq5dfT3YWPByeLAkbkQZmxassim97gxSYFr+nhx5vAZxGZ1F"
"wkAauZCVt9A7qfhYwoYFf7p939dCWg8qJnq5Zv1zv0MVnsBmmWfwNLawE3bwXwJhPQVQ3iO9hN1Z"
"xpyudzD1WGnkkiYxEraQGi1YRWidHzMIHb700kEqzugY1krU7LeQZWYilzu7niaHTkp0CNAfDrF4"
"r1bkfP0t6WxCWAr7AaMnpgFp3nlyk5FyfUXme4AJ69FzHrVzBLQ1fvjOe3h9+mA8V+LpvC9Zsyz8"
"kIxsfSLgLrRodZ5M+mDS4NCOpWeQCB4xnSUPl7w+KMBpJRCu/VMrZnoZU/1TW04Eh5I9s2fqSwYF"
"bs+6WKqCUXY7M9ZHBcB/PbMnA/vIY8x3TMFxkKoNi/oPoz3OK3S/qGb6w0j+/0k97r+lu3agKKl8"
"9WC/JopDjPYKcIqrWmWwZUVCmmO9h+XIn108guFzmYmVsEWm905DSEJc5vN5aRgDn4IPzsw4Fbok"
"gn34SflvCAz/O3b1igSk/pJk8UGgdm5Pi2tWOCxhncGxGGq8bm7yZkFKyqnWj8ARFhFmWFkV4Tg+"
"zoimdnYIwWBYWYg5a27jf7VET/+u94OVXgodUsRFHZnih131YbK6OHnITBN2ng9XhVUbUsNlYoV7"
"uh7eizDSMlluayPmTr4LFH0n8yPemGASiyQJxqHzw3GRc2j4zsHQDmk7KjE+uR4Vszj/xCl4y/F8"
"pMamxxvmVdf898mfPJ30SQjQaRFPSXyFBDgGVLaE16tTGtV+U3yYgzRxbnMDf2tgHbWVLoNVHbZp"
"eL1HFnZTS0zmDme2Tj+xXiYDZHjPzPvgX86Fu/gNc7/pd/PVb2R3AAd181+4Fre4tWHHF/6dCU/G"
"YufBpviBzQAWvsVS9v9OOq79AQRuff+rocoi8MjtRyRIhbUzmM4gIPIwOeJFGc/HKWT3UI8wSAjd"
"H5ova8JoOEDqdqNWFc8uFZ4C0m04bMMuWhc9DNJgc7cHe0O3A6M8MRzxdQRs3TytWM9XPH73S8BT"
"ra66TK4ugWWLyuPyZO3vZvNk6q/IBKkOgODTk4v1JTY/XO4dEXnoRO6vMsPqZQghPZzJd38sRoME"
"BrNWGDpweYxicgEWAvD+DfKhB3SAFPrDDgCHe/TbHGykRncWbTUrUJanvbH8bij2X/XjrM79Ofp1"
"tXCgaDKmv1E2gEFLKycXY+fSX+l1ZdKhnFxitXgaWUP6fgjsqHlq6J++UIz7oPLX8h8et3n7zvKT"
"wkxmAO/PIuKyGuoesTJ0e0NNH3KJfEzt6XvnJs7dUhjVRr7+wCeGQ1aTxhUzZ+U9Z2j/8se9rhtD"
"bBrxTn7FXcL43XuQ3ixUInP2/+wbVuqVdiSQdkYVZv5Nm7B2jqFKPpUSErweNg3dHvFK8vKEZrBR"
"yjykrmzc78fmlN06wV4wHp8RSUjXqm2A68x31dASzNRljVbcoW6RcPwVIx72xU5RHSnGqO0zR4cD"
"6qPmOW0JQmS6CMGUvgjGBPIHRs+4/wzzlrWaQLS53kCKIIgcoLI/DttlQm9rsjlnTfRfXIQp5UPq"
"RNSDeeBJN3Gbfz/NjuP/Sx6fBZLN8tPc0ZqnIQCstNYjSo/X3nVGi73uUvLXYHoDAzw3p4VQXiUp"
"L2vhTiF+oGwpUktbnZ2Z9SUfGJlIdE09l1jGIPenvkgUzw8sHeHeWXtIFRQ9dNF3BCy+l+N1N3TF"
"n3ERXK54z4V3PAqhw/cBAxHTDYIgH9wOpZLFtDh1PAmWtsvDj2ktCYYVVY7WLnkFVLWhIz0kzh6/"
"0ifNQISW3cGl2DFBgwqQosfCjv7/IQmTz9gNFweZ0CsjxJOUogsB2aw948RiVZMA3IVrWVHBlJor"
"SWDBxzGHDbEDSBGgwkmh4ufoSCFuGHW8ifzOKm6oyBbPW0UFKQS4gChXhaOnS0e7+fREYceKtB3B"
"wxulmrctOfLmvWrFJ/xOQUcHh6URYUIEyvDMKiMjSZiJ2UJbJsC9EfALx4iexg8ttbTAa/q3/E5d"
"Wxu/xAvZd1+t2WFjSBKRps95qRE+1OJOhxIf2V3pIA/SnSuFufPlLChIW0AALBycsnFApn0JOfDS"
"EqcMw14Sbfrjd9OIMub2jUExQA3UI/Hd6SLPBaLGtxsbba2sWAdCgUML1BC9+C07OxU1NMiamSlG"
"40UkOJMXk6cJkOKKo4INO+Pwypcks7QB4OFBl4y1mT1D7VhjVFMjpcOFmCDDVNHCDAnxYHnMDXAS"
"0dajJCDlJQxW0YMIKIDtNVGDlLRVwUUFyBCTpC2pIMWI+GVIseUJlJPJ8YqQw5GgBXHhQzWYs0F9"
"feufo7y0AaLNmSlJoUIJoMIDrqepINWQoQFtwhWXrK1xQ8oFmLKtDoLJwWM1C7yOEB6buSMBg9oF"
"keNJEqacnbmxqqvvQYIfReony5SK4kemp5OlMfNgI42uPfnc3CnPjGGLkUEbtu6HPflQhJ1h6THl"
"KE8YsgRWyACD8e1ZkSDGDoG1UZEGl9sD0cAEnsSVBodxtbQY82DDnqcZaUGBgoxpICaDnPUmALXo"
"LRHCL4+oJauRws2NUQGng4nBkWdIEouGj+0hAQO8NVGzAZvr+9HBwIqzSSnAi6jkCaEjgb1xq+1Z"
"KQKOv4gBgM0MosbUAYPVhM2xCIKN4SXBggyk8mehw4mg/PFBIEsAgpQxQCeBkQERhJz1021YEuVK"
"1wy06pQXrQiy5s8VqNIjNeiS4U4fm3zowIMIkLr39dgxIU8duLQnzSix4MMYsOLLDZnQ5UEBo/x7"
"jlCyLdlQ4EUJQGo4tGSiVuorKyvL3cwEGQsrGxsbS9q0tNS0lPSUtNQUQv4la0XIkf5MLtDEzPyD"
"EP39lDTGzNPUBAkrS8Hy+9WORILB1cxkUBLRurVrKwYj0N/MBAUre8L6qXjZ6ytrjvST6+uGUugf"
"sSqQYg6xx2zxqljlmEf2qTcDF1qxc8EcQIJEN8DtmMU2EGzHwNl2i9IgzYVs0ebrNuFjBxiwyfnY"
"M9eHCJS/J61wv5Gy13nZAA0OpKo97rkDChq8GTnUVdToUqQr6jdN7DfhZRQnzdW0tdXJEtCgwgu5"
"iIyUY6uuobSTJQg/BVRUCTyF6VGlo8cTE0VRN/VbITNCcHPihaFdp3DXWimSCTVTCh+oiuTsEgyJ"
"k8ulyZOg/0PVosIbmahTRSGHg7ETQ6zItCOuuQBJqxtartXEqryTsYGRHpUadBOmyg9x8qaIEysu"
"vZKneflACNDrPrmBnWrCHL/8/ZBWpJnEzU5kzcBD7mAxAAmZx1ToaFGno0DphqLKxgsjxRKsg2wX"
"FYeQlNRjcYtDAY0RuxOrK/VoqlrL3hGBl1kGaX52YKfGB5nYi0XJEKLPBy2L+AsFbkrrq9UoqqKM"
"pY1GoGtFaLKlyQeNYBaCcUGS4UrfmGVmvVd52AIDHqRJhdgwpUGH1eQ3Iaq+vkAEocdRQEVKi5V9"
"LmC52dTUsYvcqVNr2q38CtdO85jZrYJKCOL/TnzGfpJ+/EkgJ8XDHLlwSKRr0jdrYn9mTM71K0XV"
"b4/eXf70LmyQKH/Atlb6m29lp3/eVZp0+MQrJnnV7usaJrrQDQrUoLD+ti9v0c1JXNyM7DYnPZJW"
"tbtWtWs2J/EUV7VrNiedubFlhJriWfmzU2WAg/YZAAYEipwvsVBljYL0TwEmS4iH6x2BzgxymCsd"
"4LmCuwHoaOmyavpHz/d1baNV40dlTXVVDKWRsMGSPiC5A6cTCRqGyEfNSb5TVn67BCPLXEUJGAKs"
"CdDSOycH1UJbZXVFKOoKpavAucAIowlpCdCwEcFL2R4jBLDMqsp7r09NUZPKWlUFOCqi4hqJPAmI"
"tNL8c6CIpXVEkVKQxMnWCgkAudTi7FNnoMvwstvTLD98sMaazLvTDRg6ubE3NyXm6M3MC594bnr7"
"4wnIl8TJxgrJ0R0rELfossLLsNLb9/CR+2izm+W1SekRUKEiwMcC7VDxjNA1joyn+2UMpBK1UtCI"
"IMS5DbfQivz00ryzuIzT2Tm7gEmni/1FBQcMmORwo8nDj5DPW1WwUSMHgIsJ8MqVzFuvw7zvx8Yr"
"tEI/hsgDufsnJ60kOrP+rZYoQaKqBbX/ZE5m29MlcejpYXw1GrGgjamixs8booKGOk5TwRcFl/zS"
"qK17HxS1lucTUSMMgjqj4ENZEJDDRksN310Nr6OJ0UYAgtldORT1NWjLFne7WOkijAOVEs5PwXjN"
"is0BkdVDAcANqcc8soLqyju3kDs8qqLgKVLW09OFgo0DsnDjqtiDgpKiZ/yOK9UoLTHiRkGAneP8"
"jiMyomw/JlLKJmJtyXYK8nFApgeI0pYMM23697sTmZsGPkHnlwzTev2Q5xmIdrw4P6akyBPLsSlX"
"duV7H4OevxbVaGnRbvoXO1sNDMMupbiWljPr60Gx4IPtXupZWiqoqvaVqOP39Hw1CI36d9kAgo8S"
"NLR4BsjOBg8QoGQ/pnoHps4jLjEnp0/5HbGHjQqhwM1TJShDhFZETiEBw2QSDVYtLsq07XF5JXrf"
"fBSFjLVkNLslEXtN4hKgApif+c+O8mcFbWyozUzljHUoBgOi/NBs+qOvr0UQxBclH5//4QDc6+uZ"
"BIiiRQyayMbG0/wus1jiSJmF6JlrPnlVvpwYcOc9/A6qnz4tip6/DVMlYGr6g5KEcD+mcNG2tSHk"
"Icb7KbAC/Tl6nxq16NkhBJeetu9OKLmna8bANW4exrTDoFuHO4ILDsk4bvB3vPH8DihuMM19tjmn"
"i6PSsAzxGc8nh038DuBDC1SajJmmEQ2HmIyzm+W1SekRUKE6tZlr+C9ASQkPP+WM1taUlpbDr69L"
"r6+53N0B8vBAbWMD8IPg9PBAtNCR9/DQePtfURE35TW0a58AZvpLdVLXa3r3g/zEDPx3g8MyuhGN"
"h2iAk4NriULOm+B5tJHHwYKQhciLwQklwQXIicMFhSODtJGSxZfwxUiKxx0zkUBVEcEDp5PDacON"
"sEKKUkMQmScksEI1tYvg2/eUYvSSJyRglifcc+mw4OvQlTsNbNbphyqP6WOGTcEcA6PVU96xINUE"
"/EMW7cOLB+LLOhPrSbo0EgVvOOfuReaZvjRCcJwNnmYELRb5Atz80j+fISM79E1Xwn+g+H2d7gWd"
"K7n3yzZg1A4FZ1CCk5Up/mhigKizrdwa7fvBgf4r5mA5eaBR/6urdo7hhtuqRC+0NYtx5blXjw+M"
"VCOPvUGmliRw8hM5szmv/IsWJbuXusryax7D5IgVhRvW9DFFZ0VgytmoUXPjJbeTN9tASdWtP63d"
"loWRLnLgFQaGgZGR19XbQgxAlegE015obxj5dAGT9iS+IXvqwfIljCSuSFESfvX5P6B+AfFggIuR"
"BsaOuSHJekd5Rsw95EExLD9oZ4Jrh18fWIIi0t3DEejMnNcxZ2XhC41D8E62oHbnbji8MMB6nvt3"
"JryfvsD+4ARTDAO+0GPEbjkxYxnh7ZrHFuAtjFqttYy3r706+x5ajlm4Hfz2Lg0uxLo9DS1bZk0G"
"ZTmEhDXOLo6lYi5fvCElMTqOscm+Co3YIL6S2U15DAAeGtMlr8DJ7kTvqOmBna1sjx1+Dv+RGH+O"
"G7Q5eNb2s3g/A8U/c3QZrRn9vMj/Sk5dgmUwyXVbFVvvsTvjU9vpIC5XSDyGteY9WtQbe5qTqdvK"
"Jix+Arj7PLj5tqmWg/W68PaKOz+nxoPTePkB9hz73T4gZLSu8lpEm1V3H6FegiEffjJ9ZoZeM/EY"
"kzyb8fVj6kfzdG3xvSy30XGhzywlPfwO5o5JpGO0O2vCIoNPk8W5MlN0kjxgTbnDt9pa6Sgqqxcf"
"Z2+BOZXvto4ZIv7iQjfEy+0MLDZQ2QE7jAazzkJMtiZAbG+CfRFL0kMc5z34AcD4vDOFHH0BEV6C"
"40pJ7yCt4+JBkRmA77wh1//+cp4cHrM05HloGHSLxq+k6hNY8/8bcdVueaYC8jPzQqXJBrN2rNqA"
"HpOqQGxigCT1XeIPTr6hmczQodJCOVsGVF0wZIvaMsWLjoE28p8Nhg1rflSFjoGvikYknu5CMHcd"
"SiNmL7TLPjHeL2MY+NQGSMOVy1YRLd8pleyq4ngoGyTBBK8uNx6DKEsly6fUm6RkkgTZvqHdjzP+"
"UpjIxl04goY9VLWVhK/BXIdbe3m0YNmXz9wvZQ3fgTo5VOSg3i/kVAX5jefYfmJ6WjY44pby3940"
"GLsc8spV6Ni7fpD0F5LKR73OGrgvKeLq6D6tnTcofLc3GNTIZVMR0A1/a9QoZvDB/ZhYXajSIljt"
"EYOeUZcxMeHYSSDwyNtogPbdkqqZyp7/5JUWUsZXqo7FgJqREa1BwTihAuvAi3QDhUt8h7HR7wmf"
"hqu4s45EraKmkXNJwYdEg+GZlq3xrb9xrIDJqKOuNZSieKlKfq/Gne8oTCXfX1Bx0f1MnFmn98oF"
"BYSNF3sGi6+Bx6Xxq/ymWquqrtxy7OX8nutrgK66JN99D6q9xue5W3xUicHn1usNMisaMnqzgstY"
"L5vB7gBAPYmR22Wp94HjW8OF5IqWA8o5OZQ329BWHnNGabkHVd643YlWkiTtXMmB9vQ6eYh9gE+Z"
"8S2sPCBrhdhkUmpQHurhvUZBzlHuJL6ZQWNRjIQ7iHgY005CFTBSb/OLsG0int26keFCP6lS2ZGB"
"O5QJVVe3WLDWxOJ65Kw8hKXhGxszK4AWw4PBkm6WwU4tjNhmt6B+jT5hBfBtg+xA2ULvdPgdGHzD"
"3F2Hj9pWnVcfw1uzihEyJGYsPEb1qnBqLnBeu/B0l72Jt1PBW8c3rJKXBikaWOW0e5RNgTmah2Ga"
"gefssKWZjBWA2LIh412s3HItHJQ+n4WVxbZ8WlwUez8NnDd5B7j7G/f3AU4Q3NYOfe80gqjnzQq7"
"LJemT9pbwtXvf++mAYD4jh2egTvnSm6ApAdAIX6CmxdN+doWVBZ2fizKMGxFa+0jxcsS0GeAgFqH"
"P94GnHcJuhcaxaE6qS5xrdo6CFKoNYEtILJ7S0MKfqkWjLdh/Zk68HvPDub+dL6Ta9G8b4ZKKyRq"
"B49HVOeI0kcnW3PLVo2MgAXstFhWX4vcgb4qDf6Xgdc4KcEfgLEZ02pmUHxU/5zMB/00iLOOEdKq"
"Do6JeL5BQXqG5Rz6sTPNHNufPVY0TRp/HE2BEdqqho6xycl8fE2NdnxJf1ImyNrnimVJI26GpS7F"
"5xc+DOaFVEM4BNZhbSLetOwYeK5W1w+eYQ/ieilnP12ye1Cebg1tl7IX+u4YWK4m1w+KQS1fYVwI"
"DkXsxfhMbJYTqS7X8LRIEw0UlqrmhMEUlPl7gULpduzhxfhCcOyn9ACPzyqpsoBlWUvAgom9oU7l"
"E9l8VsZ++D5Vj5QQirmts2zeLyx9v8FO/Y7XWH3v5TmqerKB5M54edZ+kvT1xt0PSD1FCV/FTDys"
"da89JFlFO4L7W0pUm0f4RGRO2yPROpp3Va9hFxslQwmob6+eqa26qHiwxzb4DcdyT6J0pNP4/QEQ"
"1FtD5byh7IFFplpM5cY4MJ/ozG0XyRwiIT6nknu+Ilo6madKNWI/KhGX770aiMkKsDK2GqBS8ijh"
"ReWw5zNeseD7eQ4b8OzBHWc0PIAwR0uaR2gHmMkKi3QLdOVkWZXSbH0rhziEtPWs4SG4xv1JIF8R"
"glFgvpchoVrh89nhASxJE2QnyOqSpPcgABtc/oYfkSHz/zdaWpalZWqA+IdiNV6lvuEzf/6Cic7e"
"qUJpdfc0XddPituZjyM0ivwyskh2UIdZ8M6q373aGUWU8msN7NZJ57uyWq/SWkK2M1xgCDuzpzc6"
"sPcqBUMWEOMyY6+a/0WC7lnWwJQ8UH1sL2VCjw2kNN7w6EpbdFmOI5Kpp/wcEFdHJeyod1ZtUY83"
"qYvaXXitsUHYm+VaLx/1jCVK8IHe14+WQZqGOL1dEmh+nfYDUNh2zmQO/bJiJC8/mvdQ+3k0tGL6"
"J1zEd280QWM5P+qa2B4qOghUgJhOJW1KaQZXltGuex0Y+zPQzbkzERs4r/mR3Oxah1etaILcRC09"
"t6r3ZqabDTdHMEdYMJj97mPq09QcUTO8C8iQRuRsXWgbrMCpNeGCdWdi0fg1N09KmK02jCFzgHV1"
"gCKHDVX19r5uDp/UO/B2l8+crTGORzPc8inO6Nc9tf4OiHLDl1Ts4F4PtXydmmIMov+pciUTkmpl"
"hbtjMWCUMQcO8HICXKe1HzvRXyExXueP9oA4lUdreT/wmZ1fIxLvc+J8+Bi6LQnSpsP6wIV4QwA8"
"n+5SRoXp/MFcxJOLAtPklvEpKOnyxtu8CuJesgmpm9tPhVzz0CI4BjIujrBXCTs8aideM4U4sjbe"
"p1cSnSFo05gtV1MCKkuzsEaELkEHsHygJTUWdva0J0bnjOvqYLmUD84/Di6r1OyZKH+e4jSmhprE"
"W8DObV2C7DYESsPcTZRM6rT6DJ+LQUt0R+bj2aNqPDkRcGevA3Qm5kXuBK2U/gVBDGHpfnLF/bp7"
"b1BjRlmYIn0aj8PD9+Xzz2I2sYZq1mbY80oj4h+xfEwct72DS4+P0sfIzCYjNznAgcBQQyD395zF"
"WcYnGsptCSseStFKN6/xj0QFUXJv6rH0uU6kKeDZy8sMm4jOFTaGNT9zBQ2GFXypB9kDlLxfaZ8o"
"XnR8uIRMbVuupdfUdnjLgY4AY0nPlKa3vJFbrojC8gCGzgfHra+bIQzd7XuolXZ8TawfQgPO0RQD"
"+mDH/GbDGGez8h2+CU24mu4CNCpzKfuaxgdQYS2b+yNgsMIuF7xIfl4s3Lf+Bbfx2RddvyFpFD5+"
"gLvndK/ECxTBc4PenNuUdnA6EOeGK4DRIVkvmjzZDjhVrIV4vO/lJ//vRnjhhmNQ+L7YRH6AEkfD"
"/SSQjR/PsrwONQNiduaPAVsMT+LKFEdAYEZf0GClktTfo6JgMO17jwG4egEdho7pWZpPt7YD3jhS"
"tuyJgrcNlXa3ANl8cCDncUVaC1/2CP7LFSN0JrfSKJwBwC5oYDieyV+sxHPG0UJWUsYq7x/h64wZ"
"zNw7Vc6ynuG4hsFMLrgmU4Ua/sGpMkHM7EUMQts9EOtd9ACOaTSTkl0y79CBn92xhQkOQRfpN4xi"
"GGpsrneTxvw2sSmGwvCJFMt+c4JDHm9GDwO9EcSsLdnbroIB/xO5mPFU7eJP6lEsH+IoINScdfrB"
"rawTGyK4u5dB8ECuKfe5cq3Pdo45g6EErpKYM4bkYWlEdh6WzOy2zPu/oWbXgimKZRp/eYjfXfvR"
"MHyPe2cK3nIbw2zy+RewLrSdP+Lqbz3NbBYE1X5x7OyNpnAYogp9O46RkU9hEFqCYcc4izCssD1D"
"t8peM4pHM5ahUQvLU0+OUc0lruN5kB8qOQb20hzT+O7KjkmZ5qiOKRd21nqEq8djQwpOBqIqOoVB"
"1qOcKJWPnYr3fxq2vUqsUkF166IF+RKBeXQgor9wfryK35Ia12qECUaa/6taSySEq2nWVbCxA/y+"
"QRoWfn6RxPOWCtruLS6GJUv9jbNCu+Pv6z6Eo2S6lbYt2pVBGoAxcixQwlqXcX7ltEl8P2Sf0SR0"
"zC/u9CJwJr7hIHJcorIl0dLopiE9RWuvkjrBWsyagZ8anhwpCYvRvHbis883VII9v0bdobr/b00C"
"lEJd5MCIOTQ9JklrH4LBbCFQnyRK9xZF1AhCennjDCEsIoTlqOe+4T1AUSvIBseei1qviAfKzEyi"
"mIWleBGCuQXGGXfw59OkbHiCI1p9niG0+bZOXr/taICI1Dle8Z5oU2T7F3r6l9KXy9/CzwCVAZSC"
"bfDvth/7SqZMawjCD0OPvaFnHjTUleXnoOio7EBJXJLJDICxAzlZMeyhCj3l7J3qq+rK686rt3Z7"
"NN7gIKPjjpcbgVoy5owhiVx1hnnIbTtaJrdXHGVR06I4a8nsIxSug2G9M/8sHV2uAUSb0Dr9u92j"
"O++VdsfXloMixShBhWvqkxbmcNr3Id64eOgbf817xwDvmbzDcgwjCPYeGnN06j6IIK1DUhQu2XeW"
"+CtGye2drp4pRo6ZJuJvMRHH/PTf0+XABp4RTrbGwVZdn4K+hVsrhFYk9+Oi7ZvBLIASU8OLROzo"
"/hLtZeMgwGY3kbAQMobVrO0qEtlbp7Jnl3Z+AC6GjXwQovuT5x8c9qDZ2HMBEb6+tS0h9J12Jj6V"
"GsSWeTfgcN4MkjOuhwhzEVpN2KyKWuJ1erX3OWIGLRY/fo8FfT4TtNZd3wFbKys0E0PG8+ihWxt9"
"AbuX2ttyIWRkuYGHCVbEQdj1c4CHlCJj4cMNH/IOgWWHSmUhp2K6Wdbxt5zmPGCS9QBFgAu3ApC7"
"KslTrKVePxdsioHOlyH3atbUXltHZvhexbsTtiClVDtAmEWngNUQxB9Lcy+bxvae0Wn31CFuAyN3"
"ipVRO2vmX9Z+ogBvBzc+5ht1V+Uvb3+MYEibKL7Yrfy+oXJMZx+8IfXQq2vGjk8KhpV0TjlI5s0p"
"CjjDiCl/gYJ+htUgGOt1huJWwxHC4oKG3ZQXzZPD3OoNB384cqlk4AJqA3QCydICu+Pk4RRFgRl7"
"gRAfcPpc90aD/XyRiQQldwIDTcYnekQ1BFIDimDralAUg+EZ4XwBi0VolODhogUhnjjHk/TfYYN9"
"P1WpF6UR96XQzFxeHXPCxDMV8nudqpAfbZL72Aym6oiyn2F0b4RJGtekMKWYzMvxMDXnEdxpxIK/"
"HB61zpODPQOBO3wBa3vChK1CkGoInJAd6SH0T7xfs8ROgN5mlgA8h70WlPS75Kfazmd7eL17EXqO"
"qWo/hLG4NlRngBgaccmCpt8BRcpHWS+EH//BuDiOgXvEhLp2iZmvRvCbubvzFa+BaZwsLCtKDiVO"
"QzgElSuHDXr0aDYqZSbFl/MrpM3pCIyf2u4BgTT5NzUSmHvHTLyCwcS3oW6DnX4B3gHOFox8ybAv"
"qm5VYHqbzewWF2UMDsGsD7O2JNs2iQEfmGjXnfVZghVXvDVUMkZXPCDBP6y/QeavVQnjczIIbMdS"
"8ZDWGLNd3ER6bHHPc9RpTlbDheTqaLlcb6ZJLfyyvee8QeAgo/MxM+wun9EStiTLc4vB4ir18KW0"
"XtEltPJZCaC+iQhvq+STLdqNgfp5y+9OWEnT1NwAE/IQHIChzp7hmWyHcPwexEUd288butIEG1Xn"
"HjNDD2JJzHg8tClIrMoFxedQ9oqhM/jGTENjlH6T1u6km6h8g6XDsDyAvdFFOISdJoGaMp2GAaqH"
"YSBD8dDzroORoTkiSKTI0Lm2YgsZld60SLHH3ntED2RBqV+ETJaEKwK3xjwLgDt9iA+mTNJAgPba"
"u7Yce508kw9O3hO++ATIWdnwbbth29elhKvC03lx7xDp3HPpGcTmtN4PZHi5/7SB8lcU81934wS6"
"gdcQSM8wpMT7EKMytMmurk1AzDukzOcSVdnlSa/TJTc7a+NAJ4rHRoKLzykQFUQaxCRv1n5wz74z"
"Iy+Kz3mb852UmmY/wbcZfXkvcG/ZQYMy0Zf/HopEPf4BPrA3OF8Ciu60qDxMf0ZLYkA0BCP4xNII"
"7RHtRzaTzla53kvIt1++PzpgkRSVeikt+o2BOhtMjqGgA8odf2TQ3sX670OWlRLlPZ+/iAcWicqN"
"rtwSJ/SEo5G/nrFYw1rQTpvOLhfO4Y5tKfRc1jCGeRbQ/07uveRYzwtmjClyvfpBPtElRQSKDqbt"
"we7wYNjDRFyUF1XK/cFYGVvu5dBay5mCkkZq21LMkUFWEKgkyLaetiDysRDjVj+9DSxOGVndbeVR"
"940mGgB12cWaHYoFByw6owb5voHDUlb2jXXA8dJF5KChOSgy5+ScyUySh0EU9DIw4tFbgxDsrJ1T"
"nfxS/XwixhrOap4BuiEXVo6Zc32GiZK+nmFyl/JFtc3GvS/9fVoBHZcBlHH1gRqVAaZURKBEE6bJ"
"K2LdxCHaKYcyWiG0foTi1yG7VN25MCcWuGmNms3RIjDhsi5+/XW6LlpfuWnrGbDkVwGwVG6FUj09"
"Jjdg5fiC4fHqzGC1AEIbhmFbQ0X0vj/8fqFSVkpT6AKI37KNxow3Pfa1xL6Vwf2Ltz6NpE9w8rJM"
"T7xqWTIoHKML6a1NmcsIRnc0gTogQFWMvPGi8Q0XApd3iXUN67qd6jKKTdt/PsMjpewdOZKgao4Y"
"h2mXwd3q5RbxkcwI5rUDPzQyUsIJtRQH7Tm7vwdvv0EOXtP2oRScI7Mi/RJjOUGHJpmBzzGM+S9K"
"msQMV5QBx6JkHSGwmkK1tEdtR4JrcnvXv4tBRTwv+FupW1Fz/R1uROkJ3BL5IctBXwfjUEKC/Rcq"
"/5W8choR+VHkeR9qxQnqMGKp0L7O8Wmr9hQ7H2aHRgD+ermmUxEr1dC3cILQ+5T41FGCbVvlxj0H"
"6/L0/ZJqaeOi07IWLDzKZbyl2DglgWVnE7WDzfgBVlZYAU7zE2KNiBWA3u7ejbwEBL/cHtnIs7yL"
"vALE7+UbmLjHLXC29nKAAj2YXfmWm2MOT/szAUeChwwOS2RwKqsJgDpaC92q7qMwM3GAX4QCKtpO"
"/CNHuza2Os8tX6PLtcHxDlaoRoniNvTRltuZ9l3kmttvyE5rcy3xPS9Ks0y8wfr4dQEQCWJDUiOv"
"L7Iyyr2JvtONx8BNkcEA/nkLDdTX758RGcb4eAE1yNHhdiovPkVUXsMjL4r7L+oVu7/onG2r3ZcJ"
"DjcKoSDXLU84i2jaX6bHEawYIxWmjonJ9oKCbcffWeud71OUidev31J2fAwwVMNS8ZCl3dHwZhVJ"
"M2lsgP9QtfjeAVNKmntOQiz+O/mfuE/TlUgSrjgFJ1pgQtrnWEJRVS6cxRE2J8/SQwIL2yXM7zre"
"9Dt+AYebXJMDSzPJI3y8n9FQ7/59VqGJOJCM0HWjjJmXfL4hTT8feyU1Sq9OQ9WPrgAbOjXoe6JL"
"nry7bjFzcmBy0dIWqnQxpwhCAOIiB2ezMmwHwtsxbfhqttQahmFwC4qCdnckJVPHgxQKIKYCSamV"
"miGmK4SVPpuRibadZv3tmRsKdcoTLNqNwQs07T+ZvpFBG7RNSKSbxAcQjZHB5M39Dob8wlt4qbjT"
"lA/vPBjKnUz/KsQa7wg8QKKA7IFlsQiYn7jB/YZ8xd4itxshJEUM6vHx2uV7TDEARTPS3ckg8296"
"+MAVjyQjmeOxb1/r2FuulyE7Rnllh4nhxgV3SZpFyjGIBZwgFFfmjz2+14zPF4gkoUyjErVQJap9"
"NEXK+ZGseyQ+waW69sFde3Hgh+eiBlu4iI4G2kL1lzc6yVqsrzkJk5pda6T5tfbyen6BpdA/BEik"
"6WSefftrRjtg4PZHK4wbOshwcC06j0ECUTA0VoE6pYBkpLD94f5Xsur0zHaCjH2LRtIi6jdzZ/p1"
"mlzCW2sZbz1QzLb7Z5KPUpy11H2Iev1JBST2nk6XUIoJlKksCMKSx4hUAqZ+AuL9NF+TzLfIs2wt"
"WVtX6pZxizNcANV1zjK1ecOUpFn7hY6TLIwiHP91KaUhqy1Eg6373QHn4fcCr2DUY5m35Ksak3TE"
"EGuYS1LRdeipFsyQqBRs5qnQ7KiWYU8BKCWBFMwY28YQ2yKZ9Nv6bzf6nXrOf06gqfnG3abazqW6"
"O129QWcdBsgSLJkf/IwBJFUB4tnQKOoQwPTEHVphztNa5wcHSzJt07EqCm5+ybP2u9NfY3xjhxoa"
"A7xq54Kps9uEExXURuHbbloTptzmJhqFOSqxMdo3y3be/XXA2Uc3NBbG+9R8jhHlNcgQKNm2/Mvs"
"hiEtWaxF0L8XKh7YexB8Zw5zDD9Em3m+r6SbLM45EcI8ZIpeA50bhJNqDIYeDmrNNG+3AdwCJjDJ"
"ZQ2tNSQqm+QDGpMqHVeeCa59NuFI1FReNjfweo7pq/Me/u9KTTCuvnMVl5z7GocctI0sAyDL4pCk"
"X+BC/09J5LabtsHxbw+CcS+56jjyAvPhqluYpqKNWuyDXGqC7z0gPuS2uNB7dF6CDbuz5eqT6f3w"
"87w7Txjq0zTOdKMs1zMlWe8JPMK+hAGtWgYj7OfB4lyA/C5j0TSMbaWtMW4HkVaTjDV7Y36AE0Os"
"6LOAN6Zulv2G6VNWL2vqLH0qg2UAVcPtnZGUjw/aIQqDuTvvcpV2Xv9gp7D1Ze6WcgyQ2Qy1hOFS"
"geUCFPgBrtpu4zaD9fUgAe9GHVunTA23TXy2fGI6+IHYIcy339kYhnkzOidYWHluX1FGzvEIVz8p"
"0cI+vttSYjHbs46BC1gzCm41kcH5j3uHMAe1M3J0HkWOSI2BIRnsK37AlHOA40Iw0VS7xyTRJYAA"
"S6l85Z+BlTVkcVOLEZIywIYqDLtfmVEOVzBfkIG3v77f9VxLvUHK2sTs9pjFZEGDMgUhvQkSGUVq"
"zDcfcIEYh4GVNKLlMRs5Qy9YiLpnrYMk3rlflQG7J5zYi+wQxM/XNH3+wZS+LVxbgwDYdeY84ksW"
"JPez/qCh8dq5NgcQB8E+YeW8gB/goT/UBm5SVd9/exKCB9Tx9tahy9c5nIqx1G4XU4laSwETR+ra"
"0s9fNWk0h2b3Xo/G/pIqgnSivIfqcxX2D6YkQB9KSjKg1Sev0kIjcYHRgS9o+zIU5VTNhDvsax3s"
"6r5+fo9NvbqKRrQJVrkej2prgFJ7Iwka2oiezeSyyyLVpyNIDIZtG3NBNVnwH76Strm31lnX5OFg"
"mLGklV+bHzrp6/WkRP0oRVii6UgiyBSaTT2XllnbrzH2HfmthZG+0TeMHsliaNyPxYAKsg5EDFZj"
"0PD+O4MucYGbed34rs8bmqvptwUR5JoJoe646J/pYSGFXUMN8LM0bkeSUSyGVQ12cvF2h/8D/LRv"
"O00cgkczt6Sdbk2BaPpBearnaB2A0N6na/VHoog64k1yJ4e+e5rSepw1vRvVlOi/p49muOu/QQFv"
"FaXRJopd27ufwE0O9GG6HiG9vvV/+8/UJuxarkUR2BJ4JveN8kq3jOEOWHtrAI5gABTKLoWn1wSY"
"DpzHq1bkvovTKLtcEOYDgz8N32z/t6cAUA16zKtfOoMEJW9lPgtFbdUJm0eakS+Mbo3CKoe9Stin"
"md4Xr5y1Ubbw9oSxgU3nUVQlFnEDKnxyjUd9QBBtFyhBeperkSkVLLIUAdU4td/CrxXvzaP6Ac20"
"ne7BXbtBYf8VDCOMwi5AJVKYHzV405SpAJEyxe6/HK9CIDERO9kxnPRcnX9vA3g1NYG0MNYZsTRD"
"RTSnNwiVMVzZAYv0vSZYaizSWcekqmenzQJT5t/9QkwhuHbAXvyTImz687QhQ4ipGD2BoGok4jsV"
"iFZfJqJg8iKALdS6jSyiSaa5ySGqAXLff9r+t4bnIkrQ1a69VCHxfO/LVCL+pXZeLTakian0gydA"
"luzBiJYP95Ld7mb9ALUrrIcNgDNzlFOB64NPtulh3exfAR3b979BVj5kd4Aoc3bJYO2ApIgqxcLl"
"zXjAZ+tV9PIANA9Q1+QBA5ahYQKKonaCnkKBsBJ9zKeunxFia4O+FjdWHNrWGcFc6D8fvyGJaNhq"
"DHNcsVvYWTbhA5J5yTzEi98BkDhGWTRJg+gYWJTkboh2+9ia5fL5tcH61C+XQUwWJcBPmoDkQWVy"
"gCCzeS8bTb87SdLtqsaYeI+BzMoNeTAim1pVxSf6+5Xf9kxlhnlAFUhah9gzzAQR5jPMyUyzuV+y"
"UPmLLBB11nvGl+rrNgUiNDDjLP8oIQHDYYAapBqi8zMgPNOeIjZWHhSn+nCBrmDKevurnR9IV2pK"
"qUteglDlqBgEo92hN/N5aZwpcR3aX3HVLT6AIyaVfQFHnubChsLqYFMBBzzFwTtajnHfiT+WoWRA"
"uLiqfYAg5RQzpRd9gU7/4RE/JeK3BerzUsrhvP3sF49cpaAhI1E8ldd+tI1BtjyEoD5NnVuH5aKE"
"AEl7hiVc+6fNX7xZaoalS8BfhsF/dUIEhg2Hka0ShbwY6IvuWR8Shmx+gYFxi9g9Sw=="))
(defun c:docbar ()
  (if (not (dcl_Form_IsActive ut_docbar01_docbar))
    (progn
      ;(dcl_project_load "ut_docbar01" T)
      (dcl_project_import docbarodcl nil nil)
      (dcl_form_show ut_docbar01_docbar)
      (setstartlists)
      (setlargepreview)
      )
    (progn
      (dcl_form_close ut_docbar01_docbar)
      (if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide))
      )
    )
  (princ)
  )
(defun startdocbar ()
  (if (not (dcl_Form_IsActive ut_docbar01_docbar))
    (progn
      ;(dcl_project_load "ut_docbar01" T)
      (dcl_project_import docbarodcl nil nil)
      (dcl_form_show ut_docbar01_docbar)
      )
    )
  (setstartlists)
  (setlargepreview)
  (princ)
  )
(defun c:ut_docbar01_docbar_exit_OnClicked (/)
  (dcl_form_close ut_docbar01_docbar)
  (if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide))
  (princ)
  )
(defun c:ut_docbar01_docbar_fzd_OnClicked (/)
  (dcl_form_show ut_docbar01_splash)
  (princ)
  )
(defun c:ut_docbar01_splash_exit_OnClicked (/)
  (dcl_form_close ut_docbar01_splash)
  (princ)
  )
(defun c:ut_docbar01_docbar_OnMouseMovedOff (/)
  (if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide))
  (setq previewposition nil)
  (princ)
  )


(defun c:ut_docbar01_docbar_OnInitialize (/)
  (setdwglists)
  (setlargepreview)
  (princ)
  )

(defun c:ut_docbar01_docbar_OnDocActivated (/)
  (setstartlists)
  (setlargepreview)
  (princ)
  )
(defun c:ut_docbar01_docbar_OnEnteringNoDocState (/)
  (dcl_form_close ut_docbar01_docbar)
  (princ)
  )

(defun setdwglists ()
  (setq docurrentdwglist nil)
  (setq docurrentdwgname nil)
  (vlax-for x (vla-get-documents (vlax-get-acad-object))(setq docurrentdwglist (append docurrentdwglist (list (strcase (vla-get-fullname x))))))
  (vlax-for x (vla-get-documents (vlax-get-acad-object))(setq docurrentdwgname (append docurrentdwgname (list (strcase (vla-get-name x))))))
  (setq xo 0)
  (repeat (length docurrentdwglist)
    (if (= (nth xo docurrentdwglist) "")(setq docurrentdwglist (doclssub docurrentdwglist xo (nth xo docurrentdwgname))))
    (setq xo (1+ xo))
    )
  (if (> (length docurrentdwglist) 4)
    (progn
      (dcl_Control_SetEnabled ut_docbar01_docbar_btn_dn T)
      (setq dwgprv1 (dcl_DWGPreview_GetDwgName ut_docbar01_docbar_prev_dp1))
      (setq xxpp (- (length docurrentdwglist)(length (member dwgprv1 docurrentdwglist))))
      (if (> xxpp 0)
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_up T)
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_up nil)
	)
      (if (> (length docurrentdwglist) (+ xxpp 4))
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_dn T)
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_dn nil)
	)
      )
    (progn
      (dcl_Control_SetVisible ut_docbar01_docbar_btn_up T)
      (dcl_Control_SetVisible ut_docbar01_docbar_btn_up nil)
      (setq xxpp 0)
      )
    )
  (princ)
  )
(defun setstartlists ()
  (setq docurrentdwglist nil)
  (setq docurrentdwgname nil)
  (vlax-for x (vla-get-documents (vlax-get-acad-object))(setq docurrentdwglist (append docurrentdwglist (list (strcase (vla-get-fullname x))))))
  (vlax-for x (vla-get-documents (vlax-get-acad-object))(setq docurrentdwgname (append docurrentdwgname (list (strcase (vla-get-name x))))))
  (setq xo 0)
  (repeat (length docurrentdwglist)
    (if (= (nth xo docurrentdwglist) "")(setq docurrentdwglist (doclssub docurrentdwglist xo (nth xo docurrentdwgname))))
    (setq xo (1+ xo))
    )
  (setq curdwgfile (strcase (strcat (getvar "dwgprefix")(getvar "dwgname"))))
  (if (member (strcase (getvar "dwgname")) docurrentdwglist)(setq curdwgfile (strcase (getvar "dwgname"))))
  (if (> (length docurrentdwglist) 4)
    (progn
      (dcl_Control_SetVisible ut_docbar01_docbar_btn_dn T)
      (setq dwgprv1 (dcl_DWGPreview_GetDwgName ut_docbar01_docbar_prev_dp1))
      (setq xxpp (- (length docurrentdwglist)(length (member dwgprv1 docurrentdwglist))))
      (setq xdwgpos (- (length docurrentdwglist)(length (member curdwgfile docurrentdwglist))))
      (if (> (- xdwgpos xxpp) 3)(setq xxpp (- xdwgpos 3)))
      (if (< xdwgpos xxpp)(setq xxpp xdwgpos))
      (if (> xxpp 0)
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_up T)
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_up nil)
	)
      (if (> (length docurrentdwglist) (+ xxpp 4))
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_dn T)
	(dcl_Control_SetVisible ut_docbar01_docbar_btn_dn nil)
	)
      )
    (progn
      (dcl_Control_SetVisible ut_docbar01_docbar_btn_up T)
      (dcl_Control_SetVisible ut_docbar01_docbar_btn_up nil)
      (setq xxpp 0)
      )
    )
  (princ)
  )
(defun setlargepreview ()
  (setq curdwgfile (strcase (strcat (getvar "dwgprefix")(getvar "dwgname"))))
  (if (member (strcase (getvar "dwgname")) docurrentdwglist)(setq curdwgfile (strcase (getvar "dwgname"))))
  (setq docurrentdwgnick nil)
  (foreach n docurrentdwgname (setq docurrentdwgnick (append docurrentdwgnick (list (substr (dwgremove n) 1 20)))))
  (if (nth (+ 0 xxpp) docurrentdwglist)
    (progn
      (dcl_DWGPreview_LoadDwg ut_docbar01_docbar_prev_dp1 (nth (+ 0 xxpp) docurrentdwglist))
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx1 (nth (+ 0 xxpp) docurrentdwgnick))
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp1 T)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx1 T)
      )
    (progn
      (dcl_DWGPreview_Clear ut_docbar01_docbar_prev_dp1)
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx1 "")
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp1 nil)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx1 nil)
      )
    )
  (if (nth (+ 1 xxpp) docurrentdwglist)
    (progn
      (dcl_DWGPreview_LoadDwg ut_docbar01_docbar_prev_dp2 (nth (+ 1 xxpp) docurrentdwglist))
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx2 (nth (+ 1 xxpp) docurrentdwgnick))
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp2 T)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx2 T)
      )
    (progn
      (dcl_DWGPreview_Clear ut_docbar01_docbar_prev_dp2)
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx2 "")
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp2 nil)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx2 nil)
      )
    )
  (if (nth (+ 2 xxpp) docurrentdwglist)
    (progn
      (dcl_DWGPreview_LoadDwg ut_docbar01_docbar_prev_dp3 (nth (+ 2 xxpp) docurrentdwglist))
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx3 (nth (+ 2 xxpp) docurrentdwgnick))
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp3 T)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx3 T)
      )
    (progn
      (dcl_DWGPreview_Clear ut_docbar01_docbar_prev_dp3)
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx3 "")
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp3 nil)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx3 nil)
      )
    )
  (if (nth (+ 3 xxpp) docurrentdwglist)
    (progn
      (dcl_DWGPreview_LoadDwg ut_docbar01_docbar_prev_dp4 (nth (+ 3 xxpp) docurrentdwglist))
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx4 (nth (+ 3 xxpp) docurrentdwgnick))
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp4 T)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx4 T)
      )
    (progn
      (dcl_DWGPreview_Clear ut_docbar01_docbar_prev_dp4)
      (dcl_Control_SetCaption ut_docbar01_docbar_prev_tx4 "")
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_dp4 nil)
      (dcl_Control_SetVisible ut_docbar01_docbar_prev_tx4 nil)
      )
    )
  (if (= (nth (+ 0 xxpp) docurrentdwglist) curdwgfile)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp1 7)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp1 -22))
  (if (= (nth (+ 1 xxpp) docurrentdwglist) curdwgfile)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp2 7)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp2 -22))
  (if (= (nth (+ 2 xxpp) docurrentdwglist) curdwgfile)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp3 7)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp3 -22))
  (if (= (nth (+ 3 xxpp) docurrentdwglist) curdwgfile)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp4 7)(dcl_Control_SetBackColor ut_docbar01_docbar_prev_dp4 -22))
  (princ)
  )

(defun c:ut_docbar01_docbar_btn_up_OnClicked (/)
  (setdwglists)
  (setq xxpp (1- xxpp))
  (setlargepreview)
  (setdwglists)
  (princ)
  )

(defun c:ut_docbar01_docbar_btn_dn_OnClicked (/)
  (setdwglists)
  (if (> (length docurrentdwglist) (+ xxpp 4))(setq xxpp (1+ xxpp)))
  (setlargepreview)
  (setdwglists)
  (princ)
  )

(defun c:ut_docbar01_docbar_prev_dp1_OnMouseMove (Flags X Y /)
  (setq docpos (dcl_Control_GetPos ut_docbar01_docbar))
  (if (< (cadr docpos) 150)(setq hpos (+ (cadr docpos) 105))(setq hpos (+ (cadr docpos) -151)))
  (if xxpp
    (if (and (nth (+ 0 xxpp) docurrentdwglist)(/= previewposition 0))
      (progn
	(dcl_form_show ut_docbar01_slide)
	(dcl_Control_SetToolTipMainText ut_docbar01_docbar_prev_dp1 (nth (+ 0 xxpp) docurrentdwglist))
	(dcl_Control_SetPos ut_docbar01_slide (+ 75 (car docpos)) hpos 230 150)
	(dcl_DWGPreview_LoadDwg ut_docbar01_slide_window (nth (+ 0 xxpp) docurrentdwglist))
	(dcl_Control_SetCaption ut_docbar01_slide_tx (nth (+ 0 xxpp) docurrentdwgnick))
	(setq previewposition 0)
	)
      )
    )
  (princ)
  )
(defun c:ut_docbar01_docbar_prev_dp2_OnMouseMove (Flags X Y /)
  (setq docpos (dcl_Control_GetPos ut_docbar01_docbar))
  (if (< (cadr docpos) 150)(setq hpos (+ (cadr docpos) 105))(setq hpos (+ (cadr docpos) -151)))
  (if xxpp
    (if (and (nth (+ 1 xxpp) docurrentdwglist)(/= previewposition 1))
      (progn
	(dcl_form_show ut_docbar01_slide)
	(dcl_Control_SetToolTipMainText ut_docbar01_docbar_prev_dp2 (nth (+ 1 xxpp) docurrentdwglist))
	(dcl_Control_SetPos ut_docbar01_slide (+ 75 (car docpos)) hpos 230 150)
	(dcl_DWGPreview_LoadDwg ut_docbar01_slide_window (nth (+ 1 xxpp) docurrentdwglist))
	(dcl_Control_SetCaption ut_docbar01_slide_tx (nth (+ 1 xxpp) docurrentdwgnick))
	(setq previewposition 1)
	)
      )
    )
  (princ)
  )
(defun c:ut_docbar01_docbar_prev_dp3_OnMouseMove (Flags X Y /)
  (setq docpos (dcl_Control_GetPos ut_docbar01_docbar))
  (if (< (cadr docpos) 150)(setq hpos (+ (cadr docpos) 105))(setq hpos (+ (cadr docpos) -151)))
  (if xxpp
    (if (and (nth (+ 2 xxpp) docurrentdwglist)(/= previewposition 2))
      (progn
	(dcl_form_show ut_docbar01_slide)
	(dcl_Control_SetToolTipMainText ut_docbar01_docbar_prev_dp3 (nth (+ 2 xxpp) docurrentdwglist))
	(dcl_Control_SetPos ut_docbar01_slide (+ 75 (car docpos)) hpos 230 150)
	(dcl_DWGPreview_LoadDwg ut_docbar01_slide_window (nth (+ 2 xxpp) docurrentdwglist))
	(dcl_Control_SetCaption ut_docbar01_slide_tx (nth (+ 2 xxpp) docurrentdwgnick))
	(setq previewposition 2)
	)
      )
    )
  (princ)
  )
(defun c:ut_docbar01_docbar_prev_dp4_OnMouseMove (Flags X Y /)
  (setq docpos (dcl_Control_GetPos ut_docbar01_docbar))
  (if (< (cadr docpos) 150)(setq hpos (+ (cadr docpos) 105))(setq hpos (+ (cadr docpos) -151)))
  (if xxpp
    (if (and (nth (+ 3 xxpp) docurrentdwglist)(/= previewposition 3))
      (progn
	(dcl_form_show ut_docbar01_slide)
	(dcl_Control_SetToolTipMainText ut_docbar01_docbar_prev_dp4 (nth (+ 3 xxpp) docurrentdwglist))
	(dcl_Control_SetPos ut_docbar01_slide (+ 75 (car docpos)) hpos 230 150)
	(dcl_DWGPreview_LoadDwg ut_docbar01_slide_window (nth (+ 3 xxpp) docurrentdwglist))
	(dcl_Control_SetCaption ut_docbar01_slide_tx (nth (+ 3 xxpp) docurrentdwgnick))
	(setq previewposition 3)
	)
      )
    )
  (princ)
  )

(defun setdrawing (n)
  (setq currentdwg (nth (+ n xxpp) docurrentdwglist))
  (setq fnd nil)
  (setq chk (vla-get-documents (vlax-get-acad-object)))
  (if currentdwg
    (progn
      (vlax-for itm chk (setq ofil (vla-get-fullname itm))
        (if (= ofil "")(setq ofil (vla-get-name itm)))
        (if (= (strcase ofil) (strcase currentdwg))
          (setq fnd itm)
          )
        )
      (if fnd (vla-activate fnd))
      )
    )
  (princ)
  )

(defun largepreview (n)
  (setq currentdwg (nth (+ n xxpp) docurrentdwglist))
  (if currentdwg
    (progn
      (dcl_form_show ut_docbar01_preview)
      (dcl_Control_SetProperty ut_docbar01_Preview "TitleBarText" currentdwg)
      (dcl_BlockView_DisplayDwg ut_docbar01_Preview_BlockView1 currentdwg 0 1.0)
      )
    )
  (princ)
  )

(defun dwgremove (xtr)
  (setq xtr (substr xtr 1 (- (strlen xtr) 4)))
  xtr
  )
(defun doclssub (lst n tx1)
  (setq xlist nil)
  (setq nn 0)
  (repeat (length lst)
    (setq el1 (nth nn lst))
    (if (/= nn n)
      (setq xlist (append xlist (list el1)))
      (setq xlist (append xlist (list tx1)))
      )
    (setq nn (1+ nn))
    )
  xlist
  )

(defun c:ut_docbar01_Preview_BlockView1_OnRightClick (/)(dcl_Control_Redraw ut_docbar01_Preview_BlockView1))

(defun c:ut_docbar01_docbar_prev_dp1_OnClicked (/)(setdrawing 0)(setdwglists)(setlargepreview)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide))(princ))
(defun c:ut_docbar01_docbar_prev_dp2_OnClicked (/)(setdrawing 1)(setdwglists)(setlargepreview)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide))(princ))
(defun c:ut_docbar01_docbar_prev_dp3_OnClicked (/)(setdrawing 2)(setdwglists)(setlargepreview)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide))(princ))
(defun c:ut_docbar01_docbar_prev_dp4_OnClicked (/)(setdrawing 3)(setdwglists)(setlargepreview)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide))(princ))

(defun c:ut_docbar01_docbar_prev_dp1_OnDblClicked (/)(largepreview 0)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide)))
(defun c:ut_docbar01_docbar_prev_dp2_OnDblClicked (/)(largepreview 1)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide)))
(defun c:ut_docbar01_docbar_prev_dp3_OnDblClicked (/)(largepreview 2)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide)))
(defun c:ut_docbar01_docbar_prev_dp4_OnDblClicked (/)(largepreview 3)(if (dcl_Form_IsActive ut_docbar01_slide)(dcl_form_close ut_docbar01_slide)))

(command "opendcl")
(startdocbar)