;;;							;
;;;							;
;;;	Common Import Functions				;
;;;							;
;;;							;

;;;							;
;;;	Drawing	Drawing Opened?				;
;;;	This Routine is used when a Form Accesses 	;
;;;	Information via ObjectDBX to ensure the form	;
;;;	isn't trying to reference the active drawing!	;
;;;							;

;(setq refDwg(jb:ReturnProjectAECStylesStandardsFile))
(defun jb:IsDwgOpened(refDwg / ret)
  (setq ret(findfile(strcat
	       (vl-filename-directory refDwg)
	       (chr 92)
	       (vl-filename-base refDwg)
	       ".dwl")))
  ret)
             

;;;							;
;;;							;
;;;	(jb:ImportADTStyle (getfiled "Select a file" (getvar "dwgprefix") "dwg" 0) "AECDOOR" "AL-2-AL");
;;;							;

(defun jb:ImportADTStyle  (file aecobjtype stylename / dbxDoc blocks block aecobj newblk localBlocks)
  (setq dbxDoc (jb:OpenDbxDocument file))
  (if dbxdoc
    (progn (setq localBlocks(vla-get-blocks(vla-get-ActiveDocument (vlax-get-acad-object)))
                 blocks (vla-get-blocks dbxDoc)
                 block  (vla-add blocks (vlax-3d-point 0 0) "jbTempBlock")
                 aecobj (vla-AddCustomObject block aecobjtype))
           (if aecobj
             (progn (vla-put-stylename aecobj stylename)
                    (setq newblk (vl-catch-all-apply
                                   'vla-CopyObjects
                                   (list dbxDoc
                                         (vlax-safearray-fill
                                           (vlax-make-safearray vlax-vbObject '(0 . 0))
                                           (list (vla-item blocks "jbTempBlock")))
                                         localBlocks)))))))
  (if (tblsearch "block" "jbTempBlock")(vla-delete (vla-item localBlocks "jbTempBlock")))
  (if dbxdoc
    (jb:closedbxdocument dbxDoc)))

;;;							;
;;;	Import a Block from a DBX Document		;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   block; name of the block to import	;
;;;	Return:	the block object			;
;;;							;

(defun jb:ImportBlock  (dwg block / dbxDoc bb dbb newblk)
  (if dwg
    (setq dbxDoc (jb:OpenDbxDocument dwg)))
  (if dbxDoc
    (progn (setq bb  (vla-get-blocks dbxDoc)
                 dbb (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object))))
           (if (not
                 (vl-catch-all-error-p (vl-catch-all-apply 'vla-item (list bb block))))
             (setq newblk (vl-catch-all-apply
                            'vla-CopyObjects
                            (list dbxDoc
                                  (vlax-safearray-fill
                                    (vlax-make-safearray vlax-vbObject '(0 . 0))
                                    (list (vla-item bb block)))
                                  dbb))))))
  (if dbxdoc
    (jb:closedbxdocument dbxDoc))
  newblk)


;;;							;
;;;	Import Multiple DimStyles from a DBX Document	;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   listofstyles; list of names to import;
;;;	Return:	none					;
;;;							;


(defun jb:ImportDimStyles  (dwg listofstyles / dbxDoc ii bb dbb newstyle stylestoImport)
  (if dwg
    (setq dbxDoc (jb:OpenDbxDocument dwg)))
  (if dbxDoc
    (progn (setq bb  (vla-get-dimstyles dbxDoc)
                 dbb (vla-get-dimstyles (vla-get-ActiveDocument (vlax-get-acad-object))))
      (foreach i listofstyles
           (if (not
                 (vl-catch-all-error-p (vl-catch-all-apply 'vla-item (list bb i))))
	     (setq stylestoImport(append listofstyles(list i)))))
      (if stylestoImport
	(foreach ii stylestoImport
             (setq newstyle (vl-catch-all-apply
                            'vla-CopyObjects
                            (list dbxDoc
                                  (vlax-safearray-fill
                                    (vlax-make-safearray vlax-vbObject '(0 . 0))
                                    (list (vla-item bb ii)))
                                  dbb)))))))
  (if dbxdoc
    (jb:closedbxdocument dbxDoc))
  (vlax-release-object dbb)
  )

;;;							;
;;;	Import Multiple TextStyles from a DBX Document	;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   listofstyles; list of names to import;
;;;	Return:	none					;
;;;							;


(defun jb:ImportTextStyles  (dwg listofstyles / dbxDoc ii bb dbb newstyle stylestoImport)
  (if dwg
    (setq dbxDoc (jb:OpenDbxDocument dwg)))
  (if dbxDoc
    (progn (setq bb  (vla-get-textstyles dbxDoc)
                 dbb (vla-get-textstyles (vla-get-ActiveDocument (vlax-get-acad-object))))
      (foreach i listofstyles
           (if (not
                 (vl-catch-all-error-p (vl-catch-all-apply 'vla-item (list bb i))))
	     (setq stylestoImport(append listofstyles(list i)))))
      (if stylestoImport
	(foreach ii stylestoImport
             (setq newstyle (vl-catch-all-apply
                            'vla-CopyObjects
                            (list dbxDoc
                                  (vlax-safearray-fill
                                    (vlax-make-safearray vlax-vbObject '(0 . 0))
                                    (list (vla-item bb ii)))
                                  dbb)))))))
  (if dbxdoc
    (jb:closedbxdocument dbxDoc))
  (vlax-release-object dbb)
  )


;;;							;
;;;	Import Multiple Blocks from a DBX Document	;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   listofblocks; list of names to import;
;;;	Return:	the block object			;
;;;							;


(defun jb:ImportBlocks  (dwg listofblocks / dbxDoc ii bb dbb newblk blockstoImport)
  (if dwg
    (setq dbxDoc (jb:OpenDbxDocument dwg)))
  (if dbxDoc
    (progn (setq bb  (vla-get-blocks dbxDoc)
                 dbb (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object))))
      (foreach i listofblocks
           (if (not
                 (vl-catch-all-error-p (vl-catch-all-apply 'vla-item (list bb i))))
	     (setq blockstoImport(append blockstoImport(list i)))))
      (if blockstoImport
	(foreach ii blockstoImport
             (setq newblk (vl-catch-all-apply
                            'vla-CopyObjects
                            (list dbxDoc
                                  (vlax-safearray-fill
                                    (vlax-make-safearray vlax-vbObject '(0 . 0))
                                    (list (vla-item bb ii)))
                                  dbb)))))))
  (if dbxdoc
    (jb:closedbxdocument dbxDoc))
  (vlax-release-object dbb)
  newblk)
 
;;;							;
;;;	Return Block list from a DBX Document		;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   					;
;;;	Return:	List of strings				;
;;;							;

(defun jb:ReturnDBXBlocks  (dwg / dbxDoc ret)
  (if dwg
    (setq dbxDoc (jb:OpenDbxDocument dwg)))
  (if dbxDoc
    (progn (vlax-for x(vla-get-blocks dbxDoc)
           (if (and(= (vlax-get x 'isxref) 0)
                   (not(vl-string-search(chr 42)(vla-get-name x)))
                      (not(vl-string-search(chr 124)(vla-get-name x))))
                 
             (setq ret (append ret(list (vla-get-name x))))))))
  (if dbxdoc
    (jb:closedbxdocument dbxDoc))
  ret)




;;;							;
;;;	Import a Block from an Xref databse		;
;;;	Arguments: dwg; a valid xref database(vlaObject);
;;;		   block; name of the block to import	;
;;;	Return:	the block object			;
;;;							;

(defun jb:ImportXrefBlock(dwg block / bb dbb newblk)
  (setq bb(vla-get-blocks dwg)
	dbb (vla-get-blocks(vla-get-ActiveDocument(vlax-get-acad-object))))
  ;(if(not(vl-catch-all-error-p(vl-catch-all-apply 'vla-item (list bb block))))
  (setq newblk(vl-catch-all-apply
    'vla-CopyObjects(list dwg
    (vlax-safearray-fill (vlax-make-safearray vlax-vbObject'(0 . 0))
	      (list(vla-item bb block))) dbb)));)
  newblk
)
;;;							;
;;;	Import a Layer from a DBX Document		;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   llist; list of layer names to import	;
;;;							;
;;;							;
(defun jb:ImportLayers  (dwg llist / dbxDoc l ly)
  (if dwg
    (progn (setq dbxDoc (jb:OpenDbxDocument dwg));will return nil if the drawing is opened!!!
      (if dbxDoc
        (progn
           (setq l  (vla-get-layers dbxDoc)
                 ly (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
           (foreach
                  i  llist
             (vla-CopyObjects
               dbxDoc
               (vlax-safearray-fill
                 (vlax-make-safearray vlax-vbObject '(0 . 0))
                 (list (vla-item l i)))
               ly))
      (vlax-release-object ly)
           (jb:CloseDbxDocument dbxDoc))
        )
      )
    )
  )

;(jb:ImportLayerFilter(findfile "kb-layers-edit.dwg") "architectural")
(defun jb:ImportLayerFilter  (dwg xrec / dbxDoc l ly)
  (if dwg
    (progn (setq dbxDoc (jb:OpenDbxDocument dwg))
      (if dbxDoc
        (progn
           (setq l  (vla-item(vla-GetExtensionDictionary(vla-get-layers dbxDoc))"ACAD_LAYERFILTERS")
                 ly (vla-item(vla-GetExtensionDictionary
                      (vla-get-layers
                        (vla-get-ActiveDocument(vlax-get-acad-object))))"ACAD_LAYERFILTERS"))
           (vla-CopyObjects
               dbxDoc
               (vlax-safearray-fill
                 (vlax-make-safearray vlax-vbObject '(0 . 0))
                 (list (vla-item l xrec)))
               ly)
      (vlax-release-object ly)
           (jb:CloseDbxDocument dbxDoc))
        )
      )
    )
  )
;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;