(defun c:test (/
				c:dclInitialize
				)

(defun c:dclInitialize (/)
	(dcl_grid_addrow grid_form1_grid1 "")
)




	(command "_.OPENDCL")
	(dcl_Project_Load "grid" t)
	(dcl_form_show grid_form1)

(princ)
) ; test