;;;							;
;;;	kbWorkingStates v2.0				;
;;;	include files:					;
;;;		kbCommonFunctions			;
;;;		kbCommonLayerFunctions			;
;;;							;

(vl-load-com)

(if (not (vl-bb-ref 'kbLayerTools))
  (vl-bb-set
    'kbLayerTools
    (dcl_project_import
      '("YWt6A+PRAABY4FZVBuKTQ3USIrkPDVw7LNxbVDBTueGmiln38jxQBzljN7X2PVdogq/575pEd6TW"
"ubHNZy9sX7fYZYq92NDfyH/k3Nb1PSVKE+1qN+SqC+NIE6rk1H290HH//3gI/qQ+dH8LnkTwqvFV"
"OhMgGRgJkMPFpwWJkJCjjwkFQsCJmBgJGUFNRcXNRRFNfoZBiJvFgFYyvn4AeN95AQfHZd6lHNqy"
"i6h/uja9TgCt8sdj0UWO5L/FX2b/VwKg8EbdTndgoDNfkE6gc7xKAFe4bgBMWDnhLLIegmKccU6g"
"brm3nwvuLbIc5F0GSfwJ3Ya1CMJwH/I/sv0M38VX8K97ZT3KNMboNe78C3w++gs6eP+BcV3n7twG"
"eoR9cwTKegqbWqJ/P0Njn5VvRn65H0myvHdG+1vbFuFU9wgzmxZhuDbtTvihrU79x5uORPM7nNRR"
"N5q4tPei8yH0CGztRnBxvwAyqloCdp9YNzSOSyPAh2yuq+uNxmnBTTIacDVE/VtKF4DgMI1NZAon"
"/WCt3mmeNNZsdpNeCrQdtPwARxaJkR2xXK5BvISM9lHoinp4I2c6gjq0HgvaKowBLazTZooLc4QV"
"46hNf5Y5aJUBfZRbnFNbCtOh/TMJbPAffa7xpTTt7gCgF7fdji3wAKAHZpUXckAoNbvQHbBRQPhU"
"i/zTqn1/FsFTHOnQqtkKb4Esyac4c3TL5/7w6VoBu0CSrIOGA2bFoVIAhM/dsRzpWarBdfaF/9tJ"
"xLvJpkLgquoi2+UJIskb4IHpHiNp/thTll0/uklTFsNQlvFLbxGVBIKJ7HwTQPYjO9SfekyND8Lt"
"kD2WERd8EasrjD0jpokXrgCjw5GpJgVLFuF4o9k/Ya6bodjllPRG/CvEAF7nGS5oYFN0qMGu3JnV"
"ZIpLc4QNc+RT7OPs7GKr3h277NqgzyON+riE2niD2LCPebt4Gi4i/84AScizfxrjxWNrB9PFXP1W"
"FdxUpdzM6sbkO9v2yQ9jTyQqBN462x5bWlRJeHSkTGzvPAAsXCz6f69RxpEJdv1z+c+CR4YH2lv5"
"IjFjWq+woWdKpET1K+thSIsdtZIb1DbrkzlPAPz5yS33D/Q6EnvZgtqwiFTzS9DnWbp9A66qryYU"
"1pjQiFGeZPPpAD6G4Th4ep/js3672A2PsLi9sk3FT2nkCOOaQDQWLVNRv8UfPU858EjXN8Z/BHvK"
"sGoeDea3QPJ9hFfmPTR3CPRnjyDaFvA7mpds6EryBl1IBVY/dGPo4ADraUpI0GCuwu5G+TnNjTC1"
"ImGsvS7CR7yQfpqluMM49Uy5vknYz5Csewvy+18Xj23e2rsDJCQ2usTbe9pq16982gJYVcOo28YI"
"YTqDDXGugT0O8T2QIpEoIDXdy2umXqrSvhgpwHxV4m7TvoBlVkDo9q90knJKJf8zMifzWW1aHO3q"
"K188ej68tbX32xtW3ZuYN/LhuyEzZGA8OI73LF22SlEtLWQ9gpV2HNlPqz/CMJwteAFn0s4yw9DS"
"0dj4LZuL6wR5nFGDC2XnCWZHht7jk0k9Vgr/NVYemK3WVuIYix8Ea/T20f9sb4k+Ym8Paur2lnhb"
"XHrC2lycw1dbXND7mjr6Hjv19k8OM0xceIXetdH3v0BScJp56UaWRPJjCnJg+uG4QKUkH86HTgwY"
"cJjvUVcNQ+kmI9wfQ1avDm+c9vgx/GxzGR7r93h/W19kOqVUa3OpK8x4eqMBM3f45V/mJiOdbnJl"
"cY/C4dLEuARCFjPwc7Gr4c3e9X+WT3WEcXPEbgoPJzb2SbfxmCdvN49mqk9U+QSDDy7DgDvWzak5"
"st3dBcNSbkQoo2LjnMGi1SUK6xjFva9XBInMl5IQYjkXQmO9UfPS9/JlLM+v1b1JJK5jf5ZkdWSo"
"HBDb8l4h/vRdtqO7e8scb5yLp9O7m8gcusrQ8F/j3d3NGUoFk64Xq02KEvUkEJK5pyxBdJ9tjnZ0"
"kCfIsDJouw1BsV2EB1gvRNk2HFZFe/TX28yVIGK1lKR2j8f22i8j848mAS13LaGcYI6iYlKF89bo"
"KYp+hh5Sj4lPc6SsFptjHD/O5QskpBlb64lNz/kaLOvEEh9mn6DD1yp5/ETvxECGsLVRvnggWNjO"
"FSGoaODQpf5o37NEBrT0prtw1m5ohnFoaLL7QAbNxsZ29dFTvPsBhFzRE26ljXlhyBCjdKkhAUOi"
"Ao2zDqUTyb99cUJ+hYiT/SPFCL+WllZSgvxxnZ1AgnDCfIAlewaA62G8VRHCf+GDrCnPEupkZw+N"
"hlN+WTD3GG7oPyb4HsA/j26Qn/P5DnGf4BHcm2/gOQZgYYx2sYXiampuID4Gf597empukJ3N8bEA"
"/+2Lx2pgAI2GU65kbu3qty6nbvBKGu74clxNNzY9eBe2XnNn2l/9Sk7nNj14F7Zec2faX/1KTpc2"
"PXgXtl5zZ9pf/UoaTv1yrO8/REwy+RH0uequWfGhfAADLRrau72yQ7K2vTpD2vvVfwGKjrg9JELa"
"+9V7l47ucHGXjox6jTMrX2NgrJ5fc2CsPiuZX2NgrJ5fc3tUSYCZVLoCstke1Um9aptNipLl1LjC"
"jTYtYE2zHXgH2lfxB5mPuUJY7LEtJMAXcLBln+YBYI2xHYCqOgeyQTEO2l/xSpoD4eWzyvq5x20b"
"qsJ72t/+h2vuyHysL76Cxhf3cNL9fKwvXkTOHqKiZtf+ymru6HxsL75yx3VeU3vyJj7afHx0NnUL"
"9Xyv/BMsPiR0KmEydYt4FPtCCVthF47veGEXju94YReekPpKau54YReO7/h8rL4jcheO73hhF47v"
"eGEXvtqP9Q7avzlkAtq/Ua7YKDJ9bY1P3PE24DkT+pOWLWDqSJ8GDm3UfTnwYv+HhwcGnPdZnrdZ"
"4frpIAR34ACEFwaLqymfi6kh+Y2Zsb3lEcB3aVEg+jXpUL/7tUACgA3hPUBY8JgwMWhbDd/xsXjY"
"bFcO6P34+v0lAA5EGXMEL14flO/vPO+HkdI3Prn5bl5UAe3+9HEA74Y2hBP3tZ0dilSKJRow+53h"
"Q2W62ZavioUfbDL6NRlbQIFqM8H0MQtn5QDfwjYPT8AqGbOK5YaIV9beHAfUu4kzAsHCQf/FVZeE"
"yYdF3LkXgZ7IasEkgVFcx4ZY5AG0TPd2m4bFiAOuoK/LCqpJZK0dawycVJUlkp7oxATPnWx/0SWS"
"xj6voMWmj7gbfFIIwr6msQkC6O0Fz93ln5lSgqILeADQ/RmdDtAF7yuTDQN1A2KBOODfvwEkHx0k"
"FPEdVMeA3ah4FdjxQdXLWrkyiGVkyjf97Cop8coi/eOuR+CvXvnghZXPKqGhrt6h8dteASL91NXI"
"99JygrbxzREyXAAvseucU32CJHVI8oPr2LrPTI7KuHRTaLaEmOEUNMDeXQAn0S0BW36LJS7OKXYy"
"I0UoXIDSoJuTUbskHSauJgHcNYa5BEcONynC26bfG/wKNFNttqrAtxUBtaMg4Jyq2G7k/VIlsvmH"
"dqlOYapMiIxXQLobkpt94iRwTALmFWzBJ4LYbzS5xQQkHFEBiX/mPazw+dItn2MOBe5jGZPMLU0y"
"GUkmlCmDmOTEsx1x/WxX0SUuPOUVoBnoCNiHYiBBCP2Arv/AVwKMElnua7fntlPs021FbM83uRDa"
"HzVryxPr8He4H91LG/xd3oKepDWiR7A18olaVSJEi95k7EnJSimgNroYtGWndWLDuYB4LoyYxd5a"
"t6VIuVjPIL1dgAylHaFu1fozrawKzzKtFwUUxR+titVoakwzAaL8KNgXJNZxCyhnYuk7GfMR5NDY"
"2Yug9crwjWjRvV9F87DJoUNAx93R94/WJ8TVBaUpKQaiEZXPO+4deZapP5fPbM9gQwgVl6/jLV/T"
"qJbPs64q6bvozkVfgPrR8TBK+Ru+EAZ+ga0cmwD6yegnBBeUD+RZYvEezeIaawRLzLNh/xzleV9w"
"pUJ6a7m/+qaYiD2oDfTnnPunGPjxh+tgMuMahYHjRr7i+nGcjXq5RPiuV8CtU8cUSBvx/RXewatD"
"njjNp+RmBr2lkNp1xsijC/uJ41pc/pxT18kAzeM6Etg+hCXWVu7opRhFv6TfXahdt9BQI7Z0cYnM"
"CivQ4ltf5fD+7DMzoDRZt1nK6xDbN+D6SL+jLgNtIiwlobad/2qdUPl6wly2CnGIr8PCjdBPF2ax"
"5CbNly7OJA9sgw/judlLVlqEuFI254UAW74HaUpGs4erJLMDfIAoTCX0SfvLT83OAkSfN/Py/F/3"
"WPjkhQtjSwcnW6Cod/k6hboUpUSPDUS54nirw79c4HILku1Wa9Vrip80bNAvbzVeT+wskN3mDfBx"
"XjHOF+uyy91G4BjTh+twTRE5tt5LuuxpM4zANw+W1kxnHw32PReEktlN9a4v4KHu7wj288lH2g76"
"LVotk1bl+VlO4zf4m6YVWR/xzOcGah9gyBlzAESzH9oEggpMli1kKqvdmB51QhQ0YLWt3dj+7I7W"
"B+u7NLzd2P7gr97UYEvRdHFpP33sNFJA2IQfaTwx6HWeJEIQiHjH+o2uvKTPQkO2rL9rAzOy7JUp"
"j9wpotrJ0x4tGcLLSycgdpcUaV6wpKRqVouTSy4VFfOyNqE9aw/8sf7F48WLXatH4M3gULSrWEeb"
"bf+qpHNqXD42X+lMckZ6NnHHakX4DJ96dN1tVrB3m1+zQuXplxINNWJXKSC4Wgrh+PO8fGRyPuH/"
"Rmw+PvfHZe1gJI206x3N/U6Mk9/82FRQGEPZZ0daahrcnUZtpN0Zp0mXTFCXaDB/Sydq/qgN3Nt9"
"Ezh21WkM4tH8gaDO+YfUgAVzzTfqyGRv+hZL/LAp0ytLnME/d28fghZLvMk6SrGDJyeJIT8sXyR6"
"NoNstyOYBFUTw+AYqR9dEhWisDGttqCY02YtCMhD94kYWDEl0xc1iNrj6TGPmJQegDAucfs88JmG"
"J/DNfUE94tx5JyBbZruBfeKcfr2sQgWxj1Q86GPeC+qyoUmkTCKTbilGATGpvO6vUQtuo4CRS6lG"
"OJ0WKG654mOkFxtszSw3gOg07b0MubilCqLUEWM3qYmob/eoriU5rFMmXTdZzDgsyF5sCI5VI8lY"
"ecFzlee8klOIH1UtvxZhyPCLAGdxFIgfVRdbn72oz2UpliQsYcgs1RPJsWuiQPlLJZ/J5nAA5c9m"
"itGuKlPQ8Nce7cpGVxb277vkK81tJR/Am5i6SOAu7vYzCBwlqz0bBJPE3Wh/7s4g5SYk+MxiSCzo"
"kytFhumTBmPICT07NWmXrq0CRkwZH4qIxB+gEx2gL6mbqvGp6wviqiXIdD0ZZsF1LuW+UguOZcV1"
"0E9Z17NkMqIFBynDjZ2x/WQk7AoAwlL46AF+S8pS842dzkZue1Xo/aHUEC+tFa9TFBU7P6WLj2Vu"
"OU5GImGBbNJMv17e2iJh+TEvtNrSWHnBC2Ot1eEBPLJciJhrnmcmhBGz4P/bNcmQhpuJfjQwZBLM"
"jmRjgiiLUOQQBWnzx8/E8LQldGUGpUdN+UMuD/LVh8L29vPrn+JHz7/Pi7Dq0c7e5DH+AnF8Fzd9"
"hhj1qAi2pQi2lctjjMhjjMhjjCi0wZPuyZPuyZPuiT3OVGKMyMPI0C/R00w7Jx0gJYFnqgI6mG4z"
"IulfLqWLy/4o45WVmxChSHAHt0eRXu7rBWrBXYL0pGPCYhIgHuXIEAbNgsSkk9bfmY5JDKTln+Pe"
"7QI4Cs6yXxHNkqVLRprTlOZKowgyJHAU+G+SJ/XLlEkpqxOWDEZP6H8Xx2fEnPPjbM97WZn2ACcz"
"05Q4CStHMjPqId2DfAF15LS8bA8nhHuASFaY8plpxhDAFjbZ0qV+UhAK6bB+Utija54BKZoEs4AJ"
"G329rAp0vG19DvMQCqVQHB/3y3q5QMfRvoyqbOi7COZFU9bU+fOKpAh+Y2hw5ZNxC8S405SETaMI"
"g6eEg/gVuPOOkfxs0zfEbyCn3Cs2M7SrEQYtJ+H7uQwhpYjQl0XDFegRfCVoJcGozNUeL6EpvqhR"
"vzS2Kw4crNSLsAFtp4Q7cBfJJoYjcOdol+7Ik+8tPlWoXRnXVjCgXRmlGQ/uuWyEUmjfwqpA9W1t"
"yXCxuhwDF8MbJTL/uhxgwX0K9jPymMPgYGVseaa25hgtWEfwW+IflQYY5DPofRIgYh8tGqaTUudM"
"rahCR7b4t3dAEEUas+gnCCFF/8fyji+jUpzzzqcN3IbQrGJxylDNG3vJzeckxkmkE/OK1OQDqjIn"
"0lpC2bRVRTxAFODP3tTgLamRn1vEHYiiLtZ9QhmP5Zng6T+LRvG3SpRCuJ8zM6yi+YuPdkWi38U5"
"x4FgnrO76jIL2cKfd+uKPan61AVRRZZGY4x6p3JLIc48PfKyvCmpd3Ef/OSrAn/zldDh+uRRJrNF"
"n88L8mNCs87V6XeF+N00cO/tZN16yiH1ylgzd3oqjeo+JM0qKQmGw7TOwGaYtIjfyVNkaoHzXort"
"Dq4TcGemhy8guIrs7wChqVXX3FNEKCz9KZb69yYER1hokOSrHicscrdgR8Qk8SrH1YL7p7k9K6sR"
"oecIdgFbtkpBt/XN8Y0lrJiSfAvwgbHcSqT6q1WRKkUbac0XhoB+hfZwYeHBQ09HW708NjC3huna"
"c7WfZoiDJJ6pjZhL+e1B7C2sbOtyU/D791vJ6fq7/PK2UM/OH/Kn1qLhPJV6urhPtbmbWtJqj471"
"3rr94v4L1liL9vnltoW7ck2QQtVgzeiLWY+Qb4XkuuL7eRzdZxFZ0+W7287THQ8X+ixoCSZv9rtL"
"adJaGNn7YBy6V/DIf0Rx4JGDk6GEiMWAjkICZ5CBuDkYMd28qT/5EcyINhNosp9lJ8gzvwWycfBd"
"yfXVT5Kix81YGm0UPPBh22PoDV6w5BANKEXq+URGw3DPzvQbdg/oqZjSmr0DYooDq1ZP7xU0x/CK"
"ld7BY7z/RpXfdrAEefbNoM+ijNacUt36UBa4zB+/gsbOHlCKJ05wJtRHDubprhNQHtENow3ijAIJ"
"kUlPCrGxr5vXh4eg2WZAiTM4OpPpz4+wnrGz6b0znA2I7+/E9cewLbNCYi9NEQ2zwpPW58AusypE"
"2iDXGNYo1gjcFJjyc+IycSBNZniw4peT3uXgTQMxZz6RG32WBaiqMpEbcvahiVJ4woggSI9pRjvE"
"3c6+qeBNQwIjVpj4Tk7Z0+3pvFHCguMkgVSoFfvqX5rQ3yz2vlFYJgLyvlHFUTgydCFdKbxRPdYk"
"IPMiCKFGAOaMTHSdyilG+8yAbv9x1PE7nhWaloAoOZFThV2wXIH7E4NYKPYnUDoFgq3xnWHIysPX"
"Ys+m8TWAVKnfNyiBX8IPglxbyDFU1FTb0Y9t39nwhCfyKYGxQYnCTRzbShVzuic5XUbVR4QzU90G"
"bjJQRkAtZYjiJ8Y6TgJKjvs1eHAudzDpdT8KhbY2Q0RJ1OenyLInHx/ZVVr2oXDz+YF5J8Tigw==")
      )
    )
  )


;;;							;
;;;	Utility Functions				;
;;;							;
(defun kb:striplayername (string / pos ret)
  (if (vl-string-position (ascii "|") string)
    (setq pos (+ (vl-string-position (ascii "|") string) 2)
	  ret (substr string pos (+ (- (strlen string) pos) 1))
	  )
    (setq ret string)
    )
  ret
  )



(defun kb:GetLayerList (xref / layers ret)
  (setq layers (vla-get-layers (vla-get-activedocument (vlax-get-acad-object))))
  (cond	((= xref "*") ;gets all layers
	 (vlax-for x layers (setq ret (append ret (list (vla-get-name x)))))
	 )
	((= xref nil) ;gets only active doc layers
	 (vlax-for
		x
		 layers
	   (if (not (vl-string-search "|" (vla-get-name x)))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	((= xref "xr") ;gets all xref layers
	 (vlax-for
		x
		 layers
	   (if (vl-string-search "|" (vla-get-name x))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	(t ;gets a specific xref's layers
	 (vlax-for
		x
		 layers
	   (if (vl-string-search (strcat xref "|") (vla-get-name x))
	     (setq ret (append ret (list (vla-get-name x))))
	     )
	   )
	 )
	)
  ret
  )


(defun kb:load-plotstyle (dbxDoc lpltstyle / tempobj doc)
  (if (not (member (cons 3 lpltstyle)
		   (dictsearch (namedobjdict) "ACAD_PLOTSTYLENAME")
		   )
	   )
    (setq newln
	   (vl-catch-all-apply
	     'vla-CopyObjects
	     (list
	       dbxDoc
	       (vlax-safearray-fill
		 (vlax-make-safearray vlax-vbObject '(0 . 0))
		 (list (vla-item
			 (vla-item (vla-get-Dictionaries dbxDoc) "ACAD_PLOTSTYLENAME")
			 lpltstyle
			 )
		       )
		 )
	       (vla-item
		 (vla-get-Dictionaries (vla-get-activedocument (vlax-get-acad-object)))
		 "ACAD_PLOTSTYLENAME"
		 )
	       )
	     )
	  )
    )
  newln
  )

;;;							;
;;;	Layer States					;
;;;							;

(defun kb:LayerStateEngine (lstatename	  dwgname	layerlist     /
			    dbxdoc	  dbxdict	dict	      dbxplotstyles
			    dbxlayernames dbxlinetypes
			    )
  (setvar "clayer" "0")
  (princ "\nSetting the current layer to 0")
  (princ)
  (setq dbxdoc (kb:OpenDbxDocument DwgName))
  (if dbxdoc
    (progn (setq lstateobj (kb:getlayerobject))
	   (if lstateobj
	     (progn (vla-setdatabase lstateobj (vla-get-database dbxdoc))
		    (vlax-invoke lstateobj 'restore lstatename)
		    (setq dbxlayers (vla-get-layers dbxdoc)
			  layers    (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
			  )
    ;get a list of layers in the dbxdoc - because there's no "has" method!
		    (vlax-for
			   x
			    (vla-get-layers dbxdoc)
		      (setq dbxlayernames
			     (append dbxlayernames (list (strcase (vla-get-name x))))
			    )
		      )
    ;(setq n "X_Base43|A-Wall-Patt")
    ;(setq n(nth 3 layerlist))
		    (foreach
			   n
			    layerlist
		      (if (and (not (= n "0"))
			       (member (strcase (kb:striplayername n)) dbxlayernames)
			       )
			(progn (setq lobj    (vla-item layers n)
				     lobjdbx (vla-item dbxlayers (kb:striplayername n))
				     )
			       (foreach
				      property
					      (list "Freeze"	  "LayerOn"	"Lineweight"
						    "Lock"	  "Plottable"	"color"
						    )
				 (vlax-put lobj property (vlax-get lobjdbx property))
				 )
    ;set plotstyle
			       (setq ps (vlax-get lobjdbx "PlotStyleName"))
			       (kb:load-plotstyle dbxdoc ps)
			       (vlax-put lobj "PlotStyleName" ps)
    ;set linetype
			       (setq ln (vlax-get lobjdbx "Linetype"))
			       (if (not (tblsearch "ltype" ln))
				 (setq newln
					(vl-catch-all-apply
					  'vla-CopyObjects
					  (list	dbxDoc
						(vlax-safearray-fill
						  (vlax-make-safearray vlax-vbObject '(0 . 0))
						  (list (vla-item (vla-get-linetypes dbxDoc) ln))
						  )
						(vla-get-linetypes (vla-get-activedocument (vlax-get-acad-object)))
						)
					  )
				       )
				 )
			       (if (tblsearch "ltype" ln)
				 (vlax-put lobj "Linetype" ln)
				 )
			       )
			)
		      )
		    )
	     )
	   (kb:CloseDbxDocument dbxdoc)
	   (vlax-release-object lstateobj)
	   )
    )
  (vla-regen
    (vla-get-activedocument (vlax-get-acad-object))
    acActiveViewport
    )
  )

;;;(kb:ReturnDBXLayerStates)
(defun kb:ReturnDBXLayerStates (/		  dbxdoc	    lstate-dict-object
				lstate-dict	  named-obj-dict    ldict
				acad_lstate	  acad_lstate_defs
				)
  (setq file (kb:ReturnLayerStandardsFile))
  (if file
    (progn
      (setq dbxdoc (kb:opendbxdocument (findfile file)))
      (if dbxdoc
	(progn
	  (setq	lstate-dict-object
		 (vla-GetExtensionDictionary (vla-get-layers dbxdoc))
		lstate-dict
		 (entget (vlax-vla-object->ename lstate-dict-object))
    ;(vlax-dump-Object lstate-dict-object)
		named-obj-dict
		 (vlax-vla-object->ename (vla-get-Dictionaries dbxdoc))
		)
	  (if lstate-dict
	    (progn
	      (if (setq ldict (member (cons 3 "ACAD_LAYERSTATES") lstate-dict))
		(progn (setq acad_lstate (cdr (assoc 360 ldict)))
		       (foreach
			      x
			       (entget acad_lstate)
			 (if (and (eq 3 (car x)))
			   (setq acad_lstate_defs (append acad_lstate_defs (list (cdr x))))
			   )
			 )
		       (vlax-release-object lstate-dict-object)
		       )
		)
	      )
	    )
	  (kb:CloseDbxDocument dbxdoc)
	  )
	)
      )
    )
  acad_lstate_defs
  )



;;;								;
;;;	Import Layers 						;
;;;								;

;;;								;
;;;	Get a list of layers via ObjectDBX			;
;;;	filters out xref layers and 0, defpoints		;
;;;								;
(defun kb:GetMasterLayerList (dwg / lname llist dbxdoc)
  (if dwg
    (progn (setq dbxDoc (kb:OpenDbxDocument dwg))
	   (if dbxDoc
	     (progn (vlax-for
			   i
			    (vla-get-layers dbxDoc)
		      (setq lname (vla-get-name i))
		      (if (or
			    (not (wcmatch (strcase lname) "*|*"))
			    (not (wcmatch (strcase lname) "DEFPOINTS"))
			    (not (wcmatch (strcase lname) "0"))
			    )
			(setq llist (append llist (list lname)))
			)
		      )
		    (kb:CloseDbxDocument dbxDoc)
		    )
	     )
	   )
    )
  llist
  )

    ;(kb:FilterLayerList (kb:GetMasterLayerList nil) "A-Wall*")
(defun kb:FilterLayerList (llist fi / li)
  (foreach
	 i
	  llist
    (if	(wcmatch (strcase i) (strcase fi))
      (setq li (append li (list i)))
      )
    )
  li
  )

    ;(kb:GetLayerFilters kb%ImpLayFile)
    ;(setq dwg kb%ImpLayFile llist nil)
(defun kb:GetLayerFilters (dwg / dict lf lfdict flist llist dbxDoc)
  (if dwg
    (setq dbxDoc (kb:OpenDbxDocument dwg))
    (setq dbxDoc (vla-get-activedocument (vlax-get-acad-object)))
    )
  (setq	dict (vla-GetExtensionDictionary (vla-get-layers dbxDoc))
	lf   (vl-catch-all-apply 'vla-item (list dict "ACAD_LAYERFILTERS"))
	)
  (if (vl-catch-all-error-p lf)
    (setq llist nil)
    (progn (setq lfdict (vlax-vla-object->ename lf))
	   (foreach
		  i
		   (entget lfdict)
	     (if (= (car i) 3)
	       (setq flist (append flist (list (cdr i))))
	       )
	     )
	   (foreach
		  i
		   flist
	     (setq
	       llist (append llist
			     (list (cons i (list (cdr (nth 10 (dictsearch lfdict i))))))
			     )
	       )
	     )
	   )
    )
  (if dbxDoc
    (kb:CloseDbxDocument dbxDoc)
    )
  llist
  )


;;;*02								;
;;;	OpenDCL Subs						;
;;;								;

;;;								;
;;;	Import Layers						;
;;;								;

(defun kb:ImportLayers_OnInitialize
       (/ fileName fi layerlist st parent parent-list child-list misc-list)
  (if (not (setq fileName
		  (vl-registry-read
		    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"
		    "fileName"
		    )
		 )
	   )
    (setq fileName (kb:ReturnLayerStandardsFile))
    )
  (if fileName
    (progn
      (dcl_Tree_Clear kb001_00_LayerFilters)
      (dcl_Control_SetProperty kb001_00_SetLayerCurrent "Enabled" t)

      (dcl_Control_SetProperty kb001_00_PATH "Caption" fileName)
      (setq fi	      (kb:GetLayerFilters fileName)
	    layerlist (kb:GetMasterLayerList fileName)
	    )
      (dcl_ListBox_Clear kb001_00_Layers)
;;; If Layer List exists
      (if layerlist
	(progn (foreach
		      i
		       (list "Defpoints" "defpoints" "DEFPOINTS" "0")
		 (setq layerlist (vl-remove i layerlist))
		 )
	       (dcl_ListBox_AddList kb001_00_Layers layerlist)
	       )
	(dcl_ListBox_AddList
	  kb001_00_Layers
	  (list "The layer Standards file is opened!" "Contact IT")
	  )
	)
      (dcl_Tree_AddParent kb001_00_LayerFilters "All Layers" "*" 0 0 0) ;load parents
      (if fi
	(progn
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (if	(and (= (length st) 2) (= (cadr st) 42)) ; = "A*", or "S*" - New Parent
	      (progn (setq parent-list (append parent-list (list (cadr n))))
		     (dcl_tree_addchild kb001_00_LayerFilters "*" (car n) (cadr n) 0 0 0)
		     )
	      )
	    ) ;load children
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (cond
	      ((and (= (length st) 2) (= (cadr st) 42)))
	      ((member (setq parent (strcat (chr (car st)) "*")) parent-list)
	       (setq child-list (append child-list (list parent (cadr n))))
	       (dcl_tree_addchild kb001_00_LayerFilters parent (car n) (cadr n) 0 0 0)
	       )
	      (t
	       (setq misc-list (append misc-list (list "misc" (cadr n))))
	       (dcl_tree_addchild kb001_00_LayerFilters "*" (car n) (cadr n) 0 0 0)
	       )
	      )
	    ) ;expand tree
	  (dcl_Tree_ExpandItem kb001_00_LayerFilters "*" 1)
	  (Setq rValue (dcl_Tree_GetFirstChildItem kb001_00_LayerFilters "*"))
	  (dcl_Tree_ExpandItem kb001_00_LayerFilters rValue 1)
	  (dcl_Tree_EnsureVisible kb001_00_LayerFilters rValue)
	  (foreach
		 key
		    parent-list
	    (if	(dcl_Tree_ItemHasChildren kb001_00_LayerFilters key)
	      (progn (dcl_Tree_ExpandItem kb001_00_LayerFilters key 1)
		     (dcl_Tree_EnsureVisible
		       kb001_00_LayerFilters
		       (dcl_Tree_GetFirstChildItem kb001_00_LayerFilters key)
		       )
		     )
	      )
	    )
	  )
	)
      )

    (progn
      (dcl_Control_SetProperty kb001_00_PATH "Caption" "")
      (dcl_ListBox_AddString
	kb001_00_LAYERS
	"Select a Drawing to Import Layers"
	)
      (c:kb001_00_OpenLayerImportFile_OnClicked)
      )
    )
  )




(defun c:kb001_00_OpenLayerImportFile_OnClicked	(/ fileName)
  (setq	fileName
	 (getfiled
	   "Select a file"
	   (vl-filename-directory (kb:ReturnLayerStandardsFile))
	   "dwg"
	   0
	   )
	)
  (if fileName
    (progn

      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"
	"fileName"
	fileName
	)
      (kb:ImportLayers_OnInitialize)
      )
    )
  (princ)
  (princ)
  )

(defun c:kb001_00_LAYERFILTERS_OnSelChanged (sSelText SelKey / fileName)
  (setq fileName (dcl_Control_GetCaption kb001_00_PATH))
  (dcl_ListBox_Clear kb001_00_Layers)
  (dcl_ListBox_AddList
    kb001_00_Layers
    (kb:FilterLayerList (kb:GetMasterLayerList fileName) SelKey)
    )
  )


(defun c:kb001_00_IMPORTLAYER_OnClicked	(/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_00_Layers)
	fileName  (dcl_Control_GetCaption kb001_00_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (foreach
	     x
	      (dcl_ListBox_GetSelectedNths kb001_00_Layers)
	(dcl_ListBox_SetSel kb001_00_Layers x nil)
	)
      (foreach x layerList (princ (strcat "\n" x " has been imported!")))
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_00_SETLAYERCURRENT_OnClicked (/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_00_Layers)
	fileName  (dcl_Control_GetCaption kb001_00_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (kb:setclayer (car layerList) t)
      (dcl_form_close kb001_00)
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_00_Layers_OnSelChanged (nSelection sSelText /)
  (if (> nSelection 1)
    (dcl_Control_SetProperty kb001_00_SetLayerCurrent "Enabled" nil)
    (dcl_Control_SetProperty kb001_00_SetLayerCurrent "Enabled" t)
    )
  (princ)
  (princ)
  )




;;;*03								;
;;;	Working States						;
;;;								;
    ;(setq reportList nil)
(defun kb:WorkingStates_OnInitialize (/ dbxLlist xrefList)
  (dcl_ListView_Clear kb001_00_XREFS)

  (if(=(dcl_ListView_GetColumnCount kb001_00_XREFS)0)
  (dcl_ListView_AddColumns
    kb001_00_XREFS
    (list
      (list "Layer Containers"
	    1
	    (- (dcl_Control_GetWidth kb001_00_XREFS) 5)
	    0
	    )
      )
    )
    )
  
(dcl_ListBox_Clear kb001_00_LayerStates)
;;; layer states list control
  (dcl_ListView_AddItem
	kb001_00_XREFS
	(list 1 "All Layers")
	)

  (dcl_ListView_AddItem
	kb001_00_XREFS
	(list 0 (getvar "dwgname"))
	)

  (setq xrefList (kb:listxrefs)
	)

  (if xreflist
    (foreach
	   x xreflist
      (dcl_ListView_AddItem
	kb001_00_XREFS
	(list 2 x)
	)
      )
    )

  (setq dbxLlist (kb:ReturnDBXLayerStates))
  (if dbxLlist
    (dcl_ListBox_AddList kb001_00_LayerStates dbxLlist)
    (dcl_ListBox_AddList
      kb001_00_LayerStates
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
  (princ)
  (princ)
  )


(defun kb:00-restore (lsname xrefname /)
  (cond	((= xrefname (getvar "dwgname"))
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList nil)
	   )
	 )
	((= xrefname "All Xrefs")
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList "xr")
	   )
	 )
	((= xrefname "All Layers")
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList "*")
	   )
	 )
	(t
	 (kb:LayerStateEngine
	   lsname
	   (kb:ReturnLayerStandardsFile)
	   (kb:GetLayerList xrefname)
	   )
	 )
	)
  (princ)
  (princ)
  )


(defun c:kb001_00_LayerStates_OnSelChanged (nSelection sSelText /)
  (if kb:ChangeLayerKeys
    (kb:ChangeLayerKeys)
    )
  (princ)
  )


    ;(c:kb001_00_Restore_OnClicked)
(defun c:kb001_00_Restore_OnClicked (/ lsname xrefname)
  (setq	lsname	 (dcl_ListBox_GetText
		   kb001_00_LayerStates
		   (dcl_ListBox_GetCurSel kb001_00_LayerStates)
		   )
	xrefname (dcl_ListView_GetSelectedItems kb001_00_XREFS)
	)
  (if (not xrefname)
    (progn (setq xrefname (list "All Layers"))
	   (dcl_ListView_SetCurSel kb001_00_XREFS 0)
	   )
    )
  (if (and lsname (/= lsname ""))
    (cond ((= (vl-list-length xrefname) 1)
	   (kb:00-restore lsname (nth 0 xrefname))
	   )
	  ((> (vl-list-length xrefname) 1)
	   (foreach
		  x
		   xrefName
	     (kb:00-restore lsname x)
	     )
	   )
	  )
    (alert "Select a Layer Display!")
    )
  (princ)
  (princ)
  )


(defun c:kb001_00_ThawVP_OnClicked (/)
  (if (= (getvar "tilemode") 0)
    (command "vplayer" "_thaw" "*" "current" "" "")
    (not (dcl_MessageBox "Not allowed in Model Space!" "Thaw VP Layers" 2 1)
	 )
    )
  (princ)
  (princ)
  )


(defun c:kb001_00_LayerStates_OnDblClicked (/ path layerlist)
  (c:kb001_00_Restore_OnClicked)
  (princ)
  (princ)
  )

(defun c:kb001_00_OnClose (nUpperLeftX nUpperLeftY /)
  (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

  "isFloating"
	"false"
	)
  (princ)
  (princ)
  )

(defun c:kb001_00_OnInitialize (/)
  (kb:ImportLayers_OnInitialize)
  (kb:WorkingStates_OnInitialize)
  (princ)
  (princ)
  )



(defun c:kb001_00_OnDocActivated (/)
  (if (dcl_Form_IsActive kb001_00)
    (c:kb001_00_OnInitialize)
    )
  (princ)
  (princ)
  )


(defun c:kb001_00_Refresh_OnClicked (/)
  (c:kb001_00_OnInitialize)
  (princ)
  (princ)
  )

(defun c:kb001_00_OnEnteringNoDocState (/)
  (dcl_form_close kb001_00)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

    "isFloating"
    "true"
    )
  (princ)
  (princ)
  )


;;;								;
;;;	Tray Functions						;
;;;								;
(defun c:kb001_00_Close_OnClicked (/)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

    "isFloating"
    "false"
    )
  (dcl_form_close kb001_00)
  (princ)
  )


;; show toolbar
(defun c:kb001_00_Tray_OnClicked (/ rValue)
  (Setq rValue (dcl_Form_GetRectangle kb001_00))
  (dcl_form_close kb001_00)

    ;show at same location
    ;(if (not (dcl_Form_IsActive kb001_01))
    ;  (dcl_Form_Show kb001_01 (nth 0 rValue) (nth 1 rValue))
    ; )


    ;show at saved location - registry
  (if (not (dcl_Form_IsActive kb001_01))
    (dcl_Form_Show kb001_01)
    )
  (princ)
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;								;

(defun c:kbLayerTools (/)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive kb001_01))
	(if (not (dcl_Form_IsActive kb001_00))
	  (dcl_Form_Show kb001_00)
	  )
	)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;*04								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:001_00_IsFloating (/)
  (if dcl_HideErrorMsgBox
    (if	(and (not (dcl_Form_IsActive kb001_00))
	     (=	(vl-registry-read
		  "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_00"

		  "isFloating"
		  )
		"true"
		)
	     )
      (c:kbLayerTools)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

(kb:001_00_IsFloating)

;;;								;
;;;	LayerStates Tool Bar					;
;;;								;

(defun c:kb001_01_OnInitialize (/)
  (dcl_ComboBox_Clear kb001_01_ComboBox)
  (dcl_ComboBox_AddList
    kb001_01_ComboBox
    (kb:ReturnDBXLayerStates)
    )
  (dcl_ComboBox_SetCurSel kb001_01_ComboBox 0)
  )

(defun c:kb001_01_OnEnteringNoDocState (/)
  (dcl_form_close kb001_01)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_01"

    "isFloating"
    "true"
    )
  (princ)
  (princ)
  )

(defun c:kb001_01_LayerStates_OnClicked	(/ rValue)
  (Setq rValue (dcl_Form_GetRectangle kb001_01))
  (dcl_form_close kb001_01)
    ;show at same location
    ;(if (not (dcl_Form_IsActive kb001_00))
    ;  (dcl_Form_Show kb001_00 (nth 0 rValue) (nth 1 rValue))
    ;  )

    ;show at saved location - registry
  (if (not (dcl_Form_IsActive kb001_00))
    (dcl_Form_Show kb001_00)
    )
  )


(defun c:kb001_01_ComboBox_OnSelChanged	(nSelection sSelText /)
  (princ sSelText)
  (princ)

  (kb:LayerStateEngine
    sSelText
    (kb:ReturnLayerStandardsFile)
    (kb:GetLayerList "*")
    )

  )


(defun c:kb001_01_Close_OnClicked (/)
  (dcl_form_close kb001_01)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_01"

    "isFloating"
    "false"
    )
  (princ)
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;	(dcl_Form_GetRectangle kb001_01)816 74			;
;;;								;
(defun c:kbLayerToolsTB	(/)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive kb001_00))
	(if (not (dcl_Form_IsActive kb001_01))
	  (dcl_Form_Show kb001_01) ; 816 74)
	  )
	)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:001_01_IsFloating (/)
  (if dcl_HideErrorMsgBox
    (if	dcl_HideErrorMsgBox
      (if (and (not (dcl_Form_IsActive kb001_01))
	       (= (vl-registry-read
		    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_01"

		    "isFloating"
		    )
		  "true"
		  )
	       )
	(c:kbLayerToolsTB)
	)
      (alert "The OpenDCL arx module did not load!")
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )


(kb:001_01_IsFloating)


;;;								;
;;;	OpenDCL Subs - Palette					;
;;;								;

;;;								;
;;;	Import Layers						;
;;;								;

(defun kb:ImportLayers_02_OnInitialize
       (/ fileName fi layerlist st parent parent-list child-list misc-list)
  (if (not (setq fileName
		  (vl-registry-read
		    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"
		    "fileName"
		    )
		 )
	   )
    (setq fileName (kb:ReturnLayerStandardsFile))
    )
  (if fileName
    (progn
      (dcl_Tree_Clear kb001_02_LayerFilters)
      (dcl_Control_SetProperty kb001_02_SetLayerCurrent "Enabled" t)

      (dcl_Control_SetProperty kb001_02_PATH "Caption" fileName)
      (setq fi	      (kb:GetLayerFilters fileName)
	    layerlist (kb:GetMasterLayerList fileName)
	    )
      (dcl_ListBox_Clear kb001_02_Layers)
;;; If Layer List exists
      (if layerlist
	(progn (foreach
		      i
		       (list "Defpoints" "defpoints" "DEFPOINTS" "0")
		 (setq layerlist (vl-remove i layerlist))
		 )
	       (dcl_ListBox_AddList kb001_02_Layers layerlist)
	       )
	(dcl_ListBox_AddList
	  kb001_02_Layers
	  (list "The layer Standards file is opened!" "Contact IT")
	  )
	)
      (dcl_Tree_AddParent kb001_02_LayerFilters "All Layers" "*" 0 0 0) ;load parents
      (if fi
	(progn
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (if	(and (= (length st) 2) (= (cadr st) 42)) ; = "A*", or "S*" - New Parent
	      (progn (setq parent-list (append parent-list (list (cadr n))))
		     (dcl_tree_addchild kb001_02_LayerFilters "*" (car n) (cadr n) 0 0 0)
		     )
	      )
	    ) ;load children
	  (foreach
		 n
		  fi
	    (setq st (vl-string->list (cadr n)))
	    (cond
	      ((and (= (length st) 2) (= (cadr st) 42)))
	      ((member (setq parent (strcat (chr (car st)) "*")) parent-list)
	       (setq child-list (append child-list (list parent (cadr n))))
	       (dcl_tree_addchild kb001_02_LayerFilters parent (car n) (cadr n) 0 0 0)
	       )
	      (t
	       (setq misc-list (append misc-list (list "misc" (cadr n))))
	       (dcl_tree_addchild kb001_02_LayerFilters "*" (car n) (cadr n) 0 0 0)
	       )
	      )
	    ) ;expand tree
	  (dcl_Tree_ExpandItem kb001_02_LayerFilters "*" 1)
	  (Setq rValue (dcl_Tree_GetFirstChildItem kb001_02_LayerFilters "*"))
	  (dcl_Tree_ExpandItem kb001_02_LayerFilters rValue 1)
	  (dcl_Tree_EnsureVisible kb001_02_LayerFilters rValue)
	  (foreach
		 key
		    parent-list
	    (if	(dcl_Tree_ItemHasChildren kb001_02_LayerFilters key)
	      (progn (dcl_Tree_ExpandItem kb001_02_LayerFilters key 1)
		     (dcl_Tree_EnsureVisible
		       kb001_02_LayerFilters
		       (dcl_Tree_GetFirstChildItem kb001_02_LayerFilters key)
		       )
		     )
	      )
	    )
	  )
	)
      )

    (progn
      (dcl_Control_SetProperty kb001_02_PATH "Caption" "")
      (dcl_ListBox_AddString
	kb001_02_LAYERS
	"Select a Drawing to Import Layers"
	)
      (c:kb001_02_OpenLayerImportFile_OnClicked)
      )
    )
  )




(defun c:kb001_02_OpenLayerImportFile_OnClicked	(/ fileName)
  (setq	fileName
	 (getfiled
	   "Select a file"
	   (vl-filename-directory (kb:ReturnLayerStandardsFile))
	   "dwg"
	   0
	   )
	)
  (if fileName
    (progn

      (vl-registry-write
	"HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"
	"fileName"
	fileName
	)
      (kb:ImportLayers_OnInitialize)
      )
    )
  (princ)
  (princ)
  )

(defun c:kb001_02_LAYERFILTERS_OnSelChanged (sSelText SelKey / fileName)
  (setq fileName (dcl_Control_GetCaption kb001_02_PATH))
  (dcl_ListBox_Clear kb001_02_Layers)
  (dcl_ListBox_AddList
    kb001_02_Layers
    (kb:FilterLayerList (kb:GetMasterLayerList fileName) SelKey)
    )
  )


(defun c:kb001_02_IMPORTLAYER_OnClicked	(/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_02_Layers)
	fileName  (dcl_Control_GetCaption kb001_02_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (foreach
	     x
	      (dcl_ListBox_GetSelectedNths kb001_02_Layers)
	(dcl_ListBox_SetSel kb001_02_Layers x nil)
	)
      (foreach x layerList (princ (strcat "\n" x " has been imported!")))
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_02_SETLAYERCURRENT_OnClicked (/ layerList fileName)
  (setq	layerList (dcl_ListBox_GetSelectedItems kb001_02_Layers)
	fileName  (dcl_Control_GetCaption kb001_02_PATH)
	)
  (if fileName
    (progn
      (kb:ImportLayers fileName layerList)
      (kb:setclayer (car layerList) t)
      )
    (dcl_messagebox "No Import File has been selected!" "Set Layer Current")
    )
  (princ)
  (princ)
  )

(defun c:kb001_02_Layers_OnSelChanged (nSelection sSelText /)
  (if (> nSelection 1)
    (dcl_Control_SetProperty kb001_02_SetLayerCurrent "Enabled" nil)
    (dcl_Control_SetProperty kb001_02_SetLayerCurrent "Enabled" t)
    )
  (princ)
  (princ)
  )




;;;*03								;
;;;	Working States						;
;;;								;
    ;(setq reportList nil)
(defun kb:WorkingStates_02_OnInitialize	(/ dbxLlist xrefList reportList)
  (dcl_ListView_Clear kb001_02_XREFS)
  
  (if(=(dcl_ListView_GetColumnCount kb001_02_XREFS)0)
  (dcl_ListView_AddColumns
    kb001_02_XREFS
    (list
      (list "Layer Containers"
	    1
	    (- (dcl_Control_GetWidth kb001_02_XREFS) 5)
	    0
	    )
      )
    )
    )

(dcl_ListBox_Clear kb001_02_LayerStates)
;;; layer states list control
(dcl_ListView_AddItem
	kb001_02_XREFS
	(list 1 "All Layers")
	)

  (dcl_ListView_AddItem
	kb001_02_XREFS
	(list 0 (getvar "dwgname"))
	)

  (setq xrefList (kb:listxrefs)
	)

  (if xreflist
    (foreach
	   x xreflist
      (dcl_ListView_AddItem
	kb001_02_XREFS
	(list 2 x)
	)
      )
    )
  (setq dbxLlist (kb:ReturnDBXLayerStates)
	)
  (if dbxLlist
    (dcl_ListBox_AddList kb001_02_LayerStates dbxLlist)
    (dcl_ListBox_AddList
      kb001_02_LayerStates
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
  (princ)
  (princ)
  )





(defun c:kb001_02_LayerStates_OnSelChanged (nSelection sSelText /)
  (if kb:ChangeLayerKeys
    (kb:ChangeLayerKeys)
    )
  (princ)
  )


    ;(c:kb001_02_Restore_OnClicked)
(defun c:kb001_02_Restore_OnClicked (/ lsname xrefname)
  (setq	lsname	 (dcl_ListBox_GetText
		   kb001_02_LayerStates
		   (dcl_ListBox_GetCurSel kb001_02_LayerStates)
		   )
	xrefname (dcl_ListView_GetSelectedItems kb001_02_XREFS)
	)
  (if (not xrefname)
    (progn (setq xrefname (list "All Layers"))
	   (dcl_ListView_SetCurSel kb001_02_XREFS 0)
	   )
    )
  (if (and lsname (/= lsname ""))
    (cond ((= (vl-list-length xrefname) 1)
	   (kb:00-restore lsname (nth 0 xrefname))
	   )
	  ((> (vl-list-length xrefname) 1)
	   (foreach
		  x
		   xrefName
	     (kb:00-restore lsname x)
	     )
	   )
	  )
    (alert "Select a Layer Display!")
    )
  (princ)
  (princ)
  )


(defun c:kb001_02_ThawVP_OnClicked (/)
  (if (= (getvar "tilemode") 0)
    (command "vplayer" "_thaw" "*" "current" "" "")
    (not (dcl_MessageBox "Not allowed in Model Space!" "Thaw VP Layers" 2 1)
	 )
    )
  (princ)
  (princ)
  )


(defun c:kb001_02_LayerStates_OnDblClicked (/ path layerlist)
  (c:kb001_02_Restore_OnClicked)
  (princ)
  (princ)
  )

(defun c:kb001_02_OnClose ( / )
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"
    "isFloating"
    "false"
    )
  (princ)
  (princ)
  )
  

(defun c:kb001_02_OnInitialize (/ nUpperLeftX nUpperLeftY)
  (kb:ImportLayers_02_OnInitialize)
  (kb:WorkingStates_02_OnInitialize)
  (princ)
  (princ)
  )



(defun c:kb001_02_OnDocActivated (/)
  (if (dcl_Form_IsActive kb001_02)
    (c:kb001_02_OnInitialize)
    )
  (princ)
  (princ)
  )


(defun c:kb001_02_Refresh_OnClicked (/)
  (c:kb001_02_OnInitialize)
  (princ)
  (princ)
  )

(defun c:kb001_02_OnEnteringNoDocState (/)
  (dcl_form_close kb001_02)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"

    "isFloating"
    "true"
    )
  (princ)
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;								;

(defun c:kbLayerToolsP (/)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive kb001_02))
	(dcl_Form_Show kb001_02)
	)
      )

    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:001_02_IsFloating (/)
  (if dcl_HideErrorMsgBox
    (if	(and (not (dcl_Form_IsActive kb001_02))
	     (=	(vl-registry-read
		  "HKEY_CURRENT_USER\\Software\\kbTools2009\\kb001_02"

		  "isFloating"
		  )
		"true"
		)
	     )
      (c:kbLayerToolsp)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

(kb:001_02_IsFloating)

;;;							;
;;;	02						;
;;;							;

(defun c:kb001_03_OnInitialize ( / dbxLlist)
     (setq dbxLlist (kb:ReturnDBXLayerStates))
  (if dbxLlist
    (dcl_ListBox_AddList kb001_03_ListBox dbxLlist)
    (dcl_ListBox_AddList
      kb001_03_ListBox
      (list "The layer Standards file is opened!" "Contact IT")
      )
    )
)

(defun c:kb001_03_OnMouseMovedOff ( /)
     (dcl_Form_Close kb001_03)
)

(defun c:kb001_03_ListBox_OnDblClicked (/ lsname xref layers xname xrefname xobj)
  (setq	lsname (dcl_ListBox_GetText
		 kb001_03_ListBox
		 (dcl_ListBox_GetCurSel kb001_03_ListBox)
		 )
	xref   (dcl_Control_GetValue kb001_03_Xref)
	layers (dcl_Control_GetValue kb001_03_AllLayers)
	)
  (cond	((= xref 1)
	 (dcl_setcmdbarfocus)
	 (setq xname (entsel "\nSelect Xref:"))
	 (if xname
	   (progn
	     (setq xobj (vlax-ename->vla-object (car xname)))
	     (if (vlax-property-available-p xobj 'path)
	       (setq xrefname (vla-get-name xobj))
	       )
	     )
	   )
	 )
	((= layers 1)
	 (setq xrefname "All Layers")
	 )
	((and (= xref 0) (= layers 0))
	 (setq xrefname (getvar "dwgname"))
	 )
	)
  (if (and lsname xrefname)
    (progn
      (dcl_Form_Close kb001_03)
      (kb:00-restore lsname xrefname)
      )
    )
  )




(defun c:kb001_03_Xref_OnClicked (nValue /)
     (if(= nValue 1)
  (dcl_Control_SetValue kb001_03_AllLayers 0)
       )
)

(defun c:kb001_03_AllLayers_OnClicked (nValue /)
  (if(= nValue 1)
     (dcl_Control_SetValue kb001_03_Xref 0))
)

;;;								;
;;;	Command Interface					;
;;;								;

(defun c:kbLayerToolsPop (/ pt x y)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "kb001")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (setq pt(dcl_getmousecoords)
	    x(nth 0 pt)
	    y(nth 1 pt))
      (if (not (dcl_Form_IsActive kb001_03))
	(dcl_Form_Show kb001_03 (fix x)(fix y))
	)
      )

    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )







(princ "\nkbWorkingStates v2.0 loaded!")
(princ)
 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 0 T T nil T)
;*** DO NOT add text below the comment! ***|;
