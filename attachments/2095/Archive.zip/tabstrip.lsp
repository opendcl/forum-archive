(defun tabstrip (/ dclform c:dclInitialize)
	(defun c:dclInitialize ()
		(dcl-Control-SetTabCaptionList 
			(eval (read (strcat dclform "_TabStrip1"))) 
			(list "Group 0" "Group 1" "Group 2" "Group 3" "Group 4")
		) ; settabcaptionlist

		(dcl-TabStrip-SetCurSel 
			(eval (read (strcat dclform "_TabStrip1")))
			 4 ; <----- does not work.  0,1,2 only will work
		) ; setcursel
	) ; Initialize

	(dcl_Project_Load "tabstrip" t)

	(setq dclform "tabstrip_form1")

	(dcl_Form_Show (eval (read DCLFORM)))

) ; tabstrip

(tabstrip)
