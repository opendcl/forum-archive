(dcl-Project-Load "monitor_sized.odcl" t) 
(setq intResult (dcl-Form-Show monitor_sized/form1))
