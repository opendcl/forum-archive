(defun LoadRunTime ( / erroreopendcl )
    ;; Demand load the OpenDCL.##.ARX. This requires the OpenDCL Runtime or Studio to be installed on each PC first.
    (cond
      ( (= 'EXRXSUBR (type dcl_getversionex)) )
      ( (= 2 (boole 1 (getvar "DEMANDLOAD") 2))
        (vl-cmdf "_OPENDCL")
        (if (/= 'EXRXSUBR (type dcl_getversionex))
          (progn
            (princ "\nThe OpenDCL Runtime module failed to load. Please repair the OpenDCL installation and try again.")
            (setq erroreopendcl "si")
            ;(exit) 
          )
        )
      )
      ( (progn
          (princ "\nThe OpenDCL Runtime module cannot be loaded because demand loading is disabled.\nLoad the OpenDCL ARX file manually, or enable demand loading for commands by setting the DEMANDLOAD system variable to 2 or 3.\nSee the \"ManualLoading.lsp\" sample for a demonstration.")
          (setq erroreopendcl "si")
          ;(exit)
        )
      )
    )
    (if (= erroreopendcl "si")
      (alert (strcat "ERRORE OPENDCL\n\nQuesta versione di EmiLISP Free non � compatibile con la versione di " (getvar "PROGRAM") " in uso.\nContattare l'assistenza EmiCAD per verificare la disponibilit� di una nuova versione compatibile.\n\nhttp://www.emicad.it"))
    )
)



(defun c:test1 ()
  (vl-load-com)
  
  (or LoadRunTime (load "_OpenDclUtils.fas") (exit))  ;(vl-get-resource "EmiLISPCA")
  (LoadRunTime)
  
  (dcl_Project_Import (load "EmiLISPCA_Form1"))
  (dcl_FORM_SHOW EmiLISPCA_Form_FormPrincipale)
)

(defun c:test2 ()
  (vl-load-com)
  (or LoadRunTime (load "_OpenDclUtils.fas") (exit))  ;(vl-get-resource "EmiLISPCA")
  (LoadRunTime)
  
  (dcl_Project_Import (load "EmiLISPCA_Form2"))
  (dcl_FORM_SHOW EmiLISPCA_Form_FormPrincipale)
)
