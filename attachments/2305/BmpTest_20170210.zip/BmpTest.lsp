(setvar 'cmdecho 0)
(vl-cmdf "_Opendcl")
(setvar 'cmdecho 1)

(defun c:BmpTest/Form1/TabStrip1#OnChanged (idx /)
  (princ "\nUncomment code to see switching tab images ")
  ; (dcl-Control-SetTabImageList BmpTest/Form1/TabStrip1 (if (zerop idx) '(1 0) '(0 1)))
  (princ)
)

(defun c:BmpTest/Form1/ListView1#OnClicked (row col /)
  (dcl-ListView-SetItemImage
    BmpTest/Form1/ListView1
    row 
    col
    (abs (1- (dcl-ListView-GetItemImage BmpTest/Form1/ListView1 row col)))
  )
  (princ)
)

(defun c:BmpTest/Form1/GraphicButton1#OnClicked ( / idx)
  (setq idx
    (if (= 100 (dcl-Control-GetPicture BmpTest/Form1/GraphicButton1))
      101
      100
    )
  )
  (dcl-Control-SetPicture BmpTest/Form1/GraphicButton1 idx)
  (dcl-Control-SetPicture BmpTest/Form1/PictureBox1 idx)
  (princ)
)

(defun c:BmpTest ( / initMain)
  (dcl_Project_Load "BmpTest" T)
  (dcl-Form-Show BmpTest/Form1)
  (dcl-Tree-AddParent
    BmpTest/Form1/TreeControl1
    '(
      ("ParentA" "ParentA" 0 1 0)
      ("ParentB" "Parentb" 0 1 0)
    )
  )
  (dcl-Tree-AddChild
    BmpTest/Form1/TreeControl1
    '(
      ("ParentA" "ChildA1" "ChildA1" 0 1 0)
      ("ParentA" "ChildA2" "ChildA2" 0 1 0)
      ("ParentA" "ChildA3" "ChildA3" 0 1 0)
    )
  )
  (dcl-Grid-AddString BmpTest/Form1/Grid1 "0\tSwitchable Images")
  (dcl-Grid-SetCellImages BmpTest/Form1/Grid1 0 1 0 1)
  (dcl-Grid-SetCellStyle BmpTest/Form1/Grid1 0 1 3)
  (dcl-Grid-AddString BmpTest/Form1/Grid1 "1\tSwitchable Images")
  (dcl-Grid-SetCellImages BmpTest/Form1/Grid1 1 1 0 1)
  (dcl-Grid-SetCellStyle BmpTest/Form1/Grid1 1 1 3)
  (dcl-ListView-AddColumns BmpTest/Form1/ListView1 '(("A" 1 64) ("B" 1 64)))  
  (dcl-ListView-FillList BmpTest/Form1/ListView1'(("A1" 0 "B1" 1)))
  (princ)
)
