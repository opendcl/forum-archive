    ;;-----------------------------------------
    ;; Version a): Load the project from ODCL
    (dcl_Project_Load "test.odcl" T)
    (command "_opendcl")

;;;######################################################################
; L�nge Linienbruch in der Registry speichern
(defun c:Verdrahtung_opt_verdrahtung_inp_linienbruch_OnEditChanged  (strNewValue /)
    (if (not (dcl_Form_IsApplyEnabled Verdrahtung_opt_verdrahtung))
        (dcl_Form_SetApplyEnabled test_opt_verdrahtung T)
    )
    (setq linienbruch_temp (dcl_Control_GetText test_opt_verdrahtung_inp_linienbruch))
)
;;;######################################################################
; Fasenl�nge in der Registry speichern
(defun c:test_opt_verdrahtung_inp_fasenlaenge_OnEditChanged (strNewValue / )
    (if (not (dcl_Form_IsApplyEnabled test_opt_verdrahtung))
        (dcl_Form_SetApplyEnabled test_opt_verdrahtung T)
    )
    (setq fasenlaenge_temp (dcl_Control_GetText test_opt_verdrahtung_inp_fasenlaenge))
)
;;;######################################################################
(defun c:test_opt_verdrahtung_OnInitialize (/)
    (setq fasenlaenge_temp nil
          linienbruch_temp nil
    )
    ; Linienbruchl�nge aus Regsitry lesen und anzeigen
    (if (vl-registry-read "HKEY_CURRENT_USER\\Software\\cadraktiv\\verdrahtung" "linienbruch")
        (dcl_Control_SetText test_opt_verdrahtung_inp_linienbruch (vl-registry-read "HKEY_CURRENT_USER\\Software\\cadraktiv\\verdrahtung" "linienbruch"))
    )
    ; Fasenl�nge aus Regsitry lesen und anzeigen
    (if (vl-registry-read "HKEY_CURRENT_USER\\Software\\cadraktiv\\verdrahtung" "fasenlaenge")
        (dcl_Control_SetText test_opt_verdrahtung_inp_fasenlaenge (vl-registry-read "HKEY_CURRENT_USER\\Software\\cadraktiv\\verdrahtung" "fasenlaenge"))
    )
)
;;;;;;;######################################################################
; mache bei OK das gleiche wie bei Apply
(defun c:test_opt_verdrahtung_OnOK (/)
    (c:test_opt_verdrahtung_OnApply)
)
;;;;;;;######################################################################
(defun c:test_opt_verdrahtung_OnApply (/)
  (dcl_MessageBox "Hier sollte etwas Sinnvolles passieren: An dieser Stelle k�nnen Sie nun den Quellcode zur Ereignisfunktion hinzuf�gen\r\nc:test_opt_verdrahtung_OnApply" "Ereignisfunktion")
  (dcl_Form_SetApplyEnabled test_opt_verdrahtung nil)
)
(princ)
