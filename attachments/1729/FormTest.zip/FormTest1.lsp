; WoodBeamsDlg.lsp

;(defun c:K ()(load "FormTest1.lsp")(c:KCS_woodBEAMS))


(defun c:FORMTEST (/          
        class tow1 tow2 method run autotag %autosched beam  arch-opt plmb ang pitch isplate
        springval radiusval tab code data beams depth width tabdata %tabinit end1 end2 ext1 ext2
        %Continue return CustWidthVal CustDepthVal memb# seat1 seat2 array spacing
        brg1 brg2 custthick custwidth custdepth seatcut1 seatcut2 seatdepth1 seatdepth2 note
        
        c:WB_Dialog_OnInitialize c:hipval_OnClicked
        ); end of localized vars
        
  
  ; ODCL functions {
  ; Note: these must be localized also as they might otherwise conflict
  ; with ODCL functions defined elsewhere (in other ODCL projects)
  ;----------------
  (defun c:WB_Dialog_OnInitialize ()
    (princ "\n\n******* c:WB_Dialog_OnInitialize ******* ");****************************
  );c:WB_Dialog_OnInitialize
  
  
  (defun c:hipval_OnClicked (/)
    (princ "\n**c:hipval_OnClicked... ")
    (dcl_Form_Close WB_Dialog)
    (load "FormTest2" kcs_WoodHipValley) ; TEMP FILE
    (kcs_WoodHipValley kcs#woodbeams) ; function defined in FormTest2.lsp (for this test)
  )
  
  ; End of ODCL local functions }
  ;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
  

  ; INITIALIZE VARIABLES
  (if (null kcs#woodbeams)
    (setq kcs#woodbeams '(
      ("tab" . 0) ("class" . 0)  ("brg1" . 96) ("brg2" . 144) ("method" . 1); Preset
      ("run" . 144) ("autotag" . 1) ("beam" . "TJI-110 x 9 1/2") ; first in list for tab 0 / class 0
      ("arch-opt" . 0) ("springval" . 12.0) ("radiusval" . 180) ("autosched" . 1)
      ("end1" . 0) ("end2" . 0) ; 1=Plumb, 0=Square
      ("ext1" . 0) ("ext2" . 0) 
      ("seatcut1" . 0) ("seatcut2" . 0) ("seat1" . 0) ("seat2" . 0)
      ("CustThick" . 1.5) ("CustWidth" . 3.5) ("CustDepth" . 15.0) ; Custom GLB values
      ("pitch" . 4)  ("memb#" . 1) ; current multiple-member choice
      ("array" . 0) ("spacing" . 16) 
      ("note" . "")
    ))
  )


  ;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    

  (vl-cmdf "_OPENDCL") ; "OpenDCL Runtime [6.0.2.3] loaded" (first time)
  (princ "\r�\n�\n�\nWood Product Beams and Joists for AEC ... ")(princ)

 ;; Load the project (no longer packed in the VLX)
  (dcl_Project_Load "WoodBeams.odcl" nil) ; no forced reload

  ;; Show the main form
  (setq %Continue T)
  (while %Continue
    ;; to avoid an endless loop, the condition for repeating the loop, must negate at first
    ;; The condition will be "activated" again after dcl_form_show for some cases.
    (setq %Continue nil)    
    (setq return (dcl_Form_Show WB_Dialog))
    (princ "\n\n****** Return: ")(prin1 return)(princ);********************************************
    (cond
      ((= return 2) (setq %Continue nil))
      (T (setq %Continue T))
    )
  )
);c:KCS_WOODBEAMS

;============================================================================|
;

;============================================================================|
;============================================================================|
;============================================================================|
;============================================================================|
;============================================================================|
;============================================================================|





