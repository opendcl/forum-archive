dcl_settings : default_dcl_settings { audit_level = 3 ; }
STEEL_DIMS : dialog {
   : button {
      key = "DISPLAY_SLIDE" ;
      label = "SHOW SLIDE" ;
   }
   cancel_button ;
}
