;;;						;
;;;	Keynotes Dialog Control			;
;;;						;

;;;						;
;;;	Support Subs				;
;;;						;

(defun kb:TextWidthValue( / rValue nValue ret)
  (Setq rValue (dcl_ComboBox_GetTBText kb002_00_TextWidth))
  (cond((= (strcase rValue) "NARROW")(setq nValue 1.25))
       ((= (strcase rValue) "STANDARD")(setq nValue 2.5))
       ((= (strcase rValue) "EXTENDED")(setq nValue 3.75))
       (t (setq nValue 4.0))
       )
  (setq ret(* nValue(kb:cannoscale)))
  ret
  )


(defun c:test( / )
  (setq ent(entsel))
  (if ent
    (progn
    (setq obj(vlax-ename->vla-object(car ent))
	  width(kb:TextWidthValue)
	    )
    (vlax-put-property obj 'textwidth
	       ;(* width(kb:cannoscale))
	       width
	       )
    )
    )
  )
    

    
;;;						;
;;;	Form 01	- Keynote Info			;
;;;						;
(defun c:kb002_01_SELECT_OnClicked ( /)
  (setq ent(entsel))
  (if ent
    (progn
      (setq xdata(kb:getKeyNotexdata (car ent))
	    key(nth 0 xdata)
	    note(nth 1 xdata)
	    objtype(nth 2 xdata))
      (if (and key note objtype)
	(progn
      (dcl_Control_SetCaption kb002_01_Key key)
      (dcl_Control_SetCaption kb002_01_Note note)
      (dcl_Control_SetCaption kb002_01_ObjectType objtype)
      )
	(dcl_MessageBox "That is not a Keynote!" "Select Keynote")
	)
      )
    )
      
)
(defun c:kb002_01_CLOSE_OnClicked ( /)
     (dcl_Form_Close kb002_01)
  (princ)
)

(defun c:kb002_01_OnDocActivated ( /)
     (c:kb002_01_OnInitialize)
)
(defun c:kb002_01_OnEnteringNoDocState ( /)
     (dcl_Form_Close kb002_01)
  (princ)
)
(defun c:kb002_01_OnInitialize ( /)
     (dcl_Control_SetCaption kb002_01_Key "")
      (dcl_Control_SetCaption kb002_01_Note "")
      (dcl_Control_SetCaption kb002_01_ObjectType "")
      
)
(defun c:kbKeyInfo( / )
  (c:kb002_00_XDATA_OnClicked)
  (princ))


;;;						;
;;;	Form 00	- MainKeynote Form		;
;;;						;

;(setq data nil)
(defun c:kb002_00_OnInitialize  (/ file data)
  (dcl_ComboBox_Clear kb002_00_TextWidth)
  (dcl_ComboBox_AddList kb002_00_TextWidth 
	 (list "Narrow" "Standard" "Extended"))
  (dcl_ComboBox_SetCurSel kb002_00_TextWidth 1)
  
  (if (=(dcl_Control_GetValue kb002_00_LEADER) nil)
    (dcl_Control_SetEnabled kb002_00_TextWidth 0))

  (dcl_Control_Setcaption kb002_00_PREVIEW "")
  ;;; Project specific keynote file
  (setq file(kb:ReturnKeynoteFilename))
  (if file
    (setq data (kb:getKeynoteFileData file)))
  (if data
    (progn (dcl_ListBox_Clear kb002_00_DIV)
           (dcl_ListBox_AddList kb002_00_DIV (car data))
           (dcl_ListBox_Clear kb002_00_KEYLIST)
           (dcl_ListBox_AddList kb002_00_KEYLIST (cadr data)))
    (progn (dcl_ListBox_Clear kb002_00_KEYLIST)
           (dcl_ListBox_Clear kb002_00_DIV)))
  
(princ)(princ)
  )


(defun c:kb002_00_FIXWIDTH_OnClicked ( /)
     (dcl_SetCmdBarFocus)
  (vla-sendcommand (vla-get-ActiveDocument(vlax-get-acad-object))"kbFixWidth ")
)


(defun c:kb002_00_XDATA_OnClicked ( /)
     (if (not(dcl_Form_isactive kb002_01))(dcl_Form_show kb002_01))
  (princ)
)

(defun c:kb002_00_Swap_OnClicked ( /)
  (dcl_SetCmdBarFocus)
  (vla-sendcommand (vla-get-ActiveDocument(vlax-get-acad-object))"kbSwapKeyandNote ")
)


(defun c:kb002_00_LEADER_OnClicked (nValue /)
     (if (= nValue 1)
       (progn
    (dcl_Control_SetValue kb002_00_NOTE 0)
       (dcl_Control_SetEnabled kb002_00_TextWidth 1)
    )
       (dcl_Control_SetEnabled kb002_00_TextWidth 0)
    )
(princ)(princ)
  )


(defun c:kb002_00_NOTE_OnClicked  (nValue /)
  (if (= nValue 1)
    (progn
    (dcl_Control_SetValue kb002_00_LEADER 0)
    (dcl_Control_SetEnabled kb002_00_TextWidth 0))
    )
(princ)(princ)
  )



(defun c:kb002_00_DIV_OnSelChanged  (nSelection sSelText / div data keys)
  (setq div  (substr sSelText 1 2)
        data (kb:getKeynoteFileData (findfile(strcat(kb:returnprojectdir)"\\project.key"))))
  (if data
    (progn
      (if (= div "00")
        (progn (dcl_ListBox_Clear kb002_00_KEYLIST)
                    (dcl_ListBox_AddList kb002_00_KEYLIST (cadr data)))
    (progn
      (foreach
                  i  (cadr data)
             (if (/= i "")
               (if ;(vl-string-search (strcat div ".") i 0)
                 (=(substr i 1 2)div)
                 (setq keys (append keys (list i))))))
           (if keys
             (progn (dcl_ListBox_Clear kb002_00_KEYLIST)
                    (dcl_ListBox_AddList kb002_00_KEYLIST keys)))))))
(princ)(princ)
  )
(defun c:kb002_00_KEYLIST_OnSelChanged  (nSelection sSelText /)
  (dcl_Control_Setcaption kb002_00_PREVIEW sSelText)
  (princ)(princ)
  )


(defun c:kb002_00_MAKE_OnClicked  (/)
  (dcl_SetCmdBarFocus)
  (kb:SyncKeynoteFiletoDrawing)
  (kb:MakeKeynoteChart)
(princ)(princ)
  )

(defun c:kb002_00_UPCHART_OnClicked  (/ chart)
  (dcl_SetCmdBarFocus)
  (kb:SyncKeynoteFiletoDrawing)
  (setq chart (car(entsel "\nSelect KeyChart: ")))
  (if chart
  (kb:kn:UpdateChart chart))
  (princ)(princ))


(defun c:kb002_00_EDIT_OnClicked  (/ file)
  (setq file(kb:ReturnKeynoteFilename))
  (if file
    (startapp "notepad.exe" file))
  (princ)(princ))


(defun c:kb002_00_SYNC_OnClicked  ( / nSelection sSelText)
  (setq nSelection (dcl_ListBox_GetCurSel kb002_00_DIV)
	sSelText(dcl_ListBox_GetText kb002_00_DIV nSelection))
  (if (wcmatch(strcase(getvar "dwgprefix"))(strcase(strcat(kb:returnprojectdir)"*")))
    (progn (c:kb002_00_OnInitialize)
      	   (if (and nSelection sSelText)
	     (progn
	     (c:kb002_00_DIV_OnSelChanged nSelection sSelText)
	     (dcl_ListBox_SetCurSel kb002_00_DIV nSelection)
	     )
	     )
           (kb:SyncKeynoteFiletoDrawing)
           )
    (dcl_messagebox
      "This drawing is not a member of the active project!"
      "Synch Key Dawing"
      2
      1))
  (princ)(princ)

  )
   

(defun c:kbUPKEY (/ text key note)
  (setq	text (dcl_ListBox_GetText
	       kb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel kb002_00_KEYLIST)
	     )
  )
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(substr text 1 (vl-string-position (ascii "\t") text))
		   note	(substr text (+ 2 (vl-string-position (ascii "\t") text)))
	     )
	     (dcl_SetCmdBarFocus)
	     (if (setq ent (entsel))
	       (progn
		 (if (kb:getKeyNotexdata (car ent))

		   (kb:ChangeKeynote ent key note nil)

		   (alert "That is not a Keynote object!")
		 )
	       )
	     )
      )
    )
  )
  (princ)
  (princ)
)

(defun c:kb002_00_UPKEY_OnClicked  (/ )
(vla-sendcommand(vla-get-activedocument(vlax-get-acad-object))"kbUPKEY ")
  (princ)(princ))


(defun c:kbUPALLKEY (/ text key note)
  (setq	text (dcl_ListBox_GetText
	       kb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel kb002_00_KEYLIST)
	     )
  )
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(substr text 1 (vl-string-position (ascii "\t") text))
		   note	(substr text (+ 2 (vl-string-position (ascii "\t") text)))
	     )
	     (dcl_SetCmdBarFocus)
	     (if (setq ent (entsel))
	       (progn
		 (if (kb:getKeyNotexdata (car ent))

		   (kb:ChangeKeynote ent key note t)

		   (alert "That is not a Keynote object!")
		 )
	       )
	     )
      )
    )
  )
  (princ)
  (princ)
)

(defun c:kb002_00_UPALLKEY_OnClicked  (/ )
(vla-sendcommand(vla-get-activedocument(vlax-get-acad-object))"kbUPALLKEY ")
  (princ)(princ))


;(Setq Value (dcl_Control_GetEnabled kb002_00_TextWidthValue))


(defun c:kb002_00_FIND_OnClicked  (/ text key)
  (setq text (dcl_ListBox_GetText
               kb002_00_KEYLIST
               (dcl_ListBox_GetCurSel kb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (if text
      (progn (setq key (substr text 1 (vl-string-position (ascii "\t") text)))
             (kb:findkeynote key))))
(princ)(princ)
  )


(defun c:kb002_00_KEYLIST_OnDblClicked  (/ text nflag lflag doc)
  (setq text (dcl_ListBox_GetText kb002_00_KEYLIST(dcl_ListBox_GetCurSel kb002_00_KEYLIST))
        lflag(dcl_Control_GetValue kb002_00_LEADER)
        nflag(dcl_Control_GetValue kb002_00_NOTE)
	doc(vla-get-ActiveDocument(vlax-get-acad-object)))
  (if (and text (/= text ""))
    (progn
      (dcl_SetCmdBarFocus)
      (cond
        ((and
	   (or
	     (and(= nflag 1)(= lflag 0))
	     (and(= nflag t)(= lflag nil))
	     )
	   )
	 (vla-sendcommand doc "kbPlaceTextNote ")
	 )
        ((and
	   (or
	     (and(= nflag 0)(= lflag 1))
	     (and(= nflag nil)(= lflag t))
	     )
	   )
	 (vla-sendcommand doc "kbPlaceNote ")
	 )
        ((and
	   (or
	     (and(= nflag 0)(= lflag 0))
	     (and(= nflag nil)(= lflag nil))
	     )
	   )
	 (vla-sendcommand doc "kbPlaceKeyNote ")
	 ))))
(princ)(princ)
  )

(defun c:kb002_00_REFRESH_OnClicked (/) (c:kb002_00_OnInitialize)(princ)(princ))


(defun c:kb002_00_OnDocActivated (/) (c:kb002_00_OnInitialize)(princ)(princ))

(defun c:kb002_00_OnEnteringNoDocState ( /)
     (dcl_form_close kb002_00)
      (vl-bb-set 'kb002Floating "true")
  (princ)(princ)
)

(defun c:kb002_00_OnClose  (nUpperLeftX nUpperLeftY / )
  
  (princ)(princ))

;;;								;
;;;	Tray Functions						;
;;;								;
(defun c:kb002_00_Close_OnClicked ( / rValue ht wd)
  (vl-bb-set 'kb002Floating "false")

  (setq rValue (dcl_Form_GetControlArea kb002_00)
	wd(car rValue)
	ht(cadr rValue))
  (if (> ht 20)
  (kb:SaveFormSize "kb002_00" wd ht))
  (dcl_form_close kb002_00)
  (princ)
)


(defun kb:002_RollUp (saveFlag / rValue ht wd)
  (Setq	rValue (dcl_Form_GetControlArea kb002_00)
	wd     (car rValue)
	ht     (cadr rValue)
	)
  (if saveFlag
    (progn 
      (if (> ht 20)
  (kb:SaveFormSize "kb002_00" wd ht))
      )
    )
  (foreach
	 x (dcl_Form_GetControls kb002_00)
    (dcl_Control_SetVisible x nil)
    )
  (foreach
	 x (list kb002_00_Tray
		 kb002_00_Close
		 kb002_00_TrayRectangle
		 kb002_00_TrayLabel
		 )
    (dcl_Control_SetVisible x T)
    )
  (dcl_Control_SetToolTipMainText kb002_00_Tray "Roll Down Form")
  (dcl_Control_SetMouseOverPicture kb002_00_Tray 100)
  (dcl_Control_SetPicture kb002_00_Tray 100)
  (dcl_Form_Resize kb002_00 wd 16)
  )


(defun kb:002_RollDown (pictureFlag / rValue ht wd)
  (setq	rValue (kb:GetFormSize "kb002_00")
	wd     (car rValue)
	ht     (cadr rValue)
	)
  (foreach x (dcl_Form_GetControls kb002_00) (dcl_Control_SetVisible x t))
  (if pictureFlag
    (progn
      (if(< (dcl_Control_GetTop kb002_00_Splitter1) 90)

(dcl_Control_SetTop kb002_00_Splitter1 90))
  (dcl_Control_SetToolTipMainText kb002_00_Tray "Roll Up Form")
  (dcl_Control_SetMouseOverPicture kb002_00_Tray 101)
  (dcl_Control_SetPicture kb002_00_Tray 101)
  )
    )
  (dcl_Form_Resize kb002_00 wd ht)
  )


(defun c:kb002_00_Tray_OnClicked ( / )
  (cond((=(dcl_Control_GetPicture kb002_00_Tray)101)
	(kb:002_RollUp t))
	((=(dcl_Control_GetPicture kb002_00_Tray)100)
	 (kb:002_RollDown t)
	)
       )
(princ)
  (princ)
  )

(defun c:kb002_00_OnMouseEntered (/)
  (cond	((= (dcl_Control_GetPicture kb002_00_Tray) 101) ;it's rolled down - do nothing
	 (princ)
	 )
	((= (dcl_Control_GetPicture kb002_00_Tray) 100) ;it's rolled up - roll it down
	 (kb:002_RollDown nil)
	 )
	)
  (princ)
  (princ)
  )


(defun c:kb002_00_OnMouseMovedOff (/)
  (dcl_setcmdbarfocus)
  (cond	((= (dcl_Control_GetPicture kb002_00_Tray) 101) ;it's rolled down - do nothing
	 (princ)
	 )
	((= (dcl_Control_GetPicture kb002_00_Tray) 100) (kb:002_RollUp t))
	)
  (princ)
  (princ)
  )


;;;							;
;;;		Command Interface			;
;;;							;
(defun c:kbkeynotes  (/ )
  (if(not(member "kb002" (dcl_GetProjects)))
	 (dcl_Project_load "kb002")) 
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive kb002_00))
	(dcl_Form_Show kb002_00)
	  )
      ;Show form rolled down
	;(c:kb000_00_Tray_OnClicked)

      ;Show form rolled up
      (kb:002_RollUp nil)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)(princ))

;;;							;
;;;		Floating Form				;
;;;		Document Opened				;
;;;							;

(defun kb:kbkeynotes_IsFloating  (/ )
  (if dcl_HideErrorMsgBox
    (progn
  (if (dcl_Form_IsActive kb002_00)
    (c:kb002_00_OnDocActivated))

  (if (=(vl-bb-ref 'kb002Floating) "true")
	(c:kbkeynotes)))

  (alert "The OpenDCL arx module did not load!"))
  (princ)
  (princ))

(kb:kbkeynotes_IsFloating)


(princ "\n002 - kbTools Keynotes loaded!")
(princ)
;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
