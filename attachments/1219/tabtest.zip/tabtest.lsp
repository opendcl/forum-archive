(princ "\ncommand: tabtest sample - function ..OnChanged not called ")

(defun c:tabtest ( / tabcontrol )
  (or LoadRunTime (load "_OpenDclUtils.lsp") 
    (exit)
  )
  (LoadRunTime)
  (dcl_Project_Load "tabtest.odcl" T)

  (dcl_FORM_SHOW tabtest_Form1)
  (setq tabcontrol tabtest_Form1_TabStrip1)
  (dcl_Control_SetTabCaptionList tabcontrol (list "mytab1" "mytab2"))
 
)

(defun c:tabtest_Form1_TabStrip1_OnChanged (ItemIndex /)
  (dcl_MessageBox "To Do: code must be added to event handler\r\nc:tabtest_Form1_TabStrip1_OnChanged" "To do")
)


(defun c:tabtest_Form1_TabStrip1_OnSelChanging (ItemIndex /)
  (dcl_MessageBox "To Do: code must be added to event handler\r\nc:tabtest_Form1_TabStrip1_OnSelChanging" "To do")
)

