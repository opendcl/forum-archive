;;;							;
;;;	kbTools Command Reactor Functions		;
;;;							;

;;;							;
;;;	Command Reactors				;
;;;							;


;;;	Support Functions				;
;;;	Only used by Routines in this File		;

;;;	Call-back Functions				;

;;;	Command Will Start				;
 (defun kb:CommandWillStart(calling-reactor commands / lname)
   (cond((member (car commands) (list "MTEXT" "-MTEXT" "DTEXT" "TEXT"
                                      "-TEXT" "LEADER" "QLEADER" "MLEADER"))
	 (setq lname (AECGENERATELAYERKEY "ANNOBJ")))

        ((member (car commands) (list "DIMLINEAR" "DIMALIGNED" "DIMBASELINE"
                                      "DIMCONTINUE" "DIMDIAMETER" "DIMANGULAR"
                                      "DIMRADIUS" "DIMORDINATE" "QDIM"))
         (setq lname (AECGENERATELAYERKEY "DIMLINE")))
	((member (car commands) (list  "VPORTS" "-VPORTS"))
	 (setq lname (AECGENERATELAYERKEY "ANNDTOBJ")))

        ((member (car commands) (list "IMAGE" "-IMAGE")) ;"-XREF" "XREF" "XATTACH"
	 (setq lname "XREF"))

         )
   
   (if lname(kb:setclayer lname T))
   
   )

;;;	Command Ended					;
 (defun kb:CommandEnded(calling-reactor commands / dwgdimscale)
   (cond

     ((member (car commands) (list "XREF" "XATTACH" "-XREF"))
      (kb:resetclayer)
	 (if dcl_HideErrorMsgBox
	   (progn (if (dcl_Form_IsActive Palette_Main)
		    (kb:LayerStates_OnInitialize)
		    )
		  )
	   )
	 )
	((member (car commands) (list "MTEXT" "-MTEXT" "DTEXT"
				      "TEXT" "-TEXT" "LEADER" "QLEADER" "MLEADER"
				      "DIMLINEAR" "DIMALIGNED" "DIMBASELINE"
				      "DIMCONTINUE" "DIMDIAMETER"
				      "DIMANGULAR" "DIMRADIUS" "DIMORDINATE" "QDIM"
				      "MVIEW" "VPORTS" "-VPORTS"
                                      "IMAGE" "-IMAGE"))
         (kb:resetclayer))	
	)
   )

;;;	Command Cancelled					;
 (defun kb:CommandCancelled(calling-reactor commands / )
   (cond((member (car commands) (list "MTEXT" "-MTEXT" "DTEXT"
				      "TEXT" "-TEXT" "LEADER" "QLEADER" "MLEADER"
				      "DIMLINEAR" "DIMALIGNED" "DIMBASELINE"
				      "DIMCONTINUE" "DIMDIAMETER"
				      "DIMANGULAR" "DIMRADIUS" "DIMORDINATE" "QDIM"
				      "MVIEW" "VPORTS" "-VPORTS"
                                       "IMAGE" "-IMAGE"))
         (kb:resetclayer))
	)
   )


;;;	Construct the Command Reactor				;
(defun kb::ConstructCommandReactor  (/)
  (if (= (type *kbCommandReactor*) 'VLR-Command-Reactor)
    (progn (vlr-remove *kbCommandReactor*) (setq *kbCommandReactor* nil)))
  (if (/= (type *kbCommandReactor*) 'VLR-Command-Reactor)
    (setq *kbCommandReactor*
           (VLR-Command-Reactor
             "kbTools Command Reactor" ; Data associated with the editor reactor
             ;; call backs
             '
              ((:VLR-commandWillStart . kb:CommandWillStart)
               (:VLR-commandEnded . kb:CommandEnded)
               (:VLR-commandCancelled . kb:CommandCancelled)
	       )) ;_ end of vlr-editor-reactor
          ))

  (if (not (vlr-added-p *kbCommandReactor*))
    (progn
    (vlr-add *kbCommandReactor*)
    (vlr-set-notification *kbCommandReactor* 'active-document-only)));added 09.26.2003
  (princ))

;;; Loaded in kb-48-01b.fas



;;;			load reactors				;

    
(if kb::ConstructCommandReactor
  (kb::ConstructCommandReactor))

;;;									;
;;;		kbTools Xref Reactor Functions				;
;;;									;

;;;									;
;;;		Command Reactors					;
;;;									;


;;;		Support Functions					;
;;;		Only used by Routines in this File			;

;;;									;
;;;			XREF Reactor					;
;;;	Uses the modelspace reactor to re-set clayer			;
;;;									;

;;;			Xref Call Back functions			;

;;;			End Attach					;
(defun kb:endAttach  (reactor vla-object /)
  ;(alert "Yes")
  (if dcl_HideErrorMsgBox
    (progn
	   (if (dcl_Form_IsActive Palette_Main)
		    (kb:LayerStates_OnInitialize)
		    )
	   
	   )
    )
    (princ)
  )

;;;			Begin Attach					;
(defun kb:beginAttach  (reactor vla-object /)
  (if (not (tblsearch "layer" "XREF"))(vla-add (vla-get-layers (vla-get-activedocument(vlax-get-acad-object))) "XREF"))
  (setq kb%XrefAttach T)
  (if (tblsearch "layer" "XREF")(kb:setclayer "XREF" T))
  (princ)
  )

;;;			Construct Xref Reactor				;
(defun kb::ConstructXrefReactor  (/)
  (if (= (type *kbXrefReactor*) 'VLR-Xref-Reactor)
    (progn (vlr-remove *kbXrefReactor*)
	   (setq *kbXrefReactor* nil)))
  (if (/= (type *kbXrefReactor*) 'VLR-Xref-Reactor)
    (setq *kbXrefReactor*
	   (VLR-Xref-Reactor
	     "kbTools Xref Reactor" ; Data associated with the editor reactor
	     ;; call backs
	     '
	      ((:VLR-beginAttach . kb:beginAttach)
	       (:VLR-endAttach . kb:endAttach)
	       (:VLR-xrefSubcommandDetachItem . kb:endAttach)
               )) ;_ end of vlr-xref-reactor
	  ))
  (if (not (vlr-added-p *kbXrefReactor*))
    (progn (vlr-add *kbXrefReactor*)
	   (vlr-set-notification *kbXrefReactor* 'active-document-only)))
  (princ))


;;;				load reactor				;


(if kb::ConstructXrefReactor
  (kb::ConstructXrefReactor))



;;;									;
;;;			ModelSpace Reactor				;
;;;	Uses the modelspace reactor to re-set clayer			;
;;;									;



(defun kb::StartResetReactor( / )
(if *kbMSReactor* (vlr-remove *kbMSReactor*))
(setq *kbMSReactor* (vlr-object-reactor (list (vla-get-modelspace (vla-get-activedocument(vlax-get-acad-object)))) nil '((:vlr-objectClosed . kb:resetXrefLayer))))
(if *kbPSReactor* (vlr-remove *kbPSReactor*))
(setq *kbPSReactor* (vlr-object-reactor (list (vla-get-paperspace (vla-get-activedocument(vlax-get-acad-object)))) nil '((:vlr-objectClosed . kb:resetXrefLayer))))

  )

(defun kb:resetXrefLayer (owner reactor_object reactor_list  /)
  (if kb%XrefAttach
    (progn
      (if dcl_HideErrorMsgBox
	   (if (dcl_Form_IsActive Layers_LayerStates)
	     (c:Layers_LayerStates_Refresh_OnClicked))
         )
      (kb:resetclayer)
      (setq kb%XrefAttach nil)))
  
  )

;;;				load reactor				;


(if kb::StartResetReactor
  (kb::StartResetReactor))


;;;							;
;;;	kbTools ADT and Production Tools v1.0		;
;;;							;
;;;	include files					;
;;;							;


;;;						;
;;;		Command Reactor			;
;;;						;

;;;		Call-back Functions		;

;;;		Command Ended			;
 (defun kb:ADTCommandEnded(calling-reactor commands / Doc DwgDimScale)
    (cond
      ((member (car commands) (list "PLACEVIEW"))
       (if kb:InsertSheetViewTag
	 (kb:InsertSheetViewTag)))

      ((if (vl-string-search "CANNOSCALE" (getvar "lastprompt"))
	 (progn
       (setq dwg(vla-get-activedocument(vlax-get-acad-object))
	     annoscale(vlax-invoke dwg 'getvariable  "CANNOSCALEVALUE")
	     ltscale(*(/ 12(* annoscale 12.0))0.5)
	     )
       (if ltscale(vlax-invoke dwg "setvariable" "LTSCALE" ltscale))
       (vlax-invoke dwg 'regen  acActiveViewport)
       )))
      )
   )

;;;		Command Cancelled			;
 (defun kb:ADTCommandCancelled(calling-reactor commands / )
   (cond((member (car commands) (list "PLACEVIEW"))
         (kb:resetclayer))
	)
   )


;;;		Construct the Command Reactor		;
(defun kb::ADTConstructCommandReactor  (/)
  (if (= (type *kbADTCommandReactor*) 'VLR-Command-Reactor)
    (progn (vlr-remove *kbADTCommandReactor*) (setq *kbADTCommandReactor* nil)))
  (if (/= (type *kbADTCommandReactor*) 'VLR-Command-Reactor)
    (setq *kbADTCommandReactor*
           (VLR-Command-Reactor
             "kbTools Command Reactor" 
             '((:VLR-commandEnded . kb:ADTCommandEnded)
               (:VLR-commandCancelled . kb:ADTCommandCancelled)
	       )) 
          ))

  (if (not (vlr-added-p *kbADTCommandReactor*))
    (progn
    (vlr-add *kbADTCommandReactor*)
    (vlr-set-notification *kbADTCommandReactor* 'active-document-only)))
  (princ))


;;;		load reactors				;

    
(if kb::ADTConstructCommandReactor
  (kb::ADTConstructCommandReactor))


;;;							;
;;;	Layout Reactor					;
;;;							;



;;;
(defun kb:LayoutSwitched  (reactor layout / ActiveSpace doc dimscale)
  ;get some parameters
      (setq doc	       (vla-get-activedocument (vlax-get-acad-object))
	    dimscale(vlax-variant-value (vla-getvariable doc "dimscale"))
	    ActiveSpace(vlax-variant-value(vla-getvariable doc "tilemode"))
      )
  (cond
	;Switched from ModelSpace to Paperspace
	((= ActiveSpace 0)
	 (vla-SetVariable doc "ltscale" 0.5)
	 (princ "\nSetting Linetype Scale to 0.5")
	 )
	 
	((= ActiveSpace 1)
	 (vla-SetVariable doc "ltscale" (* dimscale 0.5))
	 (princ (strcat"\nSetting Linetype Scale to "(rtos(vlax-variant-value (vla-getvariable doc "ltscale"))2 2)))
	 )
	)
  )
	

;;; Miscellaneous Reactors
;;;
    (defun kb:ViewportReactor  (/)
      (setq *kbActiveSpace*(vlax-variant-value
			     (vla-getvariable(vla-get-activedocument
				 (vlax-get-acad-object))"tilemode")))
      
      (if (/= (type *kbViewportReactor*) 'VLR-Miscellaneous-Reactor)
	(setq *kbViewportReactor*
	       (VLR-Miscellaneous-Reactor

		 nil 
		 ' ((:VLR-layoutSwitched . kb:LayoutSwitched))
		 )
	      )
	)
      (if (not (vlr-added-p *kbViewportReactor*))
	(vlr-add *kbViewportReactor*)
	)
      (princ)
      )

;;;pgp: kbRemoveViewportReactor,		*kbRemoveViewportReactor
(defun c:kbRemoveViewportReactor()(progn(vlr-remove *kbViewportReactor*)(setq *kbViewportReactor* nil))
  (prompt "Viewport Reactor removed!")(princ))

;;;	Set Global Variables				;

      
(if kb:ViewportReactor
  (kb:ViewportReactor))




