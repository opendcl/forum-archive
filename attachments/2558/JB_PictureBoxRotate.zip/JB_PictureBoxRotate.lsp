(defun c:PBR ( / FOLDER JB_PBR$$FILELIST JB_PBR$$N X)
  (command"OPENDCL")
  
  (if(setq Folder (getfiled "OpenDcl-Datei w�hlen" (if JB_PBR$$Folder (strcat JB_PBR$$Folder "JB_PictureBoxRotate.odcl") "JB_PictureBoxRotate.odcl")"odcl" 4))
    (progn
      (setq JB_PBR$$Folder (car(fnsplitl Folder)))
      (setq JB_PBR$$FileList (mapcar '(lambda(X)(strcat JB_PBR$$Folder X))(vl-directory-files JB_PBR$$Folder "*.jpg" 1)))
      (setq JB_PBR$$n 0)
      
      (if (not JB_PBR_Explore)(dcl_project_load (strcat JB_PBR$$Folder "JB_PictureBoxRotate.odcl") 'T))
      (dcl_Form_Show JB_PBR_Explore)
      )
    )
  (princ)
  )
     
  
(defun c:JB_PBR_Explore#OnInitialize (/)
  (dcl-PictureBox-LoadPictureFile JB_PBR_Explore_Image (nth JB_PBR$$n JB_PBR$$FileList)'T)
  )

(defun c:JB_PBR_Button_Before#OnClicked (/)
  (setq JB_PBR$$n (- JB_PBR$$n 1))
  (if (< JB_PBR$$n 0)(setq JB_PBR$$n (-(length JB_PBR$$FileList)1)))
  (dcl-PictureBox-LoadPictureFile JB_PBR_Explore_Image (nth JB_PBR$$n JB_PBR$$FileList)'T)
)
(defun c:JB_PBR_Button_Next#OnClicked (/)
  (setq JB_PBR$$n (+ JB_PBR$$n 1))
  (if (>= JB_PBR$$n (length JB_PBR$$FileList))(setq JB_PBR$$n 0))
  (dcl-PictureBox-LoadPictureFile JB_PBR_Explore_Image (nth JB_PBR$$n JB_PBR$$FileList)'T)
)





    