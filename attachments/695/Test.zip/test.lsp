
(dcl_project_load "test")


(defun c:test_Form1_OnInitialize (/)
  (dcl_PictureBox_DrawLine (vl-doc-ref 'Test_Form1_PictureBox1) '((10 10 230 10 248)))
)

(defun c:test_Form1_TextButton1_OnClicked (/)
  (dcl_PictureBox_DrawLine (vl-doc-ref 'test_Form1_PictureBox1) '((10 10 230 10 248)))
)



(dcl_form_show (vl-doc-ref 'Armanew_Form1))