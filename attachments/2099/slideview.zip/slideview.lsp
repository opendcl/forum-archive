(defun slideview (/ dclform c:dclInitialize)
	(defun c:dclInitialize ()
		(dcl_SlideView_Load (eval (read (strcat DCLFORM "_SlideView1"))) "tree-simp-005.sld")
	) ; dclInitialize


	(command "_.OPENDCL")
	(dcl_Project_Load "slideview" t)
	(setq dclform "slideview_form1")
	(dcl_form_show (eval (read dclform)))

(princ)
) ; slideview


(slideview)
