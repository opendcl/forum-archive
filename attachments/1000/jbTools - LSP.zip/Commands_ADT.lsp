;;;							;
;;;	kbTools ADT and Production Tools v1.0		;
;;;							;
;;;	include files					;
;;;	Palette_Main					;


(vl-load-com)

(if (not (vl-bb-ref 'kbADT))
  (vl-bb-set
    'kbADT
    (dcl_project_import
      '("YWt6AxIHAACoOIO3BuL76rUwaj9q+IGYnCp+3V+vOjNyd2ajMvwd8a6SKkovZ781HDIydoqyfqz+"
"bz+8uHmuSxACetH36brbVaKHfsD/3EVpIGaB1Mdqi7kWKRTUwYSF4tQtmaqS1xOprpaT2U70FfZ+"
"ArJ/uDAlnkZuHXS9Vt62z/Kdtl0/suiOU7hKeEflmeYM8ocomkn9yubYM+tIdyU0u1MrzWAtmRnm"
"JHtZp9IL/F8AE0NoYpuj1PcF1Y7JNOErpNsq9WJVKqWuo6IWaUVwvDriEkLqMkPSd1KfSCimsxGS"
"FLbvS0vx+yn7qfsVvOH6kXsCVrt2lAXm+pAbbJ0mugeIR6Ib4Ty4oQs4GGD3qfl/YYDBqWwHe7WK"
"G6EoR+hHIRtNQbuJ5I5YBOVZpkY0DXtjs1cFqJjAZaLtzYJg4/+glYsntZMvFoGolRu10UMRJgCd"
"p9OBNIbpofGdgF6X45lmjGNSzrqy+T7/R5hDE8zFjM/bnbRZr4y3809ftTKwFwQi/adjYiuBwa1u"
"pKitTLScsw64W0S7wjX1B1B3BlSCMob3DqhEc2nl52kgFrtiA5mDTTXcoWzAUIBhdqFuoFUCLQbV"
"C9gLoIiVxxSGVJUBDzubBz6SwYcG4oDp/BP9FzCTUqhhSIJwIdIwYemcZI8CvozuaqV1n+kMR8T6"
"iwxSeFuoLbwris+xzGZMyEBoN/hn5gkAYSUIoQTXSBrjzZZ3iMsxnOR2NaGSOQneaVrQJoIhaAFZ"
"mmL1HIEn0KBvz8FajyKKkqhl7ZE13CFuQ++DlKtBVMSCa6aZcf7QiqE="))))


;;;							;
;;;	Standard Annotation BlockS			;
;;;	Stored in the Project AEC Styles drawing	;
;;;							;


;;;							;
;;;		Support Functions			;
;;;							;

;;;							;
;;;	Add AEC Mask Block				;
;;;							;
;;;	MaskAnchorAdd					;
;;;	[NAme/X scale/Y scale/Z scale/Rotation/Match]	;
;;;							;
;;;	MaskAttach					;
;;;							;
;;;	(kb:AddFluorMask "I_ELEC_FLUOR_2X4")		;
;;;							;

;;;pgp kbAddFluorMask,		*kbAddFluorMask
(defun c:kbAddFluorMask ( / *Error* ss ans oldsnap oldecho oldclayer newclayer dname)
	(defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (kb:ResetActiveSymbolLayer)
    (princ))

  (if(dcl_Form_IsActive Palette_Main)
  (setq	dname (dcl_Tree_GetItemText Palette_Main_04StyleTreeControl
		(dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl)))
	)

  ;import mask block
  (if (not (kb:checkForStyle "AEC_MASKBLOCK_REF" dname))
    (kb:ImportADTStyle
      (kb:ReturnProjectAECStylesStandardsFile)
      "AecMaskBlockRef"
      dname))
  
  (setq	oldsnap	  (getvar "osmode")
	oldecho	  (getvar "cmdecho")
	oldclayer (getvar "clayer")
	newclayer (AecGenerateLayerKey "lightclg")
  )
  (setvar "cmdecho" 1)

  (if newclayer
    (setvar "clayer" newclayer)
  )
  (dcl_setcmdbarfocus)
  (setvar "osmode" 0)
  (command "MaskAnchorAdd" "name" dname pause)
  (while (/= (getvar "cmdActive") 0)
    (command pause)
  )
  (setvar "osmode" oldsnap)
  (setq	ans (dcl_messagebox
	      "\nWould you like to mask the blocks now?"
	      "Mask Blocks?"
	      5
	      3
	    )
  )
  (if (= ans 6)
    (progn
      (setq ss (ssget '((0 . "AEC_MASKBLOCK_REF"))))
      (command "MaskAttach" ss "")
      (while (/= (getvar "cmdActive") 0)
	(command pause)
      )
    )
  )

  (setvar "cmdecho" oldecho)
  (setvar "clayer" oldclayer)
  (princ)
)


;(setq name "E_LIGHT_WALL_MOUNT")
;(setq llist nil ret nil)
;(kb:GetLocalSymbolBlocks "E_LIGHT*")
(defun kb:GetLocalSymbolBlocks(patt / name ret llist)
  (vlax-for x (vla-get-blocks (vla-get-activedocument(vlax-get-acad-object)))
    (setq name (vla-get-name x))
    (cond ((wcmatch name patt)
	   (setq ret(append ret(list name)))))
	  
	  )
  ret)
;(kb:GetSymbolBlocks "E_LIGHT*")
(defun kb:GetSymbolBlocks(patt / name ret llist dbxDoc)
  (setq dbxDoc(kb:OpenDbxDocument(kb:ReturnProjectAECStylesStandardsFile)))
  (if dbxDoc(progn
  (vlax-for x (vla-get-blocks dbxDoc)
    (setq name (vla-get-name x))
    (cond ((wcmatch name patt)
	   (setq ret(append ret(list name)))))
	  
	  )
  (kb:CloseDbxDocument dbxDoc)))
  ret)


(defun kb:ReturnDescription(name / ret)
  (if (tblsearch "block" name)
  (setq ret(cdr(assoc 4(tblsearch "block" name)))))
    ret)
;;;pgp: kbInsertSymbol,		*kbInsertSymbol
(defun c:kbInsertSymbol	 (/ *Error* lkey dname)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (kb:ResetActiveSymbolLayer)
    (princ))
  (if(dcl_Form_IsActive Palette_Main)
  (setq	lkey  (dcl_Tree_GetParent
		Palette_Main_04StyleTreeControl
		(dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl))
	dname (dcl_Tree_GetItemText
		Palette_Main_04StyleTreeControl
		(dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl)))
	)
	
  (cond	((or (= lkey "anno") (= lkey "lay"))
	 (if (vl-string-search "REV" (strcase dname))
	   (kb:SetActiveSymbolLayer "ANNREV")
	   (kb:SetActiveSymbolLayer "ANNDTOBJ")))
	((= lkey "appl") (kb:SetActiveSymbolLayer "APPL"))
	((= lkey "furn") (kb:SetActiveSymbolLayer "FURN"))
	((= lkey "lite") (kb:SetActiveSymbolLayer "LIGHTCLG"))
	((= lkey "powr") (kb:SetActiveSymbolLayer "POWER"))
	((= lkey "hvac") (kb:SetActiveSymbolLayer "EQUIPCLG"))
	((= lkey "plmb") (kb:SetActiveSymbolLayer "PFIXT"))
	((= lkey "fire") (kb:SetActiveSymbolLayer "FIRE"))
	((= lkey "eqmt") (kb:SetActiveSymbolLayer "EQUIP"))
	(t (kb:SetActiveSymbolLayer "EQUIP")))

  (if (not (tblsearch "block" dname))
    (kb:ImportCollectionObjects (kb:ReturnProjectAECStylesStandardsFile) "BLOCKS" (list dname)))

  (if (tblsearch "block" dname)
	     (command "_.insert" dname "_scale" 1 pause 0)
	   (alert "There was a problem Inserting the Block!"))
  (kb:ResetActiveSymbolLayer)
  (princ))


;(command "AecAnnoRevisionCloudAdd")
;(kb:SetActiveSymbolLayer "ANNOBJ")
;(setq lname "DOORNO")
(defun kb:SetActiveSymbolLayer	(lname / newlayer layers)
  (setq	layers (vlax-get-property (vla-get-activedocument(vlax-get-acad-object)) 'layers)
	kb%previouslayer
	 (vlax-get-property (vla-get-activedocument(vlax-get-acad-object)) 'activelayer)
	newlayer
	 (vlax-invoke layers "item" (kb:SetLayerKey lname)))
  (if newlayer
    (vlax-put-property (vla-get-activedocument(vlax-get-acad-object)) 'activelayer newlayer)))


;(kb:ResetActiveSymbolLayer)
(defun kb:ResetActiveSymbolLayer  (/)
  (if kb%previouslayer
    (progn (vlax-put-property (vla-get-activedocument(vlax-get-acad-object)) 'activelayer kb%previouslayer)
	   (setq kb%previouslayer nil)))
  (princ))

;(kb:InsertSheetViewTag)
(defun kb:InsertSheetViewTag( / inspt)
  (setq inspt(getvar "lastpoint"))
 (kb:SetActiveSymbolLayer "ANNDTOBJ")
        (if (not (tblsearch "block" "TAG_SHEET_VIEW_TITLE"))
          (kb:ImportCollectionObjects  (kb:ReturnProjectAECStylesStandardsFile)"BLOCKS" (list"TAG_SHEET_VIEW_TITLE")))
  (vla-insertBlock (kb:getactivespace) (vlax-3d-point inspt) "TAG_SHEET_VIEW_TITLE" 1.0 1.0 1.0 0.0)
  (kb:ResetActiveSymbolLayer)
  )


;;;pgp: kbRevCloud,		*kbRevCloud
(defun c:kbRevCloud( / *Error*)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break"
			     "Function cancelled"
			     "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (kb:SetActiveSymbolLayer "ANNREV")
        (if (not (tblsearch "block" "TAG_REVCLOUD"))
          (kb:ImportCollectionObjects
	    (kb:ReturnProjectAECStylesStandardsFile)"BLOCKS" (list"TAG_REVCLOUD")))
  (command "_.insert" "TAG_REVCLOUD" "_scale" 1 pause "0")
  (kb:ResetActiveSymbolLayer)
 
  )
 
;;;pgp:kbFindUnlinkedTags,		*kbFindUnlinkedTags
(defun c:kbFindUnlinkedTags  (/ ss o i attr)
  (setq ss (ssadd))
  (vlax-for
         o  (vla-get-modelspace (vla-get-activedocument(vlax-get-acad-object)))
    (if (= (vla-get-ObjectName o) "AcDbBlockReference")
      (progn
        (if (< (vlax-get o "hasattributes") 0)
          (progn (setq attr (vlax-invoke o "getattributes"))
                 (foreach
                        i  attr
                   (if (and (= (vlax-get i "TagString") "kb_NUMBER")
                            (= (vlax-get i "textstring") "VIEWNUMBER"))
                     (ssadd (vlax-vla-object->ename o) ss))))))))
  (sssetfirst ss ss)
  (princ)
  (princ))


;;;								;
;;;		Scheduling Control functions			;
;;;								;

;;;		Controls commands in the kbTools Menu		;


(defun kb:SetActiveScheduleStyle  (style / path)
  (setq path(strcat "HKEY_CURRENT_USER\\"
	    (vlax-product-key)
	    "\\Profiles\\"
	    (vla-get-ActiveProfile
			(vla-get-Profiles (vla-get-preferences (vlax-get-acad-object))))
	    "\\Dialogs\\"
	    "AecUiSchedule50-SchedTableCreateEx"))
  (vl-registry-write
    path
    "Style name"
    style)
  (vl-registry-write
    path
    "Title"
    (vl-string-translate "_" " " style))
  (princ))



;;;(kb:AddSchTag "SC_DOOR")
(defun kb:AddSchTag  (dname / *Error* file dim ent oe)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (if (not (kb:checkForStyle "AEC_MVBLOCK_DEFS" dname))
    (kb:ImportADTStyle (kb:ReturnProjectAECStylesStandardsFile) "AecMvBlockRef" dname))

  (if (kb:checkForStyle "AEC_MVBLOCK_DEFS" dname)
    (progn
      (if (setq file (kb:ReturnPropertySetFile))
        (progn
          (setvar "cmdecho" 1)
          (command ".AnnoScheduleTagAdd" file "_S" dname)
          )
        (alert "Can't find Property Set Definition Drawing!")))
    (alert
      (strcat dname " doesn't exist - use the style manager to import it!")))
  (princ)
  (princ))


;;;(kb:ADTScheduleAdd "ROOM_FINISH")
(defun kb:ADTScheduleAdd(dname / *Error* ent oe)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break"
			     "Function cancelled"
			     "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (if dname(kb:SetActiveScheduleStyle dname))
  (command "AecScheduleAdd")
  (princ)(princ))


;;;							;
;;;		Support Functions			;
;;;		ADT Drawing Scale			;
;;;							;
;;;pgp: kbSetupADTDimscale,		*kbSetupADTDimscale
(defun c:kbSetupADTDimscale  (/ scale-list)
  (if (= (vlax-product-key)
	 "Software\\Autodesk\\AutoCAD\\R17.2\\ACAD-7004:409")
    (progn
      (vl-registry-delete
	    (strcat
	      "HKEY_CURRENT_USER\\Software\\Autodesk\\AutoCAD"
	      "\\R17.2\\ACAD-7004:409\\AEC\\5.7\\AecBase50\\Scales\\Inches"))
      (setq scale-list
	     (list
	       (list (cons "00.ScaleName" "FULL")
		     (cons "00.ScaleNumber" "12")
		     (cons "00.ScalePerUnits" "12"))
	       (list (cons "01.ScaleName" "6\" = 1'-0\"")
		     (cons "01.ScaleNumber" "6")
		     (cons "01.ScalePerUnits" "12"))
	       (list (cons "02.ScaleName" "3\" = 1'-0\"")
		     (cons "02.ScaleNumber" "3")
		     (cons "02.ScalePerUnits" "12"))
	       (list (cons "03.ScaleName" "1-1/2\" = 1'-0\"")
		     (cons "03.ScaleNumber" "1.5")
		     (cons "03.ScalePerUnits" "12"))
	       (list (cons "04.ScaleName" "1\" = 1'-0\"")
		     (cons "04.ScaleNumber" "1")
		     (cons "04.ScalePerUnits" "12"))
	       (list (cons "05.ScaleName" "3/4\" = 1'-0\"")
		     (cons "05.ScaleNumber" "0.75")
		     (cons "05.ScalePerUnits" "12"))
	       (list (cons "06.ScaleName" "1/2\" = 1'-0\"")
		     (cons "06.ScaleNumber" "0.5")
		     (cons "06.ScalePerUnits" "12"))
	       (list (cons "07.ScaleName" "3/8\" = 1'-0\"")
		     (cons "07.ScaleNumber" "0.375")
		     (cons "07.ScalePerUnits" "12"))
	       (list (cons "08.ScaleName" "1/4\" = 1'-0\"")
		     (cons "08.ScaleNumber" "0.25")
		     (cons "08.ScalePerUnits" "12"))
	       (list (cons "09.ScaleName" "3/16\" = 1'-0\"")
		     (cons "09.ScaleNumber" "0.1875")
		     (cons "09.ScalePerUnits" "12"))
	       (list (cons "10.ScaleName" "1/8\" = 1'-0\"")
		     (cons "10.ScaleNumber" "0.125")
		     (cons "10.ScalePerUnits" "12"))
	       (list (cons "11.ScaleName" "3/32\" = 1'-0\"")
		     (cons "11.ScaleNumber" "0.09375")
		     (cons "11.ScalePerUnits" "12"))
	       (list (cons "12.ScaleName" "1/16\" = 1'-0\"")
		     (cons "12.ScaleNumber" "0.0625")
		     (cons "12.ScalePerUnits" "12"))
	       (list (cons "13.ScaleName" "1/32\" = 1'-0\"")
		     (cons "13.ScaleNumber" "0.03125")
		     (cons "13.ScalePerUnits" "12"))
	       (list (cons "14.ScaleName" "1\" = 10'-0\"")
		     (cons "14.ScaleNumber" "1")
		     (cons "14.ScalePerUnits" "120"))
	       (list (cons "15.ScaleName" "1\" = 20'-0\"")
		     (cons "15.ScaleNumber" "1")
		     (cons "15.ScalePerUnits" "240"))
	       (list (cons "16.ScaleName" "1\" = 30'-0\"")
		     (cons "16.ScaleNumber" "1")
		     (cons "16.ScalePerUnits" "360"))
	       (list (cons "17.ScaleName" "1\" = 40'-0\"")
		     (cons "17.ScaleNumber" "1")
		     (cons "17.ScalePerUnits" "480"))
	       (list (cons "18.ScaleName" "1\" = 50'-0\"")
		     (cons "18.ScaleNumber" "1")
		     (cons "18.ScalePerUnits" "600"))
	       (list (cons "19.ScaleName" "1\" = 60'-0\"")
		     (cons "19.ScaleNumber" "1")
		     (cons "19.ScalePerUnits" "720"))
	       (list (cons "20.ScaleName" "1\" = 70'-0\"")
		     (cons "20.ScaleNumber" "1")
		     (cons "20.ScalePerUnits" "840"))
	       (list (cons "21.ScaleName" "1\" = 80'-0\"")
		     (cons "21.ScaleNumber" "1")
		     (cons "21.ScalePerUnits" "960"))
	       (list (cons "22.ScaleName" "1\" = 90'-0\"")
		     (cons "22.ScaleNumber" "1")
		     (cons "22.ScalePerUnits" "1080"))
	       (list (cons "23.ScaleName" "1\" = 100'-0\"")
		     (cons "23.ScaleNumber" "1")
		     (cons "23.ScalePerUnits" "1200"))
	       (list (cons "24.ScaleName" "1\" = 150'-0\"")
		     (cons "24.ScaleNumber" "1")
		     (cons "24.ScalePerUnits" "1800"))
	       (list (cons "25.ScaleName" "1\" = 200'-0\"")
		     (cons "25.ScaleNumber" "1")
		     (cons "25.ScalePerUnits" "2400"))))

      (foreach
	     x	scale-list
	(foreach
	       xx  x
	  (vl-registry-write
	    (strcat
	      "HKEY_CURRENT_USER\\Software\\Autodesk\\AutoCAD"
	      "\\R17.2\\ACAD-7004:409\\AEC\\5.7\\AecBase50\\Scales\\Inches")
	    (car xx)
	    (cdr xx))))
      (alert
      "Unfortunately you have to re-start ADT for the changes to take effect."
      )
      )

    (alert
      "Sorry, I only wrote this for ADT 2009!"
      )))

;;;							;
;;;		Support Functions			;
;;;							;

(defun kb:checkForStyle	 (collection style / ret)
  (if (/= collection "standard")
    (progn (setq llist (kb:getLocalObjectList collection))
	   (if (member style llist)
	     (setq ret T)
	     (setq ret nil)))
    (setq ret t))
  ret)


(defun kb:ReturnCollectionName(sSelText / ret)
  (cond	((= sSelText "Walls")
	 (setq ret (list "AECWALL" "AEC_WALL_STYLES")))
	((= sSelText "Doors")
	 (setq ret (list "AECDOOR" "AEC_DOOR_STYLES")))
	((= sSelText "Windows")
	 (setq ret (list "AECWINDOW" "AEC_WINDOW_STYLES")))
	((= sSelText "Storefronts")
	 (setq ret (list "AecWindowAssembly" "AEC_WINDOW_ASSEMBLY_STYLES")))
	((= sSelText "Curtainwalls")
	 (setq ret (list "AecCurtainWallLayout" "AEC_CURTAIN_WALL_LAYOUT_STYLES")))
	((= sSelText "Spaces")
	 (setq ret (list "AecSpace" "AEC_SPACE_STYLES")))
	((= sSelText "Stairs")
	 (setq ret (list "AECStAIR" "AEC_STAIR_STYLES")))
	((= sSelText "Railings")
	 (setq ret (list "AECRAILING" "AEC_RAILING_STYLES")))
	((= sSelText "Schedule Tags")
	 (setq ret (list "AecMvBlockRef" "AEC_MVBLOCK_DEFS")))
	((= sSelText "Schedules")
	 (setq ret (list "AecScheduleTable" "AEC_SCHEDULE_TABLE_STYLES")))
	(t(setq ret(list"standard" "standard"))))
  ret)
;;;(kb:getObjectList "AEC_DOOR_STYLES")
(defun kb:getLocalObjectList(dictname / llist)
  (if (dictsearch (namedobjdict) dictname)
    (progn
    (foreach x (dictsearch (namedobjdict) dictname)
      (if (= (car x) 3)
	(setq llist (append (list (cdr x)) llist))))))
  llist)



(defun kb:getFullObjectList(dictname / llist dbxDoc dict name desc)
  (setq dbxDoc(kb:OpenDbxDocument(kb:ReturnProjectAECStylesStandardsFile)))
  (if dbxDoc(progn
  (if (dictsearch (vlax-vla-object->ename(vla-get-dictionaries dbxdoc)) dictname)
    (progn
      (setq dict (dictsearch (vlax-vla-object->ename(vla-get-dictionaries dbxdoc)) dictname))
    (foreach x dict
      (if (= (car x) 3)
	(progn
	  (setq name(cdr x)
		desc(cdr(assoc 3(cdr(dictsearch (cdar dict) name)))))
	(setq llist (append (list (cons name desc)) llist)))))))
  (kb:CloseDbxDocument dbxDoc)))
  llist)



(defun kb:getObjectList(dictname / llist dbxDoc)
  (setq dbxDoc(kb:OpenDbxDocument(kb:ReturnProjectAECStylesStandardsFile)))
  (if dbxDoc(progn
  (if (dictsearch (vlax-vla-object->ename(vla-get-dictionaries dbxdoc)) dictname)
    (progn
    (foreach x (dictsearch (vlax-vla-object->ename(vla-get-dictionaries dbxdoc)) dictname)
      (if (= (car x) 3)
	(setq llist (append (list (cdr x)) llist))))))
  (kb:CloseDbxDocument dbxDoc)))
  llist)

(defun kb:getLocalObjectList(dictname / llist dbxDoc)
  (setq dbxDoc(vla-get-ActiveDocument (vlax-get-acad-object)))
  (if dbxDoc(progn
  (if (dictsearch (vlax-vla-object->ename(vla-get-dictionaries dbxdoc)) dictname)
    (progn
    (foreach x (dictsearch (vlax-vla-object->ename(vla-get-dictionaries dbxdoc)) dictname)
      (if (= (car x) 3)
	(setq llist (append (list (cdr x)) llist))))))
  (kb:CloseDbxDocument dbxDoc)))
  llist)

(defun kb:getLocaltaglist(/ llist)
  (vlax-for
         x  (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
    (if (and(= (vlax-get-property x 'isxref) :vlax-false)
            (= (vlax-get-property x 'islayout) :vlax-false)
            (not(vl-string-search "|"(vla-get-name x)))
            (vl-string-search "SC_"(vla-get-name x)))
            
      (setq llist (append llist (list (vlax-get-property x 'name))))))
  llist)

(defun kb:gettaglist(/ llist dbxDoc)
  (setq dbxDoc(kb:OpenDbxDocument(kb:ReturnProjectAECStylesStandardsFile)))
  (if dbxDoc(progn
  (vlax-for x (vla-get-blocks dbxDoc)
    (if (and(= (vlax-get-property x 'isxref) :vlax-false)
            (= (vlax-get-property x 'islayout) :vlax-false)
            (not(vl-string-search "|"(vla-get-name x)))
            (vl-string-search "SC_"(vla-get-name x)))
            
      (setq llist (append llist (list (vlax-get-property x ' name))))))
  (kb:CloseDbxDocument dbxDoc)))
  llist)

;(setq doorlist nil localblocklist nil)
;;;pgp:kbDoorElevationTool,		*kbDoorElevationTool
(defun c:kbDoorElevationTool( / *Error* p1 doorlist dimscale i x dwg dbxdoc localblocklist)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq dwg(getfiled "Select a file" (strcat(kb:ReturnProjectDir)"\\constructs\\") "dwg" 0))
  (if dwg
    (progn
      (setq dbxdoc(kb:OPENDBXDOCUMENT dwg))
      (if dbxdoc
	(progn
(vlax-for x(vla-get-modelspace dbxdoc)
  (if (= (vla-get-ObjectName x)"AecDbDoor")
    (if (not (member (vla-get-StyleName x) doorlist))
      (setq doorlist(append doorlist(list (vla-get-StyleName x)))))))
(kb:CLOSEDBXDOCUMENT dbxdoc)
      (kb:ImportCollectionObjects dwg "BLOCKS" doorlist)

(setq p1(getpoint "\nSelect start point for Elevations: "))
      
(foreach i doorlist
  (if (tblsearch "block" i)
    ;(if (not (member i localblocklist))
      (progn
    (command "-insert" i "_scale" 1 p1 "0")
    (setq p1(list(+(car p1)120.0)(cadr p1)(caddr p1)))
    );)
    (progn
    (alert (strcat "Door Elevation '" i "' is not available - check the door style!"))
    (princ(strcat "\n" i)))
    )))
	(alert (strcat dwg " is not available - it may be opened by another user!"))
	)
      ))
  (princ))


(defun kb:ADTAdd  (style sSelText / collection aecobjtype)
  (cond	((= style "wall")
	 (setq collection "AECWALL"
	       aecobjtype "AEC_WALL_STYLES"))
	((member style (list "HM" "SC" "OT" "AL" "FD1" "FD2" "FD3" "FD4" "FD" "door"))
	 (setq collection "AECDOOR"
	       aecobjtype "AEC_DOOR_STYLES"))
	((= style "window")
	 (setq collection "AECWINDOW"
	       aecobjtype "AEC_WINDOW_STYLES"))
	((= style "doorwinass")
	 (setq collection "AecWindowAssembly"
	       aecobjtype "AEC_WINDOW_ASSEMBLY_STYLES"))
	((= style "curtain")
	 (setq collection "AecCurtainWallLayout"
	       aecobjtype "AEC_CURTAIN_WALL_LAYOUT_STYLES"))
	((= style "space")
	 (setq collection "AecSpace"
	       aecobjtype "AEC_SPACE_STYLES"))
	((= style "stair")
	 (setq collection "AECStAIR"
	       aecobjtype "AEC_STAIR_STYLES"))
	((= style "rail")
	 (setq collection "AECRAILING"
	       aecobjtype "AEC_RAILING_STYLES"))
	((= style "schdtag")
	 (setq collection "AecMvBlockRef"
	       aecobjtype "AEC_MVBLOCK_DEFS"))
	((= style "schd")
	 (setq collection "AecScheduleTable"
	       aecobjtype "AEC_SCHEDULE_TABLE_STYLES"))
	(t
	 (setq collection "standard"
	       aecobjtype "standard")))
  (if (not (kb:checkForStyle aecobjtype sSelText))
    (kb:ImportADTStyle
      (kb:ReturnProjectAECStylesStandardsFile)
      collection
      sSelText))
  (if (kb:checkForStyle aecobjtype sSelText)
    (progn (dcl_SetCmdBarFocus)
	   (cond ((= style "wall") (command ".walladd" "_style" sSelText))
		 ((member style (list "HM" "SC" "OT" "AL" "FD1" "FD2" "FD3" "FD4" "FD" "door"))
		  (command ".dooradd" pause "_style" sSelText))
		 ((= style "window") (command ".windowadd" pause "_style" sSelText))
		 ((= style "doorwinass")
		  (command "_.AecDoorWinAssemblyAdd" pause "_style" sSelText))
		 ((= style "curtain") (command ".curtainwalladd" "_style" sSelText))
		 ((= style "space") (command ".AecSpaceAdd" "_style" sSelText))
		 ((= style "stair") (command ".stairadd" "_style" sSelText))
		 ((= style "rail") (command ".railingadd" "_style" sSelText))
		 ((= style "slab") (command ".slabAdd"))
		 ((= style "roof") (command ".roofadd"))
		 ((= style "mass") (command ".masselementadd"))
		 ((= style "schdtag") (kb:AddSchTag sSelText))
		 ((= style "schd") (kb:ADTScheduleAdd sSelText))))
    (alert "These was a problem importing the style - sorry."))
  (princ)(princ))
;;;							;
;;;		Palette					;
;;;							;
;;;							;
(defun c:ADTPaletteAdd  (/ *Error* style sSelText collection aecobjtype)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ)) ;(alert "ADD")
  (setq	style	 (dcl_Tree_GetParent
		   Palette_Main_04StyleTreeControl
		   (dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl))
	sSelText (dcl_Tree_GetItemText
		   Palette_Main_04StyleTreeControl
		   (dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl)))
  
  (if (and style sSelText)(kb:ADTAdd style sSelText))
  (princ)(princ))



(defun kb:Propogate_04StyleTreeControl  (local / llist doors hmlist sclist allist sllist fd1list
				   fd2list fd3list fd4list otlist)
  (dcl_Tree_AddParent
    Palette_Main_04StyleTreeControl
    (list (list "Walls" "wall" 0 0 0)
	  (list "Doors" "door" 1 1 1)
	  (list "Storefront" "doorwinass" 2 2 2)
	  (list "Windows" "window" 3 3 3)
	  (list "Curtain Wall" "curtain" 4 4 4)
	  (list "Spaces" "space" 5 5 5)
	  (list "Stairs" "stair" 6 6 6)
	  (list "Railings" "rail" 7 7 7)
	  (list "Roofs" "roof" 8 8 8)
	  (list "Slabs" "slab" 9 9 9)
	  (list "Masses" "mass" 10 10 10)
	  (list "Schedule Tags" "schdtag" 11 11 11)
	  (list "Schedules" "schd" 12 12 12)
	  (list "Tags and Symbols" "tags" 13 13 13)
          (list "Details and Components" "det" 14 14 14)))
  (dcl_Tree_AddChild
    Palette_Main_04StyleTreeControl
    (list (list "door" "Metal Doors" "HM" 1 1 1)
	  (list "door" "Wood Doors" "SC" 1 1 1)
	  (list "door" "Aluminum & Glass Doors" "AL" 1 1 1)
	  (list "door" "other Doors" "OT" 1 1 1)
	  (list "door" "Fire Doors" "FD" 1 1 1)))
  (dcl_Tree_AddChild
    Palette_Main_04StyleTreeControl
    (list (list "FD" "1 hour doors" "FD1" 1 1 1)
	  (list "FD" "2 hour doors" "FD2" 1 1 1)
	  (list "FD" "3 hour doors" "FD3" 1 1 1)
	  (list "FD" "4 hour doors" "FD4" 1 1 1)))
;;;		Propogate Doors				;
  (progn (if local
	   (setq doorlist (kb:getlocalObjectList "AEC_DOOR_STYLES"))
	   (setq doorlist (kb:getObjectList "AEC_DOOR_STYLES")))
	 (foreach
		x  doorlist
	   (cond ((= (substr x 1 2) "HM") (setq hmlist (append (list x) hmlist)))
		 ((= (substr x 1 2) "SC") (setq sclist (append (list x) sclist)))
		 ((= (substr x 1 2) "AL") (setq allist (append (list x) allist)))
		 ((= (substr x 1 2) "SL") (setq sllist (append (list x) sllist)))
		 ((= (substr x 1 3) "FD1") (setq fd1list (append (list x) fd1list)))
		 ((= (substr x 1 3) "FD2") (setq fd2list (append (list x) fd2list)))
		 ((= (substr x 1 3) "FD3") (setq fd3list (append (list x) fd3list)))
		 ((= (substr x 1 3) "FD4") (setq fd4list (append (list x) fd4list)))
		 (t (setq otlist (append (list x) otlist)))))
	 (if hmlist
	   (foreach
		  i  hmlist
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "HM" i i 1 1 1)))
	 (if sclist
	   (foreach
		  i  sclist
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "SC" i i 1 1 1)))
	 (if allist
	   (foreach
		  i  allist
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "AL" i i 1 1 1)))
	 (if sllist
	   (foreach
		  i  sllist
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "AL" i i 1 1 1)))
	 (if otlist
	   (foreach
		  i  otlist
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "OT" i i 1 1 1)))
	 (if fd1list
	   (foreach
		  i  fd1list
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "FD1" i i 1 1 1)))
	 (if fd2list
	   (foreach
		  i  fd2list
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "FD2" i i 1 1 1)))
	 (if fd3list
	   (foreach
		  i  fd3list
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "FD3" i i 1 1 1)))
	 (if fd4list
	   (foreach
		  i  fd4list
	     (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "FD4" i i 1 1 1))))
;;;		Propogate DoorWinAssembly		;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_WINDOW_ASSEMBLY_STYLES"))
    (setq llist (kb:getObjectList "AEC_WINDOW_ASSEMBLY_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "DoorWinAss" x x 2 2 2))
;;;		Propogate Walls				;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_WALL_STYLES"))
    (setq llist (kb:getObjectList "AEC_WALL_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "wall" x x 0 0 0))
;;;		Propogate CurtainWalls			;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_CURTAIN_WALL_LAYOUT_STYLES"))
    (setq llist (kb:getObjectList "AEC_CURTAIN_WALL_LAYOUT_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "curtain" x x 4 4 4))
;;;		Propogate Windows			;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_WINDOW_STYLES"))
    (setq llist (kb:getObjectList "AEC_WINDOW_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "window" x x 3 3 3))
;;;		Propogate Spaces			;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_SPACE_STYLES"))
    (setq llist (kb:getObjectList "AEC_SPACE_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "space" x 5 5 5))
;;;		Propogate Stairs			;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_STAIR_STYLES"))
    (setq llist (kb:getObjectList "AEC_STAIR_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "stair" x x 6 6 6))
;;;		Propogate Railings			;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_RAILING_STYLES"))
    (setq llist (kb:getObjectList "AEC_RAILING_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "rail" x x 7 7 7))
;;;		Propogate Roof			;
  (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "roof" "standard" 8 8 8)
  (if local
    (setq llist (kb:getlocalObjectList "AEC_ROOF_SLAB_STYLES"))
    (setq llist (kb:getObjectList "AEC_ROOF_SLAB_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "roof" x x 8 8 8))
;;;		Propogate Slab			;
  (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "slab" "standard" 9 9 9)
  (if local
    (setq llist (kb:getlocalObjectList "AEC_SLABE_STYLES"))
    (setq llist (kb:getObjectList "AEC_SLABE_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "slab" x x 9 9 9))
;;;		Propogate Mass			;
  (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "mass" "standard" 10 10 10)
  (if local
    (setq llist (kb:getlocalObjectList "AEC_MASS_ELEM_STYLES"))
    (setq llist (kb:getObjectList "AEC_MASS_ELEM_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "mass" x x 10 10 10))
;;;		Propogate Schedules			;
  (if local
    (setq llist (kb:getlocalObjectList "AEC_SCHEDULE_TABLE_STYLES"))
    (setq llist (kb:getObjectList "AEC_SCHEDULE_TABLE_STYLES")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "schd" x x 12 12 12))
;;;		Propogate Schedule Tags			;
  (if local
    (setq llist (kb:getlocaltaglist))
    (setq llist (kb:gettaglist)))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "schdtag" x x 11 11 11))
;;;		Propogate Anno Tags			;
  (dcl_Tree_AddChild
    Palette_Main_04StyleTreeControl
    (list (list "tags" "Annotation" "anno" 13 13 13)
	  (list "tags" "Layout Blocks" "lay" 13 13 13)
	  (list "tags" "Appliances" "appl" 13 13 13)
	  (list "tags" "Furniture" "furn" 13 13 13)
	  (list "tags" "Lighting" "lite" 13 13 13)
	  (list "tags" "Power" "powr" 13 13 13)
	  (list "tags" "HVAC" "hvac" 13 13 13)
	  (list "tags" "Plumbing" "plmb" 13 13 13)
	  (list "tags" "Fire" "fire" 13 13 13)
	  (list "tags" "Equipment" "eqmt" 13 13 13)))
  (if local
    (setq llist (kb:GetLocalSymbolBlocks "TAG_*"))
    (setq llist (kb:GetSymbolBlocks "TAG_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "anno" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "LAY_*"))
    (setq llist (kb:GetSymbolBlocks "LAY_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "lay" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "I_APPL*"))
    (setq llist (kb:GetSymbolBlocks "I_APPL*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "appl" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "I_APPL*"))
    (setq llist (kb:GetSymbolBlocks "I_APPL*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "appl" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "I_FURN*"))
    (setq llist (kb:GetSymbolBlocks "I_FURN*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "furn" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "E_LIGHT*"))
    (setq llist (kb:GetSymbolBlocks "E_LIGHT*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "lite" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "E_POWER*"))
    (setq llist (kb:GetSymbolBlocks "E_POWER*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "powr" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "M_HVAC*"))
    (setq llist (kb:GetSymbolBlocks "M_HVAC*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "hvac" x x 13 13 13))

  (if local
    (setq llist (kb:GetLocalSymbolBlocks "M_PLUMB*"))
    (setq llist (kb:GetSymbolBlocks "M_PLUMB*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "plmb" x x 13 13 13))

  (dcl_Tree_AddChild
    Palette_Main_04StyleTreeControl
    (list (list "det" "3/8\" Details" "38" 14 14 14)
	  (list "det" "1/2\" Details" "12" 14 14 14)
	  (list "det" "3/4\" Details" "34" 14 14 14)
	  (list "det" "1\" Details" "1" 14 14 14)
	  (list "det" "3\" Details" "3" 14 14 14)
          (list "det" "Plan Components" "plan" 14 14 14)
          (list "det" "Site Components" "site" 14 14 14)))
  (if local
    (setq llist (kb:GetLocalSymbolBlocks "PLAN_*"))
    (setq llist (kb:GetSymbolBlocks "PLAN_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "plan" x x 14 14 14))

(if local
    (setq llist (kb:GetLocalSymbolBlocks "SITE_*"))
    (setq llist (kb:GetSymbolBlocks "SITE_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "site" x x 14 14 14))

(if local
    (setq llist (kb:GetLocalSymbolBlocks "DET_38_*"))
    (setq llist (kb:GetSymbolBlocks "DET_38_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "38" x x 14 14 14))

(if local
    (setq llist (kb:GetLocalSymbolBlocks "DET_12_*"))
    (setq llist (kb:GetSymbolBlocks "DET_12_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "12" x x 14 14 14))
(if local
    (setq llist (kb:GetLocalSymbolBlocks "DET_34_*"))
    (setq llist (kb:GetSymbolBlocks "DET_34_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "34" x x 14 14 14))
(if local
    (setq llist (kb:GetLocalSymbolBlocks "DET_1_*"))
    (setq llist (kb:GetSymbolBlocks "DET_1_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "1" x x 14 14 14))
(if local
    (setq llist (kb:GetLocalSymbolBlocks "DET_3_*"))
    (setq llist (kb:GetSymbolBlocks "DET_3_*")))
  (foreach
	 x  llist
    (dcl_Tree_AddChild Palette_Main_04StyleTreeControl "3" x x 14 14 14))

  (princ)
  (princ))


(defun c:Palette_Main_04AddClngGridButton_OnClicked	 (/)
  (command ".aecceilinggridadd" "s")
  (princ)(princ))


(defun c:Palette_Main_04AddColumnGridButton_OnClicked	(/)
  (command ".aeccolumngridadd")
  (princ)(princ))

(defun c:Palette_Main_04PropertyBrowseButton_OnClicked ( /)
     (command ".propertydatabrowse")
  (princ)(princ))

(defun c:Palette_Main_04DoorElevButton_OnClicked (/)
  (c:kbdoorelevationtool)
(princ)(princ))

(defun c:Palette_Main_SyncDWGButton_OnClicked (/)
  (command "_AecSynchronizeProjectDrawing")
(princ)(princ))

;(dcl_Control_GetToolTipMainText Palette_Main_04SwitchDocument) (getvar "filename"))
;(dcl_Control_GetToolTipBalloon Palette_Main_04StyleTreeControl)
(defun kb:ADT_OnInitialize	(/)
  (dcl_Control_SetPicture Palette_Main_04SwitchDocument 128)
  (dcl_Control_SetCaption Palette_Main_04DataFile (kb:ReturnProjectAECStylesStandardsFile))
  (kb:Propogate_04StyleTreeControl nil)
  (princ)
  (princ))


(defun c:Palette_Main_04StyleTreeControl_OnClicked  (/ key sItemText parent)
  (setq	key	  (dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl)
	sItemText (dcl_Tree_GetItemText Palette_Main_04StyleTreeControl key)
	parent	  (dcl_tree_getParent Palette_Main_04StyleTreeControl key))
  (if (member parent
	      (list "door" "doorwinass" "SC" "HM" "AL" "OT" "FD1" "FD2" "FD3" "FD4" "schdtag" "anno" "lay" "appl" "furn"
		    "fire" "plmb" "hvac" "powr"	"lite" "plan" "site" "38" "12" "34" "1" "3"))
    (progn (if (tblsearch "block" sItemText)
	(dcl_BlockView_DisplayBlock Palette_Main_04StylePreview sItemText 0 0.75)
	(progn (dcl_BlockView_PreLoadDwg
		 Palette_Main_04StylePreview
		 (kb:ReturnProjectAECStylesStandardsFile))
	       (dcl_BlockView_DisplayBlock Palette_Main_04StylePreview sItemText 0 0.75)))
      )
     (dcl_BlockView_Clear Palette_Main_04StylePreview)
    )
    	   
  (princ)(princ))



(defun c:Palette_Main_04StyleTreeControl_OnDblClicked  (/ key itemName)
  (setq itemName(dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl)
	key(dcl_Tree_GetParent Palette_Main_04StyleTreeControl itemName))
  
  (if (member key
	      (list "anno" "lay" "appl" "furn" "fire" "plmb" "hvac" "powr" "lite" "plan" "site" "38" "12" "34" "1" "3"))
;check for mask block
    (if (vl-string-search "E_LIGHT_FLUOR" itemName)
      (vla-sendcommand
      (vla-get-activedocument (vlax-get-acad-object))
      "kbAddFluorMask ")
      
    (vla-sendcommand
      (vla-get-activedocument (vlax-get-acad-object))
      "kbInsertSymbol ")
  )
    (vla-sendcommand
      (vla-get-activedocument (vlax-get-acad-object))
      "ADTPaletteAdd "))
  (princ)(princ))



(defun c:Palette_Main_04SwitchDocumentButton_OnClicked	 (/)
  (dcl_Tree_Clear Palette_Main_04StyleTreeControl)
  (if (= (dcl_Control_GetPicture Palette_Main_04SwitchDocumentButton) 128)
    (progn (dcl_Control_SetCaption Palette_Main_04DataFile "")
      (dcl_Control_SetCaption Palette_Main_04DataFile(getvar "dwgname"))
      (dcl_Control_SetPicture Palette_Main_04SwitchDocumentButton 133)
      (dcl_Control_SetMouseOverPicture Palette_Main_04SwitchDocumentButton 133)
	   (kb:Propogate_04StyleTreeControl t))
    (progn (dcl_Control_SetPicture Palette_Main_04SwitchDocumentButton 133)
      (dcl_Control_SetCaption Palette_Main_04DataFile "")
      (dcl_Control_SetCaption Palette_Main_04DataFile(kb:ReturnProjectAECStylesStandardsFile))
      (dcl_Control_SetMouseOverPicture Palette_Main_04SwitchDocumentButton 128)
      (dcl_Control_SetPicture Palette_Main_04SwitchDocumentButton 128)
	   (kb:Propogate_04StyleTreeControl nil)))
  (princ)
  (princ))


(defun c:Palette_Main_04StyleManagerButton_OnClicked  (/ sSelText)
  (Setq	sSelText
	 (dcl_Tree_GetParent
	   Palette_Main_04StyleTreeControl
	   (dcl_Tree_GetSelectedItem Palette_Main_04StyleTreeControl)))
  (cond	((= sSelText "wall") (command ".wallstyle"))
	((member sSelText
		 (list "HM" "SC" "OT" "AL" "FD1" "FD2" "FD3" "FD4" "FD"))
	 (command ".doorstyle"))
	((= sSelText "window") (command ".windowstyle"))
	((= sSelText "doorwinass") (command "_.AecDoorWinAssemblystyle"))
	((= sSelText "curtain") (command ".curtainwallstyle"))
	((= sSelText "Ceiling Grids") (command "aecstylemanager"))
	((= sSelText "space") (command ".spacestyle"))
	((= sSelText "stair") (command ".stairstyle"))
	((= sSelText "rail") (command ".railingstyle"))
	((= sSelText "Structural Grid") (command "aecstylemanager"))
	((= sSelText "roof") (command "aecstylemanager"))
	((= sSelText "schdtag") (command "aecstylemanager"))
	((= sSelText "schd") (command "aecschedulestyle"))
	(t (command "aecstylemanager")))
  (princ)(princ))


;;;								;
;;;	Popup Commands						;
;;;								;

(defun c:kbADTPopupAdd  (/ *Error* style sSelText collection aecobjtype)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ)) ;(alert "ADD")
  (setq	style	 (vl-bb-ref 'ADTPopupStyle)
	sSelText (dcl_ListBox_GetText
		   ADT_ADTPopup_ListBox
		   (dcl_ListBox_GetCurSel ADT_ADTPopup_ListBox)))
  
  (if (and style sSelText)(kb:ADTAdd style sSelText))
  (princ)(princ))


(defun c:ADT_ADTPopup_OnInitialize ( / style)
  (setq style(vl-bb-ref 'ADTPopupStyle))
  (if style
    (progn
  (dcl_ListBox_Clear ADT_ADTPopup_ListBox)
  (cond ((= style "wall")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_WALL_STYLES")
	 )
       )
      ((= style "door")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_DOOR_STYLES")
	 )
       )
      ((= style "window")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_WINDOW_STYLES")
	 )
       )
      ((= style "doorwinass")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_WINDOW_ASSEMBLY_STYLES")
	 )
       )
      ((= style "curtain")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_CURTAIN_WALL_LAYOUT_STYLES")
	 )
       )
      ((= style "space")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_SPACE_STYLES")
	 )
       )
      ((= style "stair")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_STAIR_STYLES")
	 )
       )
      ((= style "rail")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_RAILING_STYLES")
	 )
       )
      ((= style "slab")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_SLAB_STYLES")
	 )
       )
      ((= style "roof")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_ROOFSLAB_STYLES")
	 )
       )
      ((= style "mass")
       (dcl_ListBox_AddList
	 ADT_ADTPopup_ListBox
	 (kb:getObjectList "AEC_MASS_ELEM_STYLES")
	 )
       )
      )
)
    )
(princ)
  (princ)
)

(defun c:ADT_ADTPopup_ListBox_OnDblClicked ( /)
  (vla-sendcommand
      (vla-get-activedocument (vlax-get-acad-object))
      "kbADTPopupAdd ")
     
(princ)
  (princ)
)
(defun c:ADT_ADTPopup_OnMouseMovedOff ( /)
     (dcl_form_close ADT_ADTPopup)
(princ)
  (princ)
)

;;;							;
;;;		Command Line 04				;
;;;	(kb:adtpop "door")				;

(defun kb:adtpop(objectType / pt x y)
  (if (not (member "ADT" (dcl_GetProjects)))
    (dcl_Project_load "ADT"))
  (if dcl_showErrorMsgBox
    (progn
      (setq pt (dcl_getmousecoords)
	    x  (-(nth 0 pt)10)
	    y  (-(nth 1 pt)10)
	    )
      (vl-bb-set 'ADTPopupStyle objectType)
      (if (not (dcl_Form_IsActive ADT_ADTPopup))
	  (dcl_Form_Show ADT_ADTPopup (fix x) (fix y)))

      
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ))

;;;pgp: kbWallPop,		*kbWallPop
(defun c:kbWallPop (/)
  (kb:adtpop "wall")
  (princ) (princ)
  )

;;;pgp: kbDoorPop,		*kbDoorPop
(defun c:kbDoorPop (/)
  (kb:adtpop "door")
  (princ) (princ)
  )

;;;pgp: kbWindowPop,		*kbWindowPop
(defun c:kbWindowPop (/)
  (kb:adtpop "window")
  (princ) (princ)
  )

;;;pgp: kbStorefrontPop,		*kbStorefrontPop
(defun c:kbStorefrontPop (/)
  (kb:adtpop "doorwinass")
  (princ) (princ)
  )

;;;pgp: kbCurtainPop,		*kbCurtainPop
(defun c:kbCurtainPop (/)
  (kb:adtpop "curtain")
  (princ) (princ)
  )

;;;pgp: kbSPacePop,		*kbSpacePop
(defun c:kbSpacePop (/)
  (kb:adtpop "space")
  (princ) (princ)
  )

;;;pgp: kbStairPop,		*kbStairPop
(defun c:kbStairPop (/)
  (kb:adtpop "stair")
  (princ) (princ)
  )

;;;pgp: kbRailPop,		*kbRailPop
(defun c:kbRailPop (/)
  (kb:adtpop "rail")
  (princ) (princ)
  )

;;;pgp: kbSlabPop,		*kbSlabPop
(defun c:kbSlabPop (/)
  (kb:adtpop "slab")
  (princ) (princ)
  )

;;;pgp: kbRoofPop,		*kbRoofPop
(defun c:kbRoofPop (/)
  (kb:adtpop "roof")
  (princ) (princ)
  )

;;;pgp: kbMassPop,		*kbMassPop
(defun c:kbMassPop (/)
  (kb:adtpop "mass")
  (princ) (princ)
  )

(princ "\nADT & Production Tools loaded!")
(princ)
;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
