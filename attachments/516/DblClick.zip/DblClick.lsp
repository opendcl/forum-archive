(command "opendcl")
 (dcl_project_load "TestChkBoxDictEvent.odcl" T)
  ;;reload flag

  (dcl_Form_Show TestChkBoxDictEvent_Form1)

(defun c:TestChkBoxDictEvent_Form1_CheckBox1_OnClicked (Value /)
  ;(tcam:createdict "test3")
  (princ "Clicked ")
  (princ)
)

(defun c:TestChkBoxDictEvent_Form1_CheckBox1_OnDblClicked (/)
  (princ "DblClicked ")
  (princ)
)
