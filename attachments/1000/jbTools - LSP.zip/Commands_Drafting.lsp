(if (not (vl-bb-ref 'Drafting))
  (vl-bb-set
    'Drafting
    (dcl_project_import
      '("YWt6AxIkAADj7RL6BuKTJ6MxYitqQerRJd5TboUfin+t1NYjxc6SfDMCVxZc6nzTr+ZK15JQpRzJ"
"uyzalnWFePdxuGndL23h8+H3pLhZ3ECquuaAf8CLuzr1QN+P3ZVHmVBFTcGj4x/eHveyTA2ZCbHH"
"maIFkEcZGHAFjMmNKkYzQTOvZhsW5FiWXOPbYzoK3eC2dv1iomD0L/LEV7fyL5QamHa71/Wsom2f"
"CPJsAvMucSHd8lyqv4LDQly9Q2Oi6Z8V7LjTrMI2kp8g37kKAuS5Csyyeok7KgzqAW/YCmmQrNQz"
"2ghPIfixRqFZ1uhkOxZrMco/GMXxMuvQHxuQ89kmEeixalGPRjUC+5HZtiLZqGvQfMVHN0tVI1yx"
"shfduTFCFa2Unun6AKu/RIB1viF8gZlwwFCGEa5JMYvgj3lDdaeTIDZlUdqzw+KRQsIapD+pQSrJ"
"3DSXkXzgf4JLJajnZOdh/wC7/XHYllbfWePfjNhBPb0yAeSxd5tjHeB3BOsXmFGuTJW7xKvMMKOU"
"+Q7V5bWV7cXaLLQThHBMO/2d+Klq8x6XvXCDyp5E8YREOZsbTOFE5dUdQf2zEH4Cr13VF/bzqbiZ"
"R+MG6JGFhwTosimwYhD/LUj14rkesAVjxFZKXXCAKI5WRpP9vgG8vye//b4BYo7u/QsjfT45OQNm"
"kq5wjRV86YZ6jjn+QXiCH/4dGfWEU0BxhjwPQCu1HJE33sF2hstMUFWQpFYjw5bMRaMQRL8ATWO4"
"N4F6WWsIye1gbgKqv4l0kHi5gnFiyyGawncM4dpYsUKI/J3GYilNpEAVrFzDbaive4yvrx1uVg9m"
"gU1G1FVOkF8RHhZMZnq5cWVmw06hbv/ciKabD8I2xvIilPhINYkNmLIs4RiWauMZ8IqjYfyx/0B2"
"N41CnpjzzuKbkZ3GZi13FMet3ocoD/FTwJPSOokGdyiINY9zv5w9ToApuSwMr5pdbErM8B6MFwzR"
"l2bDsqkX5Jqn+DY/wbf4cv1VvQ2v0xitrDPTbaBU2Wu8aa3xVaPiXRHEBz+OpY4MCOH9jdyx6yDE"
"tkEDFsRGf42PB9CUgvj+QH6KbpecTutCKT1EA1u5z9DBu6x72PmzdLQj/DT9zDFtODRTwv8/lyjN"
"a/yMU4x4G+q8e9uskZzeqovSVVZVR7AILnh529mkX0v5RmXX+SEARMqErt8LeSXlNg4BNNVjFxD7"
"VKvzxihAGi3sgjVNAaQrk/YNwdPzCk0x0fAwFzO6qDHEh0C8g+NETDxP2IpM8fJtwMooI9zCuP4U"
"+Ue7rBgmuc3Cp50KW9aw36bZsA/BrtF8iNcNVqPZsN+CjW7boEQ5ky2Syy0K/+mTKavGX+xIyNSv"
"KFeAwlggGUM9Et3lJ4xWFiavCvlgfYRDIXlYo3zXYZVooe0BlDHtiQ2RZIfZANINlhkN9kT5nAuq"
"RwqDoKqhwCSpVZlcpXcB6xEf3C/1djEelqtBvSjlq8mlNxD9/JB2EhDKDFtH1hjdsGZIViXe6M+o"
"XpN/wz8/lC0Sql5k/15Ccj9sf4JWloF4jla2AX78kg/5gLmiuHjD0KHZ+N1GOmwGIQ4uLpCgmt4y"
"/MB7viYXZ3HWwsJ9Bu2VX1gtn4clwECsVlcK7FARQf9LBjleJgLgvmeMeNXQhXB4Ha656ZyLQ/9h"
"J5NtxsLtEkH9/b3PJAa2wNErrzDURwfNj/OpARYHkVgDPv2pOM2tOrUyRUjKImZIvRlFp4EKS5VW"
"Rf9iK0QM6Oa1pzgArLvpu7s7kLeVYQH5pjgAB4NS3/t0udsnpchK1XwNF1DRIU/HAuaIiYMIsCtT"
"KKSCAKpd6GeJz7LsJBjX8huIxlJNxW/oz3wyULip+5SMUzfVOX8NZesLK3nKKhbzV5LUDyVanR3v"
"OssmOtAMWjQCm/5bKumkHI+BA3KWLwRhRhrrst9a0T+AZJjBA8bxAX9Fa9Yq"))))


;;;							;
;;;	Select Layer(s) Form				;
;;;(kb:SelectLayerForm)					;

(defun kb:SelectLayerForm  (/ ret)

(defun c:Drafting_SelectLayer_OnInitialize (/ llist)
  (vlax-for
	 x (vla-get-layers (vla-get-activedocument (vlax-get-acad-object)))
    (if	(not (vl-string-search "|" (vla-get-name x) 0))
      (setq llist (append llist (list (vla-get-name x))))
      )
    )
  (if llist
    (progn
      (setq llist (ACAD_STRLSORT llist))
      (dcl_ListBox_AddList Drafting_SelectLayer_LayerList llist)
      )
    )
  )

(defun c:Drafting_SelectLayer_OnCancelClose (bCancelling /)
  (setq ret nil)
  ret
)

(defun c:Drafting_SelectLayer_CancelButton_OnClicked ( /)
  (dcl_form_close Drafting_SelectLayer)
  (setq ret nil)
  ret  
)

(defun c:Drafting_SelectLayer_SelectButton_OnClicked ( / )
  (setq ret (dcl_ListBox_GetText Drafting_SelectLayer_LayerList 
		    (dcl_ListBox_GetCurSel Drafting_SelectLayer_LayerList)
		    )
	   )
  
  (dcl_form_close Drafting_SelectLayer)
  ret
)

(if(not(member "Drafting" (dcl_GetProjects)))
	 (dcl_Project_load "Drafting")) 
  (dcl_Form_Show Drafting_SelectLayer)
  
  ret)

;;;						;
;;;	3d Tools				;
;;;						;
;;;pgp: kbSubtract,		*kbSubtract
(defun c:kbSubtract (/ *Error* cmde subtract_ent subtract_objects e)
  (defun *Error* (Msg)
     (cond ((or (not Msg)
           (member Msg '("console break" "Function cancelled" "quit / exit abort" ))))
           ((princ (strcat "\nError: " Msg)))) 
     (princ)
  )
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setvar "CMDECHO" 0)
  (prompt "\nSelect solids and regions to subtract from ...")
  (setq subtract_ent (ssget'((0 . "3DSOLID"))))
  (if subtract_ent(progn
		    (prompt "\nSelect solids and regions to subtract ...")
    (setq subtract_objects (ssget)))
  )
  (if subtract_objects
    (progn
    (setq cnt 0 num(sslength subtract_ent))
    (while(< cnt num)
      (setq e (ssname subtract_ent cnt))
      (setq subtract_obj(kb:copysolidstosubtract subtract_objects))
      (command "_.subtract" e "" subtract_obj "")
      (princ "\nDone!")
      (setq cnt(1+ cnt))))
  )
  (vla-EndUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (princ)
)

(defun kb:copysolidstosubtract(subtract_objects / o new-o cnt num subtract_obj)
  (setq cnt 0
	num(sslength subtract_objects)
	subtract_obj(ssadd))
    (while(< cnt num)
      (setq o (vlax-ename->vla-object(ssname subtract_objects cnt))
	    new-o(vla-copy o) 
	    subtract_obj(ssadd (vlax-vla-object->ename new-o) subtract_obj)
	    cnt(1+ cnt))
      )
subtract_obj)


;;;pgp: kbIntersect,		*kbIntersect
(defun c:kbIntersect (/ *Error* cmde subtract_ent subtract_objects e)
  (defun *Error* (Msg)
     (cond ((or (not Msg)
           (member Msg '("console break" "Function cancelled" "quit / exit abort" ))))
           ((princ (strcat "\nError: " Msg)))) 
     (princ)
  )
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setvar "CMDECHO" 0)
  (setq subtract_objects (ssget))
  
  (if subtract_objects
    (progn
    (command "_.copy" subtract_objects "" "0,0,0" "0,0,0")
    (command "_.intersect" subtract_objects "")
      (princ "\nDone!"))
  )
  (vla-EndUndoMark  (vla-get-activedocument(vlax-get-acad-object)))
  (princ)
)

;;;pgp: kbSlice,		*kbSlice
(defun c:kbSlice (/ *Error* subtract_ent subtract_objects)
  (defun *Error* (Msg)
     (cond ((or (not Msg)
           (member Msg '("console break" "Function cancelled" "quit / exit abort" ))))
           ((princ (strcat "\nError: " Msg)))) 
     (princ)
  )
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setvar "CMDECHO" 0)
  (setq subtract_objects (ssget))
  
  (if subtract_objects
    (progn
    (command "_.slice" subtract_objects "" "_O" pause "_B")
      (princ "\nDone!"))
  )
  (vla-EndUndoMark  (vla-get-activedocument(vlax-get-acad-object)))
  (princ)
)

;;;pgp: kbmiter,		*kbmiter
(defun c:kbmiter(/ *Error* cmde subtract_ent subtract_objects e)
  (defun *Error* (Msg)
     (cond ((or (not Msg)
           (member Msg '("console break" "Function cancelled" "quit / exit abort" ))))
           ((princ (strcat "\nError: " Msg)))) 
     (princ)
  )
  ;(vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setvar "CMDECHO" 0)
  (setq subtract_objects (ssget)
        p1(getpoint "\nSelect miter Start Point: ")
        p2(getpoint p1"\nDirection: ")
        p3(list(car p1)(cadr p1)(+ (caddr p1) 100.0)))
  
  (if (and p1 p2 p3 subtract_objects)
    (progn
    (command "_.slice" subtract_objects "" p1 p2 p3 "_B")
      (princ "\nDone!"))
  )
  ;(vla-EndUndoMark  (vla-get-activedocument(vlax-get-acad-object)))
  (princ)
)


;;;
;;; Gets and sets the vertical dimension
;;; of 3d objects
;;;
(defun kb:set_vert (/ vert off_dist dist)
  (setq vert(getenv "kb_3D_VERT"))
  (if (not vert)
    (setq vert (rtos 0.1 4)))
  
  (setq off_dist (getdist (strcat "\nSelect height or Through <" vert "> ")))
  (if off_dist
    (setq dist off_dist
	  vert (rtos off_dist 4))
    (setq dist (distof vert 4))
    )
  (setenv "kb_3D_VERT" vert)
  dist
)


;;;pgp: kb3dRectangMass,		*kb3dRectangMass
(defun c:kb3dRectangMass (/ *Error* pt1 sol lname)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    )
       )))
  ((princ (strcat "\nError: " Msg)))
 )
 (princ)
)
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setq pt1 (getpoint "\nFirst corner: "))
  (while pt1
    (progn
      (command "._rectang" pt1 pause)
      (do_extrude)
      (setq sol(entlast)
	    lname(vlax-get(vlax-ename->vla-object sol)'layer))
      (command "_.masselement" "_convert" sol "" "_yes" "" "")
      (vlax-put(vlax-ename->vla-object(entlast))'layer lname)
      (setq pt1 (getpoint "\nFirst corner: "))
    )
  )
  (vla-endUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  
  (princ)
)

;;;pgp: kbExtrudeLast,		*kbExtrudeLast
(defun c:kbExtrudeLast (/ *Error*)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    )
       )))
  ((princ (strcat "\nError: " Msg)))
 )  
 (princ)
)
  
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (do_extrude)
  (vla-endUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  
  (princ)
)


;;;pgp: kb3dRectang,		*kb3dRectangRectang
(defun c:kb3dRectang (/ *Error* pt1)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    )
       )))
  ((princ (strcat "\nError: " Msg)))
 )
 (princ)
)
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setq pt1 (getpoint "\nFirst corner: "))
  (while pt1
    (progn
      (command "._rectang" pt1 pause)
      (do_extrude)
      (setq pt1 (getpoint "\nFirst corner: "))
    )
  )
  (vla-endUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  
  (princ)
)

(defun do_extrude (/ rc dist)
  (setq rc (entlast)
	dist (kb:set_vert))
  (command "_.EXTRUDE" rc "" dist "")
  (if (setq obj(vlax-ename->vla-object rc))
  (vla-delete obj))
  (princ)
)
;;;pgp: kbBatchEntityExtrude,		*kbBatchEntityExtrude
(defun c:kbBatchEntityExtrude(/ *Error* ss num cnt a b off_dist dist)
  (defun *Error* (Msg)
     (cond((or (not Msg)(member Msg '("console break" "Function cancelled" "quit / exit abort"))))
     ((princ (strcat "\nError: " Msg))))(princ))
  (vla-StartUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (setq ss(ssget(list(cons 0 "LWPOLYLINE"))))
  (if ss
    (progn (setq b 0
                 a (rtos (getvar "userr1") 4)
                 b (getvar "userr1"))
           (prompt (strcat "\nSelect height or Through <" a "> "))
           (setq off_dist (getdist))
           (if (= off_dist nil)
             (setq dist b)
             (not (setq dist off_dist)))
           (setq num (sslength ss)
                 cnt 0)
           (while (< cnt num)
             (command "_.EXTRUDE" (ssname ss cnt) "" dist "") (setq cnt (1+ cnt)))
             (setvar "userr1" dist)))
  (vla-endUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (princ))

;;;pgp: kbEntityExtrude,		*kbEntityExtrude
  (defun c:kbEntityExtrude (/ *Error* obj )
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    )
       )))
  ((princ (strcat "\nError: " Msg)))
 )
 (princ)
)
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setq obj (kb:entsel "\nSelect an object:" nil nil (list "3DFACE" "LWPOLYLINE" "SPLINE" "POLYLINE" "REGION" "CIRCLE" "ELLIPSE")nil))
  (if obj
    (ent_extrude obj))
  (vla-endUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  
)


(defun ent_extrude (obj / b a off_dist dist )
  (setq b 0
   a (rtos (getvar "userr1") 4)
   b (getvar "userr1"))
  (prompt (strcat "\nSelect height or Through <" a "> "))
  (setq off_dist (getdist))
  (if (= off_dist nil)
    (setq dist b)
    (not (setq dist off_dist)
    )
  )
  (command "_.EXTRUDE" obj "" dist "")
  (setvar "userr1" dist)
  (princ)
)
;;;pgp: kb3dBoundary,		*kb3dBoundary
(defun c:kb3dBoundary (/ *Error* b p1)		;3d boundary
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    ))))
  ((princ (strcat "\nError: " Msg))))
 (princ)
)
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setvar "CMDECHO" 0)
  (setq p1 (getpoint "\nSelect internal point: "))
  (while p1
    (progn
      (command ".-boundary" p1 "")
      (while (= (logand (getvar "cmdactive")1)1)(command "_y"))
  (do_extrude)
      (setq p1 (getpoint "\nSelect internal point: "))
      ))
  (vla-endUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  
  (princ)
)
;;;pgp: kb3dBoundaryRepeat,		*kb3dBoundaryRepeat
(defun c:kb3dBoundaryRepeat (/ *Error* b p1)		;3d boundary
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    ))))
  ((princ (strcat "\nError: " Msg))))
 (princ)
)
  
  (vla-StartUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  (setvar "CMDECHO" 0)
  (setq p1 (getpoint "\nSelect internal point: "))
  (while p1
    (progn
      (command ".-boundary" p1 "")
      (while (= (logand (getvar "cmdactive")1)1)(command "_y"))
  (do_extrude_repeat)
      (setq p1 (getpoint "\nSelect internal point: "))
      ))
  (vla-endUndoMark  (vla-get-activedocument(vlax-get-acad-object)) )
  
  (princ)
)
;;;pgp: kbBatchMassConvert,		*kbBatchMassConvert
(defun c:kbBatchMassConvert(/ *Error* ss num cnt layername)
  (defun *Error* (Msg)
     (cond((or (not Msg)(member Msg '("console break" "Function cancelled" "quit / exit abort"))))
     ((princ (strcat "\nError: " Msg))))(princ))
  (vla-StartUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (setq ss(ssget(list(cons 0 "3DSOLID"))))
  (if ss
    (progn
      (setq num(sslength ss)
            cnt 0)				
         (while (< cnt num)
	   (setq layername(vla-get-layer(vlax-ename->vla-object (ssname ss cnt))))
	   (command ".MASSELEMENTCONVERT" (ssname ss cnt) "" "_y" "")
	   (vla-put-layer(vlax-ename->vla-object (entlast)) layername)
	   (setq cnt(1+ cnt)))
      ))
  (vla-endUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (princ))
;;;pgp: kbMoveFace,		*kbMoveFace
(defun c:kbMoveFace( / )
  (command "_solidedit" "_face" "_move"))

;;;						;
;;;	View Tools				;
;;;						;
;;;pgp: kbSnapshot,		*kbSnapshot
(defun c:kbSnapshot (/ *Error* bn bc)
  (defun *Error* (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))
	       )
	   )
	  ((princ (strcat "\nError: " Msg)))
	  )
    (setvar "clayer" lay)
    (setvar "osmode" osm)
    (setvar "autosnap" asnp)
    (princ)
    )
  (setvar "cmdecho" 0)
  (setq	bn "Snapshot1"
	bc 1
	)
  (while (/= (tblsearch "VIEW" bn) nil)
    (setq bc (1+ bc)
	  bn (strcat "Snapshot" (itoa bc))
	  )
    )
  (command "-view" "_s" bn)
  (princ)
  (princ (strcat "\n" bn " has been created!"))
  (princ)
  )

;;;							;
;;;	OpenDCL Control Functions			;
;;;							;

;;;							;
;;;	Form 00 - Save View / View Window		;
;;;							;
;;;pgp: kbSaveView,		*kbSaveView
(defun c:kbSaveView (/)
  (defun c:Drafting_SaveView_OnInitialize (/)
    (dcl_Control_SetPicture Drafting_SaveView_SaveButton 101)
    (dcl_Control_SetMouseOverPicture Drafting_SaveView_SaveButton 101)
    )
  (defun c:Drafting_SaveView_SaveButton_OnClicked (/ Value)
    (Setq Value (dcl_Control_GetText Drafting_SaveView_TextBox))
    (if	Value
      (progn (dcl_form_close Drafting_SaveView) (command "-view" "_s" Value))
      (dcl_messagebox "Enter a View Name to save" "Save View" 2 3)
      )
    )
  (defun c:Drafting_SaveView_CloseButton_OnClicked (/)
  (dcl_form_close Drafting_SaveView)
)

  (if (not (member "Drafting" (dcl_GetProjects)))
    (dcl_Project_load "Drafting")
    )
  (if dcl_HideErrorMsgBox
    (dcl_Form_Show Drafting_SaveView)
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )


;;;							;
;;;	Form 01 - Save Window View			;
;;;							;
;;;pgp: kbSaveViewWindow,		*kbSaveViewWindow
(defun c:kbSaveViewWindow (/)
  (defun c:Drafting_SaveView_OnInitialize (/)
    (dcl_Control_SetPicture Drafting_SaveView_SaveButton 100)
    (dcl_Control_SetMouseOverPicture Drafting_SaveView_SaveButton 100)
    )
  (defun c:Drafting_SaveView_SaveButton_OnClicked (/ Value)
    (Setq Value (dcl_Control_GetText Drafting_SaveView_TextBox))
    (if	Value
      (progn (dcl_form_close Drafting_SaveView)
	     (command "-view" "_w" Value)
	     (while (= (logand (getvar "CMDACTIVE") 1) 1) (vl-cmdf pause))
	     )
      (dcl_messagebox "Enter a View Name to save" "Save View" 2 3)
      )
    )
  (defun c:Drafting_SaveView_CloseButton_OnClicked (/)
  (dcl_form_close Drafting_SaveView)
)
  (if (not (member "Drafting" (dcl_GetProjects)))
    (dcl_Project_load "Drafting")
    )
  (if dcl_HideErrorMsgBox
    (dcl_Form_Show Drafting_SaveView)
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;							;
;;;	UCS Utility Functions				;
;;;							;

;;;(kb:ListOrthoUCS)
(defun kb:ListOrthoUCS (/ ucslist)
  (setq	ucslist
	 (list (cons "Bottom" "ucs orthoGraphic Bottom ")
	       (cons "Front" "ucs orthoGraphic Front ")
	       (cons "Back" "ucs orthoGraphic Back ")
	       (cons "Left" "ucs orthoGraphic Left ")
	       (cons "Right" "ucs orthoGraphic Right ")
	       (cons "45" "ucs _z 45 ")
	       (cons "Origin" "ucs _o ")
	       (cons "Object" "ucs _ob ")
	       )
	)
  ucslist
  )

;;;(kb:ListNamedUCS)
(defun kb:listNamedUCS (/ ucslist)
  (setq ucslist (list (cons "World" "ucs World ")))
  (vlax-for
	 x (vla-get-UserCoordinateSystems
	     (vla-get-ActiveDocument (vlax-get-acad-object))
	     )
    (setq ucslist
	   (append ucslist
		   (list (cons (vlax-get-property x 'name)
			       (strcat "ucs restore " (vlax-get-property x 'name) " ")
			       )
			 )
		   )
	  )
    )
  ucslist
  )


;;;						;
;;;	Move / Copy / Alaign Commands		;
;;;						;

(defun kb:CopyEdit  (/ *error* ent)
  (defun *Error*  (Msg)
    (cond
      ((or (not Msg)
	   (member Msg
		   '("console break"
		     "Function cancelled"
		     "quit / exit abort"))))
      ((princ (strcat "\nError: " Msg))))
    (princ)
    )
  (setvar "cmdecho" 0)
  (princ "\nSelect entities to Copy: ")
  (setq	ent (kb:entsel
	      "\nSelect text to Copy & Edit: "
	      nil
	      nil
	      (list "TEXT" "MTEXT")
	      nil))
  (while ent
    (progn
      (command "_.copy" ent "" (cdr (assoc 10 (entget (car ent)))) pause)
      (command "_.ddedit" (entlast))
      (vl-cmdf)
      (setq ent	(kb:entsel
		  "\nSelect text to Copy & Edit: "
		  nil
		  nil
		  (list "TEXT" "MTEXT")
		  nil))
      )
    )
  (princ)
  (princ)
  )
;;; Copy text then edit
;;;pgp: kbCopyEdit,		*kbCopyEdit
(defun c:kbCopyEdit (/)
  (vla-StartUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (kb:CopyEdit)
  (vla-EndUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (princ)
  (princ)
)

(defun kb:CopyRotate (  / *Error* ss1 ss e l c new_point)
  (defun *Error* (Msg)
    (cond
      ((or (not Msg)
	   (member Msg
		   '("console break"
		     "Function cancelled"
		     "quit / exit abort"
		    ))))
      ((princ (strcat "\nError: " Msg))))
    (princ)
  )
  (setvar "cmdecho" 0)
  (setq ss1 (ssadd))
  (if (setq ss (ssget))
    (progn
      (setq e (entlast)
	    l e)
      (prompt "\nSelect base point: ")
      (if (vl-cmdf "_.copy" ss "" pause pause)
	(progn
	  (while e
	    (setq e (entnext e))
	    (if	e
	      (setq ss1 (ssadd e ss1))
	    )
	  )
	  (if ss1
	    (progn
	      (setq new_point (getvar "lastpoint"))
              (vl-cmdf "_.rotate" ss1 "" new_point pause)
              ))))))
  (princ)
  (princ)
  );;;
;;; Copy objects then rotate them
;;;pgp: kbCopyRotate,		*kbCopyRotate
(defun c:kbCopyRotate (/)
  (vla-StartUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (kb:CopyRotate)
  (vla-EndUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (princ)
  (princ)
)



(defun kb:MoveRotate ( / *Error* ss new_point)
  (defun *Error* (Msg)
    (cond
      ((or (not Msg)
	   (member Msg
		   '("console break"
		     "Function cancelled"
		     "quit / exit abort"
		    ))))
      ((princ (strcat "\nError: " Msg))))(princ))
  (setvar "cmdecho" 0)
  (if (setq ss (ssget))
    (progn
      (prompt "\nSelect base point: ")
      (if (vl-cmdf "_.move" ss "" pause pause)
	(progn
          (setq new_point (getvar "lastpoint"))
          (vl-cmdf "_.rotate" ss "" new_point pause)   
	      ))))  
  (princ)
  (princ)
)



;;;
;;; Move objects then rotate them
;;;pgp: kbMoveRotate,		*kbMoveRotate
(defun c:kbMoveRotate (/)
  (vla-StartUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (kb:MoveRotate)
  (vla-EndUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (princ)
  (princ)
)


(defun kb:CopyA  (/ *Error* ss1 ss e l c p1 p2 p3 p4)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (setq ss1 nil ss nil e nil l nil c nil p1 nil p2 nil p3 nil p4 nil)
    (princ))
  (setvar "cmdecho" 0)
  (setq ss1 (ssadd)
        ss  (ssget)
        p1  (getpoint "\nSpecify first source point: ")
        p2  (getpoint p1 "\nSpecify first destination point: ")
        e   (entlast)
        l   e)
  (if (vl-cmdf "_.copy" ss "" p1 p2)
    (progn (while e
             (setq e (entnext e))
             (if e
               (setq ss1 (ssadd e ss1))))
           (if ss1
             (progn (setq p3 (getpoint "\nSpecify second source point: ")
                          p4 (getpoint p3 "\nSpecify second destination point: "))
                    (command "_.align" ss1 "" p2 p2 p3 p4 "" "no")))))
  (princ)
  (princ))


;Specify second source point:
;Specify second destination point:
;Specify third source point or <continue>:
;Scale objects based on alignment points? [Yes/No] <N>:		    
;;;
;;; Copy objects then align them
;;;pgp: kbCopyAlign,		*kbCopyAlign
(defun c:kbCopyAlign (/)
  (vla-StartUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (kb:CopyA)
  (vla-EndUndoMark (vla-get-activedocument(vlax-get-acad-object)))
  (princ)
  (princ)
)

;;;							;
;;;			Apart				;
;;;							;
;;;pgp: kbApart,		*kbApart
(defun c:kbApart( / )
  (kb:apart nil)
  (princ)
  (princ)
  )
;;;pgp: kbApartE,		*kbApartE
(defun c:kbApartE( / )
  (kb:apart T)
  (princ)
  (princ)
  )



(defun kb:Apart (kb_erase_pt / *Error* e p1 p2 side1 side2 s1 s2 rad)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort")
       )))
  ((princ (strcat "\nError: " Msg))))
 (if _osmode(setvar "OSMODE" _osmode))
 (princ)
)
  (setq	_osmode(getvar "OSMODE"))
  (setvar "osmode" 0)
  (setq off_test (getvar "offsetdist"))
  (if (= off_test -1)
    (setq b "Through")
    (setq b (rtos (getvar "offsetdist") 4))
    )
  (initget "S")
  (setq off_dist (getdist (strcat "\nOffset distance or Through <" b "> ")))
  (if  off_dist 
    (setq dist (* off_dist 0.5))
    (if (= b "Through")
    (setq dist 0.5)  
    (setq dist (*(getvar "offsetdist")0.5))
      )
    )
  (setq e-list(list "LINE" "ARC" "LWPOLYLINE" "ELLIPSE" "CIRCLE" "SPLINE"))
  ;(setq e (car (entsel)))
  
  (setq ss(ssget))
  (setq i -1)
	(while (setq e (ssname ss (setq i (1+ i))))
	  
  (if (and e (member (cdr(assoc 0(entget e))) e-list))
    (progn
      (cond
;;;LINE
	((= (cdr (assoc 0 (entget e))) "LINE")
	 (setq p1 (trans (cdr (assoc 10 (entget e))) 1 0)
	       p2 (trans (cdr (assoc 11 (entget e))) 1 0)
	 )
	 (setq side1 (cal "nor(p1,p2)")
	       side2 (cal "nor(p2,p1)")
	 )
	 (setq s1 (cal "p1 + side1")
	       s2 (cal "p1 + side2")
	 )
	)
;;;ELLIPSE
	((= (cdr (assoc 0 (entget e))) "ELLIPSE")
	 (setq s2  (trans (cdr (assoc 10 (entget e))) 1 0)
					;center of the arc
	       p1 (cdr (assoc 11 (entget e)))
	       rad(cal "dist(s2,p1)")
	       s1
		   (vlax-curve-getPointAtDist
		     (vlax-ename->vla-object e)
		     (+ 1.0 rad)
		   )
	 ) 
	)
;;;ARC
	((= (cdr (assoc 0 (entget e))) "ARC")
	 (setq s2 (trans (cdr (assoc 10 (entget e))) 1 0)
					;center of the arc
	       s1
		  (vlax-curve-getPointAtDist
		    (vlax-ename->vla-object e)
		    1.0
		  )
	 )
	)
;;;LWPOLYLINE
	((or (= (cdr (assoc 0 (entget e))) "LWPOLYLINE")
	     (= (cdr (assoc 0 (entget e))) "PLINE")
	     (= (cdr (assoc 0 (entget e))) "SPLINE"))
	 (setq p1 (trans (cdr (assoc 10 (entget e))) 1 0)
	       p2 (trans
		    (cdr
		      (assoc 10
			     (cdr (member (assoc 10 (entget e)) (entget e))
			     )
		      )
		    )
		    1
		    0
		  )
	 )
	 (setq side1 (cal "nor(p1,p2)")
	       side2 (cal "nor(p2,p1)")
	 )
	 (setq s1 (cal "p1 + side1")
	       s2 (cal "p1 + side2")
	 )
	)
;;;CIRCLE
	((= (cdr (assoc 0 (entget e))) "CIRCLE")
	 (setq s2  (trans (cdr (assoc 10 (entget e))) 1 0)
					;center of the arc
	       rad (cdr (assoc 40 (entget e)))
	       s1
		   (vlax-curve-getPointAtDist
		     (vlax-ename->vla-object e)
		     (+ 1.0 rad)
		   )
	 )
	)
      )
      (if
	(vl-cmdf "_.offset" dist e s1 e s2 "")
	(progn
	 (if kb_erase_pt(vl-cmdf "_.erase" e ""))
	 (setvar "offsetdist"(* 2 dist))
	 )
      )
    )
    (princ "Can't split that object!")
  )
	  )
  (setvar "osmode" _osmode)
  (princ)
  (princ)
)


;;;						;
;;;		Draworder			;
;;;						;
;;;pgp: kbBack,		*kbBack
(defun c:kbBack( / ss)
  (prompt "\nSelect objects to move back: ")
  (setq ss(ssget))
  (if ss(command "_.draworder" ss "" "_back"))
  (princ))
;;;pgp: kbUp,		*kbUp
(defun c:kbUp( / ss)
  (prompt "\nSelect objects to move back: ")
  (setq ss(ssget))
  (if ss(command "_.draworder" ss "" "_above"))
  (princ))

;;;						;
;;;		Divide				;
;;;						;
(defun kb:Divide (cmd / *Error* ent num)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    )
       )))((princ (strcat "\nError: " Msg))))
  (redraw (car ent) 4)  
 (setvar "cecolor" "bylayer")
 (setvar "osmode" old_snap)
 (princ)
)
(setq old_snap (getvar "osmode")
  old_ptype (getvar "pdmode")
  ent (kb:entsel "\nSelect object: " nil nil nil nil))
  (if ent
    (progn
       (redraw (car ent) 3)
      (if (= cmd "_.measure")
  (setq num (getdist "\n<Segment length>: "))    
  (setq num (getstring "\n<Number of segments>: ")))
  (redraw (car ent) 4)
  (if num
    (progn
      (if(/= (logand old_snap 8) 8)
      (setvar "osmode"(+ old_snap 8)))
      (if(= (logand (getvar "osmode") 16384) 16384)
      (setvar "osmode"(- (getvar "osmode")16384)))
  (if (/= (getvar "pdmode") 3)
    (setvar "pdmode" 3))
  (setvar "cmdecho" 0)
  (setvar "cecolor" "2")
  (vl-cmdf cmd ent num)
  (setvar "cecolor" "bylayer")
  (princ "\nUse \"kbErasePoints\" to, well, erase points and re-set System Variables.")
      ))
      ))
  (princ)
)
;;;pgp: kbErasePoints,		*kbErasePoints
(defun c:kbErasePoints ( / ep_set)
  (if old_ptype(setvar "pdmode" old_ptype))
  (setvar "cmdecho" 0)
  (if old_snap(setvar "osmode" old_snap))
  (setq ep_set (ssget "x" '((0 . "point") (62 . 2))))
  (command "_.erase" ep_set "")
  (princ "\nPoints erased, System re-set.")
  (princ)
)

;;;pgp: kbDivide,		*kbDivide
(defun c:kbDivide ()
  (kb:Divide "_.divide")
  (princ)
)
;;;pgp: kbMeasure,		*kbMeasure
(defun c:kbMeasure()
  (kb:Divide "_.measure")
  (princ)
)

;;;						;
;;;		Fillet				;
;;;						;
;;;pgp: kbFilletRadiusRedo,		*kbFilletRadiusRedo
(defun c:kbFilletRadiusRedo( / flag)
  (setq kb%filletradius(getdist "Radius: "))
  (if kb%filletradius
    (progn
      (setvar "filletrad" kb%filletradius)
  (command "_.aecfillet" "_u" "_m" "_r" "")))
  )
;;;pgp: kbFilletRadius,		*kbFilletRadius
(defun c:kbFilletRadius( / flag)
  (if kb%filletradius
    (progn
      (setvar "filletrad" kb%filletradius)
      (command "_.aecfillet" "_u" "_m" "_r" "")
      )
    (c:kbFilletRadiusRedo)
    )
  )

;;;pgp: kbFillet0,		*kbFillet0
(defun c:kbFillet0( / )
  (command "_.aecfillet" "_u" "_m" "_r" "0"))

;;;						;
;;;		Break				;
;;;						;
;;;pgp: kb1PointBreak,		*kb1PointBreak
(defun c:kb1PointBreak (/ *Error* bk_ent bk_p1)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg) 
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    ))))
  ((princ (strcat "\nError: " Msg))))
    (if bk_ent(redraw (car bk_ent) 4))
 (princ)
)
  (setvar "cmdecho" 0)
  (setq bk_ent (kb:entsel "\nSelect object: " nil nil nil nil))
  (While bk_ent
    (progn
      (redraw (car bk_ent) 3)
      (setq bk_p1 (getpoint "\nSelect point: "))
      (setq bk (vl-cmdf "_break" bk_ent "_f" bk_p1 bk_p1))
      (princ)
      (if bk
	(princ "\nEntity broken!")
      )
      (redraw (car bk_ent) 4)
      (setq bk_ent (kb:entsel "\nSelect object: " nil nil nil nil))
    )
    (not (princ "\nSee ya!")
    )
  )
)


;;
;;
;;Select - 2 point break 
;;;pgp: kb2PointBreak,		*kb2PointBreak
(defun c:kb2PointBreak (/ *Error* bk_ent bk_p1 bk_p2)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    ))))
  ((princ (strcat "\nError: " Msg)))
 )
    (if bk_ent(redraw (car bk_ent) 4))
 (princ)
)
  (setvar "cmdecho" 0)
  (setq bk_ent (kb:entsel "\nSelect object: " nil nil nil nil))
  (While bk_ent
    (progn
      (redraw (car bk_ent) 3)
      (setq bk_p1 (getpoint "\nSelect point: "))
  (setq bk_p2 (getpoint "\nSelect second point: "))
  (setq bk(vl-cmdf "_break" bk_ent "_f" bk_p1 bk_p2))
  (princ)
      (if bk
	(princ "\nEntity broken!")
      )
      (redraw (car bk_ent) 4)
      (setq bk_ent (kb:entsel "\nSelect object: " nil nil nil nil))
    )
    (not (princ "\nSee ya!")
    )
  )
)

;;;						;
;;;		Batt				;
;;;						;
;;;pgp: kbBatt,		*kbBatt
(defun c:kbBatt (/ *Error* A ANG1 ANG2 ANG3 ANG4 ANG5 ANG6 LEN1 LEN2 PT1 PT2 PT3 PT4 PT5 PT6 PT7 THK1 THK2 THK3 THK4 trimline)
  (defun *Error* (Msg)
 (cond
  ((or (not Msg)
       (member Msg '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                    )
       )))
  ((princ (strcat "\nError: " Msg)))) ;_ closes cond
    ; re-sets go here
    (setvar "aunits" au)
    (setvar "auprec" ap)
    (setvar "osmode" os)
 (princ)
)
  (setq au(getvar "aunits")
	ap(getvar "auprec")
	os(getvar "osmode"))
  (setvar "cmdecho" 0)
  (setvar "aunits" 3)
  (setvar "auprec" 8)
  (if (= (getvar "userr1") 0.0)
    (progn
      (setvar "userr1" 1)
    (setq THK(rtos 1 4)))
  (setq THK(rtos (getvar "userr1") 4)))
  (setq	PT1 (getpoint "\nEnter start point: ")
	PT2 (getpoint PT1 "\nEnter end point: ")
	THK1(getdist (strcat "\nEnter insulation thickness "THK))
  )
  (if(or(= THK1 nil)(= THK1 0.0))
    (setq THK1 (getvar "userr1"))
    (setvar "userr1" THK1))
       
  (setq	THK2(* THK1 0.25)
	THK3(* THK1 0.40000000)
	THK4(* THK1 0.44721360)
	LEN1(distance PT1 PT2)
	LEN2(/ LEN1 THK1)
	ANG1(angle PT1 PT2)       
	ANG2(+ ANG1 0.0)
	ANG3(+ ANG1 1.10714872)
	ANG4(+ ANG1 2.21429744)
	ANG5(+ ANG1 4.06888787)
	ANG6(+ ANG1 4.24874137)
	a 0
    )
  (setq trimline (ssadd))
  (setvar "osmode" 0)
  (while (< a LEN2)
    (if (= a 0)
      (progn
	(setq PT3 (polar PT1 ANG3 THK4)
	      PT4 (polar PT3 ANG4 THK2)
	      PT5 (polar PT4 ANG2 THK3)
	      PT6 (polar PT5 ANG5 THK2)
	      PT7 (polar PT6 ANG2 THK3)
	      a 0.5
	)
	(command ".pline" PT1 "w" 0.0 0.0 "a" "d" ANG2 PT3 "l" PT4 "a" PT5 "l" PT6 "a" PT7)
        )
      (progn
        (setq PT3 PT7
	      PT4 (polar PT3 ANG4 THK2) 
	      PT5 (polar PT4 ANG2 THK3) 
	      PT6 (polar PT5 ANG5 THK2) 
	      PT7 (polar PT6 ANG2 THK3)) 
	      (command PT3 "l" PT4 "a" PT5 "l" PT6 "a" PT7)
	      (setq a (+ a 0.5))
        )
      )
    )
  (command "")
  (command ".line" pt2 (polar pt2 (+ ANG1 1.5708) THK1) "")
  (ssadd (entlast) trimline)
  (command ".trim" trimline "" pt7 "")
  (command ".erase" trimline "")
  (*Error* nil)
  (princ)
)

;;;							;
;;;		Filter tools				;
;;;							;
;;;pgp: kbFilterErase,		*kbFilterErase
(defun c:kbFilterErase ()
  (kbFilter)
  (command "_.erase")
  (princ)
)
;;;pgp: kbFilterDraworderBack,		*kbFilterDraworderBack
(defun c:kbFilterDraworderBack ()
  (kbFilter)
  (command "draworder" "b")
  (princ)
)
;;;pgp: kbFilterDraworderFront,		*kbFilterDraworderFront
(defun c:kbFilterDraworderFront ()
  (kbFilter)
  (command "draworder" "f")
  (princ)
)
;;;pgp: kbModifyFilter,		*kbModifyFilter
(defun c:kbModifyFilter ()
  (kbFilter)
  (princ)
)
;;;pgp: kbFilterCount,		*kbFilterCount
(defun c:kbFilterCount ( / cnt)
  (sssetfirst gripset)
  (kbFilter)
  (setq cnt(sslength(cadr(ssgetfirst))))
  (alert (strcat "There are "(itoa cnt) " entities selected"))
  (sssetfirst gripset)
  (princ (strcat "There are "(itoa cnt) " entities selected"))
  (princ)
)
;;
;;Grip Modify with Filter
;;
(defun kbFilter (/ *Error* test_set test_set2 elay hlay test_lay add_elay)
  (defun *Error* (Msg)
     (cond ((or (not Msg) 
           (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
           ((princ (strcat "\nError: " Msg))))
     (if hLAY(redraw (car hLAY) 4))
    (princ)
  )
    
  (setq	eLAY (kb:entsel "\nPick an object to set layer filter: " nil nil nil nil))
  (if elay
    (progn
      (setq hLAY eLAY)
      (redraw (car hLAY) 3)
      (if eLAY
	(progn
	  (setq test_LAY (cdr (assoc 8 (entget (car eLAY)))))
	  (prompt "\nSelect objects: ")
	  (setq test_set (ssadd))
	  (setq add_eLAY (car eLAY))
	  (ssadd add_eLAY test_set)
	  (setq test_set2 (ssget (list (cons 8 test_LAY))))
	  (if test_set2
	    (progn
	      (ssadd add_eLAY test_set2)
	      (redraw (car hLAY) 4)
	      (sssetfirst test_set2 test_set2)
	    )
	    (not
	      (progn
		(redraw (car hLAY) 4)
		(sssetfirst test_set test_set)
	      )
	    )
	  )
	)
      )
    )
  )
  (princ)
)

;;;							;
;;;		Hatch Tools				;
;;;							;
;;;pgp: kbHatchCont,		*kbHatchCont
(defun c:kbHatchCont  (/ snap pt ent1 match ent2)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (if snap(setvar "osmode" snap))
    (princ))
  (setq snap(getvar "osmode"))
  (setvar "osmode" 0)
  (if (not kb%matchhatent)
    (setq kb%matchhatent (kb:MatchHatch)))

    
  (initget 1 "Inherit")
  (setq pt (getpoint "\nSelect internal point:  , or \"I\"nherit "))
  (if (= pt "Inherit")
    (progn (setq ent1 (kb:MatchHatch)
                 kb%matchhatent ent1)
           (command "._bhatch")
           (while (= (logand (getvar "CMDACTIVE") 1) 1) (vl-cmdf pause))
           (setq ent2 (entlast))
           (command ".matchprop" ent1 ent2 ""))
    (progn
    (command "._bhatch" pt)
    (while (= (logand (getvar "CMDACTIVE") 1) 1) (vl-cmdf pause))
           (setq ent2 (entlast))
    (command ".matchprop" kb%matchhatent ent2 ""))
    )(*error* nil)(princ))




(defun kb:MatchHatch ( / ret)
  (setq ret (kb:entsel "\nSelect a hatch to inherit Properties: " nil nil (list "HATCH") nil))
    (car ret))

;;;pgp: kbColorHatch,		*kbColorHatch
(defun c:kbColorHatch( / )
  (setvar "HPNAME" "Solid")
  (command "-hatch")
  (princ)
  (princ)
  )

;;
;;Boundary Utility
;;;pgp: kbQuickBoundary,		*kbQuickBoundary
(defun c:kbQuickBoundary (/ *Error* p1)
 (defun *Error* (Msg)
     (cond ((or (not Msg) 
           (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
           ((princ (strcat "\nError: " Msg))))
     (princ)
  )
  (setvar "cmdecho" 1)
  (initget 1)
  (setq p1 (getpoint "\nSelect internal point: "))
  (vl-cmdf "_.-boundary" p1 )
  (princ)
  (princ)
)

;;;							;
;;;		Offset Erase				;
;;;							;
;;;pgp: kbOffsetErase,		*kbOffsetErase
(defun c:kbOffsetErase (/ *Error* oldecho)
  (defun *Error* (Msg)
    (cond
      ((or (not Msg)
	   (member Msg
		   '("console break" "Function cancelled"  "quit / exit abort"))))
      ((princ (strcat "\nError: " Msg)))
      
      (setvar "cmdecho" oldecho)
    )(princ))

  (setq oldecho(getvar "cmdecho"))
  (setvar "cmdecho" 1)
      (command ".offset" "_erase" "_yes")
      (while (= (logand (getvar "CMDACTIVE") 1) 1) (vl-cmdf pause))
      (command ".offset" "_erase" "_no" "" "")
(princ))



;;;							;
;;;		Offset Layer				;
;;;							;
;;;pgp: kbOffsetLayer,		*kbOffsetLayer
(defun c:kbOffsetLayer (/ *Error* offlay lay oldecho)  
  (defun *Error* (Msg)
    (cond
      ((or (not Msg)
	   (member Msg
		   '("console break" "Function cancelled"  "quit / exit abort"))))
      ((princ (strcat "\nError: " Msg)))
      (kb:resetclayer)
      (setvar "cmdecho" oldecho)
    )(princ))

(setq oldecho(getvar "cmdecho"))
  (setvar "cmdecho" 1)
  (if (not (setq lay
		  (kb:entsel
		    "\nPick an object on the layer for Offset or [Return] to select from list: "
		    nil
		    nil
		    nil
		    nil)))
    (setq offlay (kb:SelectLayerForm))
    (setq offlay (cdr (assoc 8 (entget (car lay))))))
  (if offlay
    (progn
      (kb:setclayer offlay t)
      (command ".offset" "_layer" "_current")
      (while (= (logand (getvar "CMDACTIVE") 1) 1) (vl-cmdf pause))
      (command ".offset" "_layer" "_source" "" "")
      (kb:resetclayer)))
(princ))



;;;						;
;;;	PLine Functions				;
;;;						;
;;;pgp: kbPlineJoin,		*kbPlineJoin
(defun c:kbPlineJoin( / ent)
  (setq ent(car(entsel)))
  (if ent
    (progn
      (command ".pedit" ent)
    (if (= (cdr(assoc 0 (entget ent)))"LWPOLYLINE")
      (command"_j")
      (command "_yes" "_j"))
      )))

  
;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 0 T T nil T)
;*** DO NOT add text below the comment! ***|;
