;;;
;;; Ereignis Beispiel
;;;
;;; Dieses Beispiel demonstriert die grundlegende Ereignisbehandlung
;;;

;; Hauptprogramm
(defun c:Events (/ cmdecho result)

	;; Sicherstellen, dass die OpenDCL-Laufzeitumgebung geladen wurde (ohne Meldungen an der Befehlszeile)
	(setq cmdecho (getvar "CMDECHO"))
	(setvar "CMDECHO" 0)
	(command "_OPENDCL")
	(setvar "CMDECHO" cmdecho)

	;; Projekt laden
	(dcl_Project_Load (*ODCL:Samples:FindFile "EventHandling.odcl") T)

	;; Dialog anzeigen
	(setq result (dcl_Form_Show EventHandling_Main))

	;; Dies ist eine modale Dialogbox. Das bedeutet, dass das Programm an dieser
	;; Zeile stehen bleibt und (dcl_Form_Show) solange keinen Wert zur�ckgibt,
	;; bis der modale Dialog geschlosswen wird.
	;; In der Zwischenzeit �bernehmen die Ereignisfunktionen die Dialogsteuerung.
	;; Der R�ckgabewert von (dcl_Form_Show) wird verwendet, um die n�chste Aktion
	;; zu bestimmen.

	(if (= result 10)
		(dcl_Form_Show EventHandling_Congrats)
	)

	(princ)
)

;; Den Anwender fragen, ob er abbrechen m�chte
;; Gibt T zur�ck, wenn der Anwender Ja gedr�ckt hat; nil, wenn nicht
(defun EventHandling_PromptClose (/)
	(=
		6 ; 'Ja' Ergebnis
		(dcl_MessageBox
			"Sind Sie sicher, dass Sie abbrechen wollen?"
			"OpenDCL Beispiel"
			15 ; Ja/Nein mit 'Nein' als Vorgabe/Fokus
			3 ; Fragezeichen-Symbol
		)
	)
)

;|<<OpenDCL Event Handlers>>|;

(defun c:EventHandling_Main_OnInitialize (/)
	(dcl_Control_SetText EventHandling_Main_txtPassword "")
	(princ)
)

(defun c:EventHandling_Main_txtPassword_OnEditChanged (sText /)
	(if (= (strcase sText) "TON")
		(dcl_Form_Close EventHandling_Main 10) ; 10 zur�ckgeben im Falle einer korrekten Antwort
	)
	(princ)
)

(defun c:EventHandling_Main_btnGiveUp_OnClicked ()
	(if (EventHandling_PromptClose)
		(dcl_Form_Close EventHandling_Main)
	)
	(princ)
)

(defun c:EventHandling_Main_OnCancelClose (Canceling /)
	;; Gibt die Ereignisfunktion den Wert T zur�ck, wird der Dialog nicht geschlossen
	(not (EventHandling_PromptClose))
)

(defun c:EventHandling_Congrats_btnExit_OnClicked ()
	(dcl_Form_Close EventHandling_Congrats)
	(princ)
)

(princ)

;|<<OpenDCL Beispiel Abschluss>>|;

;;;######################################################################
;;;######################################################################
;;; Der folgende Abschnitt dient dazu, die Beispiel-Dateien zu lokalisieren.
;;; Die Pfadangabe wird um den Abschnitt des Beispielordner, erweitert, der
;;; durch das Installationsprogramm in der Registry eingetragen wurde.
;;; Die globalen Variable *ODCL:Prefix und die Function *ODCL:Samples:FindFile
;;; werden in allen Beispieldateien verwendet.
;;;
(or *ODCL:Samples:FindFile
	(defun *ODCL:Samples:FindFile (file)
		(setq *ODCL:Prefix
			(cond
				(	*ODCL:Prefix
				) ;_ Bereits definiert
				(	(vl-registry-read
						"HKEY_CURRENT_USER\\SOFTWARE\\OpenDCL"
						"SamplesFolder"
					)
				) ;_ 32-bit Variante aktueller Nutzer
				(	(vl-registry-read
						"HKEY_LOCAL_MACHINE\\SOFTWARE\\OpenDCL"
						"SamplesFolder"
					 )
				) ;_ 32-bit Variante alle Nutzer
				(	(vl-registry-read
						"HKEY_CURRENT_USER\\SOFTWARE\\Wow6432Node\\OpenDCL"
						"SamplesFolder"
					)
				) ;_ 64-bit Variante aktueller Nutzer
				(	(vl-registry-read
						"HKEY_LOCAL_MACHINE\\SOFTWARE\\Wow6432Node\\OpenDCL"
						"SamplesFolder"
					)
				) ;_ 64-bit Variante alle Nutzer
			)
		)
		(cond
			((findfile file)) ; �berpr�fe zun�chst den Supportpfad
			(*ODCL:Prefix (findfile (strcat *ODCL:Prefix file)))
			(file)
		)
	)
)

;; Ist der Hauptdialog der OpenDCL-Beispiele aktiv, starte das Beispiel sofort.
;; Andernfalls gib einen Text in der Befehlszeile aus, mit welchem Kommando das Beispiel
;; gestartet werden kann. Auf diesem Wege wird sichergestellt, dass der Name des Beispiels
;; nur an einer Stelle definiert werden muss. Das macht es einfacher, den Code wiederzuverwenden.

(	(lambda (demoname)
		(if *ODCL:MasterDemo
			(progn
				(princ (strcat "'" demoname "\n"))
				(apply (read (strcat "C:" demoname)) nil)
			)
			(progn
				(princ (strcat "\n" demoname " OpenDCL-Beispiel ist geladen."))
				(princ (strcat " (Starten Sie das Beispiel mit dem Befehl " (strcase demoname) ")\n"))
			)
		)
	)
	"Events"
)
(princ)

;;;######################################################################
;;;######################################################################

;|�Visual LISP� Format Options�
(80 4 50 2 nil "end of " 80 50 0 0 2 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
