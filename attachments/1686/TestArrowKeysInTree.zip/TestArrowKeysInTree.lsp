(defun c:TestArrowKeysInTree_Main_OnInitialize (/)
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeGraphicButton "A: Do not change Graphic Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeGraphicButton "B: Do not change Graphic Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeGraphicButton "C: Change Graphic Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeGraphicButton "D: Change Graphic Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeGraphicButton "E: Do not change Graphic Button")
  
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeTextButton "A: Do not change Text Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeTextButton "B: Do not change Text Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeTextButton "C: Change Text Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeTextButton "D: Change Text Button")
  (dcl_Tree_AddParent TestArrowKeysInTree_Main_TreeTextButton "E: Do not change Text Button")
  (princ)
)

(defun c:TestArrowKeysInTree_Main_TreeGraphicButton_OnSelChanged (label key)
  (if (member (substr label 1 1) '("C" "D"))
    (dcl_Control_SetEnabled
      TestArrowKeysInTree_Main_GraphicButton1
      (not (dcl_Control_GetEnabled TestArrowKeysInTree_Main_GraphicButton1))
    )
  )
)

(defun c:TestArrowKeysInTree_Main_TreeTextButton_OnSelChanged (label key)
  (if (member (substr label 1 1) '("C" "D"))
    (dcl_Control_SetEnabled
      TestArrowKeysInTree_Main_TextButton1
      (not (dcl_Control_GetEnabled TestArrowKeysInTree_Main_TextButton1))
    )
  )
)

(defun c:TestArrowKeysInTree ()
  (vl-cmdf "OPENDCL")
  (dcl_Project_Load "TestArrowKeysInTree" 'T)
  (dcl_Form_Show TestArrowKeysInTree_Main)
  (princ)
)
