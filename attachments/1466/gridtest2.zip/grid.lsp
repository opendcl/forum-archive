(defun c:test (/
				dclform
				c:dclInitialize
				c:dclEndLabelEdit
				)

(defun c:dclEndLabelEdit (Row Column / valx listx)
   (setq valx (dcl_Grid_GetCellText (eval (read (strcat dclform "_Grid1"))) Row Column)
      listx (car (dcl_Grid_GetCellDropList (eval (read (strcat dclform "_Grid1"))) Row Column))
      listx (if (not (member valx listx)) (append listx (list valx)) listx)
   ) ; setq
   (dcl_Grid_SetCellDropList (eval (read (strcat dclform "_Grid1"))) Row Column listx)
) ; EndLabelEdit

(defun c:dclInitialize (/ grid1 vlist i)
	(setq grid1 (eval (read (strcat dclform "_grid1"))))
	 ; wipe out what's there
	(while (> (dcl_Grid_GetRowCount GRID1) 0)
		(dcl_Grid_DeleteRow GRID1 0)
	) ; while
	(while (> (dcl_Grid_GetColumnCount GRID1) 0)
		(dcl_Grid_DeleteColumn GRID1 0)
	) ; while
	 ; add a default row
	(dcl_grid_addrow GRID1 "")
	 ; now pad columns
	 ; first our dummy read-only column
	(dcl_grid_addcolumns GRID1 (list
		(list "" 0 0)
	)) ; list addcolumns
	 ; add 1 column
	(dcl_grid_addcolumns GRID1 (list
		(list "Column1" 0 100) ; adding the title for the column
	)) ; list addcolumns
	(dcl_Grid_SetCellStyle GRID1 0 1 36) ; set to combobox

	(setq i 1)
	(while (< i 100)
		(setq vlist (append vlist (list (itoa i))))
	(setq i (1+ i))
	) ; while
		
	(dcl_Grid_SetCellDropList grid_Form1_Grid1 0 1 vlist)
) ; Initialize


(setq dclform "grid_form1")

	(command "_.OPENDCL")
	(dcl_Project_Load "grid" t)
	(dcl_form_show grid_form1)

(princ)
) ; test