;;; BC 13.2.10
;;; ODCL 7.0.1.1
;;; Win XP

;;; Problem:
    ; : ._OPEN
    ; Drawing name: D:/bKG_tmp/20131024B/test_inserted.dwg
    ; : 
    ; : 
    ; : (LOAD "D:/LispTools/DwgBrowser.lsp")C:DWGBROWSER
    ; : DWGBROWSER
    ; : OPENDCL
    ; OpenDCL Runtime [7.0.1.1] loaded
    ; : (dcl_BlockView_DisplayBlock DwgBrowser_Form1_BlockView1 "Square" 0 0.95)     <<<<<< Paste code on command line.
    ; T
    ; : (dcl_BlockView_DisplayDwg   DwgBrowser_Form1_BlockView1 "Circ.dwg" 0 0.95)
    ; T
    ; : (dcl_BlockView_DisplayBlock DwgBrowser_Form1_BlockView1 "Square" 0 0.95)
    ; nil                                                                            <<<<<< Block does not display.
    ; : (dcl_BlockView_DisplayBlock DwgBrowser_Form1_BlockView1 "Square" 0 0.95)     <<<<<< Paste code on command line.
    ; T

(defun c:DwgBrowser ( / )
  (command "OPENDCL")
  (dcl_Project_Load "DwgBrowser" T)
  (dcl_Form_Show DwgBrowser_Form1)
  (princ)
)
