(defun c:spawn (/ DCLFORM c:dclButtonClicked c:dclInitialize)
	(defun c:dclButtonClicked ()
		(dcl_Form_Close (eval (read dclform)) 1)
	) ; ButtonClicked
	(setq DCLFORM "test_form2")

	(dcl_form_show (eval (read dclform)))
) ; spawn

(defun c:test (/ DCLFORM c:dclButtonClicked c:SpawnDialog c:dclInitialize)
	(defun c:dclSpawnDialog ()
		(c:Spawn)
	) ; SpawnDialog
	(defun c:dclButtonClicked ()
		(dcl_Form_Close (eval (read dclform)) 1)
	) ; ButtonClicked
	(defun c:dclInitialize ()
		(princ)
	) ; Initialize

	(command "_.OPENDCL")
	
	(dcl_project_load "test" t)
	(setq DCLFORM "test_form1")
	
	(dcl_form_show (eval (read dclform)))
	
) ; test
