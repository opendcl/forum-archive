(setvar 'cmdecho 0)
(command "OPENDCL")
(setvar 'cmdecho 1)

(defun c:BitmapTest_Form1_OnInitialize (/)
  (dcl_PictureBox_LoadPictureFile BitmapTest_Form1_PictureBox1 (nth currentImageIndex imageList) T)
)

(defun c:BitmapTest_Form1_BtnNext_OnClicked (/)
  (setq currentImageIndex
    (rem
      (1+ currentImageIndex)
      (length imageList)
    )
  )
  (dcl_PictureBox_LoadPictureFile BitmapTest_Form1_PictureBox1 (nth currentImageIndex imageList) T)
)

(defun c:BitmapTest_Form1_BtnAuto_OnClicked ( / i)
  (princ "\nPlease wait until the number is 99\n")
  (setq i 0)
  (setvar 'cmdecho 0)
  (repeat 100
    (princ (strcat "\r" (itoa i)))
    (setq i (1+ i))
    (c:BitmapTest_Form1_BtnNext_OnClicked)
    ; (sleep 500) ; Delay is milliseconds (Bricscad)
    (command "_.delay" 500)
  )
  (setvar 'cmdecho 1)
)

(defun c:BitmapTest_Form1_BtnCancel_OnClicked (/)
  (dcl_Form_Close BitmapTest_Form1)
)

(defun c:BitmapTest1 ( / currentImageIndex imageList)
  (setq imageList
    '("Roy_1.png" "Roy_2.png" "Roy_3.png")
  )
  (setq currentImageIndex 0)
  (dcl_Project_Load "BitmapTest" T)
  (dcl_Form_Show BitmapTest_Form1)
  (princ)
)

(defun c:BitmapTest2 ( / currentImageIndex imageList)
  (setq imageList
    '("Ingo_01.png" "Ingo_02.png" "Ingo_03.png")
  )
  (setq currentImageIndex 0)
  (dcl_Project_Load "BitmapTest" T)
  (dcl_Form_Show BitmapTest_Form1)
  (princ)
)

(defun c:BitmapTest2A ( / currentImageIndex imageList)
  (setq imageList
    '("Ingo_01.bmp" "Ingo_02.bmp" "Ingo_03.bmp")
  )
  (setq currentImageIndex 0)
  (dcl_Project_Load "BitmapTest" T)
  (dcl_Form_Show BitmapTest_Form1)
  (princ)
)

(defun c:BitmapTest3 ( / currentImageIndex imageList)
  (setq imageList
    '("Ingo_256_Colors_01.png" "Ingo_256_Colors_02.png" "Ingo_256_Colors_03.png" )
  )
  (setq currentImageIndex 0)
  (dcl_Project_Load "BitmapTest" T)
  (dcl_Form_Show BitmapTest_Form1)
  (princ)
)

(princ "\nUse BitmapTest1, BitmapTest2, BitmapTest2A or BitmapTest3. ")
(princ)
