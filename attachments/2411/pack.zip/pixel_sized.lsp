(dcl-Project-Load "pixel_sized.odcl" t) 
(setq intResult (dcl-Form-Show pixel_sized/form1))
