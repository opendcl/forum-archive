(setvar 'cmdecho 0)
(vl-cmdf "_Opendcl")
(setvar 'cmdecho 1)

(defun c:BmpTest ()
  (dcl_Project_Load "BmpTest" T)
  (dcl-Form-Show BmpTest/Form1)
  (dcl-Tree-AddParent
    BmpTest/Form1/TreeControl1
    '(
      ("ParentA" "ParentA" 0 1 0)
      ("ParentB" "Parentb" 0 1 0)
    )
  )
  (dcl-Tree-AddChild
    BmpTest/Form1/TreeControl1
    '(
      ("ParentA" "ChildA1" "ChildA1" 0 1 0)
      ("ParentA" "ChildA2" "ChildA2" 0 1 0)
      ("ParentA" "ChildA3" "ChildA3" 0 1 0)
    )
  )
)
