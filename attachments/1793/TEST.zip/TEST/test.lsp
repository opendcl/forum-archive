(defun c:test ()
  (or LoadRunTime (load "_OpenDclUtils.lsp") (exit))
  (LoadRunTime)
  
  (if (/= (findfile "TEST.odcl") nil) 
      (dcl_Project_Load "TEST.odcl" T)
  )

  (dcl_Form_Show TEST_Form1)
)


(defun c:TEST_Form1_OnMouseEntered (/)
  (princ "\nenter")
)

(defun c:TEST_Form1_OnSize (NewWidth NewHeight /)
  (dcl_Control_SetWidth TEST_Form1_TextButton1 (- NewWidth 16))
)

