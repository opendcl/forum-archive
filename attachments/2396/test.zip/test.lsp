	(defun c:TEST (/ DCLFORM urlx c:dclInitialize)

		 ;-----------------------------------------------------
		(defun c:dclInitialize (/)
			(dcl-AxControl-Invoke (eval (read (strcat DCLFORM "/Explorer1"))) "Navigate2" urlx)
		) ; initialize
		 ;-----------------------------------------------------

		(setq urlx "http://www.opendcl.com")

		(dcl-Project-Load "test" t)
		(setq DCLFORM "test/form1")
		(dcl-Form-Show (eval (read DCLFORM))) ; fires initialize

	) ; TEST

(c:TEST)
(princ)
