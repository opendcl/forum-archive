;;;						;
;;;	Control Events				;
;;;						;

;;;	ListView				;
;;;						;
  
;;;	OnClicked Event				;
  (defun c:BlockManager_PaletteManager_BlocksListView_OnClicked (Row Column /)
  (setq dwgname(dcl_ListView_GetItemText BlockManager_PaletteManager_BlocksListView Row)
        dir (dcl_Tree_GetSelectedItem BlockManager_PaletteManager_NavTreeControl))
    (dcl_BlockView_DisplayDwg BlockManager_PaletteManager_PreviewBlockView (findfile(strcat dir "\\" dwgname)))
    )


;;;	OnDblClicked Event			;
  (defun c:BlockManager_PaletteManager_BlocksListView_OnDblClicked (Row Column /)
  (c:BlockManager_PaletteManager_InsertButton_OnClicked)
)

;;;	TreeView				;
;;;						;

;;;	OnSelChanged Event			;
(defun c:BlockManager_PaletteManager_NavTreeControl_OnSelChanged (Label Key / )
  (dcl_Control_SetCaption BlockManager_PaletteManager_PathLabel Key)
  (bm:PopulateListView (strcat Key "\\"))
)

;;;	OnItemExpanded Event			;
(defun c:BlockManager_PaletteManager_NavTreeControl_OnItemExpanded (Label Key / )
   (if (not(= (dcl_Tree_GetRootItem BlockManager_PaletteManager_NavTreeControl)Key))
      (progn
   (bm:PopulateExpandingItem Key)
   (dcl_Control_SetCaption BlockManager_PaletteManager_PathLabel Key)
   ))
)



;;;	BlockView				;
;;;						;

;;;	OnDblClicked Event			;
(defun c:BlockManager_PaletteManager_PreviewBlockView_OnDblClicked (/)
  (c:BlockManager_PaletteManager_InsertButton_OnClicked)
)

;;;	Close Button				;
;;;						;

;;;	OnClicked Event				;

(defun c:BlockManager_PaletteManager_CloseButton_OnClicked (/)
  (bm:SaveListViewSettings)
  (dcl_Form_Close BlockManager_PaletteManager)
)

;;;	Insert Button				;
;;;						;

;;;	OnClicked Event				;
  (defun c:BlockManager_PaletteManager_InsertButton_OnClicked (/ path blockname)
  (setq blockName(dcl_ListView_GetItemText BlockManager_PaletteManager_BlocksListView (dcl_ListView_GetCurSel BlockManager_PaletteManager_BlocksListView))
        path(dcl_Tree_GetSelectedItem BlockManager_PaletteManager_NavTreeControl)
        )
    (if (and path blockName)
	     (command "_insert" (strcat path "\\" blockname))
      )
)

;;;	Directory Button			;
;;;						;

;;;	OnClicked Event				;
(defun c:BlockManager_PaletteManager_DirectoryButton_OnClicked (/)
  (bm:SaveDir)
  (c:BlockManager_PaletteManager_OnInitialize)
)

;;;	Directory Button			;
;;;						;

;;;	OnClicked Event				;
(defun c:BlockManager_PaletteManager_ToggleButton_OnClicked (/)
  (dcl_MessageBox "To Do: code must be added to event handler\r\nc:BlockManager_PaletteManager_ToggleButton_OnClicked" "To do")
)




