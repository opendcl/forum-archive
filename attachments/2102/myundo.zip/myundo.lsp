(defun c:myundo(/ oAcad oDoc ptStart ptTarget doCont intRet
		  tostring select_point split aCmd aError nerror
		  point_from_text point_from_text_ctl
		  c:myundo/myundo#OnInitialize
		  c:myundo/myundo#OnCancelClose
		  c:myundo/myundo/pbStart#OnClicked
		  c:myundo/myundo/pbTarget#OnClicked
		  c:myundo/myundo/pbAccept#OnClicked
		  c:myundo/myundo/pbCancel#OnClicked
		  c:myundo/myundo/pbDraw#OnClicked
		  c:myundo/myundo/pbError#OnClicked
		  c:myundo/myundo/edtStart#OnEditChanged
		  c:myundo/myundo/edtTarget#OnEditChanged
		)
  (if (null dcl-project-load) (command "opendcl"))
  (if (not (member "myundo" (dcl-getprojects))) (dcl-project-load "D:/Service/Support/OpenDCL/150309/myundo.odcl"))

  (defun nerror (s)
    (if s
      (progn
	(if (dcl-form-isactive myundo/myundo) (dcl-form-close myundo/myundo 0))
	(princ (strcat "\nError occured: " s))
      ); progn
    ); if
    (if (and oDoc (= (logand (getvar "UNDOCTL") 8) 8))
      (progn
	(vla-EndUndoMark oDoc)
	(if s (command-s "_undo" "1"))
      ); progn
    ); if
    (if aCmd (setvar "cmdecho" aCmd))
    (setq *error* aerror)
  ); nerror

  (defun tostring (uVal)
    (cond
      ((not uVal) "")
      ((= (type uVal) 'REAL) (rtos uVal 2 3))
      ((= (type uVal) 'INT) (itoa uVal))
      ((listp uVal) (strcat (tostring (car uVal)) "," (tostring (cadr uVal)) "," (tostring (last uVal))))
    ); if
  ); tostring

  (defun select_point (symVar refPoint text / p)
    (if (and (setq p (vl-catch-all-apply 'getpoint (list refPoint (strcat "\nPick "text": "))))
	     (not (vl-catch-all-error-p p)))
      (set symVar p)
    ); if
  ); select_point

  (defun point_from_text (symVar text / p)
    (if (and text (/= (setq text (vl-string-trim " " text)) ""))
      (if (and (setq p (mapcar 'atof (split text ",")))
	       (or (= (length p) 2) (= (length p) 3)))
	(progn
	  (set symvar (if (= (length p) 2) (reverse (cons 0.0 (reverse p))) p))
	  T
	); progn
	nil
      ); if
      nil
    ); if
  ); point_from_text

  (defun point_from_text_ctl (symVar text control)
    (dcl-Control-SetBackColor control
      (if (and (setq res (vl-catch-all-apply 'point_from_text (list symVar text)))
	       (not (vl-catch-all-error-p res))) -6 1))
  ); point_from_text_ctl

  (defun split (text delimiter / items intLen intLast intPos)
    (setq items '())
    (setq intLen (strlen delimiter))
    (setq intLast 0)

    (while (setq intPos (vl-string-search delimiter text intLast))
      (setq items (cons (substr text (1+ intLast) (- intPos intLast)) items)
	    intLast (+ intPos intLen))
    ); while
    (setq items (cons (substr text (1+ intLast)) items))

    (reverse items)
  ); split

  (defun c:myundo/myundo#OnInitialize (/)
    (dcl-control-settext myundo/myundo/edtStart (tostring ptStart))
    (dcl-control-settext myundo/myundo/edtTarget (tostring ptTarget))
    (dcl-Control-SetBackColor myundo/myundo/edtStart -6)
    (dcl-Control-SetBackColor myundo/myundo/edtTarget -6)
  ); c:myundo/myundo#OnInitialize

  (defun c:myundo/myundo#OnCancelClose (intIsESC /) (/= intIsESC 1))

  (defun c:myundo/myundo/pbStart#OnClicked (/) (dcl-form-close myundo/myundo 3))
  (defun c:myundo/myundo/pbTarget#OnClicked (/) (dcl-form-close myundo/myundo 4))
  (defun c:myundo/myundo/pbAccept#OnClicked (/) (dcl-form-close myundo/myundo 1))
  (defun c:myundo/myundo/pbCancel#OnClicked (/) (dcl-form-close myundo/myundo 2))
  (defun c:myundo/myundo/edtStart#OnEditChanged (strNewValue /) (point_from_text_ctl 'ptStart strNewValue myundo/myundo/edtStart))
  (defun c:myundo/myundo/edtTarget#OnEditChanged (strNewValue /) (point_from_text_ctl 'ptTarget strNewValue myundo/myundo/edtTarget))
  (defun c:myundo/myundo/pbError#OnClicked () (/ 1 0))

  (defun c:myundo/myundo/pbDraw#OnClicked ()
    (vla-addline (vla-get-ModelSpace oDoc) (vlax-3d-point ptStart) (vlax-3d-point ptTarget))
    (vla-update oAcad)
  ); c:myundo/myundo/pbDraw#OnClicked


  (setq oAcad (vlax-get-acad-object)
	oDoc (vla-get-ActiveDocument oAcad)
	ptStart (getvar "LASTPOINT")
	ptTarget ptStart
	doCont T
	aCmd (getvar "cmdecho")
	aerror *error*
	*error* nerror)
  
  (setvar "cmdecho" 0)
  (vla-StartUndoMark oDoc)
  (while doCont
    (setq doCont nil)
    (setq intRet (dcl-form-show myundo/myundo))
    (cond
      ((= intRet 1) (vla-EndUndoMark oDoc))
      ((= intRet 2) (vla-EndUndoMark oDoc) (command-s "_undo" "1"))
      ((= intRet 3) (select_point 'ptStart ptTarget "startpoint") (setq doCont T))
      ((= intRet 4) (select_point 'ptTarget ptStart "targetpoint") (setq doCont T))
    ); cond
  ); while

  (nerror nil)

  (princ)
); myundo