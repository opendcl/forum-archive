;;;								;
;;;		Common Layer Functions				;
;;;		Layers, Layer States, Layer Filters		;
;;;								;
;;;								;

(defun jb:BlockLayerZero(nameStr / )
  (if (tblsearch "block" nameStr)
    (progn
(vlax-for x (vla-item (vla-get-blocks (vla-get-activedocument(vlax-get-acad-object))) nameStr)
  (vlax-put-property x 'layer "0")
  (vlax-put-property x 'color acByLayer)
  (princ "\nLayer changed!")
  ))
    (alert (strcat "\n" NameStr " not found!")))
  (princ))

;;; only sets the layerkey - local routine
;;; must deal with re-setting the previous layer
;;;(SETQ LKEY "ANNOBJ")
(defun jb:SetLayerKey  (lkey / lname)
  (if (not AecSetLayerKeyOverride)
    (jb:loadAECLayerARX))
  (if AecSetLayerKeyOverride
  (if (member lkey (aeclayerkeylist))
    (setq lname (AecGenerateLayerKey lkey))
    (setq lname (getvar "clayer")))
    (setq lname (getvar "clayer")))
  lname)



(defun jb:getlayers(filter / llist)
  (vlax-for x (vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))
    (if (vl-string-search filter (vla-get-name x) 0)
      (setq llist(append llist(list(vla-get-name x))))))
  (if llist(ACAD_STRLSORT llist))
  llist)

;;;		Set a layer current				;
;;;		If pclayer is T the previous clayer string	;
;;;		is saved in the variable "jb%oldClayer"		;
;;;								;
(defun jb:setclayer  (lname pclayer / layer)
  (if pclayer(setq jb%oldClayer(getvar "clayer")))
  (if (tblsearch "layer" lname)
    (setq layer(vla-item(vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))lname))
    (setq layer(vla-add(vla-get-layers (vla-get-activedocument(vlax-get-acad-object)))lname)))
  (vla-put-LayerOn layer 1)
  (vlax-put-property layer 'lock :vlax-false)
  (vl-catch-all-apply 'vla-put-Freeze (list layer :vlax-false))
  (vla-put-ActiveLayer (vla-get-activedocument(vlax-get-acad-object)) layer))

;;;		ReSet jb%oldClayer				;
;;;		sets jb%oldClayer to nil			;
(defun jb:resetclayer  ( / layer doc)
  (if (and jb%oldClayer
  (tblsearch "layer" jb%oldClayer))
    (progn (setq layer (vla-item (vla-get-layers (vla-get-activedocument(vlax-get-acad-object))) jb%oldClayer))
           (vla-put-LayerOn layer 1)
           (vlax-put-property layer 'lock :vlax-false)
           (vl-catch-all-apply 'vla-put-Freeze (list layer :vlax-false))
           (vla-put-ActiveLayer (vla-get-activedocument(vlax-get-acad-object)) layer)))
  (setq jb%oldClayer nil)
  )
;;; Get the layer state object
;;; (setq layobj(jb:GetLayerObject))
;;; should be released after use!!
;;; (vlax-release-object ret)
(defun jb:GetLayerObject  (/ file ret)
  (cond
             ((= (substr (getvar "ACADVER") 1 5) "15.06")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager")))
             ((= (substr (getvar "ACADVER") 1 4) "16.0")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.16")))
             ((= (substr (getvar "ACADVER") 1 4) "16.1")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.16")))
    ((= (substr (getvar "ACADVER") 1 4) "16.2")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.16")))
    ((= (substr (getvar "ACADVER") 1 4) "17.0")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.17")))
    ((= (substr (getvar "ACADVER") 1 4) "17.1")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.17")))
    ((= (substr (getvar "ACADVER") 1 4) "17.2")
              (setq ret (vla-GetInterfaceObject
              (vlax-get-acad-object)
              "AutoCAD.AcadLayerStateManager.17")))
    )
  
  ret)

(defun jb:DeleteLayerFilters  (/ extdict doc)
  (setq doc     (vla-get-activedocument (vlax-get-acad-object))
        extdict (vla-GetExtensionDictionary (vla-get-layers doc)))
  (vlax-for x (vla-item extdict "ACAD_LAYERFILTERS") (vla-delete x))
  (vlax-release-object extdict)
  (princ)
  (princ))


(defun jb:DeleteAllLayerStates  (/ extdict doc)
  (setq doc     (vla-get-activedocument (vlax-get-acad-object))
        extdict (vla-GetExtensionDictionary (vla-get-layers doc)))
  (vlax-for x (vla-item extdict "ACAD_LAYERSTATES") (vla-delete x))
  (vlax-release-object extdict)
  (princ))


;;; Make a layer
;;;use (jb:makelayer "Test" 7 "Hidden" 30  "black" -1)
(defun jb:makelayer  (lname color linetype lineweight plotstylename plottable / layers pstyle layer)
  (setq layers(vla-get-layers (vla-get-activedocument(vlax-get-acad-object))))
  (if (not (tblsearch "layer" lname))
    (setq layer (vla-add layers lname))
    (setq layer (vla-item layers lname)))
  (if layer
    (progn (vlax-put layer "color" color)
           (vlax-put layer "linetype" linetype)
           (vlax-put layer "lineweight" lineweight)
           (vlax-put layer "plotstylename" plotstylename)
           (vlax-put layer "plottable" plottable)))
  layer)


;(c:jbCreateAllLayerKeys)
(defun c:jbCreateAllLayerKeys ( / )
   (if aeclayerkeylist
   (mapcar 'aecgeneratelayerkey(aeclayerkeylist)))
 )



