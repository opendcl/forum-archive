(defun c:hidpi (/ c:dclInitialize dclform urlx)
	(setq urlx "https://www.yahoo.com")

	(defun c:dclInitialize ()
		(dcl-AxControl-Invoke (eval (read (strcat DCLFORM "/Explorer1"))) "Navigate2" urlx)
	) ; Initialize
	
	(dcl-project-load "hidpi" t)
	(setq dclform "hidpi/form1")
	(dcl-form-show (eval (read dclform)))
(princ)
) ; hidpi

(c:hidpi)
(princ)
