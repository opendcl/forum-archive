;;;
;;; Beispiel Erweiterte Liste
;;;
;;; Dieses Beispiel demonstriert die Anwendung der erweiterten Liste/mehrspaltigen Liste und ihren Ereignissen.
;;;

;; Hauptprogramm
(defun c:ListView (/ cmdecho)

	;; Sicherstellen, dass die OpenDCL-Laufzeitumgebung geladen wurde (ohne Meldungen an der Befehlszeile)
	(setq cmdecho (getvar "CMDECHO"))
	(setvar "CMDECHO" 0)
	(command "_OPENDCL")
	(setvar "CMDECHO" cmdecho)

	;; Projekt laden
	(dcl_Project_Load (*ODCL:Samples:FindFile "ListView.odcl"))

	;; Dialog anzeigen
	(dcl_Form_Show ListView_ListViewDlg)

	;; Dies ist eine modale Dialogbox. Das bedeutet, dass das Programm an dieser
	;; Zeile stehen bleibt und (dcl_Form_Show) solange keinen Wert zur�ckgibt,
	;; bis der modale Dialog geschlosswen wird.
	;; In der Zwischenzeit �bernehmen die Ereignisfunktionen die Dialogsteuerung.

	(princ)
)

;|<<OpenDCL Ereignisfunktionen>>|;

;; Diese Funktion wird automatisch ausgef�hrt, wenn der Dialog geladen wird.
(defun c:ListViewDlg_OnInitialize ( / Col0Width Col1Width Col2Width Col3Width)
    
	;; Spaltenbreite von einem Text ableiten
	(setq Col0Width (dcl_ListView_CalcColWidth ListView_ListViewDlg_ListView1 "Spalte 0     ")
		  Col1Width (dcl_ListView_CalcColWidth ListView_ListViewDlg_ListView1 "Spalte 1     ")
		  Col2Width (dcl_ListView_CalcColWidth ListView_ListViewDlg_ListView1 "Spalte 2     ")
		  Col3Width (dcl_ListView_CalcColWidth ListView_ListViewDlg_ListView1 "Spalte 3     ")
	)
	;; Spalten mit der berechneten Breite hinzuf�gen
	(dcl_ListView_AddColumns ListView_ListViewDlg_ListView1
							  (list (list "Spalte 0" 0 Col0Width)
									(list "Spalte 1" 0 Col1Width)
									(list "Spalte 2" 0 Col2Width)
									(list "Spalte 3" 0 Col3Width)
							  )
	)
	;; Bereinigen und F�llen der Liste
	(dcl_ListView_FillList
		ListView_ListViewDlg_ListView1
		(list ;; Elemente der Zeile 1
			  (list "Zelle 1a" 0 "Zelle 2a" 0 "Zelle 3a" 0 "Zelle 4a" 0)
			  ;; Elemente der Zeile 2
			  (list "Zelle 1b" 1 "Zelle 2b" 1 "Zelle 3b" 1 "Zelle 4b" 1)
			  ;; Elemente der Zeile 3
			  (list "Zelle 1c" 2 "Zelle 2c" 2 "Zelle 3c" 2 "Zelle 4c" 2)
		)
	)
)

;;-----------------------------------------------------------

(defun c:ListView_ListViewDlg_ListView1_OnClicked (nRow nCol /)
	 (dcl_MessageBox (strcat "Spalte " (itoa nCol) ", Zeile " (itoa nRow))
					  "Geklickte Zelle"
	 )
)

;;-----------------------------------------------------------

;; Hat der Anwender die Schlie�en-Schaltfl�che geklickt, wird der Dialog geschlossen
(defun c:ListViewDlg_Close_Clicked () (dcl_Form_Close ListView_ListViewDlg))

(princ)

;|<<OpenDCL Beispiel Abschluss>>|;

;;;######################################################################
;;;######################################################################
;;; Der folgende Abschnitt dient dazu, die Beispiel-Dateien zu lokalisieren.
;;; Die Pfadangabe wird um den Abschnitt des Beispielordner, erweitert, der
;;; durch das Installationsprogramm in der Registry eingetragen wurde.
;;; Die globalen Variable *ODCL:Prefix und die Function *ODCL:Samples:FindFile
;;; werden in allen Beispieldateien verwendet.
;;;
(or *ODCL:Samples:FindFile
	(defun *ODCL:Samples:FindFile (file)
		(setq *ODCL:Prefix
			(cond
				(	*ODCL:Prefix
				) ;_ Bereits definiert
				(	(vl-registry-read
						"HKEY_CURRENT_USER\\SOFTWARE\\OpenDCL"
						"SamplesFolder"
					)
				) ;_ 32-bit Variante aktueller Nutzer
				(	(vl-registry-read
						"HKEY_LOCAL_MACHINE\\SOFTWARE\\OpenDCL"
						"SamplesFolder"
					 )
				) ;_ 32-bit Variante alle Nutzer
				(	(vl-registry-read
						"HKEY_CURRENT_USER\\SOFTWARE\\Wow6432Node\\OpenDCL"
						"SamplesFolder"
					)
				) ;_ 64-bit Variante aktueller Nutzer
				(	(vl-registry-read
						"HKEY_LOCAL_MACHINE\\SOFTWARE\\Wow6432Node\\OpenDCL"
						"SamplesFolder"
					)
				) ;_ 64-bit Variante alle Nutzer
			)
		)
		(cond
			((findfile file)) ; �berpr�fe zun�chst den Supportpfad
			(*ODCL:Prefix (findfile (strcat *ODCL:Prefix file)))
			(file)
		)
	)
)

;; Ist der Hauptdialog der OpenDCL-Beispiele aktiv, starte das Beispiel sofort.
;; Andernfalls gib einen Text in der Befehlszeile aus, mit welchem Kommando das Beispiel
;; gestartet werden kann. Auf diesem Wege wird sichergestellt, dass der Name des Beispiels
;; nur an einer Stelle definiert werden muss. Das macht es einfacher, den Code wiederzuverwenden.

(	(lambda (demoname)
		(if *ODCL:MasterDemo
			(progn
				(princ (strcat "'" demoname "\n"))
				(apply (read (strcat "C:" demoname)) nil)
			)
			(progn
				(princ (strcat "\n" demoname " OpenDCL-Beispiel ist geladen."))
				(princ (strcat " (Starten Sie das Beispiel mit dem Befehl " (strcase demoname) ")\n"))
			)
		)
	)
	"ListView"
)
(princ)

;;;######################################################################
;;;######################################################################

;|�Visual LISP� Format Options�
(80 4 50 2 nil "end of " 80 50 0 0 2 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
