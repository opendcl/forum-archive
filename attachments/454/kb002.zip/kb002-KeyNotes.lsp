;;;								;
;;;	Keynote Creating Routines				;
;;;								;

;;;	Return Style Dogleg Length				;

;;;--------------------------------------------------------------------;
;;;  This function builds two VARIANTS from the two parameters.        ;
;;;  The first parameter is a list specifying the DXF group codes, the ;
;;;  second list specifies the DXF values.                             ;
;;;  After converting the parameters into safearrays, this function    ;
;;;  creates two variants containing the arrays.                       ;
;;;--------------------------------------------------------------------;
(defun kb:BuildArrays  (DxfTypes dxfValues / ListLength	Counter	Code VarValue ArrayTypes
			ArrayValues VarTypes VarValues Result)
  ;; Get length of the lists
  (setq ListLength (1- (length DxfTypes)))
  ;; Create the safearrays for the dxf group code and value
  (setq	ArrayTypes  (vlax-make-safearray vlax-vbInteger (cons 0 ListLength))
	ArrayValues (vlax-make-safearray vlax-vbVariant (cons 0 ListLength)))
  ;; Set the array elements
  (setq Counter 0)
  (while (<= Counter ListLength)
    (setq Code	   (nth Counter DxfTypes)
	  VarValue (vlax-make-variant (nth Counter DxfValues)))
    (vlax-safearray-put-element ArrayTypes Counter Code)
    (vlax-safearray-put-element ArrayValues Counter VarValue)
    (setq counter (1+ counter))) ;_ end of while
  ;; Create the two VARIANTs
  (setq	VarTypes  (vlax-make-variant ArrayTypes)
	VarValues (vlax-make-variant ArrayValues))
  ;; Create a (Lisp) list which contains the two safearrays and
  ;; return this list.
  (setq Result (list VarTypes VarValues))
  Result) ;_ end of defun

;;;								;
;;;	putKeyNoteData:						;
;;;		KeyValue: the key - "01.001"			;
;;;(kb:putKeyNotexdata (car(entsel)) "99-002")			;
;;;	use:							;
;;;	(kb:putKeyNotexdata (car(entsel)) "99-002" "This is a test" "KeyLeader" "96.0")			;
(defun kb:putKeyNotexdata  (entity key note typeflag insScale / VlaxEntity DxfTypes DxfValues)
  (setq VlaxEntity (vlax-ename->vla-object entity))
  (if (/= VlaxEntity nil)
    (progn (setq xdatas	(kb:BuildArrays
			  '(1001 1000 1000 1000 1000)
			  (list "kbKeynotes" key note typeflag insScale)))
	   (setq DxfTypes  (nth 0 xdatas)
		 DxfValues (nth 1 xdatas))
	   (vla-setXData VlaxEntity DxfTypes DxfValues)))
  (princ))

    ;(kb:getKeyNotexdata(car(entsel)))
(defun kb:getKeyNotexdata  (ename / myData key note objtype insScale)
  (setq myData (cadr (assoc -3 (entget ename (list "kbKeynotes")))))
  (if myData
    (setq key	  (cdr (nth 1 myData))
	  note	  (cdr (nth 2 myData))
	  objtype (cdr (nth 3 myData))
	  insScale(cdr (nth 4 myData))
	  ))
  (list key note objtype insScale))



;;;								;
;;;	Keynote Editing						;
;;;								;

;;;(setq obj(vlax-ename->vla-object(car(entsel))))
;;;								;
;;;	Change Keynote						;
;;;								;
;;;	used for changing all 3 types				;
;;	of Keynotes: Inserts, Mtext, Mleader			;
;;;								;

(defun kb:ChangeKeynote	 (ent key note kbknflag / obj oldnote oldkey oldkey xkey xdata nscale)
  (setq	obj   (vlax-ename->vla-object (car ent))
	xdata (kb:getKeyNotexdata (car ent)))
  (if xdata
    (progn
      (setq oldkey  (nth 0 xdata)
	    oldnote (nth 1 xdata)
	    objType (nth 2 xdata)
            nscale(nth 3 xdata))
      (if (and oldkey oldnote objType nscale)
	(progn
	  (cond
	    ((= objType "KEYLEADER") ;It's a KeyNote
	     (vla-put-textstring obj key)
	     (vlax-put obj "color" acByLayer)
	     (kb:putKeyNotexdata (car ent) key note objType nscale)
	     (if kbknflag
	       (progn
		 (vlax-for
			obj  (kb:getactivespace)
		   (if (setq xkey (kb:getKeyNotexdata (vlax-vla-object->ename obj)))
		     (progn (if	(= objType (nth 2 xkey))
			      (progn (if (= oldKey (nth 0 xkey))
				       (progn (vla-put-textstring obj key)
					      (vlax-put obj "color" acByLayer)
					      (kb:putKeyNotexdata
						(vlax-vla-object->ename obj)
						key
						note
						objType
                                                nscale)))))))))))
	  ((or (= objType "NOTELEADER") (= objType "MTEXT")) ;It's a LeaderNote or Mtext
	    (vla-put-textstring obj note)
	    (vlax-put obj "color" acByLayer)
	    (kb:putKeyNotexdata (car ent) key note objType nscale)
	    (if	kbknflag
	      (progn
		(vlax-for
		       obj  (kb:getactivespace)
		  (if (setq xkey (kb:getKeyNotexdata (vlax-vla-object->ename obj)))
		    (progn (if (= objType (nth 2 xdata))
			     (progn (if	(= oldKey (nth 0 xkey))
				      (progn (vla-put-textstring obj note)
					     (vlax-put obj "color" acByLayer)
					     (kb:putKeyNotexdata
					       (vlax-vla-object->ename obj)
					       key
					       note
					       objType nscale)))))))))))))))
	(alert "No XDATA"))
  (princ))


;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
