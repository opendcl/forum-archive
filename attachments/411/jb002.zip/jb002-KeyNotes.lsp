;;;								;
;;;	Keynote Creating Routines				;
;;;								;

;;;	Return Style Dogleg Length				;

;;;--------------------------------------------------------------------;
;;;  This function builds two VARIANTS from the two parameters.        ;
;;;  The first parameter is a list specifying the DXF group codes, the ;
;;;  second list specifies the DXF values.                             ;
;;;  After converting the parameters into safearrays, this function    ;
;;;  creates two variants containing the arrays.                       ;
;;;--------------------------------------------------------------------;
(defun jb:BuildArrays  (DxfTypes dxfValues / ListLength	Counter	Code VarValue ArrayTypes
			ArrayValues VarTypes VarValues Result)
  ;; Get length of the lists
  (setq ListLength (1- (length DxfTypes)))
  ;; Create the safearrays for the dxf group code and value
  (setq	ArrayTypes  (vlax-make-safearray vlax-vbInteger (cons 0 ListLength))
	ArrayValues (vlax-make-safearray vlax-vbVariant (cons 0 ListLength)))
  ;; Set the array elements
  (setq Counter 0)
  (while (<= Counter ListLength)
    (setq Code	   (nth Counter DxfTypes)
	  VarValue (vlax-make-variant (nth Counter DxfValues)))
    (vlax-safearray-put-element ArrayTypes Counter Code)
    (vlax-safearray-put-element ArrayValues Counter VarValue)
    (setq counter (1+ counter))) ;_ end of while
  ;; Create the two VARIANTs
  (setq	VarTypes  (vlax-make-variant ArrayTypes)
	VarValues (vlax-make-variant ArrayValues))
  ;; Create a (Lisp) list which contains the two safearrays and
  ;; return this list.
  (setq Result (list VarTypes VarValues))
  Result) ;_ end of defun

;;;								;
;;;	putKeyNoteData:						;
;;;		KeyValue: the key - "01.001"			;
;;;(jb:putKeyNotexdata (car(entsel)) "99-002")			;
;;;	use:							;
;;;	(jb:putKeyNotexdata (car(entsel)) "99-002" "This is a test" "KeyLeader")			;
(defun jb:putKeyNotexdata  (entity key note typeflag / VlaxEntity DxfTypes DxfValues)
  (setq VlaxEntity (vlax-ename->vla-object entity))
  (if (/= VlaxEntity nil)
    (progn (setq xdatas	(jb:BuildArrays
			  '(1001 1000 1000 1000)
			  (list "jbKeynotes" key note typeflag)))
	   (setq DxfTypes  (nth 0 xdatas)
		 DxfValues (nth 1 xdatas))
	   (vla-setXData VlaxEntity DxfTypes DxfValues)))
  (princ))

    ;(jb:getKeyNotexdata(car(entsel)))
(defun jb:getKeyNotexdata  (ename / myData key note objtype)
  (setq myData (cadr (assoc -3 (entget ename (list "jbKeynotes")))))
  (if myData
    (setq key	  (cdr (nth 1 myData))
	  note	  (cdr (nth 2 myData))
	  objtype (cdr (nth 3 myData))))
  (list key note objtype))

;;;								;
;;;	Place a KeyNote and Leader				;
;;;	Mleader and Mtext					;
;;;								;

(defun c:jbPlaceMleaderKeyNote	 (/ *Error* text p1 p2 key note mleader mleaderObj width dwg annoscale gap)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq	text (dcl_ListBox_GetText
	       jb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel jb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq  key	 (substr text 1 (vl-string-position (ascii "\t") text))
	    note (substr text (+ 2 (vl-string-position (ascii "\t") text)))
	    )
      (if (and key note)
	(progn
	  (command
	    ".mleader"
	    "_O"
	    "_C" "_M";make sure the content is mtext
	    "_X"
	    pause pause ".")
	  
	  (setq mleader (entlast))
	  (if
	    (= (vla-get-objectname (setq mleaderObj (vlax-ename->vla-object mleader)))
	       "AcDbMLeader")
	     (progn 
	       (vlax-put-property mleaderObj 'TextString key)
	       (jb:putKeyNotexdata (entlast) key note "KEYLEADER")
	       (vlax-put-property mleaderobj 'DoglegLength 0.125)
	       )
	    )
	  )
	)
      )
    )
  (princ))

;;;								;
;;;	Place a Keyed Note and Leader				;
;;;	Mleader and Mtext					;
;;;								;

(defun c:jbPlaceMleaderNote  (/ *Error* text p1 p2 key note mleader mleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
	       (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq	text (dcl_ListBox_GetText
	       jb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel jb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq key	 (substr text 1 (vl-string-position (ascii "\t") text))
	    note (substr text (+ 2 (vl-string-position (ascii "\t") text)))
	    width(jb:GetADTVar 40)
	    )
      (if (not width)(setq width 96.0))
      (if (and key note)
	(progn
	  (command
	    ".mleader"
	    "_O"
	    "_C" "_M";make sure the content is mtext
	    "_X"
	    pause pause ".")
	  (setq mleader (entlast))
	  (if
	    (= (vla-get-objectname (setq mleaderObj (vlax-ename->vla-object mleader)))
	       "AcDbMLeader")
	     (progn (vlax-put-property mleaderObj 'TextString note)
		    (vlax-put-property mleaderobj 'DoglegLength 0.125)
	       (vlax-put-property mleaderObj 'TextWidth (* 2.0 width))
		    (jb:putKeyNotexdata (entlast) key note "NOTELEADER")))))))
  (princ))

;;;								;
;;;	Place a Keyed Note Only					;
;;;	Mtext Only						;
;;;								;

(defun c:jbPlaceTextNote  (/ text key note lname ent)
  (setq	text (dcl_ListBox_GetText
	       jb002_00_KEYLIST
	       (dcl_ListBox_GetCurSel jb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (if	text
      (progn (setq key	(substr text 1 (vl-string-position (ascii "\t") text))
		   note	(substr text (+ 2 (vl-string-position (ascii "\t") text))))
    ;(setq lname (jb:SetLayerKey "ANNOBJ"))
	     (vl-cmdf ".mtext" pause pause note "")
	     (setq ent (vlax-ename->vla-object (entlast)))
	     (if (= (vla-get-ObjectName ent) "AcDbMText")
	       (jb:putKeyNotexdata (entlast) key note "MTEXT")))))
  (princ))


;;;								;
;;;	Keynote Editing						;
;;;								;

;;;(setq obj(vlax-ename->vla-object(car(entsel))))
;;;								;
;;;	Change Keynote						;
;;;								;
;;;	used for changing all 3 types				;
;;	of Keynotes: Inserts, Mtext, Mleader			;
;;;								;

(defun jb:ChangeKeynote	 (ent key note jbknflag / obj oldnote oldkey oldkey xkey xdata)
  (setq	obj   (vlax-ename->vla-object (car ent))
	xdata (jb:getKeyNotexdata (car ent)))
  (if xdata
    (progn
      (setq oldkey  (nth 0 xdata)
	    oldnote (nth 1 xdata)
	    objType (nth 2 xdata))
      (if (and oldkey oldnote objType)
	(progn
	  (cond
	    ((= objType "KEYLEADER") ;It's a KeyNote
	     (vla-put-textstring obj key)
	     (vlax-put obj "color" acByLayer)
	     (jb:putKeyNotexdata (car ent) key note objType)
	     (if jbknflag
	       (progn
		 (vlax-for
			obj  (jb:getactivespace)
		   (if (setq xkey (jb:getKeyNotexdata (vlax-vla-object->ename obj)))
		     (progn (if	(= objType (nth 2 xkey))
			      (progn (if (= oldKey (nth 0 xkey))
				       (progn (vla-put-textstring obj key)
					      (vlax-put obj "color" acByLayer)
					      (jb:putKeyNotexdata
						(vlax-vla-object->ename obj)
						key
						note
						objType)))))))))))
	  ((or (= objType "NOTELEADER") (= objType "MTEXT")) ;It's a LeaderNote or Mtext
	    (vla-put-textstring obj note)
	    (vlax-put obj "color" acByLayer)
	    (jb:putKeyNotexdata (car ent) key note objType)
	    (if	jbknflag
	      (progn
		(vlax-for
		       obj  (jb:getactivespace)
		  (if (setq xkey (jb:getKeyNotexdata (vlax-vla-object->ename obj)))
		    (progn (if (= objType (nth 2 xdata))
			     (progn (if	(= oldKey (nth 0 xkey))
				      (progn (vla-put-textstring obj note)
					     (vlax-put obj "color" acByLayer)
					     (jb:putKeyNotexdata
					       (vlax-vla-object->ename obj)
					       key
					       note
					       objType)))))))))))))))
	(alert "No XDATA"))
  (princ))
;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 T nil nil T)
;*** DO NOT add text below the comment! ***|;
