;;;										;
;;;		Automatic Layering for ADT 					;
;;;		Layer names come directly from the LOCAL AEC Layer Key Styles	;
;;;		It is assumed that ADT has done it's job and Imported the	;
;;;		Key Styles in the drawing stored at				;
;;;		(kb:GetSavedAECLayerStandardDrawing)				;
;;;										;



;;;										;

(vl-load-com)

;;;(setq data(kb:GetSavedAECLayerStandardDrawing))
(defun kb:GetSavedAECLayerStandardDrawing  (/ stand standard dwg)
  (setq ret(kb:GetLayerFile)
        dwg   (findfile (car ret))
        stand (cdr ret)
        pos   (vl-string-search (chr 9) stand))
  (if pos
    (setq standard (vl-string-subst "" (substr stand (1+ pos)) stand))
    (setq standard stand))
  (cons dwg standard))

 
;;; CHANGE A LIST OF LAYERKEYS


;;;
;;; Get the root layer name from the data drawing
;;;(setq data nil file nil dict nil lobj nil lname nil)
;;;(kb:GetRootLayerNameList (list "ANNDTOBJ"))
(defun kb:GetRootLayerNameList  (keyList / data file dict lobj lname)
  (setq data(kb:GetSavedAECLayerStandardDrawing)
        file (car data)
        dict (cdr data))
  (setq dbxdoc (kb:opendbxdocument file))
  (setq dbxdict (vlax-vla-object->ename
                  (vla-item (vla-get-dictionaries dbxDoc) "AEC_LAYERKEY_STYLES"))
        laykey  (dictsearch dbxdict dict))
  (if laykey
    (progn (foreach
                  i  keyList
             (if (setq lobj
                        (vl-catch-all-apply
                          'vla-item
                          (list
                            (vlax-get-property (vlax-ename->vla-object (cdar laykey)) 'keys)
                            i)))
               (setq retList (append retList (list (cons i (vlax-get-property lobj 'layer))))))))
    (dcl_messagebox
      (strcat "WARNING!\n"
              "\nThe current documents LayerKey Style "
              "\ndoes not match the Standard LayerKey Style. "
              "\nUse \"AecDwgLayerSetup\" to change the Style.")
      "jbTools"
      2
      1))
  (kb:CloseDbxDocument dbxdoc)
  retList)

;;; Get the root layer name from the active drawing
;;;(kb:GetLocalRootLayerNameList(list "ANNDTOBJ"))
(defun kb:GetLocalRootLayerNameList  (keyList / data dict lobj lname)
  (setq data   (kb:GetSavedAECLayerStandardDrawing)
        dict   (cdr data)
        doc    (vla-get-activedocument (vlax-get-acad-object))
        ddict  (vlax-vla-object->ename
                 (vla-item (vla-get-dictionaries Doc) "AEC_LAYERKEY_STYLES"))
        laykey (dictsearch ddict dict))
  (foreach
         i  keyList
    (if (setq
          lobj (vl-catch-all-apply
                 'vla-item
                 (list (vlax-get-property (vlax-ename->vla-object (cdar laykey)) 'keys)
                       i)))
      (setq retList (append retList (list (cons i (vlax-get-property lobj 'layer)))))))
  retList)
;;; (setq fullkeyList(cons  (list(list "1" "2"))"PREFIX"))
;;; Added 12.2004: Position of LayerMod: (cdr keylist)
;;; This command is fired from the Working States Manager form
;;; (setq key "A1")
;;; (kb:ChangeLayerKeyNameList "A7" (list "ANNDTOBJ" "ANNELOBJ" "ANNOBJ" "ANNREV" "ANNSXOBJ" "ANNSYMOBJ" "DIMLINE"))
;;; (kb:ChangeLayerKeyNameList nil (list "ANNDTOBJ" "ANNELOBJ" "ANNOBJ" "ANNREV" "ANNSXOBJ" "ANNSYMOBJ"))
;;; CHECK key BEFORE PASSING TO THIS FUNCTION!!!
(defun kb:ChangeLayerKeyNameList  (key lkList / oldecho lkey lkstyle activekeyStyle
                                      rootlayernameList i new-lname dict position keyList)
  (if (= (strcase key) "STANDARD")
    (setq key nil))
  (setq position(cdr lkList)
        keyList(car lkList))
  (setq rootlayernameList
         (kb:GetRootLayerNameList keyList)
        activekeyStyle
         (cdr (kb:GetSavedAECLayerStandardDrawing)))
;;; check to see if layerkeystyle exists
  (cond ((vl-catch-all-error-p
           (setq dict
                  (vl-catch-all-apply
                    'vla-item
                    (list
                      (vla-get-dictionaries (vla-get-activedocument (vlax-get-acad-object)))
                      "AEC_LAYERKEY_STYLES")))))
        ((vl-catch-all-error-p
           (setq lkstyle (vl-catch-all-apply 'vla-item (list dict activekeyStyle))))))
  (if (not (vl-catch-all-error-p lkstyle))
    (progn (foreach
                  i  rootlayernameList
             (if (not (vl-catch-all-error-p
                        (setq lkey (vl-catch-all-apply
                                     'vla-item
                                     (list (vlax-get-property lkstyle 'Keys) (car i))))))
               (progn (if key
                        (progn
                          (cond((= position "SUFFIX")
                        (setq new-lname (strcat (cdr i) "-" key)))
                               ((= position "PREFIX")
                        (setq new-lname (strcat key(cdr i))))
                               (t
                        (setq new-lname (cdr i))))
                      (vlax-put-property lkey 'layer new-lname))
                        (progn
                        (setq new-lname (cdr i))
                        (vlax-put-property lkey 'layer new-lname)))
                        )))))
    (if lkstyle(progn(setq ret T)(vlax-release-object lkstyle))
      (setq ret nil))
  ret)
  

;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
