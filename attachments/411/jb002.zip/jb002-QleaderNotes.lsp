;;;								;
;;;	Place a KeyNote and Qleader				;
;;;	Qleader and Mtext					;
;;;								;


(defun c:jbPlaceKeyNote  (/ *Error* text p1 p2 key note qleader qleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (dcl_ListBox_GetText
               jb002_00_KEYLIST
               (dcl_ListBox_GetCurSel jb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq key  (substr text 1 (vl-string-position (ascii "\t") text))
            note (substr text (+ 2 (vl-string-position (ascii "\t") text))))
      (if (and key note)
        (progn (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
               (vla-StartUndoMark doc)
               (jb:SetAcadDim
                 '((3 . "")(40 . 0.0)(60 . 0)(61 . 0)
                   (62 . 1)(63 . 1)(64 . 0)(65 . 0)
                   (67 . 2)(68 . 1)(69 . 0)(70 . 0)
                   (72 . 0)))
               (prompt "\nSpecify first leader point: ")
               (vl-cmdf "_.qleader" pause)
               (prompt "\nSpecify next point: ")
               (vl-cmdf pause)
               (prompt "\nSpecify text width: ")
               (vl-cmdf pause "." "")
        (setq qleader (entlast))
        (if (= (vla-get-objectname (setq qleaderObj (vlax-ename->vla-object qleader)))
               "AcDbMText")
          (progn (vlax-put-property qleaderObj 'TextString key)
                 (jb:putKeyNotexdata (entlast) key note "KEYLEADER")))))))
  (vla-EndUndoMark doc)(princ)
  )

;;;								;
;;;	Place a Keyed Note and Qleader				;
;;;	Qleader and Mtext					;
;;;								;

(defun c:jbPlaceNote  (/ *Error* text p1 p2 key note qleader qleaderObj)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq text (dcl_ListBox_GetText jb002_00_KEYLIST(dcl_ListBox_GetCurSel jb002_00_KEYLIST)))
  (if (and text (/= text ""))
    (progn
      (setq key  (substr text 1 (vl-string-position (ascii "\t") text))
            note (substr text (+ 2 (vl-string-position (ascii "\t") text))))
      (if (and key note)
        (progn (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
               (vla-StartUndoMark doc)
               (jb:SetAcadDim
                 '((3 . "")(40 . 0.0)(60 . 0)(61 . 0)
                   (62 . 1)(63 . 1)(64 . 0)(65 . 0)
                   (67 . 2)(68 . 1)(69 . 0)(70 . 0)
                   (72 . 0)))
               (prompt "\nSpecify first leader point: ")
               (vl-cmdf "_.qleader" pause)
               (prompt "\nSpecify next point: ")
               (vl-cmdf pause)
	  ;;Bombs out here - "Invalid Input"
               (prompt "\nSpecify text width: ")
               (vl-cmdf pause "." "")
        (setq qleader (entlast))
        (if (= (vla-get-objectname (setq qleaderObj (vlax-ename->vla-object qleader)))
               "AcDbMText")
          (progn (vlax-put-property qleaderObj 'TextString note)
                 (jb:putKeyNotexdata (entlast) key note "NOTELEADER")
            ))))))
  
  (vla-EndUndoMark doc)
    (princ))


;|�Visual LISP� Format Options�
(94 2 4 0 nil "end of " 72 6 0 0 1 nil nil nil T)
;*** DO NOT add text below the comment! ***|;
