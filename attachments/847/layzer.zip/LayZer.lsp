(defun LayZer_addLayers (thelist / lyrn lyrlt)
  (foreach lyr (vl-remove-if-not '(lambda(x) (member (car x) thelist)) layzerlayerdata)
    (setq lyrn (car lyr)
          lyrlt (caddr lyr)
    )
    (if (not (tblsearch "LAYER" lyrn))
      (progn
        (command "_.-layer" "_n" lyrn)
        (command)
      )
    )
    (if (not (tblsearch "LTYPE" lyrlt))
      (progn
        (command "_.-linetype" "_l" lyrlt "acad.lin")
        (command)
      )
    )
    (command "_.-layer" "_lweight" (cadr lyr) lyrn "_ltype" lyrlt lyrn "_color" (cadddr lyr) lyrn "_plot" (last lyr) lyrn)
    (command)
  )
)

(defun c:LayZer_Dia_Prelist_OnSelChanged (ItemIndex Value /)
  (dcl_ListBox_Clear LayZer_Dia_Midlist)
  (dcl_ListBox_AddList LayZer_Dia_Midlist (mapcar 'car (cadr (car (vl-remove-if-not '(lambda(x) (= (car x) Value)) layzerlayerfams)))))
  (princ)
)

(defun c:LayZer_Dia_Midlist_OnSelChanged (ItemIndex Value /)
  (dcl_ListBox_Clear LayZer_Dia_Layerlist)
  (dcl_ListBox_AddList LayZer_Dia_Layerlist (cadr (car (vl-remove-if-not '(lambda(x) (= (car x) Value)) (cadr (car (vl-remove-if-not '(lambda(x) (= (car x) (substr Value 1 1))) layzerlayerfams)))))))
  (princ)
)

(defun c:LayZer_Dia_AddButton_OnClicked (/)
  (LayZer_addLayers (dcl_ListBox_GetSelectedItems LayZer_Dia_Layerlist))
  (princ)
)

(defun c:LayZer_Dia_CloseButton_OnClicked (/)
  (dcl_Form_Close LayZer_Dia)
  (setq layzerlayerdata nil
        layzerlayerfams nil
  )
  (princ)
)

(defun c:layzer (/ layfile excel workbooks currworkbook activesheet cells ct layerprelist layerlist layername layerlw layerlt layercol layerplot layernamelist pre)
  (if (setq layfile (getfiled "msLayZer: Select layer spreadsheet..." "" "xls" 0))
    (progn
      (command "_.opendcl")
      (vl-load-com)

      (if (not (setq excel (vlax-create-object "Excel.Application")))
        (progn
          (alert "Excel is not installed on this computer or is not loading. Exiting.")
          (exit)
        )
      )
      (setq workbooks (vlax-get-property excel 'Workbooks))
      (if (not (setq currworkbook (vlax-invoke-method workbooks 'Open layfile)))
        (progn
          (alert "The file failed to load. Exiting.")
          (exit)
        )
      )
      (setq activesheet (vlax-get-property excel 'ActiveSheet)
            cells (vlax-get-property activesheet 'Cells)
            ct 1
            layzerlayerdata (list)
            layerprelist (list)
            layerlist (list)
            layzerlayerfams (list)
      )

      (while (and
               (vlax-variant-value (setq layername (vlax-get-property (vlax-variant-value (vlax-get-property cells 'Item ct 1)) 'Value)))
               (if (= 5 (vlax-variant-type layername))
                 (setq layername (itoa (fix (vlax-variant-value layername))))
                 (setq layername (vlax-variant-value layername))
               )
             )
        (if (and
              (setq layerlw (vlax-get-property (vlax-variant-value (vlax-get-property cells 'Item ct 2)) 'Value))
              (= 5 (vlax-variant-type layerlw))
            )
          (if (= 0.0 (setq layerlw (abs (vlax-variant-value layerlw))))
            (setq layerlw "Default")                
          )
          (setq layerlw "Default")
        )

        (if (and
              (setq layerlt (vlax-get-property (vlax-variant-value (vlax-get-property cells 'Item ct 3)) 'Value))
              (= 8 (vlax-variant-type layerlt))
            )
          (setq layerlt (vlax-variant-value layerlt))
          (setq layerlt "Continuous")
        )

        (if (and
              (setq layercol (vlax-get-property (vlax-variant-value (vlax-get-property cells 'Item ct 4)) 'Value))
              (or
                (= 5 (vlax-variant-type layercol))
                (= 8 (vlax-variant-type layercol))
              )
            )
          (if (= 5 (vlax-variant-type layercol))
            (if (or
                  (< 255 (setq layercol (fix (vlax-variant-value layercol))))
                  (> 1 layercol)
                )
              (setq layercol "white")
            )
            (if (not (member (strcase (setq layercol (vlax-variant-value layercol)) T) '("red" "yellow" "green" "cyan" "blue" "magenta" "white")))
              (setq layercol "white")
            )
          )
          (setq layercol "white")
        )

        (if (not (and
              (setq layerplot (vlax-get-property (vlax-variant-value (vlax-get-property cells 'Item ct 5)) 'Value))
              (= 8 (vlax-variant-type layerplot))
              (or
                (= "p" (setq layerplot (strcase (substr (vlax-variant-value layerplot) 1 1) T)))
                (= "n" layerplot)
              )
            ))
          (setq layerplot "p")
        )

        (setq layzerlayerdata (append layzerlayerdata (list (list layername layerlw layerlt layercol layerplot)))
              ct (1+ ct)
        )
      )

      (vlax-invoke-method excel 'Quit)
      (vlax-release-object cells)
      (vlax-release-object activesheet)
      (vlax-release-object currworkbook)
      (vlax-release-object workbooks)
      (vlax-release-object excel)
      (gc)

      (setq layernamelist (mapcar 'car layzerlayerdata))
      (foreach layer layernamelist
        (if (not (member (setq pre (substr layer 1 1)) layerprelist))
          (setq layerprelist (append layerprelist (list pre)))
        )
      )
      (foreach layer layernamelist
        (if (not (member (setq pre (substr layer 1 6)) (mapcar 'car layerlist)))
          (setq layerlist (append layerlist (list (list pre (vl-remove-if-not '(lambda(x) (= (substr x 1 6) pre)) layernamelist)))))
        )
      )
      (foreach layerpre layerprelist
        (setq layzerlayerfams (append layzerlayerfams (list (list layerpre (vl-remove-if-not '(lambda(x) (= (substr (car x) 1 1) layerpre)) layerlist)))))
      )

      (dcl_Project_Load "LayZer.odcl" T)
      (dcl_Form_Show LayZer_Dia)
      (dcl_ListBox_AddList LayZer_Dia_Prelist layerprelist)
    )
    (prompt "\nNo file selected!")
  )
  (princ)
)