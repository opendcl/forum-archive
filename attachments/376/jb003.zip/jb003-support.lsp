;;;							;
;;;	jbBlock Tools v2.0				;
;;;	include files:					;
;;;		jbCommonFunctions			;
;;;		jbCommonImportFunctions			;
;;;							;

;;;							;
;;;	Utility Sub Routines				;
;;;							;

;;;							;
;;;		Insert All Blocks!			;
;;;							;
(defun c:jbInsertAllBlocks( / doc blocks ins space name)
  (if (= (dcl_MessageBox
	     "Do you really want to Insert all blocks?"
	     "Insert All Blocks"
	     5
	     4)
	   6)
    (progn
      (setq ins(vlax-3d-point 0 0)
            space(JB:GETACTIVESPACE)
            doc(vla-get-ActiveDocument(vlax-get-acad-object))
            blocks(vla-get-blocks doc))
      (vlax-for x blocks
        (setq name(vla-get-name x))
        (if (and(= (vlax-get-property x 'isxref) :vlax-false)
            (= (vlax-get-property x 'islayout) :vlax-false)
            (not(vl-string-search "|"name))
            (not(vl-string-search "*"name))
            )
          (vla-InsertBlock space ins name 1.0 1.0 1.0 0.0)))))
  (princ))


(defun jb:InsertSomeBlocks(wildcard / doc blocks ins space name)
      (setq ins(vlax-3d-point 0 0)
            space(JB:GETACTIVESPACE)
            doc(vla-get-ActiveDocument(vlax-get-acad-object))
            blocks(vla-get-blocks doc))
      (vlax-for x blocks
        (setq name(vla-get-name x))
        (if (and(= (vlax-get-property x 'isxref) :vlax-false)
            (= (vlax-get-property x 'islayout) :vlax-false)
            (not(vl-string-search "|"name))
            (not(vl-string-search "*"name))
		(wcmatch name wildcard)
            )
          (vla-InsertBlock space ins name 1.0 1.0 1.0 0.0)))
  (princ))

;;;							;
;;;		Swap Block 				;
;;;							;
(defun c:jbSwap( / )
  (prompt "\nSelect Blocks or Xrefs to Swap!")
  (princ "\nSelect Block to Clone:")
  (setq newBlockName(ssget ":s" '((0 . "INSERT"))))
  (if newBlockName
    (progn
      (jb:Swap(cdr(assoc 2(entget(ssname newBlockName 0)))))
    (princ "\nNot a Block!")
    )
  )
  (princ))
 

(defun jb:swapblock  (ent newBlockName / new_blk)
  (setq new_blk (subst (cons 2 newBlockName) (assoc 2 ent) ent))
  (entmod new_blk)
  (princ "\nBlock swapped!"))

(defun jb:Swap  (newBlockName / *error* a x SS NUM CNT e blk ANS new_blk)
  (defun *Error*  (Msg)
    (cond ((or (not Msg)
               (member Msg '("console break" "Function cancelled" "quit / exit abort"))))
          ((princ (strcat "\nError: " Msg))))
    (princ))
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (if newBlockName
    (progn (setq x (tblsearch "block" newBlockName))
           (if x
             (progn (prompt "\nSelect blocks to be swapped: ")
                    (setq SS (ssget '((0 . "INSERT"))))))))
  (if SS
    (progn
      (setq NUM (sslength SS)
            CNT 0)
      (while (< CNT NUM)
        (setq e (ssname SS CNT))
        (cond
          ((= (vlax-property-available-p (vlax-ename->vla-object e) 'IsDynamicBlock)
              :vlax-false)
           (if (= (vlax-get (vlax-ename->vla-object e) 'IsDynamicBlock) :vlax-false)
             (jb:swapblock (entget e) newBlockName)))
          (t (jb:swapblock (entget e) newBlockName)))
        (setq CNT (1+ CNT)))
      (princ "  Done... "))
    (princ "  Nothing selected. "))
  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (princ))

;;;							;
;;;		WClip	 				;
;;;							;

(defun jb:WCGetTempFile()
  (strcat(VL-FILENAME-DIRECTORY(findfile "acad.mnl"))"\\")
)

(defun jb:WCget_file_list (jbWC_clip_file / file_list)
  (if jbWC_clip_file
  (cond
    ((= jbWC_clip_file "Clipit1") (setq file_list "2, 3, 4"))
    ((= jbWC_clip_file "Clipit2") (setq file_list "1, 3, 4"))
    ((= jbWC_clip_file "Clipit3") (setq file_list "1, 2, 4"))
    ((= jbWC_clip_file "Clipit4") (setq file_list "1, 2, 3"))
  )
    (setq file_list "2, 3, 4")
    )
  file_list  
)


(defun jb:WclipGetPara (ss pt / p file_list jbWC_clip_file)
  (if (not jbWC_file)
    (setq jbWC_file "Clipit1"))

  (setq file_list(jb:WCget_file_list jbWC_file)
	llist (list "1" "2" "3" "4"))

  (if ss(progn
      (princ (strcat "Defaulting to " jbWC_file))
      (initget "1 2 3 4")
      (setq p (getpoint	(strcat	"\nSelect "pt"or <enter> for origin - or "
				file_list)))
  (if (= (type p) 'STR)
    (progn
      (cond ((= p "1")
	     (setq jbWC_file "Clipit1"))
	    ((= p "2")
	     (setq jbWC_file "Clipit2"))
	    ((= p "3")
	     (setq jbWC_file "Clipit3"))
	    ((= p "4")
	     (setq jbWC_file "Clipit4"))
      )
	(princ (strcat "\nChanging to " jbWC_file))
	     (setq p (getpoint
		      (strcat "\nSelect basepoint or <enter> for origin")))
	)
    )
    (cond       
       ((= p nil)
	(setq p (getvar "UCSORG"))))
  (list jbWC_file p)
)))

(defun jb:WclipIt (cf ss pt / tp w)
  (setq tp(jb:WCGetTempFile)
	W(strcat tp jbWC_file ".dwg"))
  (cond((= cf "insert")
      (if (findfile W)
	(progn
	  (setvar "cmdecho" 0)
	  (command "insert" w pt "" "" "0")
	  (command "._explode" (entlast))
	  (vla-Delete
	    (vla-item (vla-get-Blocks  (vla-get-activedocument(vlax-get-acad-object)) ) jbWC_file)
	  )
	  (princ "\nClipped Entities Pasted!")
	  (princ)
	)
	(alert(strcat jbWC_file " does not exist!")
	  )
      ))
      ((= cf "clip")
	(setvar "cmdecho" 0)
	(if (findfile w)
	  (progn(prompt (strcat "\nOverwriting file " jbWC_file))
	    (command "_wblock" w "y" "" pt ss "")
	    (command "_oops"))
	  (progn(command "_wblock" w	"" pt ss "")
	    (command "_oops"))
	  )
	(princ "\nEntities clipped!")
	(princ)
	)
  )
  
)

(defun c:jbWclip (/ *Error* go)
  (defun *Error* (Msg)
     (cond((or (not Msg)(member Msg '("console break" "Function cancelled" "quit / exit abort"))))
     ((princ (strcat "\nError: " Msg))))(princ))

  (setq	ss (ssget))
  (if ss (progn
      (if (setq go(jb:WclipGetPara ss "base point"))
	(jb:WclipIt "clip" ss (cadr go))
	(princ "See ya"))))
  (princ)
  (princ)
)

(defun c:jbWclipInsert (/ *Error*)
  (defun *Error* (Msg)
     (cond((or (not Msg)(member Msg '("console break""Function cancelled""quit / exit abort"))))
	  ((princ (strcat "\nError: " Msg))))(princ))

  (if (setq go(jb:WclipGetPara T "insertion point "))
	(jb:WclipIt "insert" (car go)(cadr go))
	(princ "See ya")
      )
  (princ)
  (princ)
)

(defun c:jbADWclip( / )
  (command "_adcenter")
  (command "_adcnavigate" (jb:WCGetTempFile))
  (princ)
  (princ)
 )

(defun c:jbDDWclip( / file go)
  (setq file(getfiled "Select a ClipFile to insert: " (jb:WCGetTempFile) "dwg" 16))

  (if file
    (progn
      (setq jbWC_file(vl-filename-base file))
  (if (setq go(jb:WclipGetPara T "insertion point "))
	(jb:WclipIt "insert" (car go)(cadr go))
	(princ "See ya")
      )))
  (princ)
 )


;;;							;
;;;	XREF UTILITIES					;
;;;							;
;;;
;;;(setq ret(jb:Return40Pop))


(defun c:jbUnloadXrefPop( / )
  (jb:Return40Pop "-xref _unload ")
  (progn(menucmd "P0=jb00.POP0")
	  (menucmd "P0=*")
  ))

(defun c:jbReloadXrefPop( / )
  (jb:Return40Pop "-xref _reload ")
  (progn(menucmd "P0=jb00.POP0")
	  (menucmd "P0=*")
  ))

(defun c:jbDetachXrefPop( / )
  (jb:Return40Pop "-xref _detach ")
  (progn(menucmd "P0=jb00.POP0")
	  (menucmd "P0=*")
  ))


(defun c:jbReloadAll  (/ *Error*)
  (if (jb:DwgHasXrefs)
    (progn (vl-cmdf "_.-xref" "_reload" "*")
	   (prompt "\nAll External references have been reloaded."))
    (alert "There are no External References to Reload!   "))
  (princ))

(defun c:jbUnloadAll  (/ xrefyes)
  (if (jb:DwgHasXrefs)
    (progn (vl-cmdf "_.-xref" "_Unload" "*")
	   (prompt "\nAll External references have been reloaded."))
    (alert "There are no External References to Unload!   "))
  (princ))


(defun c:jbDetachAll  (/ xrefyes)
  (if (jb:DwgHasXrefs)
    (if	(= (dcl_MessageBox
	     "Do you really want to detach ALL Xrefs?"
	     "Detach Xrefs"
	     5
	     4)
	   6)
      (progn (vl-cmdf "_.-xref" "_detach" "*")
	     (prompt "\nAll External references have been detached.")))
    (alert "There are no External References to Detach!   "))
  (princ))


(defun c:jbDetachXref  (/ ent obj)
  (if (and (setq ent (jb:entsel "\nSelect an Xref to Detach:" nil nil (list "INSERT") nil)
		 obj (vlax-ename->vla-object (car ent)))
	   (vlax-property-available-p obj 'path))
    (progn (vla-detach
	     (vla-item (vla-get-blocks (vla-get-activedocument(vlax-get-acad-object))) (vla-get-name obj)))
	   (if (dcl_form_isactive jb502_00)
	     (c:jb502_00_Refresh_OnClicked)))))

(defun c:jbUnloadXref  (/ ent obj)
  (if (and (setq ent (jb:entsel "\nSelect an Xref to Unload:" nil nil (list "INSERT") nil)
		 obj (vlax-ename->vla-object (car ent)))
	   (vlax-property-available-p obj 'path))
    (vla-unload
      (vla-item (vla-get-blocks (vla-get-activedocument(vlax-get-acad-object))) (vla-get-name obj)))))

(defun c:jbReloadXref  (/ ent obj)
  (if (and (setq ent (jb:entsel "\nSelect an Xref to Reload:" nil nil (list "INSERT") nil)
		 obj (vlax-ename->vla-object (car ent)))
	   (vlax-property-available-p obj 'path))
    (vla-reload
      (vla-item (vla-get-blocks (vla-get-activedocument(vlax-get-acad-object))) (vla-get-name obj)))))


(defun c:jbCountBlock  (/ *Error* a blk_name ss ss1 cnt num)
  (defun *Error*  (Msg)
    (cond
      ((or (not Msg)
           (member Msg
                   '("console break"
                     "Function cancelled"
                     "quit / exit abort"
                     ))))
      ((princ (strcat "\nError: " Msg))))
    (princ))
  (setq a (entsel "\nSelect block to count: <you must re-select to add to selection!>"))
  (if a
    (progn
  (cond ((= (cdr (assoc 0 (entget (car a)))) "AEC_MVBLOCK_REF")
         (setq ss(ssadd)
               blk_name (vla-get-stylename (vlax-ename->vla-object (car a)))
               ss1       (ssget (list (cons 0 "AEC_MVBLOCK_REF")))
               num      (sslength ss1)
               cnt      0)				
         (while (< cnt num)
           (if (= (vla-get-stylename (vlax-ename->vla-object (ssname ss1 cnt)))
                   blk_name)
             (setq ss  (ssadd (ssname ss1 cnt) ss)))
           (setq cnt (1+ cnt))))
        ((= (cdr (assoc 0 (entget (car a)))) "INSERT")
         (setq blk_name (cdr (assoc 2 (entget (car a))))
               ss       (ssget (list (cons 0 "INSERT") (cons 2 blk_name)))
               ))
        (t (setq ss nil)(alert "Not a Block or Multiview Block!"))
        )
  (if ss
    (progn
      (alert (strcat "There are "
                     (itoa (sslength ss))
                     " instances of block "
                     blk_name
                     " in your selection."
                     ))
      (princ (sslength ss))))))
  (princ))