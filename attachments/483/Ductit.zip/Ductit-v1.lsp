;;;							;
;;;	Ductit v1.0					;
;;;							;

(vl-load-com)

(if (not (vl-bb-ref 'Ductit))
  (vl-bb-set
    'Ductit
    (dcl_project_import
      '("YWt6A7EiAADwepriBuKTJyMSaitqQDU1VXruYdPcVsvcPHI0x2vScVx7Ye5o9PQ43aiAIzs01S7W"
"X1iqQdz897gmTUCP3lhYXDQubW2zOPM/x3FAv3VaZGxPC28Grm4zxgCZsOOwMLGSzLv0bselp0WN"
"s4eHkEcJsAixMFxcBbQ4ObsspDaTqjUVDhoOkfk03DRRLW+wzURe39ftaC5VsJitItS7IjnJnNLw"
"aHwXuSdlGmoLntJtCaT+y58weRoVDyM1jTzh6FOwfdAeMX8T/fvHzqI3iz6m3Hgk9c0Elqmfuxl1"
"D9FwjGQIZ8F7BAtK6LgF0LLjsQcimCju30+A5Hu4sv0v+EnHG4+2zmA95VsabS4LRaM4h+8UX0ip"
"PFXX5ZC6r3WIlQ/Z5WDda6p9p2C2oH3Cq6Md7Xnb6cB6CgdPUbUO0g8GVQufA83JhOjKxCM8MTUW"
"UTPbrXJoxeW03bXy+cjGTUkAP0RnhHznZtiGK3I79KFbTJze18/TQcMqJ9jijHg94bssb4r3+kDr"
"yIi6riBxI+VeT0/0CUtcojWpHqD6wwntoVLN7YSvGB117UIAA7QY1RY66KTu31CSgm96BXIj6gHn"
"aZadQK6bTK5VHdfhQyrvHk0DT6iq9EOtmyYL/ylLu5Ug/MPE8OC6BUmQjiCgnvICOlxxYbWzTiA8"
"V+eRMG7krvo53WS5nVA6I/AwaWBjaINCILAvwZachZgckZ04Z+Q1HdfPYBTw39FDylT4aASWRNfG"
"XPgAia4Mx3llW6pa38VaCv3yHaCYpZDfd4xHoFvf42yELjxhNtYV9jpYnMsoPJX4BhuAjmeU7ywx"
"NhYlrB2KSjPYTvdSmWzD0k/9ZC5/fe2P/HVkuZEQSkpTjggH4POHcGKrMKNBQj2xro6vkYDWwUHi"
"hvvtEkg1p/0nRICDBYYCn9+8aVDU1NQWuPJnKi0tPQ2Yst+r1SktLS1tS0pKLgMDQ4tBHdfHp6xl"
"yuESsK7JhfGvgF05lsuJCRwTEjOddg5mDLin1nzY/le4Elbc/xXiFp5kxsjfJH5CfmCeXH5gJhn0"
"cg59on5JfnIO9RX1FRXiJ5Uov+G3f3AePubsLMJInp7evj8/pi98eXtwdGJqRlYODkq/P//9fHl7"
"cHRiYgsOLp7evj///Xx5e3l0QmoGVrm9+LUNMoZrnk5GEsYaDq8O0J82vdZ4aWl4oqpGr57cv7v7"
"e0JKBhaOrn8dSHJrBhYOrp7ev/892b89/f14eb2VuMV1X4L6UZ291WLdPo/Lcz1zoX9Gew5kvj9+"
"MH8CecZnvjZuzlNl2L2HeHCBf4J5jrFXdJ5BHmJifA520gsXdU3f4wkYuJdLnh6esf7lf3F9AVDL"
"sn1PTp4f5nlomKxzW31QeCJyNmZGCiV+InJqc/pyfn1QwlNyDT8wcsZm8PmdvMX/zW7G0xq/v/z9"
"e3l1cGhiogh8eX1waGJSRmYODiVyYlJGJg7Onh6/f9gPfnl5dXBoYtKfgYYefbhSalP6yphiX/Ho"
"A84T6K+GkgPpJCQk1tHR8cgQozR9fX3KEaFApMMFSWNGDv5wY0Q6+XFh2L+/P0QPnHrjQgfs8IEb"
"l+NjRY5ijW2TSENwZTCCHPahUPJ1nbyGoXAFsPOfkji06AxCosWpsTv9+EdWM0E5vYuD695p6Crf"
"QRq+lYXlPcmdLz5BTG6XmYIht4THgntF/epFwwBS4LVxK9eEGnWUmY1RakHMe4tXV+/kQTQiWYpt"
"h+2EvYj4plSZjL1NnK+uCsUhcrG3EXOAtTKcZSdMK4GL7pW36Bu13Ie5tBaQsWriVc2os2mFB1ix"
"riWamVOf4kBo28pGtJHbi4aIoIdxpGUHw/JPWgRnBUIqJGWcO1dLlOP36ki6day5DWy0FSiyia5K"
"AtvzEscRrrG4TC3Csv7KKiQ9nQfXxjRUiLXuA13fLayoEWyES2/k56KAokaqFCScZOiTymiZw8Yt"
"M9Oq/2mxF5NZSOYNkXdYzWxA2GsVHistXUIQjsjwtxA1IAGZbGyD49bz6Kmh92gkwsFtN/PGwY3b"
"+WDoQ+catZn0PEOclg9yxbsPtkVvFkhNTx+Y1KyyUgtH6rhghwmlLlMZw02L1oqmVN9Id8Na34Vb"
"yjM8cTaWP3cz6K49bEREihpahBQraqhsYMtXWwIifbyknWwFYWyiNwPdrdVgit8BNKi1nFuBFGQ3"
"t1HTwGmRY8GQ20g0u03QwBG5yFzX6pSFmIctFNnaa6YYKVZIm5PlnBsIR/dMxfU40bI4LhcbSNvz"
"4NLxS/uU3QIa9Cm0r1L1V/ubK3fDIiyHB5syVSyXm/ltbyvs5S20MaccyUsbQNhpdADWLpZtkIKD"
"X1pb9t0s9t1hcym0jO2C+w6cHCFbrFW6h4w1HorRIo+soz/cCjkuXjWf62w015gdmxHxu9UHWguI"
"1Qd3y4RZbMsEROuM7RnKrpxBB+go1SWCgknUZPzE")
      )
    )
  )

;;;							;
;;;	Support Functions				;
;;;							;

;;;							;
;;; 	Open a dbxDoc					;
;;; 	use (setq dbxDocument(kb:OpenDbxDocument dwgname)) ;
;;;							;
(defun kb:OpenDbxDocument (DwgName / app doc dbxopen dbxDoc)
  (setq app (vlax-get-acad-object)
        doc (vla-get-ActiveDocument app)
        )
  (if (/= dwgname (vla-get-fullname doc))
    (progn (cond ((= (substr (getvar "ACADVER") 1 5) "15.06")
                  (setq dbxDoc  (vla-GetInterfaceObject app "ObjectDBX.AxDbDocument")
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName))
                        )
                  )
                 (t
                  (setq dbxDoc  (vla-GetInterfaceObject
                                  app
                                  (strcat "ObjectDBX.AxDbDocument." (substr (getvar "acadver") 1 2))
                                  )
                        dbxopen (vl-catch-all-apply 'vla-open (list dbxDoc DwgName))
                        )
                  )
                 )
           (if (vl-catch-all-error-p dbxopen)
             (setq dbxDoc nil)
             )
           )
    )
  dbxDoc
  )

;;; 							;
;;; Close dbxDoc					;
;;; (kb:CloseDbxDocument dbxDocument)			;
;;;							;
(defun kb:CloseDbxDocument (dbxdoc)
  (if (= (type dbxDoc) 'VLA-OBJECT)
    (progn (vlax-release-object dbxDoc) (setq dbxDoc nil))
    )
  )



;;;							;
;;;	Import a Block from a DBX Document		;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   block; name of the block to import	;
;;;	Return:	the block object			;

(defun kb:ImportBlock (dwg block / dbxDoc bb dbb newblk)
  (if dwg
    (setq dbxDoc (kb:OpenDbxDocument dwg))
    )
  (if dbxDoc
    (progn (setq bb  (vla-get-blocks dbxDoc)
                 dbb (vla-get-blocks (vla-get-ActiveDocument (vlax-get-acad-object)))
                 )
           (if (not
                 (vl-catch-all-error-p (vl-catch-all-apply 'vla-item (list bb block)))
                 )
             (setq newblk (vl-catch-all-apply
                            'vla-CopyObjects
                            (list dbxDoc
                                  (vlax-safearray-fill
                                    (vlax-make-safearray vlax-vbObject '(0 . 0))
                                    (list (vla-item bb block))
                                    )
                                  dbb
                                  )
                            )
                   )
             )
           )
    )
  (if dbxdoc
    (kb:closedbxdocument dbxDoc)
    )
  newblk
  )

;;;							;
;;;	Return Block list from a DBX Document		;
;;;	Arguments: dwg; a valid drawing name and path	;
;;;		   					;
;;;	Return:	List of strings				;
;;;							;

(defun kb:ReturnDBXBlocks (dwg / dbxDoc ret)
  (if dwg
    (setq dbxDoc (kb:OpenDbxDocument dwg))
    )
  (if dbxDoc
    (progn (vlax-for
                  x (vla-get-blocks dbxDoc)
             (if (and (= (vlax-get x 'isxref) 0)
                      (not (vl-string-search (chr 42) (vla-get-name x)))
                      (not (vl-string-search (chr 124) (vla-get-name x)))
                      )
               (setq ret (append ret (list (vla-get-name x))))
               )
             )
           )
    )
  (if dbxdoc
    (kb:closedbxdocument dbxDoc)
    )
  ret
  )

;;;							;
;;;	Add Duct Component				;
;;;	Always called from the OpenDCL Form		;
;;;							;

(defun kb:AddDuctComponent( / Index Item parent)
     (Setq Index(dcl_Tree_GetSelectedItem Ductit_00_Tree)
	   Item(dcl_Tree_GetItemText Ductit_00_Tree Index)
	   parent (dcl_Tree_GetParent Ductit_00_Tree Index)
	   )
  (if parent
    (progn
      (setq Block(strcat "DUCT_" Item)
	    dwg(findfile(strcat parent ".dwg"))
	    )
      (kb:ImportBlock dwg Block)
      (if (tblsearch "block" Block)
	(command "-insert" Block "_scale" 1 pause "0")
	)
      )
    )
    (princ)
    (princ)
    )

;;;							;
;;;	OpenDCL Control Functions			;
;;;							;

(defun c:Ductit_00_OnInitialize ( / dir nFiles)
     (setq dir(strcat(vl-filename-directory(findfile "Ductit-v1.lsp"))"\\")
	    nFiles(vl-directory-files dir "*.dwg" 1)
	   )
  (if nFiles
    (progn
      (foreach x nFiles
	(cond((= (strcase(vl-filename-base x)) "DUCTS")
	      (setq imageIndex 0))
	     ((= (strcase(vl-filename-base x)) "REDUCERS")
	      (setq imageIndex 1))
	     ((= (strcase(vl-filename-base x)) "ELBOWS")
	      (setq imageIndex 2))
	     ((= (strcase(vl-filename-base x)) "DIFFUSERS")
	      (setq imageIndex 3))
	     )
	     
	     (dcl_Tree_AddParent Ductit_00_Tree 
	(vl-filename-base x) 
	(vl-filename-base x)
	       imageIndex
	)
		   )

      (foreach x nFiles
	(cond((= (strcase(vl-filename-base x)) "DUCTS")
	      (setq imageIndex 0))
	     ((= (strcase(vl-filename-base x)) "REDUCERS")
	      (setq imageIndex 1))
	     ((= (strcase(vl-filename-base x)) "ELBOWS")
	      (setq imageIndex 2))
	     ((= (strcase(vl-filename-base x)) "DIFFUSERS")
	      (setq imageIndex 3))
	     )
	(setq blocks(kb:ReturnDBXBlocks (findfile x)))
	(foreach i Blocks
	  (if (vl-string-search "DUCT_"(strcase i))
	     (dcl_Tree_AddChild Ductit_00_Tree
	       (vl-filename-base x)
	(vl-string-left-trim "DUCT_" (strcase i))
	       imageIndex))
		   )
	)
      )
    )  
)



(defun c:Ductit_00_OnEnteringNoDocState ( /)
     (dcl_form_close Ductit_00)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\Ductit\\Ductit_00"

    "isFloating"
    "true"
    )
  (princ)
  (princ)
  )

(defun c:Ductit_00_Tree_OnClicked ( / Index Item parent)
     (Setq Index(dcl_Tree_GetSelectedItem Ductit_00_Tree)
	   Item(dcl_Tree_GetItemText Ductit_00_Tree Index)
	   parent (dcl_Tree_GetParent Ductit_00_Tree Index)
	   )
	
  (if parent
    (progn
      (dcl_BlockView_PreLoadDwg Ductit_00_BlockView 
	(findfile(strcat parent ".dwg")
	  )
	)
      (dcl_BlockView_DisplayBlock Ductit_00_BlockView 
	(strcat "DUCT_" Item) 0 0.75)
      )
    )
  (princ)
  (princ)
)

(defun c:Ductit_00_Tree_OnDblClicked ( /)
     (kb:AddDuctComponent)
)

(defun c:Ductit_00_BlockView_OnDblClicked ( /)
     (kb:AddDuctComponent)
)

(defun c:Ductit_00_Add_OnClicked ( /)
     (kb:AddDuctComponent)
)

;;;								;
;;;	Version							;
;;;								;

(defun c:DuctitVer (/)
  (prompt "DuctitVer = Version 1.0.0.0 (read only)")
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;								;

(defun c:Ductit (/)
  (if (not (member "kb001" (dcl_GetProjects)))
    (dcl_Project_load "Ductit")
    )
  (if dcl_HideErrorMsgBox
    (progn
      (if (not (dcl_Form_IsActive Ductit_00))
	(if (not (dcl_Form_IsActive Ductit_00))
	  (dcl_Form_Show Ductit_00)
	  )
	)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;*04								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:Ductit_00_IsFloating (/)
  (if dcl_HideErrorMsgBox
    (if	(and (not (dcl_Form_IsActive Ductit_00))
	     (=	(vl-registry-read
		  "HKEY_CURRENT_USER\\Software\\Ductit\\Ductit_00"

		  "isFloating"
		  )
		"true"
		)
	     )
      (c:kbLayerTools)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

(kb:Ductit_00_IsFloating)