(defun sps ()
(dcl_LoadProject "steel_slides")

(defun c:steel_slides/STEELSLIDE#OnInitialize (/)
(dcl-Control-SetBackColor steel_slides/STEELSLIDE/SlideView 9)
(dcl-SlideView-Load steel_slides/STEELSLIDE/SlideView "UB_DIMS.SLD")
)
(dcl_Form_Show "steel_slides" "STEELSLIDE")
(dcl-SlideView-Load steel_slides/STEELSLIDE/SlideView "UB_DIMS.SLD")
(dcl-Control-SetList steel_slides/STEELSLIDE/DIMENS "H" "B" "W" "T" "D" "A" "K" "C" "R1" "R2" "S1" "S2" "S3" "S4")
(dcl-Control-SetList steel_slides/STEELSLIDE/BASEPLATE "WIDTH" "LENGTH" "THICK" "BOLT" "PITCH" "SPACING" "WEB" "FLANGE")
)

(defun c:steel_slides/STEELSLIDE/EXIT#OnClicked (/)
(dcl-Form-Close steel_slides/STEELSLIDE)
)
(princ)


(defun C:STEEL_DIMS ()
   (setq dcl_id (load_dialog "STEEL_DIMS.dcl"))
   (if (not (new_dialog "STEEL_DIMS" dcl_id)) (exit))
;
;
   (action_tile "DISPLAY_SLIDE" "(default_action $key)")
;
   (action_tile "accept" "(done_dialog)")
   (action_tile "cancel" "(done_dialog)")
;
   (start_dialog)
   (unload_dialog dcl_id)
   (princ)
)
;
(defun default_action (key)
(sps)
)
;
(princ "Function Name(s) defined: STEEL_DIMS ")
(princ)
