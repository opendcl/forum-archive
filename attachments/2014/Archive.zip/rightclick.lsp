;;; ----------------- RIGHTCLICK ------------------------
	(defun fx:RIGHTCLICK (lItems lXY / MYFORM Ok X Y MENUITEMS 
							MouseMove 
							c:dclCancelClose
							c:dclCancelClicked
							c:dclLbl0Clicked
							c:dclLbl1Clicked
							c:dclLbl2Clicked
							c:dclLbl0MouseMove
							c:dclLbl1MouseMove
							c:dclLbl2MouseMove
							c:dclCancelMouseMove
							c:dclInitialize
							)
		 ; lItems is list of menu items (we will add Cancel at the bottom)
		 ; lXY is the X Y desired to display
		 ; displays an r/c menu of list of item labels desired,
		 ; returns the item selected
		 ; opendcl, had to be called by opendcl
		 ; MENUITEMS is how many items are in the menu,
		 ; so we can easily add another row and it will auto-adjust for existing calls
		 ;-------------------------------------
		(defun MouseMove (x / i)
			(setq i 0)
			(while (< i MENUITEMS) ; note menuitems is 1-based, i is 0-based
				(dcl_Control_SetVisible 
					(eval (read (strcat MYFORM "_frm" (itoa i))))
					(and (= i x) (nth i lItems)) ; on if our guy, off otherwise (and make sure an option)
				) ; setvisible
			(setq i (1+ i))
			) ; while
			 ; and our cancel item
			(dcl_Control_SetVisible (eval (read (strcat MYFORM "_frmCancel")))
				(> x (1- MENUITEMS)) ; menuitems is 1-based, x is 0-based
			) ; setvisible
		) ; MouseMove
		 ;-------------------------------------
		(defun c:dclCancelClose (reason)
			(zerop reason)
		) ; CancelClose
		 ;-------------------------------------
		(defun c:dclLbl0Clicked ()
			(dcl_Form_Close (eval (read MYFORM)) (+ 0 10))
		) ; Lbl0Clicked
		 ;-------------------------------------
		(defun c:dclLbl1Clicked ()
			(dcl_Form_Close (eval (read MYFORM)) (+ 1 10))
		) ; Lbl1Clicked
		 ;-------------------------------------
		(defun c:dclLbl2Clicked ()
			(dcl_Form_Close (eval (read MYFORM)) (+ 2 10))
		) ; Lbl2Clicked
		 ;-------------------------------------
		(defun c:dclCancelClicked ()
			(dcl_Form_Close (eval (read MYFORM)) _ODCL_CANCEL)
		) ; CancelClicked
		 ;-------------------------------------
		(defun c:dclLbl0MouseMove (Flags X Y /)
			(MouseMove 0)
		) ; Lbl0MouseMove
		 ;-------------------------------------
		(defun c:dclLbl1MouseMove (Flags X Y /)
			(MouseMove 1)
		) ; Lbl1MouseMove
		 ;-------------------------------------
		(defun c:dclLbl2MouseMove (Flags X Y /)
			(MouseMove 2)
		) ; Lbl2MouseMove
		 ;-------------------------------------
		(defun c:dclCancelMouseMove (Flags X Y /)
			(MouseMove MENUITEMS)
		) ; CancelMouseMove
		 ;-------------------------------------
		(defun c:dclInitialize (/ i)
			(setq i 0)
			(while (< i MENUITEMS)
				(if (nth i lItems)
					(dcl_Control_SetCaption (eval (read (strcat MYFORM "_lbl" (itoa i)))) (nth i lItems))
					 ; otherwise, empty entry here
					(dcl_Control_SetCaption (eval (read (strcat MYFORM "_lbl" (itoa i)))) "")
				) ; if
			(setq i (1+ i))
			) ; while
		) ; Initialize
		 ;-------------------------------------
		(setq MYFORM "rightclick_rightclick"
			X (car lXY)
			Y (cadr lXY)
			MENUITEMS 3
			Ok (dcl_form_show (eval (read MYFORM)) X Y)
		) ; setq
		(if (/= Ok _ODCL_CANCEL) ; then it was our 10+ nth val
			(nth (- Ok 10) lItems)
		) ; if
	) ; RIGHTCLICK
;;; -----------------------------------------------------
