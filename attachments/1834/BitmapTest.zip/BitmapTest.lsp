(defun c:FlexColorDialog_Form1_OnInitialize (/)
  (dcl_PictureBox_LoadPictureFile BitmapTest_Form1_PictureBox1 (nth currentImageIndex imageList) T)
)

(defun c:FlexColorDialog_Form1_BtnNext_OnClicked (/)
  (setq currentImageIndex
    (rem
      (1+ currentImageIndex)
      (length imageList)
    )
  )
  (dcl_PictureBox_LoadPictureFile BitmapTest_Form1_PictureBox1 (nth currentImageIndex imageList) T)
)

(defun c:FlexColorDialog_Form1_BtnCancel_OnClicked (/)
  (dcl_Form_Close BitmapTest_Form1)
)

(defun c:BitmapTest ( / currentImageIndex imageList)
  (setvar 'cmdecho 0)
  (command "OPENDCL")
  (setvar 'cmdecho 1)
  (setq imageList
    '("1.png" "2.png" "3.png")
  )
  (setq currentImageIndex 0)
  (dcl_Project_Load "BitmapTest" T)
  (dcl_Form_Show BitmapTest_Form1)
  (princ)
)



