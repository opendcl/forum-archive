// Reopens the current drawing
// Many thanks to Kean Walmsley for his Blog
// http://through-the-interface.typepad.com/through_the_interface/2007/03/closing_all_ope.html

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.ApplicationServices;
using acadApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace ReOpen
{
    public class ReOpen
    {
        // Define AutoLISP function 
        [LispFunction("reload")]
        public void fun_reload()
        {
            AcadClose();    
        }

        [CommandMethod("reload", CommandFlags.Session)]

        public void cmd_reload()
        {
            AcadClose();
        }


        private string AcadClose()
        {
            DocumentCollection oDocs = acadApp.DocumentManager;
            Document oDoc = oDocs.MdiActiveDocument;

            string strCurrentFile = oDoc.Name;

            if (oDoc.IsReadOnly)
            {
                oDoc.CloseAndDiscard();
            }
            else
            {
                int isModified = System.Convert.ToInt32(acadApp.GetSystemVariable("DBMOD"));

                // No need to save if not modified
                if (isModified == 0)
                {
                    oDoc.CloseAndDiscard();
                }
                else
                {
                    int intReturn = System.Convert.ToInt32(MessageBox.Show("Do you want to save changes to " + strCurrentFile + "?", "Reopen current drawing", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1));

                    switch (intReturn)
                    {
                        case 6:
                            // this may save the drawing at strange places, espeacially if it wasn't saved before
                            // oDoc.Save(); // Does not work, not implemented yet (http://discussion.autodesk.com/forums/message.jspa?messageID=6110668)
                            oDoc.CloseAndSave(strCurrentFile);
                            break;
                        case 7:
                            oDoc.CloseAndDiscard();
                            break;
                        default:
                            strCurrentFile = "";
                            break;
                    }
                }
            }

            if (strCurrentFile != "")
            {
                try
                {
                    oDocs.Open(strCurrentFile,false);
                }
                catch (InvalidCastException e)
                {
                    throw (e);    // Rethrowing exception e
                }
            }

            return strCurrentFile;
        }
    }
}
