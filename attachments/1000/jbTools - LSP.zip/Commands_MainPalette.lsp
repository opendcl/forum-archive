;;;							;
;;;	Layer Commands					;
;;;	include files:					;
;;;	Palette_Main				;
;;;;(dcl_Form_Show Palette_Main)

(vl-load-com)

(if (not (vl-bb-ref 'kbMainPalette))
  (vl-bb-set
    'kbMainPalette
    (dcl_project_import
      '("YWt6A8YyAQCbFTujBuKTQ3XqKrvryeVvZG95LncAXFOVee0eeGRu7OJO8oY9ru8xWpjdTbLK3L05"
"Zj/2tB064t735tYPqtJaOc3l4lpsqQujYiNEujscBPO3ZLM5aksv8eeWtrdcd2CgoAWVA9SUwwDh"
"l5DnYJKUsQUrC9WUKKvDyRAroynRqEIW/ItlrHYzrnjTrvDhKGZyfrFzf2Y0SWYDjGoW/xhGbQGt"
"XnUtHnwyu4E3ZkR/WJ0DaJFZHiJjvS6mCnLn+oFT5o8qwhW8jvJWsNpi5U4YT/gwvyrT4h1V2NDN"
"LKkftBcGORdWk3r64/bBcoAtAK1uWPVHMv9act0ybfaWn4b9T+40Ht6bTtQYUNgmfLVey3U4p59o"
"PhRgqqY/6j0UQyGmw/sG2OD6vT4M12PQ4Z85x44xnyMULtw4/4FxSeCDgdCHYa2C8RSAJR72LWu8"
"meHq1HPHZGUWf1K5MWXS/KpR6iY28wkNhf4MJbNjtbYdgpa7jlcuhYNMzmWVTMZ2gbG8xpvmDVXa"
"qFcXQWTgCGjYInJNj6nw39VP8N4kXhtURz+UW7PBOI9hYSCsh4YlvNtuqmwmOYYANbWLSLMB45QZ"
"XERsUlxEK1ncqnxYnocmtDRSH/tRT1tfmwqiOxCtbTvacKl2E/k4JrXqnPDm9TvbjwlbKNtzQRcS"
"sEjGPF/GWfaelEv8QjhVya+LkVmBJ9Dhd5Qmc9H1y4pZvE6lAeb7pWIS9Mv2qTS4zqOUpitqSYIC"
"JvTzzWKdpE+o+5qmXasmlLobhsX8X04AljLSm3zyDzfk5IB88iH17rXTDCxNPxvMzw76/N3xNbOu"
"pEWT1+mZ6UTWy7NXJKUiloQNqmlpxgD44d1PjSJTAMhoceSOrqeHSnNh98OBOIBo87qlYgb4NSPT"
"h+lEl22F1vPoFY8pF4DdHtbtweck0uhIyng0QCrqUlH/J1Wu3j39uecGE5s/G3SYXywYT+lYWcnX"
"QoYyuMqtBt7nspvLHvAZ3PYu+eLaomv3YC64+7pJjvCfFRKGMZSs28hw+csHMqKTsmDTrn6pzMol"
"MH2pbzQt8XHo9r8HxwwDd6iAFF/vYah2mTnkgbnkgfkbWMoly4KBlMooPB2yek28RSSEEBmqaoDt"
"y4qRxIYOAvZS6er8YDwh7JN64GTScLQUndnIF6yUWWRpefJykvFETIKqu5TR+psf5LrtOPDdtwHJ"
"KNBKDCJwlLbP+4Ij0FS8h2PR11ists/+nIHcN1E3BCDhLtuZFi7bWZlRNzG4EdBoQSX18V9TQX1s"
"NYxGnh+3XffzaB5VSb9khmLMJX494Giw7vsM1Mwdx6ePNsWXraKG1CxMbuctKZXEX2ANTE3p7ken"
"ITyYglwmsjcdW1UIrQuYQuQmtJM5J3fj/fI6vMl/p5VENnMpNslQ4i/dmhSxEeRP4XQZozXKggso"
"gMKYYd+HwSbP0jGH2BQiSByo6Tq/d5qB6pVB6IIZFJKgIZJRz4WW+nHF4ZOwFmbRTohhk7AYZgDs"
"KNG3X83C8ljw2BaXfbq7m9709U8uojIWeofZFYa4bmER/1tAVrsOdI8ymDlu3fWb9xUPOKT0sqKw"
"MjDte5RHEwLRQsiop0ZEpY7UKPOoo2ylouaO8t65tG2ADY8BR0ildBLOSkipJFgMw1f1H1L4UX8d"
"T18DIrVJ8u9auDY9juqBlfecuDuIuV6SQjb6M1UrILxga0r8K/dlWAf3hZY4WJbVzhdoFRUolJSo"
"3z6sDT5blzguN+Rky2bsGIIc7ooo7irDJHSP1gTddLcUO7P1MFyBrjY6KWVmAH7Wc+3fzKp48PHf"
"SI5SOVzDZUsXtNpqCX/LNss/5VMq4BpiHqRCzYhGbuP34trPiJ+6pI0v7Rado+UIaMRPiCuwX+wH"
"sYvhOY8FI0HTjNoEImxjem/ailbzuh02KfBBO705XI+nA9JOTjeV/cMwTAGNp3jdYjksLp/7lFLR"
"E9A87yuCPMsBIKvrz+zQ8gsGK+GALRdwVcL1MH0mrpSpYC7n7rn3/qvR0f5x7dSdrG9Ub9ifYiDE"
"ISTqiLEG6e7n1yM8CO8GJAVIzHc3rccm+WgDYdfaddU9k9ysMB99D0eLAC539IlQfHb0g796Ky8F"
"Y9Kd1QyHig7HYjo4K7eS67Jrw4XjDgjBJU/Q553YXYLnhue4hZ4aDuu7sXry5fjjpLIbU5hjjiiC"
"IfJHqA85MT83Kpyjka8L9pc71nnIzFPxFVwMcGwmJY4ghlm9NkcEsCvMUNe8z9C6dDnXuHkjn1aL"
"CCVV1p29kV4GApaRGzvUwc3StrV/4Bu73wtSCqgetSD20jvVTvmOXBwxtlyci+vaNzX6MjW8P/X9"
"C95sDHAqPBsG904HTy5csrNPd+2VJ3ofbABfhb45bh+0DKMgaEK6KQw8WaiA01w4xocyLRnPK7pM"
"SMAS15oDoM57JaARUp38U73p/kN5WQK453QkzhvBRDDjRu2zyDcrbCU5F1reGBnR+kh+zTIcF/ui"
"6E4nt9zaYyovvB0QbwW6OkVbp11YdqBdiM2BLOfWZoXRvEcr67AMpQFz6OXAbGsuWJhMpAUT/R57"
"6gkgfObtjVHdw+kd8jc1sMLRA/KRRkGxbEUcqlwo5SayoM5A8CLp9k5w8qw2k2bTZ9oQnPcO/gS7"
"neiqkpWEJsNcgmLD4YkgQwSBNhSIzYY38kjVj+nOquzydzTJR+GLlKu9m7MGTxkRUf+bWL2JvwhC"
"Fa5sN474srsk9TZav1gVbDfS8DdsklH8WpYQ3jOSYmyYQzgBbOg5/kg1adCkvd5Fr7UMubWYrxfC"
"yUu+WEgJE1PejWN0krYlMWxFyP608EJuab/wQq65HrnpvuyuKk+g8dOJWxHJuRpvx/5JyiRfi1vz"
"AgoMqdm0IVBPRSIoGIjGIrXBN41JFYAws2FIa8FRGhQAF54qAzyGol7GgXiw2kM+xxyod21vSRWP"
"26y7SRSHChYAN/oC/IKQHfDWNdlIxs+6/c9Li+U82Jr4KJXZSgH+mLBVBOz+FKiKe2hGGypf4xeK"
"RtVOIWXhNyBl4eY4V08S/LDeWO4S/FDZhsPkwWET/MYC17VYi8+o0dICYjtf4OvxH9y1JItL8eyw"
"tPn3fKxWrNA79CYXZwhwuocHQ9Zavo2TZo0NIGItx4IdlP2Mk/IB5LEfzlkcSn7aJ1PNmTlKTi6m"
"LMLF5J9p1RMlHw0AM3TiYkAuBPfMxAIovpTsDJ7bG0FtwDfeZMNpHbxp6inLCVQEOeOfhR854ynA"
"Wv+3RZp/fK1+CzIDdPyr3DSmL9EWBd5amUhjAwuS2a1T5IZ+2PfiCHyF2Q93rUZKtc8qAPjxGOS2"
"20idgeqs4fhPxHA19xJxKpvZcf37NCLN0ZZ6KmPadNZu/4g+Z6Ng1hQhvTEaNxKGetYSGBTVg4MT"
"IY1aBqbUnHdBomBWnRFxip/NSWfpjmdLQFqIWPU+G9MxF9K7GylhUCqDG0g3jRmytCejcMl5tGrI"
"eZTDbLQSLFj1a/hR/Ty0ZRNhDPXrxlge+/fZ1P5oHrg+Bd4yq2DWypQeSgXeMuZDrn4tVrUVwQri"
"0sCuz8gVByw09LIGofgie9kp+owGViRITw9xy1T5bCddkB10b4lUcCP0Q8eiQBCadPP28JIZqzIr"
"u1j48TuvlCdHtCfyY57198os5CLhlrjNKzFnMJ1AeLROoYTHWHSKh+sAnrQ3ZDXi38w+7iy72HFs"
"9Rg1T4A2WSSJGLCa8jkSg5pBYPtmieswwAGoVaExrtnZYVgNRyO4sXzr/lCSeWdBrqrxjg2/TT8F"
"y+vNib+AlCDcjukJkV28NDULNSCPcZrNZRRGyTfCnTSRYNadqnqhvBFRbgXLZ4IynmqKaP13Zklj"
"kVglBcnK+TUmMvuvw6XVYxe9BRicvZRueZEywvqNDlz7Ro2OxV/84Gse38lxKvCZjR/0JkVQNJGP"
"oQFlP/PQwGvb77PCKF0pybzkLJC4zy8Ce5C4CzzOiLwGNaOAWf4+HYH93giF467Jo7B9qT6qIDaq"
"jFqZCuEtpNneVFCgxDxI9GkkugRoiUpzQbMP8ZGqi+Y5vz3gywzv0CfaIwYhbhnRUkhanCJ1YNOa"
"GsmvrELo2Q8qIbtt8ljXCOG/WCN34TtnzvqzODvSolxMr0F9VK+R/JzKZdDZQJlFy4mksVSOTjuW"
"jWqvNrApcawJlnjGIJ3OWZEWB6YNasvro0CqZBM2CZsbs98IDxfZvjQeOejDbEWM2jwcOTw2Hbkt"
"GgjKGYYNxxCpjyTRI0HlX7kdpkwYJStC4yBqPQwzhO5fl/d/819BYLDuHzqI3x84tP8JykJNg93W"
"45I9ifoUKZ+o8JJhfqjwKXz6J0XgGKV00HyJH3UrwcinJlL99blMEsgRy8Qzpt/iL5eVeeF2GaYO"
"PNLQXXrORpHgBCbiuaWHMi31BwMYZ9EoeWARZj/G+Jsmk9f0AHbdwboWovut1X+8aDBBGO2c63BP"
"0M0IxRkfNm0xNDY62NuX91QYd8z3KeyW6iwAkQ77dy35twdpp72aXfdbaZwOrBzDRjqqUf67QWiw"
"nL+HK2fCtJ6eGw6gsROqZkj+v9F+678D8o5AUWV/9pMwBFYL982S5RiM7afntgTbS5/fKTtv0tUd"
"y1Ycv6jPupQ4n/kgi0yqQstJvSrUho4BwbxPRMWxGoRuMsHURGv+3ODCIHRU942swDScjRpsMR2N"
"sb/xXtTVA9h71TQ6rIRWlpinQH72JGWvsPZJ3GtYj5S2aE63HpiJqUGYJFl+xu2r1J4uennRdzb8"
"/UntfHq5K950cOFdZRjiG/MNiMaZGxQLkx5bZaWnfNw3bXW8WlHzgSc2jdzcbn7IfNP133Rpd2/q"
"oh7c0/T8fi+eAfB1kWytpLMLDneAyY4ObE5vdwNVNg4Qq2BUl0oaVWJk3EiQDJME/s6bpPt10/Mx"
"BWWqq1uqQ2YFlQlQ7crDmTxEpWT5+ndUdZwiVCklzYvKu2hFpvymIbU1zbbcAmlVKKyULI613vQb"
"oGGVvdno6pd5B3T2cpEU/VXs1cR9InFUP81Qbj6utT5blrW/Pa65Uyo2xq4WkQi91LShG/ZO5Hpv"
"JAtKd2aRly99UY1gH/GuWorUdAGGcAF+rVB/dgW3pQ8ILfU7ULwFdxFfyEx/hbOV9S2txzCbG6Qt"
"3Nf+RP8r50v+J5cDASAYYzATx7ZsATM/FIfXnwOc4THLKdSFfAjCWnQHYT5s+8Ixbl50J6HvOl/1"
"MCtqMOK92gdk1b4V74bQu9UT9eL4jSanEB91dSW7WJyzJNEnE+yoRRLldF9GUdImv5fOiTlWugFS"
"4PHLETxj2URoVXq2USbrdu4pn312znMqfJq7ROt+uaUz45i5gKSvqbSa2BFo0+xoougnWdbETb1/"
"zeJoH+KIXcCU9i4e4tjZvDfQB+F0GcXCe6j0/MWOmwdcQoSNt3HuAX5C4bLxkjUShEKHNYUCDBRA"
"yiXyNs3A6M6Z69mtgg5HALqMMXisEtk4UdATC/BH6GkJKF/lpnLR6Yt3No2XC1UHWwBzhbGYEBAb"
"1qxRng71+WeZuG5yse/BzPFcluEt4pYvS0ToswU+YhHxszyEJrNVUoiXW7SYFJfw9B2Gfw4qogb2"
"WWQCqQo1BipivZXcPWt7rZg15RuAHD6RGB+ixaJvdoy1SHTng8RFkQ8wTUdgnHd88GG+ubXDIYCd"
"m1xCiG2yqOsN6Pdd3PBd4cH2rKnzSm9LQhCleplZpBho4SavAaQfGy4v6ujUelRUn07r+f9PMqN2"
"fRDm5Er1KT2S3R4imDQllWMgRW+rGhJY0eKmJeOApfGMrgpgPp5FtcYwT/hYYLQ0j9ijDygYwNF2"
"5Kzp0XbkM93LivReIJXpIG8KWrvpjms/YmGdXr4nfjvj3Z3VI4qYXj78XivZ/uvnXjOHF7ic0qL9"
"jdXQIyopzZMG98fI/rQi6e1BHk/vuW73h5j+ORjxzRvQgJrCU/vlJgxRq5wqVyAXdfZwPQHqPEJy"
"A8oD8rUsugFLIF3MC3r7VDTQK5jQTEkG54U/Lufl50v+xxF+68fZ//nHMeu3L84G5by4yB/Q9mX+"
"MjBXMNpusc8/ywCxnOmb1rq5vj3+ADlBKr7iXJJuOqDi7DbuSdFabDX91MKPIjRc/eNuMngi0Wxk"
"h481NnimTzxrA4CkXrATTKBTGEDfgpYjJ+oAVMFpFUyYxWatr4cVLU7A8I2zjDcSs05vneWPCViA"
"WJ+izamRtJwX1aHFzFiNIGEz47aE6ljiiqC526hEFguNx1Y9Tn1esm7SAH9IkGuobe7KttIRP1HJ"
"MOluWB+Acfanpa+IciFDv0+Tp8NskTxvmUwq5BM6ogkLO1me1OBmHhaYgcSx3TuFyJ0GpbjUcS8v"
"bVEk0NJ0eVaUJ/tzfh+xVGKRCcqyMkZl90ZTCzXkZ7yT5jStUp0whdzvIuvjfaangUs6QqD1vx97"
"djUdRHM85k4GcO3XzAqiHTAQfHZFmBr6oIIX231U4Add8rkvd9K0vn9ykgGupU+qwBz7L8L6/Urj"
"Gw5QyI7slA1lRIVMhbtOKKB2bhjSAvzCwjXdqjQSDCzM0Ru74pRfCTKkl+R0Kc09MSP2NAgr2HAe"
"FIHdo/DsJcnzWQgr+AidW/iYXSRa+ND5HvigelQ9zX4uZwTqsq4ZX5A15gq77e19+gc9sRryPCAr"
"uFO+xsq2NcF6/eBBWe/WOwFzgDiuxVkfVsH/7CK9otcoDwpbxbYElenOhwp6ag74JlNMcg/fcaCa"
"DEe2w+r94BnAeWf4tfZxBDjxYHNZ4g588mVJcDBBgwomxg5fsuNFaWRkZB6EipceIhE8Hd13ofpp"
"vpKwvbBpoPtpoAJtyAKBOTYb6iVoASO+tbCa2zJNZui/znL753xa9Z8nwrccBmi9zdg2qPufI2ag"
"++BQcpFMu3QIYL2NZuC5jkJ4mk+iOsH3AE2xp+Qi9VKAxI7p2SspOFft38QfRpzuP2JMdrJWX3Bn"
"ul/9Rhpu+XKcvhZccGe6X/1GGm75cpy+1l1wZ7pf/UYabvlynO6/fEz2OXiPtk5g2NZgHTzhUIKb"
"jxn0VF1QJ1JC9XsbT61SnLyz/u8nwrdcUCe6++V7j7ZcYCe6XaU7H9gWVLpd9UYab/lSnD4z6TtC"
"zPY9aA+2LcOP4eVutW/hwqvCZ7jWVT0ALUpL6KP7Rgsf3yMmPmmcqvsbCR8aaRisqzsH59xFxhJy"
"uYzFzoJQUuHE1nW1kdwOut91D5ZMM5BIr20nUONO3ZCzXXAHUlHxxptv8ULouSM1Bh5lmm/xQp//"
"a52QuDoHulvxxppv90Jotlr+xppPH2D/jGbuOSL2Uoz6dYg3YA+3LQVOUDpzqnUjMjRYnB5ccFic"
"HlxwWJy+mvpGmm95bQ9Ob/lCnL5a+Ebm9v33Rub2/fdGHqiGvQ66vzpiMrq/OnoyUkHx5+fmrjre"
"EuiEdoWv2kxWEfy3vDeObiIIpxvOGLNkpsoXbaIDiaOOtSGAbGAHmm8Gj7tpH4mQo46EldG9pRHB"
"c5HDiWCSocFhBHDmjp6o07a5uq8yioZNu/tAajqA5jDpYiQ2EazllFFeH8qKwAb+B75C3h2V5WDE"
"r5dnDgy0XkpDCm3C6r8ApvHf4qLy7sDlD+pM7h5d6qEToURnLod51gL2LMDqoJAurwp5EtSP2inC"
"EASfMsWQ+4XRpQsMBMOTo7BzNXEkhH0ImTs2Ecnl5ULKAqtVZDA0ELTvQJdDsBRIAWlfA951NIE6"
"orI0nIKuf9N/gqWtFK+QWSIZfQq189aHo0T1ijEKVZdXoQmh67ZpkoooaOCKLHhygNCbZmBc2glN"
"3s4JIxmE2KmUMZeaBlfPEQTDg6uMM1V1y8v9rbWLiTqFqmHSv7nJg72tJV3mq/CggPEmQLZ+e6fX"
"PgTJgg4Z2wmD2CKBf5DGq8rk1pLVbPCgLygEhfE96mqjo6IA0In3EPshyopetw3vPhMDVUMBxAOs"
"CeWjoxRwVHwfl8MLKG92UaEKOGGFXF1u0wK7V3aK3AJ7f0MDalldruWMG3oELwF7/86KMsWC7dco"
"Xl7bid9Btad6ljv+kQKXQTxtaCh3hKb7i8c+KjYzLdY9sLaVRQDWkiBOw23eS9Cwjt+XIweghYow"
"CksDJgS7i8wCzoC05CDfwRARBHsB8wBaBApMbQKj0yzlamGzu3zwkWSYAKgUc8TU1fioFNrNRtJE"
"LazeDHcPo8NlUcmuiyutYjqp4gdOPykdgzAP4++dVfLL0M4Zbtu5lW7AsKYtVSHzi5zkTZcU5NHk"
"0KD6qYmrpJpsYeZh5gV4m2xDy0PLkWC+Cobf1f9hxBBjGlpWALEmXb+OlburSvO6pdW6i8v5U4EM"
"lYROm6NNCKHUPNPGr4LFx7lKsvNZk+fvvWJJ4Bpyb6nT90NNlgTOKCLhQq5N6NDq4Y6R0UvGi5Y0"
"gHH49gYPg4ixcawLOBC4vyS9wvt+GZbbwTzBP0mDY5XPYNFBhefnZTqpou5GKV2fDWNV0Oad5bim"
"YukI9SoMw7H1/BqF53uCMgVVkaVTnYO0m2/Sy33gicLxgh8FOUkVj9ukNaTWm63fh9vD2kHsgVZA"
"4rsc6Kp4Segg3m6l5pVYcyDJkkrKJEHbh8tdfnVBo9dAwwdvvKbI4g9wbB5itYbWYWFijlsTOViY"
"Zda8N0u8lYNcEiA5VbuJX4hR6aZggMxMke8j0Juh2oflSwHZmHEFNoDA7vmYUdO+TSOWZjsAGbQ6"
"IyJg1yw50aH6g0gLs0tkjXr2L0SH05Y5JloPudgZqRQcS9D+xakzsRFTq3uiI/98M28whT9rMIk8"
"Qq1LI0bPQdAOrGEbV4tXWUTVAjONAUv660i5GtuAHmP8HliOQm8IRs/wg7hLhUvxWwJw8ifYfCFg"
"YYiq6VEVN9I6A1bN9O8uJ/uk0VEnm3OOH+t0yYJ2QfQATEF1PJn/4LP6x8QUMnufcVl4Zi0jfVRn"
"qT2Odi7/+CzfubR5bTOrOlS+yK+Bd72fiCVDGb9bDhBvWStpsNmkVau5gZOGXKAeB3U+pmVSVZCn"
"cuA6ntHrnfk8s8Kp+aMPhc1dwYNEgn5QBoKcyAj+CU7QH5BFKNSrXuhmN/nXmyrc/pXe7k0Cc223"
"1vfybf1y5URTWdT4qXLExLCwH/2WWKsnxTN6ckVefBTJER2uH3muXwKTCAoGYwg+2klGOcRdGY5L"
"q+ec1Z/q+B9eoDkk1jvYcNxo3wEMLdtoH00xD+jRRsc3DccsxiYnu1NEUOCbfdCysrvzgpHlK37m"
"aObtpEJcwhFXL57Dm2i8wTLwRpW0wJjSn735afSMs3mB8UOQhpbrbHcxQxMCUgZqM+1YMff2sb1x"
"QbLlW25PAXqgyBOlfXFCDr/78y+eYQGCj9nhAGSBy1x0ny0hIVF+jtibtNX8jSGK+1F7ap+VbhM6"
"YNWO1SGDdJ8RlqYmdmHn+M/raFMkWhZYynYSAjDjaL0tVkLETx24Tocg90l/hkYmAwuN0zY2hrvl"
"VodpnfbNlla/rA2o0Jng8Yy7f0Nc2n7w4AdOzvgZfs52CUjA/JVWPbRQfnPyS6b7vEW+3JE89VZ4"
"QBxr4lrPlGXDA3TLARaRudu97AH3zdBUaRkH5bAXXM7z0+M+c6D/r5DjZVHCksLPwIdF20V2RUkg"
"gsMWtoG7vSml2QykuZUEvScp6fvNBEn4BI1XK7B9e+GecsM7/TkjCnjX/mJi0d6y/lrAC3o3m42c"
"nRPn/jRHvtZz2K2XEaIHKVZClIeGgaORgY6VyRF3uxm69m+lCYB8ga+Fjh2B96H2w/gNaFnh/of1"
"ESMMPGXaaSkrdBnrtF/PuvtxMxzRLleh9na6fIhz92Blr3uJL35Jh3z9+b/9/x0vNVFW1KFX7kYV"
"FyEOaCqgpPBRcL+2OrnBoo7HFIWKCYV6RZzSG65ZjVL9a3G9jxT/AATMn8MJEDRP8Q41aYmM82kB"
"UWSMAY+Oq4jX4oiPxKCyzdBXaRmL/K3DdMHo03gu+4HOv0XVxvueS9lr6pVVOeKLa0aKmCeDkECT"
"D9+Of6B/f2HVwPnCXbDEQP7NiH8PqED1JSgFRjUm22YguMw7NK8oVxI1HOfsCnTl7Gqgz8ntfSyc"
"oM6cevIfClSp6h8bH6KMb++7+HNc549vWWX9bc5vdSXZoi5o5/3dh6SVqLgsU7DhS00obPrx6zq+"
"OTGMh/t1zoNugMGABSlS0sSQgZmWjkEGhlnmWhA9EwWSj5aOCQDVlaeBt7VfCQKNsDVByR6Ip3OG"
"geP5wFl8f4CTpMvBv+XIa8WOALlNsaS+CVMRxZT7aeChiQEBBZfxAcaE9OiRQopRZvC+4dAFBICZ"
"4L2Bp83JRDsiBLf8oYGQu+AJxLuJu5kBrYq7NTuq4nUBQxauJQ1QApDPWclFo/+hqSAHl9OpIWuh"
"QZEHh/wNsDyeM8mAmIZtAAWIB+qB2CUBk17xh5kBj4q1wYHThpgJQwun2/VOQu8GZe32+gZRK4hQ"
"uoero1GDm7NBwYi0kMhVJJDHgaW/U8ib5QkckfWIp4SePc8EOQL3zRDSDOiBiS6cUtN2IbAMwEGz"
"Q/uOZBnDjIwQvyc1JGl1sOzBSaIOwy16LIDV0ZLoR5WsO3VjNj9lZBnDj6RVTBlfHGTCgruCgYmn"
"GRqwvO4jrMDHPf9wgLYnAQSLa78n9sGyJ6CCCXsM6FHCiTXiy8CcOQ2n82I9gWU48GJNbGMj+6FL"
"bJPqOInqG9sU+9ua76NMSlOeLCjDdMuyHuhH/QMaMNNaDeCNB77BWPztS1CKFEfm7O/yfujtRo5w"
"5gKdPrRJ34e1Nzyfw7B/jURTeXNA3t4cnnXrkDvREY5XKgQOhXoaleUBCoYm8EYbfer9LQJZXt9+"
"IAbPaG/uuspb79eYYtterciBem78MLZGSffJLCiF9YC7UdHt/sp7norAYjCnRP8sV1y6P1gZZeT0"
"Wtgq9CPYlzu4GmVNeVW0urGuO1AwptpX26aODGvKlEV601+eUmf3ght4DjQP1Gg+vjD6zYTan50b"
"TsfLA8WySQH2OADYejjirH+bZRPJjWnIEWlphBJpql2EyI4WxbgM4nMgFU/O+dGFRQWkh4QGsdIn"
"FRRFRYndgaKkpclB8I+ZqKCkp7eppRFpjsmgcM58R8WNiKRfVbLgJLRl0eaV7ktVBDpHVQT49tUt"
"kmQU5+W0pkw4N4puJR/Wk2+ggxg0Bokt/h/Q1tv+pIkFvpI/kYRgbV/Pdyhi1jOfiwPNCGU4Ic2A"
"gx92IUUIkoTgk2bgJhG8/2q8HVwG8GpxcgKwrB2GV97zf1OtgVXnD83USobGUF4BEXWFoHkdpvGG"
"YeyO+2IPqLN/4qsFw/u6L6YJmbEJRCGK5GOUaeMDUf6bWlDCfVijRu6MMxaADOwuBpGpe41ES3lj"
"wA4/O79pVqMZgpFlAgSpQPvNi7FBTALSUQ+02LRk/XwSLQPd3L0FSU91x8C/2aKOq4To3cBvYw+o"
"UxufUqaMKgyNMImlzz0C313posJ98idlLnnAx7j+b2M8Z6CMQrIg+ZfstyoMTXPMt783Cu7SaT0k"
"sF5LihqorU9fvFllqFsZ7VDg4uOa+qgu5pI+V632s8yLwEW47UR1yQtyOIYqjcQaDAzsjNO/UT9I"
"Htwv4u6U7TA+RHs4HcOvP4fZRZAxWNkfb7caRMeXTzCl7qLPSefSvYKhhr3NdgIMdETAzo5Iqu1v"
"gclxvPCDt+MF05HNhdLlYwVPrUMBpgeuSoGLFckTxQd/qUmpj6Q/MIxxaYDnA7ez8b5WTuzNchbC"
"fRV/S/j/jni8AQmRP1W3TQWP5aLK/ZTCzKBmIgGxxDWRJ0MRNQ39r+7KaB7JmkiRQxZbB5hzFLZa"
"Zv0l8hqDw5WYEyenHkpZl6VOtPy5EQxqsiW6oXg8Xve+c4nSmhJ3DCyzwg8ukdCVZLeaqPPOq8aM"
"P90HFTkNOcx/zTueajyo2RWUn4xkhMSOY7fwefM5kcN/X1MSV6UaNUP3h7hvXbhi82lnAI7wcyVh"
"w8nYbWTIIqvOxweUmPjX/WW5qx0zMPsi+R8K8pUSEgqeRey34o/joiiduaEm98YLSvJNmFvfYIVy"
"HmKSHzDvaeFFWHOwk05Oiu/FeR0zb2140OdDUCfhuNKKmWjzDzeCEDDwkGbrSjhbsf0vi+oNzECX"
"fYKBvdkLVw==")
      )
    )
  )

(defun c:Palette_Main_OnInitialize (/)
  (kb:LayerStates_OnInitialize)
  (kb:ImportLayers_OnInitialize)
  (kb:ImportManager_OnInitialize)
  (kb:ADT_OnInitialize)
  (kb:Keynotes_OnInitialize)
)

;throws an exception
(defun c:Palette_Main_OnClosexx (nUpperLeftX nUpperLeftY /)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\Palette_Main"
    "isFloating"
    "false"
    )
  (princ)
  (princ)
  )


(defun c:Palette_Main_OnClose ( /)
  (vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\Palette_Main"
    "isFloating"
    "false"
    )
  (princ)
  (princ)
  )


(defun c:Palette_Main_OnDocActivated (/)
  (if (dcl_Form_IsActive Palette_Main)
    (c:Palette_Main_OnInitialize)
    )
  (princ)
  (princ)
  )

(defun c:Palette_Main_OnEnteringNoDocState (/)
  (if (dcl_Form_IsActive Palette_Main)
    (dcl_form_close Palette_Main)
    )
  (princ)
  (princ)
  )

;;;								;
;;;	Command Interface					;
;;;								;
;;;pgp: kbTools,		*kbTools
(defun c:kbTools (/)
  (if (not (member "Palette" (dcl_GetProjects)))
    (dcl_Project_load "Palette")
    )
  (if dcl_HideErrorMsgBox
    (if	(not (dcl_Form_IsActive Palette_Main))
      (progn
	(vl-registry-write
    "HKEY_CURRENT_USER\\Software\\kbTools2009\\Palette_Main"
    "isFloating"
    "true"
    )
      (dcl_Form_Show Palette_Main)
      ))
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

;;;								;
;;;		Floating Form					;
;;;		Document Opened					;
;;;								;

(defun kb:Palette_Main_IsFloating	(/)
  (if dcl_HideErrorMsgBox
    (if	(=	(vl-registry-read
		  "HKEY_CURRENT_USER\\Software\\kbTools2009\\Palette_Main"

		  "isFloating"
		  )
		"true"
		)
	     
      (c:kbTools)
      )
    (alert "The OpenDCL arx module did not load!")
    )
  (princ)
  (princ)
  )

(kb:Palette_Main_IsFloating)


(princ "\nPalette Commands loaded!")
(princ)
 ;|�Visual LISP� Format Options�
(94 2 4 1 nil "end of " 72 6 0 0 0 T T nil T)
;*** DO NOT add text below the comment! ***|;
