
(defun c:test (/ dclform photo c:dclInitialize)
	(defun c:dclInitialize ()
		(dcl-PictureBox-LoadPictureFile (eval (read (strcat dclform "/PictureBox1"))) photo t)
	) ; initialize

	(setq dclform "test/form1"
		photo (findfile "ALLI-3637.jpg")
	) ; setq

	(command "_.OPENDCL")

	(alert "first, we bring up our dialog and display the image")

	(dcl-project-load "test" t)
	(dcl-form-show (eval (read dclform)))

	(alert "Now let's insert that photo.")

	(command "_.-IMAGE" "_A" photo (list 0 0) "1" "0" (list 100 100))

	(command "_.ZOOM" "_E")
	
	(alert "Now we pull up that dialog again.")
	
	(dcl-form-show (eval (read dclform)))

) ; test
